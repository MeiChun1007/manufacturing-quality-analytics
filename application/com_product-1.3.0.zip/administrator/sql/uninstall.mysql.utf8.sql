DROP TABLE IF EXISTS `#__product_components`;
DROP TABLE IF EXISTS `#__product_catalogs`;
