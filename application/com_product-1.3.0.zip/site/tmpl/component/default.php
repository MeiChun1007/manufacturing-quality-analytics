<?php
/**
 * @version    CVS: 1.0.0
 * @package    Com_Product
 * @author     Mei Chun <qc.yolotech@gmail.com>
 * @copyright  2026 YOLO
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

// No direct access
defined('_JEXEC') or die;

use \Joomla\CMS\HTML\HTMLHelper;
use \Joomla\CMS\Factory;
use \Joomla\CMS\Uri\Uri;
use \Joomla\CMS\Router\Route;
use \Joomla\CMS\Language\Text;
use \Joomla\CMS\Session\Session;
use Joomla\Utilities\ArrayHelper;
use \Joomla\CMS\Layout\LayoutHelper;

$canEdit = Factory::getApplication()->getIdentity()->authorise('core.edit', 'com_product.' . $this->item->id);

if (!$canEdit && Factory::getApplication()->getIdentity()->authorise('core.edit.own', 'com_product' . $this->item->id))
{
	$canEdit = Factory::getApplication()->getIdentity()->id == $this->item->created_by;
}
?>

<div class="item_fields">
<?php if ($this->params->get('show_page_heading')) : ?>
    <div class="page-header">
        <h1> <?php echo $this->escape($this->params->get('page_heading')); ?> </h1>
    </div>
    <?php endif;?>
	<table class="table">
		

		<tr>
			<th><?php echo Text::_('COM_PRODUCT_FORM_LBL_COMPONENT_COMPONENT_NAME'); ?></th>
			<td><?php echo $this->item->component_name; ?></td>
		</tr>

		<tr>
			<th><?php echo Text::_('COM_PRODUCT_FORM_LBL_COMPONENT_CUSTOM_FIELD_1'); ?></th>
			<td><?php echo $this->item->custom_field_1; ?></td>
		</tr>

		<tr>
			<th><?php echo Text::_('COM_PRODUCT_FORM_LBL_COMPONENT_CUSTOM_FIELD_2'); ?></th>
			<td><?php echo $this->item->custom_field_2; ?></td>
		</tr>

		<tr>
			<th><?php echo Text::_('COM_PRODUCT_FORM_LBL_COMPONENT_CUSTOM_FIELD_3'); ?></th>
			<td><?php echo $this->item->custom_field_3; ?></td>
		</tr>

		<tr>
			<th><?php echo Text::_('COM_PRODUCT_FORM_LBL_COMPONENT_CUSTOM_FIELD_4'); ?></th>
			<td><?php echo $this->item->custom_field_4; ?></td>
		</tr>

		<tr>
			<th><?php echo Text::_('COM_PRODUCT_FORM_LBL_COMPONENT_CUSTOM_FIELD_5'); ?></th>
			<td><?php echo $this->item->custom_field_5; ?></td>
		</tr>

	</table>

</div>

<?php $canCheckin = Factory::getApplication()->getIdentity()->authorise('core.manage', 'com_product.' . $this->item->id) || $this->item->checked_out == Factory::getApplication()->getIdentity()->id; ?>
	<?php if($canEdit && $this->item->checked_out == 0): ?>

	<a class="btn btn-outline-primary" href="<?php echo Route::_('index.php?option=com_product&task=component.edit&id='.$this->item->id); ?>"><?php echo Text::_("COM_PRODUCT_EDIT_ITEM"); ?></a>
	<?php elseif($canCheckin && $this->item->checked_out > 0) : ?>
	<a class="btn btn-outline-primary" href="<?php echo Route::_('index.php?option=com_product&task=component.checkin&id=' . $this->item->id .'&'. Session::getFormToken() .'=1'); ?>"><?php echo Text::_("JLIB_HTML_CHECKIN"); ?></a>

<?php endif; ?>

<?php if (Factory::getApplication()->getIdentity()->authorise('core.delete','com_product.component.'.$this->item->id)) : ?>

	<a class="btn btn-danger" rel="noopener noreferrer" href="#deleteModal" role="button" data-bs-toggle="modal">
		<?php echo Text::_("COM_PRODUCT_DELETE_ITEM"); ?>
	</a>

	<?php echo HTMLHelper::_(
                                    'bootstrap.renderModal',
                                    'deleteModal',
                                    array(
                                        'title'  => Text::_('COM_PRODUCT_DELETE_ITEM'),
                                        'height' => '50%',
                                        'width'  => '20%',
                                        
                                        'modalWidth'  => '50',
                                        'bodyHeight'  => '100',
                                        'footer' => '<button class="btn btn-outline-primary" data-bs-dismiss="modal">Close</button><a href="' . Route::_('index.php?option=com_product&task=component.remove&id=' . $this->item->id, false, 2) .'" class="btn btn-danger">' . Text::_('COM_PRODUCT_DELETE_ITEM') .'</a>'
                                    ),
                                    Text::sprintf('COM_PRODUCT_DELETE_CONFIRM', $this->item->id)
                                ); ?>

<?php endif; ?>