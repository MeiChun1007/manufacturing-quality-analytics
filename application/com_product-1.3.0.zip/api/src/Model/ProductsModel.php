<?php

/**
 * @package    Com_Product
 * @copyright  2026 YOLO
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace Product\Component\Product\Api\Model;

\defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\MVC\Model\BaseDatabaseModel;
use Joomla\Database\DatabaseInterface;

class ProductsModel extends BaseDatabaseModel
{
	/**
	 * Every row (all states, so ids stay consistent) of both master tables.
	 *
	 * @return  array  ['components' => [...], 'catalogs' => [...]]
	 */
	public function export(): array
	{
		$db = Factory::getContainer()->get(DatabaseInterface::class);

		return [
			'components' => $this->allRows($db, '#__product_components'),
			'catalogs'   => $this->allRows($db, '#__product_catalogs'),
		];
	}

	private function allRows(DatabaseInterface $db, string $table): array
	{
		$db->setQuery(
			$db->getQuery(true)
				->select('*')
				->from($db->quoteName($table))
				->order($db->quoteName('id') . ' ASC')
		);

		return $db->loadAssocList() ?: [];
	}
}
