<?php

/**
 * @package    Com_Product
 * @copyright  2026 YOLO
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace Product\Component\Product\Api\Controller;

\defined('_JEXEC') or die;

use Joomla\CMS\MVC\Controller\BaseController;

/**
 * Read-only: GET /api/index.php/v1/products
 * Returns the product master data: components (parts) and catalogs (models).
 */
class ProductsController extends BaseController
{
	public function displayList()
	{
		$user = $this->app->getIdentity();

		if (!$user || $user->guest || !$user->authorise('core.manage', 'com_product')) {
			$this->respond(['errors' => [['title' => 'Forbidden']]], 403);
		}

		try {
			$model = $this->factory->createModel('Products', 'Api', ['ignore_request' => true]);
			$data  = $model->export();
		} catch (\Throwable $e) {
			$this->respond(['errors' => [['title' => 'Export failed', 'detail' => $e->getMessage()]]], 500);
		}

		$this->respond([
			'data' => $data,
			'meta' => [
				'components' => count($data['components']),
				'catalogs'   => count($data['catalogs']),
			],
		]);
	}

	protected function respond(array $payload, int $status = 200): void
	{
		$this->app->setHeader('status', (string) $status, true);
		$this->app->setHeader('Content-Type', 'application/json; charset=utf-8', true);
		$this->app->sendHeaders();

		echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

		$this->app->close();
	}
}
