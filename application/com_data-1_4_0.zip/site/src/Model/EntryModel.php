<?php

/**
 * @version    CVS: 1.0.0
 * @package    Com_Data
 * @author     Mei Chun <qc.yolotech@gmail.com>
 * @copyright  2026 YOLO
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace Data\Component\Data\Site\Model;
// No direct access.
defined('_JEXEC') or die;

use \Joomla\CMS\Factory;
use \Joomla\Utilities\ArrayHelper;
use \Joomla\CMS\Language\Text;
use \Joomla\CMS\Table\Table;
use \Joomla\CMS\MVC\Model\ItemModel;
use \Joomla\CMS\Helper\TagsHelper;
use \Joomla\CMS\Object\CMSObject;
use \Joomla\CMS\User\UserFactoryInterface;
use \Data\Component\Data\Site\Helper\DataHelper;
use \Joomla\Database\DatabaseInterface;

/**
 * Data model.
 *
 * @since  1.0.0
 */
class EntryModel extends ItemModel
{
	public $_item;





	/**
	 * Method to auto-populate the model state.
	 *
	 * Note. Calling getState in this method will result in recursion.
	 *
	 * @return  void
	 *
	 * @since   1.0.0
	 *
	 * @throws Exception
	 */
	protected function populateState()
	{
		$app  = Factory::getApplication('com_data');
		$user = $app->getIdentity();

		// Check published state
		if ((!$user->authorise('core.edit.state', 'com_data')) && (!$user->authorise('core.edit', 'com_data'))) {
			$this->setState('filter.published', 1);
			$this->setState('filter.archived', 2);
		}

		// Load state from the request userState on edit or from the passed variable on default
		if (Factory::getApplication()->input->get('layout') == 'edit') {
			$id = Factory::getApplication()->getUserState('com_data.edit.entry.id');
		} else {
			$id = Factory::getApplication()->input->get('id');
			Factory::getApplication()->setUserState('com_data.edit.entry.id', $id);
		}

		$this->setState('entry.id', $id);

		// Load the parameters.
		$params       = $app->getParams();
		$params_array = $params->toArray();

		if (isset($params_array['item_id'])) {
			$this->setState('entry.id', $params_array['item_id']);
		}

		$this->setState('params', $params);
	}

	/**
	 * Method to get an object.
	 *
	 * @param   integer $id The id of the object to get.
	 *
	 * @return  mixed    Object on success, false on failure.
	 *
	 * @throws Exception
	 */
	public function getItem($id = null)
	{
		if ($this->_item === null) {
			$this->_item = false;

			if (empty($id)) {
				$id = $this->getState('entry.id');
			}

			// Get a level row instance.
			$table = $this->getTable();

			// Attempt to load the row.
			if ($table && $table->load($id)) {


				// Check published state.
				if ($published = $this->getState('filter.published')) {
					if (isset($table->state) && $table->state != $published) {
						throw new \Exception(Text::_('COM_DATA_ITEM_NOT_LOADED'), 403);
					}
				}

				// Convert the Table to a clean CMSObject.
				$properties  = $table->getProperties(1);
				$this->_item = ArrayHelper::toObject($properties, CMSObject::class);
			}

			if (empty($this->_item)) {
				throw new \Exception(Text::_('COM_DATA_ITEM_NOT_LOADED'), 404);
			}
		}



		$container = \Joomla\CMS\Factory::getContainer();

		$userFactory = $container->get(UserFactoryInterface::class);

		if (isset($this->_item->created_by)) {
			$user = $userFactory->loadUserById($this->_item->created_by);
			$this->_item->created_by_name = $user->name;
		}

		$container = \Joomla\CMS\Factory::getContainer();

		$userFactory = $container->get(UserFactoryInterface::class);

		if (isset($this->_item->modified_by)) {
			$user = $userFactory->loadUserById($this->_item->modified_by);
			$this->_item->modified_by_name = $user->name;
		}

		if (isset($this->_item->component) && $this->_item->component != '') {
			if (is_object($this->_item->component)) {
				$this->_item->component = ArrayHelper::fromObject($this->_item->component);
			}

			$values = (is_array($this->_item->component)) ? $this->_item->component : explode(',', $this->_item->component);

			$textValue = array();

			foreach ($values as $value) {
				$db    = Factory::getContainer()->get(DatabaseInterface::class);
				$query = $db->getQuery(true)
					->select($db->quoteName('component_name'))
					->from($db->quoteName('#__product_components'))
					->where($db->quoteName('id') . ' = ' . $db->quote((int) $value));

				$db->setQuery($query);
				$results = $db->loadObject();

				if ($results) {
					$textValue[] = $results->component_name;
				}
			}

			$this->_item->component = !empty($textValue) ? implode(', ', $textValue) : $this->_item->component;
		}

		if (isset($this->_item->model) && $this->_item->model != '') {
			if (is_object($this->_item->model)) {
				$this->_item->model = ArrayHelper::fromObject($this->_item->model);
			}

			$values = (is_array($this->_item->model)) ? $this->_item->model : explode(',', $this->_item->model);

			$textValue = array();

			foreach ($values as $value) {
				$db    = Factory::getContainer()->get(DatabaseInterface::class);
				$query = $db->getQuery(true)
					->select($db->quoteName('model_name'))
					->from($db->quoteName('#__product_catalogs'))
					->where($db->quoteName('id') . ' = ' . $db->quote((int) $value));

				$db->setQuery($query);
				$results = $db->loadObject();

				if ($results) {
					$textValue[] = $results->model_name;
				}
			}

			$this->_item->model = !empty($textValue) ? implode(', ', $textValue) : $this->_item->model;
		}

		if (isset($this->_item->vendor) && $this->_item->vendor != '') {
			if (is_object($this->_item->vendor)) {
				$this->_item->vendor = ArrayHelper::fromObject($this->_item->vendor);
			}

			$values = (is_array($this->_item->vendor)) ? $this->_item->vendor : explode(',', $this->_item->vendor);

			$textValue = array();

			foreach ($values as $value) {
				$db    = Factory::getContainer()->get(DatabaseInterface::class);
				$query = $db->getQuery(true)
					->select($db->quoteName('name'))
					->from($db->quoteName('#__users'))
					->where($db->quoteName('id') . ' = ' . $db->quote((int) $value));

				$db->setQuery($query);
				$results = $db->loadObject();

				if ($results) {
					$textValue[] = $results->name;
				}
			}

			$this->_item->vendor = !empty($textValue) ? implode(', ', $textValue) : $this->_item->vendor;
		}

		// Resolve remark IDs into readable remark text (from #__vendor_remarks)
		if (isset($this->_item->remark) && $this->_item->remark != '') {
			if (is_object($this->_item->remark)) {
				$this->_item->remark = ArrayHelper::fromObject($this->_item->remark);
			}

			$values = (is_array($this->_item->remark)) ? $this->_item->remark : explode(',', $this->_item->remark);
			$values = array_filter(array_map('intval', $values));

			if (!empty($values)) {
				$db    = Factory::getContainer()->get(DatabaseInterface::class);
				$query = $db->getQuery(true)
					->select($db->quoteName('vr.remark'))
					->from($db->quoteName('#__vendor_details', 'vd'))
					->join('INNER', $db->quoteName('#__vendor_remarks', 'vr') . ' ON ' . $db->quoteName('vr.id') . ' = ' . $db->quoteName('vd.remark'))
					->where($db->quoteName('vd.id') . ' IN (' . implode(',', $values) . ')');

				$db->setQuery($query);
				$textValue = $db->loadColumn();

				$this->_item->remark = !empty($textValue) ? implode(', ', $textValue) : $this->_item->remark;
			}
		}

		// Resolve lot value into its label (0 = Normal, 1 = Resort),
		// keeping the raw value available for conditional checks in the template.
		if (isset($this->_item->lot) && $this->_item->lot !== '') {
			$lotOptions = array(
				'0' => Text::_('COM_DATA_LOT_NORMAL'),
				'1' => Text::_('COM_DATA_LOT_RESORT'),
			);

			$this->_item->lot_raw = $this->_item->lot;
			$this->_item->lot     = $lotOptions[$this->_item->lot] ?? $this->_item->lot;
		}

		// Resolve Resort NC (multiple select, comma-separated ids) into readable NC labels
		if (isset($this->_item->resort_nc) && $this->_item->resort_nc != '') {
			if (is_object($this->_item->resort_nc)) {
				$this->_item->resort_nc = ArrayHelper::fromObject($this->_item->resort_nc);
			}

			$values = (is_array($this->_item->resort_nc)) ? $this->_item->resort_nc : explode(',', $this->_item->resort_nc);
			$values = array_filter(array_map('intval', $values));

			if (!empty($values)) {
				$db    = Factory::getContainer()->get(DatabaseInterface::class);
				$query = $db->getQuery(true)
					->select($db->quoteName('nc'))
					->from($db->quoteName('#__nc_types'))
					->where($db->quoteName('id') . ' IN (' . implode(',', $values) . ')');

				$db->setQuery($query);
				$textValue = $db->loadColumn();

				$this->_item->resort_nc = !empty($textValue) ? implode(', ', $textValue) : $this->_item->resort_nc;
			}
		}

		$container = \Joomla\CMS\Factory::getContainer();

		$userFactory = $container->get(UserFactoryInterface::class);

		if (isset($this->_item->operator)) {
			$user = $userFactory->loadUserById($this->_item->operator);
			$this->_item->operator = $user->name;
		}

		if (isset($this->_item->id)) {
			$db    = Factory::getContainer()->get(DatabaseInterface::class);
			$query = $db->getQuery(true)
				->select($db->quoteName(['nc_type', 'nc_category', 'nc_quantity', 'nc_percentage']))
				->from($db->quoteName('#__data_entry_nc'))
				->where($db->quoteName('entry_id') . ' = ' . (int) $this->_item->id)
				->order($db->quoteName('ordering') . ' ASC, ' . $db->quoteName('id') . ' ASC');

			$db->setQuery($query);

			$this->_item->nc_entries = $db->loadObjectList() ?: array();
		}

		return $this->_item;
	}



	/**
	 * Get an instance of Table class
	 *
	 * @param   string $type   Name of the Table class to get an instance of.
	 * @param   string $prefix Prefix for the table class name. Optional.
	 * @param   array  $config Array of configuration values for the Table object. Optional.
	 *
	 * @return  Table|bool Table if success, false on failure.
	 */
	public function getTable($type = 'Entry', $prefix = 'Administrator', $config = array())
	{
		return parent::getTable($type, $prefix, $config);
	}

	/**
	 * Get the id of an item by alias
	 * @param   string $alias Item alias
	 *
	 * @return  mixed
	 * 
	 * @deprecated  No replacement
	 */
	public function getItemIdByAlias($alias)
	{
		$table      = $this->getTable();
		$properties = $table->getProperties();
		$result     = null;
		$aliasKey   = null;
		if (method_exists($this, 'getAliasFieldNameByView')) {
			$aliasKey   = $this->getAliasFieldNameByView('entry');
		}


		if (key_exists('alias', $properties)) {
			$table->load(array('alias' => $alias));
			$result = $table->id;
		} elseif (isset($aliasKey) && key_exists($aliasKey, $properties)) {
			$table->load(array($aliasKey => $alias));
			$result = $table->id;
		}

		return $result;
	}

	/**
	 * Method to check in an item.
	 *
	 * @param   integer $id The id of the row to check out.
	 *
	 * @return  boolean True on success, false on failure.
	 *
	 * @since   1.0.0
	 */
	public function checkin($id = null)
	{
		// Get the id.
		$id = (!empty($id)) ? $id : (int) $this->getState('entry.id');

		if ($id) {
			// Initialise the table
			$table = $this->getTable();

			// Attempt to check the row in.
			if (method_exists($table, 'checkin')) {
				if (!$table->checkin($id)) {
					return false;
				}
			}
		}

		return true;
	}

	/**
	 * Method to check out an item for editing.
	 *
	 * @param   integer $id The id of the row to check out.
	 *
	 * @return  boolean True on success, false on failure.
	 *
	 * @since   1.0.0
	 */
	public function checkout($id = null)
	{
		// Get the user id.
		$id = (!empty($id)) ? $id : (int) $this->getState('entry.id');


		if ($id) {
			// Initialise the table
			$table = $this->getTable();

			// Get the current user object.
			$user = Factory::getApplication()->getIdentity();

			// Attempt to check the row out.
			if (method_exists($table, 'checkout')) {
				if (!$table->checkout($user->get('id'), $id)) {
					return false;
				}
			}
		}

		return true;
	}

	/**
	 * Publish the element
	 *
	 * @param   int $id    Item id
	 * @param   int $state Publish state
	 *
	 * @return  boolean
	 */
	public function publish($id, $state)
	{
		$table = $this->getTable();

		$table->load($id);
		$table->state = $state;

		return $table->store();
	}

	/**
	 * Method to delete an item
	 *
	 * @param   int $id Element id
	 *
	 * @return  bool
	 */
	public function delete($id)
	{
		$table = $this->getTable();


		return $table->delete($id);
	}
}
