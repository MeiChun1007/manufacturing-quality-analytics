<?php

/**
 * @version    CVS: 1.3.0
 * @package    Com_Data
 * @author     Mei Chun <qc.yolotech@gmail.com>
 * @copyright  2026 YOLO
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace Data\Component\Data\Site\Model;
// No direct access.
defined('_JEXEC') or die;

use \Joomla\CMS\Factory;
use \Joomla\CMS\MVC\Model\BaseDatabaseModel;
use \Joomla\Database\DatabaseInterface;
use \Joomla\CMS\Language\Text;
use \Joomla\CMS\Component\ComponentHelper;


/**
 * Model Summary report: rows are (Part, Model) combinations aggregated over
 * a chosen period - either one ISO week (Monday-Sunday) or one calendar
 * month - built from #__data_entry joined to #__data_entry_nc, with model
 * names resolved from #__product_catalogs.
 *
 * Also powers a "Top N highest NC rate" leaderboard over the same period,
 * with a minimum Total Sort threshold so low-volume (part, model)
 * combinations don't produce misleadingly high NC% rankings.
 *
 * @since  1.3.0
 */
class NcmodelsummaryModel extends BaseDatabaseModel
{
	/** @var string  'week' or 'month' */
	protected $filterPeriodType = 'week';

	/** @var int  Selected calendar/ISO year. */
	protected $filterYear;

	/** @var string  ISO year-week key, e.g. "2026-W30". */
	protected $filterWeek = '';

	/** @var string  "YYYY-MM". */
	protected $filterMonth = '';

	/** @var string  a.component value, or '' for all parts. */
	protected $filterPart = '';

	/** @var  string */
	protected $filterModel = '';

	/** @var int  How many rows the Top NC leaderboard shows. */
	protected $filterTopLimit = 5;

	/** @var  string */
	protected $filterVendor = '';

	/** @var  string */
	protected $filterOperator = '';

	/** @var  string */
	protected $filterLot = '';

	/** @var  string */
	protected $filterRemark = '';

	/**
	 * @var  string  Y-m-d
	 * @since  1.3.0
	 */
	protected $filterDateFrom = '';

	/**
	 * @var  string  Y-m-d
	 * @since  1.3.0
	 */
	protected $filterDateTo = '';

	/**
	 * @var  int  Minimum Total Sort a (part, model) combination must have to
	 *            be eligible for the leaderboard. Not currently exposed as a
	 *            UI filter - fixed here, adjust if your typical batch sizes
	 *            call for a different cutoff.
	 */
	protected $filterMinSort = 100;

	/** @var \DateTime  Start of the resolved period, 00:00:00. */
	protected $periodStart;

	/** @var \DateTime  End of the resolved period, 23:59:59. */
	protected $periodEnd;

	/**
	 * Constructor.
	 *
	 * @param   array  $config  An optional associative array of configuration settings.
	 *
	 * @since   1.3.0
	 */
	public function __construct($config = array())
	{
		parent::__construct($config);

		$this->populateState();
	}

	/**
	 * Read all filters from the request, persist them in user state, and
	 * resolve the selected (or default = current) period into concrete
	 * start/end DateTimes.
	 *
	 * @return  void
	 *
	 * @since   1.3.0
	 */
	protected function populateState()
	{
		$app     = Factory::getApplication();
		$context = 'com_data.modelsummary.';
		$now = Factory::getDate('now', 'Asia/Kuala_Lumpur');

		// --- Clear Filters: wipe stored session state, then fall through to defaults ---
		if ($app->input->getInt('clearfilters', 0) === 1) {
			$keys = array('part', 'model', 'lot', 'remark', 'vendor', 'operator', 'year', 'week', 'period_type', 'top_limit', 'date_from', 'date_to');

			foreach ($keys as $key) {
				$app->setUserState($context . 'filter.' . $key, null);
			}

			$app->input->set('filter_part', null);
			$app->input->set('filter_model', null);
			$app->input->set('filter_vendor', null);
			$app->input->set('filter_operator', null);
			$app->input->set('filter_remark', null);
			$app->input->set('filter_lot', null);
			$app->input->set('filter_year', null);
			$app->input->set('filter_week', null);
			$app->input->set('filter_period_type', null);
			$app->input->set('filter_date_from', null);
			$app->input->set('filter_date_to', null);
			$app->input->set('filter_top_limit', null);
		}

		$defaultTo   = new \DateTime('now');
		$defaultFrom = (clone $defaultTo)->modify('-29 days');

		$this->filterPeriodType = (string) $app->getUserStateFromRequest($context . 'filter.period_type', 'filter_period_type', 'week', 'string');
		$this->filterYear       = (int) $app->getUserStateFromRequest($context . 'filter.year', 'filter_year', '', 'int');
		$this->filterDateFrom   = (string) $app->getUserStateFromRequest($context . 'filter.date_from', 'filter_date_from', $defaultFrom->format('Y-m-d'), 'string');
		$this->filterDateTo     = (string) $app->getUserStateFromRequest($context . 'filter.date_to', 'filter_date_to', $defaultTo->format('Y-m-d'), 'string');
		$this->filterPart       = (string) $app->getUserStateFromRequest($context . 'filter.part', 'filter_part', '', 'string');
		$this->filterTopLimit   = (int) $app->getUserStateFromRequest($context . 'filter.top_limit', 'filter_top_limit', 5, 'int');
		$this->filterVendor  	= (string) $app->getUserStateFromRequest($context . 'filter.vendor', 'filter_vendor', '', 'string');
		$this->filterModel      = (string) $app->getUserStateFromRequest($context . 'filter.model', 'filter_model', '', 'string');
		$this->filterOperator 	= (string) $app->getUserStateFromRequest($context . 'filter.operator', 'filter_operator', '', 'string');
		$this->filterLot		= (string) $app->getUserStateFromRequest($context . 'filter.lot', 'filter_lot', '', 'string');
		$this->filterRemark 	= (string) $app->getUserStateFromRequest($context . 'filter.remark', 'filter_remark', '0', 'string');

		$rawWeek  = (string) $app->getUserStateFromRequest($context . 'filter.week', 'filter_week', '', 'string');
		$rawMonth = (string) $app->getUserStateFromRequest($context . 'filter.month', 'filter_month', '', 'string');

		// Empty (unselected) or explicit 'all' both mean "whole year" - see note above
		// re: this changing the previous "defaults to current week/month" behaviour.
		$this->filterWeek  = $rawWeek === 'all' ? 'all' : (int) $rawWeek;
		$this->filterMonth = $rawMonth === 'all' ? 'all' : (int) $rawMonth;

		if (!in_array($this->filterPeriodType, array('week', 'month', 'custom'), true)) {
			$this->filterPeriodType = 'custom';
		}


		if ($this->filterYear < 2000 || $this->filterYear > 2100) {
			$this->filterYear = (int) $now->format('o');
		}

		if ($this->filterWeek !== 'all' && ($this->filterWeek < 1 || $this->filterWeek > 53)) {
			$this->filterWeek = (int) $now->format('W');
		}

		if ($this->filterMonth !== 'all' && ($this->filterMonth < 1 || $this->filterMonth > 12)) {
			$this->filterMonth = (int) $now->format('n');
		}

		if (!in_array($this->filterTopLimit, array(3, 5, 10, 15, 20), true)) {
			$this->filterTopLimit = 5;
		}

		// Guard against an inverted or malformed custom range - only meaningful
		// when period_type is 'custom', but validated unconditionally so a stale
		// stored value can't cause a bad range if the user switches back to it later.
		if ($this->filterDateFrom === '' || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $this->filterDateFrom)) {
			$this->filterDateFrom = $defaultFrom->format('Y-m-d');
		}

		if ($this->filterDateTo === '' || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $this->filterDateTo)) {
			$this->filterDateTo = $defaultTo->format('Y-m-d');
		}

		if ($this->filterDateFrom > $this->filterDateTo) {
			list($this->filterDateFrom, $this->filterDateTo) = array($this->filterDateTo, $this->filterDateFrom);
		}


		// A preset overrides the working date range for THIS request only - it
		// never overwrites the persisted custom date_from/date_to user state, so
		// switching back to "Custom" later still shows whatever range someone
		// last set there, rather than losing it.

		if ($this->filterPeriodType === 'week') {
			if ($this->filterWeek === 'all') {
				$this->resolveYearPeriod();
			} else {
				$this->resolveWeekPeriod();
			}
			$this->filterDateFrom = $this->periodStart->format('Y-m-d');
			$this->filterDateTo   = $this->periodEnd->format('Y-m-d');
		} elseif ($this->filterPeriodType === 'month') {
			if ($this->filterMonth === 'all') {
				$this->resolveYearPeriod();
			} else {
				$this->resolveMonthPeriod();
			}
			$this->filterDateFrom = $this->periodStart->format('Y-m-d');
			$this->filterDateTo   = $this->periodEnd->format('Y-m-d');
		} else {
			$this->periodStart = new \DateTime($this->filterDateFrom);
			$this->periodEnd   = new \DateTime($this->filterDateTo);
		}

		// --- Default (and, for operator-restricted users, FORCE) the Operator
		// filter to "own account" - keyed off the same viewOwnOperator groups
		// applyPeriodFilters() uses for the actual query-level restriction, so
		// the pre-selected filter and the enforced boundary never drift apart.
		// Super Users are exempt, matching applyPeriodFilters()'s core.admin check.
		$user   = $app->getIdentity();
		$userId = (int) $user->get('id');

		if ($userId > 0) {
			$userGroupIds = array_map('intval', (array) $user->get('groups'));
			$params       = ComponentHelper::getParams('com_data');
			$viewOwnOperatorGroups = array_map('intval', (array) $params->get('viewOwnOperator', []));
			$viewOwnVendorGroups = array_map('intval', (array) $params->get('viewOwnVendor', []));

			$isSuperUser = $user->authorise('core.admin');

			if (!$isSuperUser && !empty(array_intersect($userGroupIds, $viewOwnOperatorGroups))) {
				$this->filterOperator = $userId;
			}

			if (!$isSuperUser && !empty(array_intersect($userGroupIds, $viewOwnVendorGroups))) {
				$this->filterVendor = $userId;
			}
		}
	}

	/**
	 * Resolve the selected (or default = current) ISO week into
	 * Monday 00:00:00 - Sunday 23:59:59.
	 *
	 * @return  void
	 *
	 * @since   1.3.0
	 */
	protected function resolveWeekPeriod()
	{
		$this->periodStart = new \DateTime();
		$this->periodStart->setISODate($this->filterYear, $this->filterWeek, 1)->setTime(0, 0, 0);

		$this->periodEnd = clone $this->periodStart;
		$this->periodEnd->modify('+6 days')->setTime(23, 59, 59);
	}

	/**
	 * Resolve the selected (or default = current) calendar month into
	 * the 1st 00:00:00 - last day 23:59:59.
	 *
	 * @return  void
	 *
	 * @since   1.3.0
	 */
	protected function resolveMonthPeriod()
	{
		$this->periodStart = new \DateTime();
		$this->periodStart->setDate($this->filterYear, $this->filterMonth, 1)->setTime(0, 0, 0);

		$this->periodEnd = clone $this->periodStart;
		$this->periodEnd->modify('last day of this month')->setTime(23, 59, 59);
	}


	/**
	 * Resolve the selected (or default = current) calendar year into
	 * Jan 1 00:00:00 - Dec 31 23:59:59. Used when period_type is 'week' or
	 * 'month' but no specific week/month is selected ('all' or unset).
	 *
	 * @return  void
	 *
	 * @since   1.5.0
	 */
	protected function resolveYearPeriod()
	{
		$this->periodStart = new \DateTime();
		$this->periodStart->setDate($this->filterYear, 1, 1)->setTime(0, 0, 0);

		$this->periodEnd = clone $this->periodStart;
		$this->periodEnd->setDate($this->filterYear, 12, 31)->setTime(23, 59, 59);
	}

	/**
	 * True when the resolved period is "whole year" — i.e. period_type is
	 * 'week'/'month' but the corresponding selector is 'all'.
	 *
	 * @return  boolean
	 *
	 * @since   1.5.0
	 */
	protected function isFullYearPeriod()
	{
		return ($this->filterPeriodType === 'week' && $this->filterWeek === 'all')
			|| ($this->filterPeriodType === 'month' && $this->filterMonth === 'all');
	}


	/**
	 * Split an ISO year-week key ("2026-W30") into [year, week], or [null, null] if empty/invalid.
	 *
	 * @param   string  $key  The ISO year-week key.
	 *
	 * @return  array
	 *
	 * @since   1.3.0
	 */
	protected function parseIsoWeekKey($key)
	{
		if ($key !== '' && preg_match('/^(\d{4})-W(\d{1,2})$/', $key, $m)) {
			return array((int) $m[1], (int) $m[2]);
		}

		return array(null, null);
	}

	/**
	 * The currently active filters, so the view can re-select them in the controls.
	 *
	 * @return  object
	 *
	 * @since   1.3.0
	 */
	public function getActiveFilters()
	{
		return (object) array(
			'period_type'  => $this->filterPeriodType,
			'week'         => $this->filterWeek,
			'month'        => $this->filterMonth,
			'part'         => $this->filterPart,
			'model'       => $this->filterModel,
			'top_limit'    => $this->filterTopLimit,
			'min_sort'     => $this->filterMinSort,
			'period_start' => $this->periodStart->format('Y-m-d'),
			'period_end'   => $this->periodEnd->format('Y-m-d'),
			'vendor'       => $this->filterVendor,
			'operator'    => $this->filterOperator,
			'remark'      => $this->filterRemark,
			'lot'         => $this->filterLot,
			'date_from'    => $this->filterDateFrom,
			'date_to'      => $this->filterDateTo,
		);
	}

	/**
	 * Distinct Part values (a.component), for the "SELECT PART" filter.
	 *
	 * @return  array
	 *
	 * @since   1.3.0
	 */
	public function getPartOptions()
	{
		$db = Factory::getContainer()->get(DatabaseInterface::class);

		$query = $db->getQuery(true)
			->select(
				'DISTINCT ' . $db->quoteName('a.component', 'value') . ', ' .
					$db->quoteName('pc.component_name', 'text')
			)
			->from($db->quoteName('#__data_entry', 'a'))
			->join('INNER', $db->quoteName('#__product_components', 'pc') . ' ON ' . $db->quoteName('pc.id') . ' = ' . $db->quoteName('a.component'))
			->where($db->quoteName('a.component') . ' != ' . $db->quote(''))
			->where($db->quoteName('a.state') . ' = ' . $db->quote(1))
			->order($db->quoteName('pc.component_name') . ' ASC');


		// Apply selected filters, EXCEPT the current Part filter
		$this->applyPeriodFilters($db, $query, 'a', ['part']);

		$db->setQuery($query);

		return $db->loadObjectList() ?: array();
	}

	/**
	 * Distinct list of models available for the Model Selector.
	 *
	 * @return  array
	 *
	 * @since   1.3.0
	 */
	public function getModelOptions()
	{
		$db = Factory::getContainer()->get(DatabaseInterface::class);

		$query = $db->getQuery(true)
			->select(
				'DISTINCT ' . $db->quoteName('pm.id', 'value') . ', ' .
					$db->quoteName('pm.model_name', 'text')
			)
			->from($db->quoteName('#__data_entry', 'a'))
			->join('INNER', $db->quoteName('#__product_catalogs', 'pm') . ' ON ' . $db->quoteName('pm.id') . ' = ' . $db->quoteName('a.model'))
			->where($db->quoteName('a.model') . ' IS NOT NULL')
			->where($db->quoteName('a.state') . ' = 1');

		// Apply selected filters, EXCEPT the current Model filter
		$this->applyPeriodFilters($db, $query, 'a', ['model']);

		$query->order($db->quoteName('pm.model_name') . ' ASC');

		$db->setQuery($query);

		return $db->loadObjectList() ?: array();
	}

	/**
	 * Distinct Remark values (a.lot), for the "SELECT REMARK" filter.
	 *
	 * @return  array
	 *
	 * @since   1.3.0
	 */
	public function getLotOptions()
	{
		$db = Factory::getContainer()->get(DatabaseInterface::class);

		$query = $db->getQuery(true)
			->select(
				'DISTINCT ' . $db->quoteName('vr.id', 'value') . ', ' .
					$db->quoteName('vr.remark', 'text')
			)
			->from($db->quoteName('#__data_entry', 'a'))
			->join('INNER', $db->quoteName('#__vendor_details', 'vd') . ' ON ' . $db->quoteName('vd.id') . ' = ' . $db->quoteName('a.remark'))
			->join('INNER', $db->quoteName('#__vendor_remarks', 'vr') . ' ON ' . $db->quoteName('vr.id') . ' = ' . $db->quoteName('vd.remark'))
			->join('INNER', $db->quoteName('#__users', 'uv') . ' ON ' . $db->quoteName('uv.id') . ' = ' . $db->quoteName('a.vendor'))
			->where($db->quoteName('a.remark') . ' != ' . $db->quote(''))
			->where($db->quoteName('a.state') . ' = ' . $db->quote(1));

		// Apply selected filters, EXCEPT the current Lot filter
		$this->applyPeriodFilters($db, $query, 'a', ['lot']);

		$query->order($db->quoteName('vr.remark') . ' ASC');

		$db->setQuery($query);

		return $db->loadObjectList() ?: array();
	}


	/**
	 * Distinct list of models available for the Vendor Selector.
	 *
	 * @return  array
	 *
	 * @since   1.2.0
	 */
	public function getVendorOptions()
	{
		$db = Factory::getContainer()->get(DatabaseInterface::class);

		$query = $db->getQuery(true)
			->select(
				'DISTINCT ' . $db->quoteName('a.vendor', 'key') . ', ' .
					$db->quoteName('uv.name', 'value')
			)
			->from($db->quoteName('#__data_entry', 'a'))
			->join('INNER', $db->quoteName('#__users', 'uv') . ' ON ' . $db->quoteName('uv.id') . ' = ' . $db->quoteName('a.vendor'))
			->where($db->quoteName('a.state') . ' = 1')
			->order($db->quoteName('uv.name') . ' ASC');

		// Apply selected filters, EXCEPT the current vendor filter
		$this->applyPeriodFilters($db, $query, 'a', ['vendor']);

		$db->setQuery($query);

		return $db->loadObjectList() ?: array();
	}

	/**
	 * Distinct list of operators available for the Operator Selector.
	 *
	 * @return  array
	 *
	 * @since   1.2.0
	 */
	public function getOperatorOptions()
	{
		$db = Factory::getContainer()->get(DatabaseInterface::class);

		$query = $db->getQuery(true)
			->select(
				'DISTINCT ' . $db->quoteName('a.operator', 'key') . ', ' .
					$db->quoteName('uv.name', 'value')
			)
			->from($db->quoteName('#__data_entry', 'a'))
			->join('INNER', $db->quoteName('#__users', 'uv') . ' ON ' . $db->quoteName('uv.id') . ' = ' . $db->quoteName('a.operator'))
			->where($db->quoteName('a.state') . ' = 1')
			->order($db->quoteName('uv.name') . ' ASC');

		// Apply selected filters, EXCEPT the current Vendor filter
		$this->applyPeriodFilters($db, $query, 'a', ['operator']);

		$db->setQuery($query);

		return $db->loadObjectList() ?: array();
	}

	public function getRemarkOptions()
	{
		$remarkOptions = array(
			'0' => Text::_('COM_DATA_LOT_NORMAL'),
			'1' => Text::_('COM_DATA_LOT_RESORT'),
		);

		return $remarkOptions;
	}

	/**
	 * Years with data, newest first. Always includes the current year.
	 *
	 * @return  array  Plain list of ints, e.g. [2027, 2026, 2025]
	 */
	public function getYearOptions()
	{
		$db = Factory::getContainer()->get(DatabaseInterface::class);

		$query = $db->getQuery(true)
			->select('DISTINCT YEAR(' . $db->quoteName('date') . ') AS yr')
			->from($db->quoteName('#__data_entry'))
			->where($db->quoteName('date') . ' IS NOT NULL')
			->order('yr DESC');

		$db->setQuery($query);
		$years = array_map('intval', $db->loadColumn() ?: array());

		$currentYear = (int) (new \DateTime())->format('Y');

		if (!in_array($currentYear, $years, true)) {
			array_unshift($years, $currentYear);
			rsort($years);
		}

		return $years;
	}

	/**
	 * Distinct ISO weeks (Monday-Sunday, derived from the `date` field) available
	 * for the Week Selector, newest first. Always includes the current week.
	 *
	 * @return  array  List of objects: { value: "2026-W30", week: 30, year: 2026, label: "20 Jul - 26 Jul 2026" }
	 *
	 * @since   1.3.0
	 */
	public function getWeekOptions()
	{
		$db = Factory::getContainer()->get(DatabaseInterface::class);

		$query = $db->getQuery(true)
			->select('DISTINCT WEEK(' . $db->quoteName('date') . ', 3) AS wk') // mode 3 = ISO week, 1-53
			->from($db->quoteName('#__data_entry'))
			->where('YEAR(' . $db->quoteName('date') . ') = ' . (int) $this->filterYear)
			->order('wk DESC');

		$db->setQuery($query);
		$weeks = array_map('intval', $db->loadColumn() ?: array());

		$now = new \DateTime();

		if ((int) $now->format('o') === $this->filterYear && !in_array((int) $now->format('W'), $weeks, true)) {
			$weeks[] = (int) $now->format('W');
		}

		if (empty($weeks) && $this->filterWeek !== 'all') {
			$weeks[] = $this->filterWeek;
		}

		rsort($weeks);

		$options = array();
		$options[] = (object) array('value' => 'all', 'label' => Text::_('COM_DATA_ALL_WEEKS'));

		foreach ($weeks as $week) {
			$start = new \DateTime();
			$start->setISODate($this->filterYear, $week, 1);
			$end = (clone $start)->modify('+6 days');

			$options[] = (object) array(
				'value' => $week,
				'label' => sprintf('%s - %s', $start->format('d M'), $end->format('d M')),
			);
		}

		return $options;
	}

	/**
	 * The current default week key (this ISO week), used before any filter is applied.
	 *
	 * @return  string
	 *
	 * @since   1.3.0
	 */
	protected function defaultWeekKey()
	{
		$now = new \DateTime();

		return sprintf('%04d-W%02d', (int) $now->format('o'), (int) $now->format('W'));
	}

	/**
	 * Recent months available for the Month Selector, newest first.
	 * Always includes the current month even with no data yet.
	 *
	 * @return  array  List of objects: { value: "2026-07", label: "July 2026" }
	 *
	 * @since   1.3.0
	 */
	public function getMonthOptions()
	{
		$db = Factory::getContainer()->get(DatabaseInterface::class);

		$query = $db->getQuery(true)
			->select('DISTINCT MONTH(' . $db->quoteName('date') . ') AS mo')
			->from($db->quoteName('#__data_entry'))
			->where('YEAR(' . $db->quoteName('date') . ') = ' . (int) $this->filterYear)
			->order('mo DESC');

		$db->setQuery($query);
		$months = array_map('intval', $db->loadColumn() ?: array());

		$now     = Factory::getDate('now', 'Asia/Kuala_Lumpur');


		if ((int) $now->format('Y') === $this->filterYear && !in_array((int) $now->format('n'), $months, true)) {
			$months[] = (int) $now->format('n');
		}

		if (empty($months) && $this->filterMonth !== 'all') {
			$months[] = $this->filterMonth;
		}

		rsort($months);

		$options = array();
		$options[] = (object) array('value' => 'all', 'label' => Text::_('COM_DATA_ALL_MONTHS'));


		foreach ($months as $m) {
			$d = Factory::getDate('now', 'Asia/Kuala_Lumpur');
			$d->setDate($this->filterYear, $m, 1);

			$options[] = (object) array(
				'value' => $m,
				'label' => $d->format('F'),
			);
		}

		return $options;
	}


	/**
	 * Full (Part, Model) summary rows for the current period, sorted by NC%
	 * descending. No minimum-volume threshold - every (part, model) that had
	 * any activity in the period shows up here.
	 *
	 * @return  array  List of row objects, see runSummaryQuery().
	 *
	 * @since   1.3.0
	 */
	public function getSummaryRows()
	{
		return $this->runSummaryQuery(null, 0);
	}

	/**
	 * Top N (part, model) combinations by NC% for the leaderboard, excluding
	 * combinations below the minimum Total Sort threshold.
	 *
	 * @return  array  List of row objects, see runSummaryQuery().
	 *
	 * @since   1.3.0
	 */
	public function getTopNc()
	{
		return $this->runSummaryQuery($this->filterTopLimit, $this->filterMinSort);
	}

	/**
	 * Shared query builder for both the full table and the Top N leaderboard.
	 *
	 * Total Sort is de-duplicated by entry id before summing (via a subquery),
	 * so an entry that reported several NC rows under the same (part, model)
	 * doesn't have its `total` counted more than once.
	 *
	 * @param   int|null  $limit    Max rows to return, or null for all.
	 * @param   int       $minSort  Minimum Total Sort to be eligible (0 = no minimum).
	 *
	 * @return  array  List of objects: { part, model_id, model, last_update,
	 *                 ttl_sort, ttl_acc, acc_pct, ttl_nc, nc_pct }
	 *
	 * @since   1.3.0
	 */
	protected function runSummaryQuery($limit, $minSort = 0)
	{
		$db = Factory::getContainer()->get(DatabaseInterface::class);

		// Total Sort per (part, model): dedupe entries first, then sum.
		$sortSubQuery = $db->getQuery(true)
			->select(
				'DISTINCT ' . $db->quoteName('a.id') . ', ' .
					$db->quoteName('a.component') . ', ' .
					$db->quoteName('a.model') . ', ' .
					$db->quoteName('a.vendor') . ', ' .
					$db->quoteName('a.remark') . ', ' .
					$db->quoteName('a.lot') . ', ' .
					$db->quoteName('a.resort_nc') . ', ' .
					$db->quoteName('a.total') . ', ' .
					$db->quoteName('a.date')
			)
			->from($db->quoteName('#__data_entry', 'a'))
			->where($db->quoteName('a.state') . ' = 1');
		$this->applyPeriodFilters($db, $sortSubQuery);

		$sortQuery = $db->getQuery(true)
			->select('component, model, vendor, remark, lot, resort_nc, SUM(total) AS ttl_sort, MAX(date) AS last_update')
			->from('(' . (string) $sortSubQuery . ') AS dedup')
			->group('component, model, vendor, remark, lot, resort_nc');

		$db->setQuery($sortQuery);
		$sortRows = $db->loadObjectList() ?: array();

		// Total NC per (part, model), joined through the NC child table.
		$ncQuery = $db->getQuery(true)
			->select(
				$db->quoteName('a.component') . ', ' .
					$db->quoteName('a.model') . ', ' .
					$db->quoteName('a.vendor') . ', ' .
					$db->quoteName('a.remark') . ', ' .
					$db->quoteName('a.lot') . ', ' .
					$db->quoteName('a.resort_nc') . ', ' .
					'SUM(' . $db->quoteName('nc.nc_quantity') . ') AS ttl_nc'
			)
			->from($db->quoteName('#__data_entry_nc', 'nc'))
			->join('INNER', $db->quoteName('#__data_entry', 'a') . ' ON ' . $db->quoteName('a.id') . ' = ' . $db->quoteName('nc.entry_id'))
			->where($db->quoteName('a.state') . ' = 1')
			->group($db->quoteName('a.component') . ', ' . $db->quoteName('a.model') . ', ' . $db->quoteName('a.vendor') . ', ' . $db->quoteName('a.remark') . ', ' . $db->quoteName('a.lot') . ', ' . $db->quoteName('a.resort_nc'));
		$this->applyPeriodFilters($db, $ncQuery);

		$db->setQuery($ncQuery);

		$ncByKey = array();

		foreach ($db->loadObjectList() ?: array() as $r) {
			$ncByKey[$r->component . '|' . $r->model . '|' . $r->vendor . '|' . $r->remark . '|' . $r->lot . '|' . $r->resort_nc] = (float) $r->ttl_nc;
		}

		// Model id -> name lookup (a.model is a foreign key into #__product_catalogs).
		$modelNames = $this->getModelNameMap($db);

		// Part id -> name lookup (a.component is a foreign key into #__product_components).
		$partNames = $this->getPartNameMap($db);

		$vendorNames = $this->getVendorNameMap($db);
		$remarkNames = $this->getRemarkNameMap($db);
		$resortNames = $this->getResortNameMap($db);
		$lotLabels = array(
			'0' => Text::_('COM_DATA_LOT_NORMAL'),
			'1' => Text::_('COM_DATA_LOT_RESORT'),
		);
		$rows = array();

		foreach ($sortRows as $sr) {
			$key     = $sr->component . '|' . $sr->model . '|' . $sr->vendor . '|' . $sr->remark . '|' . $sr->lot . '|' . $sr->resort_nc;
			$ttlSort = (float) $sr->ttl_sort;
			$ttlNc   = $ncByKey[$key] ?? 0.0;
			$ttlAcc  = $ttlSort - $ttlNc;
			$accPct  = $ttlSort > 0 ? ($ttlAcc / $ttlSort) * 100 : 0.0;
			$ncPct   = $ttlSort > 0 ? ($ttlNc / $ttlSort) * 100 : 0.0;

			$rows[] = (object) array(
				'part_id'     => $sr->component,
				'part'		  => $partNames[$sr->component] ?? $sr->component,
				'model_id'    => $sr->model,
				'model'       => $modelNames[$sr->model] ?? $sr->model,
				'vendor_id'   => $sr->vendor,
				'vendor'      => $vendorNames[$sr->vendor] ?? $sr->vendor,
				'remark'      => $sr->remark,
				'remark_label' => $remarkNames[$sr->remark] ?? $sr->remark,
				'lot'         => $sr->lot,
				'lot_label'   => $lotLabels[$sr->lot] ?? $sr->lot,
				'resort_nc_id' => $sr->resort_nc,
				'resort_nc'   => $resortNames[$sr->resort_nc] ?? $sr->resort_nc,
				'last_update' => $sr->last_update,
				'ttl_sort'    => $ttlSort,
				'ttl_acc'     => $ttlAcc,
				'acc_pct'     => $accPct,
				'ttl_nc'      => $ttlNc,
				'nc_pct'      => $ncPct,
			);
		}

		usort(
			$rows,
			function ($a, $b) {
				return $b->nc_pct <=> $a->nc_pct; // worst NC% first
			}
		);

		if ($minSort > 0) {
			$rows = array_values(
				array_filter(
					$rows,
					function ($row) use ($minSort) {
						return $row->ttl_sort >= $minSort;
					}
				)
			);
		}

		if ($limit !== null) {
			$rows = array_slice($rows, 0, $limit);
		}

		return $rows;
	}

	/**
	 * Build an id -> model_name lookup from #__product_catalogs.
	 *
	 * @param   DatabaseInterface  $db  The database driver.
	 *
	 * @return  array
	 *
	 * @since   1.3.0
	 */
	protected function getModelNameMap(DatabaseInterface $db)
	{
		$query = $db->getQuery(true)
			->select($db->quoteName(array('id', 'model_name')))
			->from($db->quoteName('#__product_catalogs'));

		$db->setQuery($query);

		$map = array();

		foreach ($db->loadObjectList() ?: array() as $r) {
			$map[$r->id] = $r->model_name;
		}

		return $map;
	}

	/**
	 * Build an id -> component_name lookup from #__product_components.
	 *
	 * @param   DatabaseInterface  $db  The database driver.
	 *
	 * @return  array
	 *
	 * @since   1.3.0
	 */
	protected function getPartNameMap(DatabaseInterface $db)
	{
		$query = $db->getQuery(true)
			->select($db->quoteName(array('id', 'component_name')))
			->from($db->quoteName('#__product_components'));

		$db->setQuery($query);

		$map = array();

		foreach ($db->loadObjectList() ?: array() as $r) {
			$map[$r->id] = $r->component_name;
		}

		return $map;
	}

	/**
	 * Build an id -> name lookup from #__users, for vendor display names.
	 *
	 * @param   DatabaseInterface  $db  The database driver.
	 *
	 * @return  array
	 *
	 * @since   1.3.0
	 */
	protected function getVendorNameMap(DatabaseInterface $db)
	{
		$query = $db->getQuery(true)
			->select($db->quoteName(array('id', 'name')))
			->from($db->quoteName('#__users'));

		$db->setQuery($query);

		$map = array();

		foreach ($db->loadObjectList() ?: array() as $r) {
			$map[$r->id] = $r->name;
		}

		return $map;
	}

	protected function getRemarkNameMap(DatabaseInterface $db)
	{
		$query = $db->getQuery(true)
			->select($db->quoteName(array('vd.id', 'vr.remark')))
			->from($db->quoteName('#__vendor_details', 'vd'))
			->join('INNER', $db->quoteName('#__vendor_remarks', 'vr') . ' ON ' . $db->quoteName('vr.id') . ' = ' . $db->quoteName('vd.remark'))
			->where($db->quoteName('vd.state') . ' = 1');

		$db->setQuery($query);

		$map = array();

		foreach ($db->loadObjectList() ?: array() as $r) {
			$map[$r->id] = $r->remark;
		}

		return $map;
	}

	protected function getResortNameMap(DatabaseInterface $db)
	{
		$query = $db->getQuery(true)
			->select($db->quoteName(array('id', 'nc')))
			->from($db->quoteName('#__nc_types'))
			->where($db->quoteName('state') . ' = 1');

		$db->setQuery($query);

		$map = array();

		foreach ($db->loadObjectList() ?: array() as $r) {
			$map[$r->id] = $r->nc;
		}

		return $map;
	}

	/**
	 * Apply the Part filter and the resolved period range, shared by every
	 * query in this model.
	 *
	 * @param   DatabaseInterface              $db     The database driver.
	 * @param   \Joomla\Database\DatabaseQuery  $query  The query to constrain.
	 *
	 * @return  void
	 *
	 * @since   1.3.0
	 */
	protected function applyPeriodFilters(DatabaseInterface $db, $query, $alias = 'a', array $exclude = [])
	{

		// --- Access control ---
		$user = Factory::getApplication()->getIdentity();

		$userId       = (int) $user->get('id');
		$userGroupIds = array_map('intval', (array) $user->get('groups'));

		$params = ComponentHelper::getParams('com_data');

		$viewAllGroups         = array_map('intval', (array) $params->get('viewAll', []));
		$viewOwnOperatorGroups = array_map('intval', (array) $params->get('viewOwnOperator', []));
		$viewOwnVendorGroups   = array_map('intval', (array) $params->get('viewOwnVendor', []));
		$viewAllVendorGroups   = array_map('intval', (array) $params->get('viewAllVendor', []));

		$isSuperUser        = $user->authorise('core.admin');
		$canViewAll          = !empty(array_intersect($userGroupIds, $viewAllGroups));
		$canViewOwnOperator  = !empty(array_intersect($userGroupIds, $viewOwnOperatorGroups));
		$canViewOwnVendor    = !empty(array_intersect($userGroupIds, $viewOwnVendorGroups));
		$canViewAllVendor    = !empty(array_intersect($userGroupIds, $viewAllVendorGroups));

		if (!$userId) {
			$query->where('1 = 0'); // Guest - shouldn't normally reach here given DisplayController's login gate, but defended anyway.
		} elseif ($isSuperUser || $canViewAll) {
			// No restriction.
		} elseif ($canViewOwnOperator || $canViewOwnVendor || $canViewAllVendor) {
			$conditions = array();

			if ($canViewOwnOperator) {
				$conditions[] = $db->quoteName($alias . '.operator') . ' = ' . $userId;
			}

			if ($canViewOwnVendor || $canViewAllVendor) {
				// Vendor ids this user can see records for: themselves, plus
				// anyone listed under them as "Main Vendor" in #__vendor_access
				// (delegation - a main vendor can see their sub-vendors' records too).
				$vendorIds = array($userId);

				$accessQuery = $db->getQuery(true)
					->select($db->quoteName('vendors'))
					->from($db->quoteName('#__vendor_access'))
					->where($db->quoteName('main_vendor') . ' = ' . $userId)
					->where($db->quoteName('state') . ' = 1');

				$db->setQuery($accessQuery);
				$delegatedRows = $db->loadColumn() ?: array();

				foreach ($delegatedRows as $csv) {
					foreach (explode(',', (string) $csv) as $id) {
						$id = (int) $id;

						if ($id > 0) {
							$vendorIds[] = $id;
						}
					}
				}

				$vendorIds = array_unique($vendorIds);

				// FIND_IN_SET, not plain '=' - a.vendor can hold multiple comma-separated
				// vendor ids (same multi-value storage pattern as component/model).
				$vendorConditions = array();

				foreach ($vendorIds as $vendorId) {
					$vendorConditions[] = 'FIND_IN_SET(' . $vendorId . ', ' . $db->quoteName($alias . '.vendor') . ')';
				}

				$conditions[] = '(' . implode(' OR ', $vendorConditions) . ')';
			}

			$query->where('(' . implode(' OR ', $conditions) . ')');
		} else {
			$query->where('1 = 0'); // Authenticated, but in none of the configured groups.
		}

		// --- User-selectable filters ---

		if (
			$this->filterPart !== '' &&
			!in_array('part', $exclude, true)
		) {
			$query->where(
				$db->quoteName($alias . '.component') . ' = ' .
					$db->quote($this->filterPart)
			);
		}

		if (
			$this->filterModel !== '' &&
			!in_array('model', $exclude, true)
		) {
			$query->where(
				$db->quoteName($alias . '.model') . ' = ' .
					$db->quote($this->filterModel)
			);
		}

		if (
			$this->filterVendor !== '' &&
			!in_array('vendor', $exclude, true)
		) {
			$query->where(
				$db->quoteName($alias . '.vendor') . ' = ' .
					$db->quote($this->filterVendor)
			);
		}

		if (
			$this->filterOperator !== '' &&
			!in_array('operator', $exclude, true)
		) {
			$query->where(
				$db->quoteName($alias . '.operator') . ' = ' .
					$db->quote($this->filterOperator)
			);
		}

		if (
			$this->filterRemark !== '' &&
			!in_array('remark', $exclude, true)
		) {
			$query->where(
				$db->quoteName($alias . '.lot') . ' = ' .
					$db->quote($this->filterRemark)
			);
		}

		if (
			$this->filterLot !== '' &&
			!in_array('lot', $exclude, true)
		) {
			$query->where(
				'EXISTS (SELECT 1 FROM ' . $db->quoteName('#__vendor_details', 'vdf') .
					' WHERE ' . $db->quoteName('vdf.id') . ' = ' . $db->quoteName($alias . '.remark') .
					' AND ' . $db->quoteName('vdf.remark') . ' = ' . $db->quote($this->filterLot) . ')'
			);
		}

		$query->where(
			$db->quoteName($alias . '.date') .
				' BETWEEN ' .
				$db->quote($this->periodStart->format('Y-m-d H:i:s')) .
				' AND ' .
				$db->quote($this->periodEnd->format('Y-m-d H:i:s'))
		);
	}
}
