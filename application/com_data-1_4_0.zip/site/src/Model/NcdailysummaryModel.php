<?php

/**
 * @version    CVS: 1.3.0
 * @package    Com_Data
 * @author     Mei Chun <qc.yolotech@gmail.com>
 * @copyright  2026 YOLO
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace Data\Component\Data\Site\Model;
// No direct access.
defined('_JEXEC') or die;

use \Joomla\CMS\Factory;
use \Joomla\CMS\MVC\Model\BaseDatabaseModel;
use \Joomla\Database\DatabaseInterface;
use \Joomla\CMS\Language\Text;
use \Joomla\CMS\Component\ComponentHelper;


/**
 * Daily NC% Summary: rows are (Part, Model, Vendor) combinations, columns
 * are always the 7 calendar days (Monday-Sunday) of one selected ISO week.
 * Each cell is that combination's NC% for that specific day
 * (day_nc_qty / day_sort_qty * 100) - not a share of anything else, so it
 * reads the same way as an Excel "Sum of NC%" pivot with Date in Columns.
 *
 * Total Sort/NC per day are de-duplicated by entry id before summing, so an
 * entry with several NC rows under the same (part, model, vendor) doesn't
 * have its `total` counted more than once.
 *
 * @since  1.3.0
 */
class NcdailysummaryModel extends BaseDatabaseModel
{
	/** @var string  a.component value, or '' for all parts. */
	protected $filterPart = '';

	/** @var string  a.model value (FK id), or '' for all models. */
	protected $filterModel = '';

	/** @var string  a.vendor value (FK id), or '' for all vendors. */
	protected $filterVendor = '';

	/** @var string  a.lot value (FK id), or '' for all lots. */
	protected $filterLot = '';

	/** @var int  Selected ISO year. */
	protected $filterYear;

	/** @var int  Selected ISO week within $filterYear (1-53). */
	protected $filterWeek;

	/** @var \DateTime  Monday 00:00:00 of the selected/default ISO week. */
	protected $weekStart;

	/** @var \DateTime  Sunday 23:59:59 of the selected/default ISO week. */
	protected $weekEnd;

	/**
	 * Constructor.
	 *
	 * @param   array  $config  An optional associative array of configuration settings.
	 *
	 * @since   1.3.0
	 */
	public function __construct($config = array())
	{
		parent::__construct($config);

		$this->populateState();
	}

	/**
	 * Read all filters from the request, persist them in user state, and
	 * resolve the selected (or default = current) ISO week into a concrete
	 * Monday-Sunday date range.
	 *
	 * @return  void
	 *
	 * @since   1.3.0
	 */
	protected function populateState()
	{
		$app     = Factory::getApplication();
		$context = 'com_data.ncdailysummary.';
		$now     = new \DateTime('now', Factory::getApplication()->get('offset') ? new \DateTimeZone(Factory::getApplication()->get('offset')) : null);

		// --- Clear Filters: wipe stored session state, then fall through to defaults ---
		if ($app->input->getInt('clearfilters', 0) === 1) {
			$keys = array('part', 'model', 'vendor', 'year', 'week', 'lot');

			foreach ($keys as $key) {
				$app->setUserState($context . 'filter.' . $key, null);
			}

			$app->input->set('filter_part', null);
			$app->input->set('filter_model', null);
			$app->input->set('filter_vendor', null);
			$app->input->set('filter_year', null);
			$app->input->set('filter_week', null);
			$app->input->set('filter_lot', null);
		}

		$this->filterPart   = (string) $app->getUserStateFromRequest($context . 'filter.part', 'filter_part', '', 'string');
		$this->filterModel  = (string) $app->getUserStateFromRequest($context . 'filter.model', 'filter_model', '', 'string');
		$this->filterVendor = (string) $app->getUserStateFromRequest($context . 'filter.vendor', 'filter_vendor', '', 'string');
		$this->filterLot    = (string) $app->getUserStateFromRequest($context . 'filter.lot', 'filter_lot', '', 'string');
		$this->filterYear   = (int) $app->getUserStateFromRequest($context . 'filter.year', 'filter_year', (int) $now->format('o'), 'int');
		$this->filterWeek   = (int) $app->getUserStateFromRequest($context . 'filter.week', 'filter_week', (int) $now->format('W'), 'int');

		if ($this->filterYear < 2000 || $this->filterYear > 2100) {
			$this->filterYear = (int) $now->format('o');
		}

		if ($this->filterWeek < 1 || $this->filterWeek > 53) {
			$this->filterWeek = (int) $now->format('W');
		}

		$this->weekStart = new \DateTime();
		$this->weekStart->setISODate($this->filterYear, $this->filterWeek, 1)->setTime(0, 0, 0);

		$this->weekEnd = clone $this->weekStart;
		$this->weekEnd->modify('+6 days')->setTime(23, 59, 59);

		// --- Default (and, for operator-restricted users, FORCE) the Operator
		// filter to "own account" - keyed off the same viewOwnOperator groups
		// applyEntryFilters() uses for the actual query-level restriction, so
		// the pre-selected filter and the enforced boundary never drift apart.
		// Super Users are exempt, matching applyEntryFilters()'s core.admin check.
		$user   = $app->getIdentity();
		$userId = (int) $user->get('id');

		if ($userId > 0) {
			$userGroupIds = array_map('intval', (array) $user->get('groups'));
			$params       = ComponentHelper::getParams('com_data');
			$viewOwnVendorGroups = array_map('intval', (array) $params->get('viewOwnVendor', []));

			$isSuperUser = $user->authorise('core.admin');

			if (!$isSuperUser && !empty(array_intersect($userGroupIds, $viewOwnVendorGroups))) {
				$this->filterVendor = $userId;
			}
		}
	}

	/**
	 * The currently active filters, so the view can re-select them in the controls.
	 *
	 * @return  object
	 *
	 * @since   1.3.0
	 */
	public function getActiveFilters()
	{
		return (object) array(
			'part'       => $this->filterPart,
			'model'      => $this->filterModel,
			'vendor'     => $this->filterVendor,
			'lot'     => $this->filterLot,
			'year'       => $this->filterYear,
			'week'       => $this->filterWeek,
			'week_start' => $this->weekStart->format('Y-m-d'),
			'week_end'   => $this->weekEnd->format('Y-m-d'),
		);
	}

	/**
	 * Distinct Part values (a.component), for the "SELECT PART" filter.
	 *
	 * @return  array
	 *
	 * @since   1.3.0
	 */
	public function getPartOptions()
	{
		$db = Factory::getContainer()->get(DatabaseInterface::class);

		$query = $db->getQuery(true)
			->select(
				'DISTINCT ' . $db->quoteName('a.component', 'value') . ', ' .
					$db->quoteName('pc.component_name', 'text')
			)
			->from($db->quoteName('#__data_entry', 'a'))
			->join('INNER', $db->quoteName('#__product_components', 'pc') . ' ON ' . $db->quoteName('pc.id') . ' = ' . $db->quoteName('a.component'))
			->where($db->quoteName('a.component') . ' != ' . $db->quote(''))
			->where($db->quoteName('a.state') . ' = ' . $db->quote(1))
			->order($db->quoteName('pc.component_name') . ' ASC');

		// Apply selected filters, EXCEPT the current Part filter
		$this->applyEntryFilters($db, $query, 'a', ['part']);

		$db->setQuery($query);

		return $db->loadObjectList() ?: array();
	}

	/**
	 * Distinct list of models available for the Model Selector.
	 *
	 * @return  array  List of objects: { value, text }
	 *
	 * @since   1.3.0
	 */
	public function getModelOptions()
	{
		$db = Factory::getContainer()->get(DatabaseInterface::class);

		$query = $db->getQuery(true)
			->select(
				'DISTINCT ' . $db->quoteName('pm.id', 'value') . ', ' .
					$db->quoteName('pm.model_name', 'text')
			)
			->from($db->quoteName('#__data_entry', 'a'))
			->join('INNER', $db->quoteName('#__product_catalogs', 'pm') . ' ON ' . $db->quoteName('pm.id') . ' = ' . $db->quoteName('a.model'))
			->where($db->quoteName('a.model') . ' IS NOT NULL')
			->where($db->quoteName('a.state') . ' = 1');

		// Apply selected filters, EXCEPT the current Model filter
		$this->applyEntryFilters($db, $query, 'a', ['model']);

		$query->order($db->quoteName('pm.model_name') . ' ASC');

		$db->setQuery($query);

		return $db->loadObjectList() ?: array();
	}

	/**
	 * Distinct list of vendors available for the Vendor Selector.
	 *
	 * @return  array  List of objects: { key, value }
	 *
	 * @since   1.3.0
	 */
	public function getVendorOptions()
	{
		$db = Factory::getContainer()->get(DatabaseInterface::class);

		$query = $db->getQuery(true)
			->select(
				'DISTINCT ' . $db->quoteName('a.vendor', 'key') . ', ' .
					$db->quoteName('uv.name', 'value')
			)
			->from($db->quoteName('#__data_entry', 'a'))
			->join('INNER', $db->quoteName('#__users', 'uv') . ' ON ' . $db->quoteName('uv.id') . ' = ' . $db->quoteName('a.vendor'))
			->where($db->quoteName('a.state') . ' = 1')
			->order($db->quoteName('uv.name') . ' ASC');

		// Apply selected filters, EXCEPT the current Vendor filter
		$this->applyEntryFilters($db, $query, 'a', ['vendor']);

		$db->setQuery($query);

		return $db->loadObjectList() ?: array();
	}

	/**
	 * Years with data, newest first. Always includes the current year.
	 *
	 * @return  array  Plain list of ints, e.g. [2027, 2026, 2025]
	 *
	 * @since   1.3.0
	 */
	public function getYearOptions()
	{
		$db = Factory::getContainer()->get(DatabaseInterface::class);

		$query = $db->getQuery(true)
			->select('DISTINCT YEAR(' . $db->quoteName('date') . ') AS yr')
			->from($db->quoteName('#__data_entry'))
			->where($db->quoteName('date') . ' IS NOT NULL')
			->order('yr DESC');

		$db->setQuery($query);
		$years = array_map('intval', $db->loadColumn() ?: array());

		$currentYear = (int) (new \DateTime())->format('Y');

		if (!in_array($currentYear, $years, true)) {
			array_unshift($years, $currentYear);
			rsort($years);
		}

		return $years;
	}

	/**
	 * ISO weeks that have data within $filterYear, newest first. Always
	 * includes the current week if $filterYear is the current year.
	 *
	 * @return  array  List of objects: { value: 30, label: "20 Jul - 26 Jul" }
	 *
	 * @since   1.3.0
	 */
	public function getWeekOptions()
	{
		$db = Factory::getContainer()->get(DatabaseInterface::class);

		$query = $db->getQuery(true)
			->select('DISTINCT WEEK(' . $db->quoteName('date') . ', 3) AS wk') // mode 3 = ISO week
			->from($db->quoteName('#__data_entry'))
			->where('YEAR(' . $db->quoteName('date') . ') = ' . (int) $this->filterYear)
			->order('wk DESC');

		$db->setQuery($query);
		$weeks = array_map('intval', $db->loadColumn() ?: array());

		$now = new \DateTime();

		if ((int) $now->format('o') === $this->filterYear && !in_array((int) $now->format('W'), $weeks, true)) {
			$weeks[] = (int) $now->format('W');
		}

		if (empty($weeks)) {
			$weeks[] = $this->filterWeek;
		}

		rsort($weeks);

		$options = array();

		foreach ($weeks as $week) {
			$start = new \DateTime();
			$start->setISODate($this->filterYear, $week, 1);
			$end = (clone $start)->modify('+6 days');

			$options[] = (object) array(
				'value' => $week,
				'label' => sprintf('%s - %s', $start->format('d M'), $end->format('d M')),
			);
		}

		return $options;
	}

	/**
	 * Fixed Lot options: Normal / Resort.
	 *
	 * @return  array  Key-value pairs: '0' => 'Normal', '1' => 'Resort'
	 *
	 * @since   1.3.0
	 */
	public function getLotOptions()
	{
		return array(
			'0' => Text::_('COM_DATA_LOT_NORMAL'),
			'1' => Text::_('COM_DATA_LOT_RESORT'),
		);
	}

	/**
	 * Build the pivot: rows are (Part, Model, Vendor) combinations, columns
	 * are always the 7 calendar days (Monday-Sunday) of the selected week -
	 * present or not. Each cell is that row's NC% FOR THAT SPECIFIC DAY
	 * (day_nc_qty / day_sort_qty * 100), matching an Excel "Sum of NC%"
	 * pivot with Date across the columns - not a share of the week or of
	 * other rows.
	 *
	 * @return  object  { dates, rows }
	 *
	 * @since   1.3.0
	 */
	public function getPivot()
	{
		$db = Factory::getContainer()->get(DatabaseInterface::class);

		$dates  = array();
		$cursor = clone $this->weekStart;

		for ($i = 0; $i < 7; $i++) {
			$dates[] = $cursor->format('Y-m-d');
			$cursor->modify('+1 day');
		}

		// --- Total Sort per (part, model, vendor, date, remark, lot): dedupe entries first
		// (one row per entry), THEN sum, so an entry with several NC rows
		// doesn't inflate that day's sort total. ---
		$sortSubQuery = $db->getQuery(true)
			->select(
				'DISTINCT ' . $db->quoteName('a.id') . ', ' .
					$db->quoteName('a.component') . ', ' .
					$db->quoteName('a.model') . ', ' .
					$db->quoteName('a.vendor') . ', ' .
					$db->quoteName('a.remark') . ', ' .
					$db->quoteName('a.lot') . ', ' .
					$db->quoteName('a.resort_nc') . ', ' .
					$db->quoteName('a.total') . ', ' .
					'DATE(' . $db->quoteName('a.date') . ') AS entry_date'
			)
			->from($db->quoteName('#__data_entry', 'a'))
			->where($db->quoteName('a.state') . ' = 1');
		$this->applyEntryFilters($db, $sortSubQuery);

		$sortQuery = $db->getQuery(true)
			->select('component, model, vendor, remark, lot, resort_nc, entry_date, SUM(total) AS day_sort')
			->from('(' . (string) $sortSubQuery . ') AS dedup')
			->group('component, model, vendor, remark, lot, resort_nc, entry_date');

		$db->setQuery($sortQuery);
		$sortRows = $db->loadObjectList() ?: array();

		// --- Total NC per (part, model, vendor, date, remark), joined through the NC child table. ---
		$ncQuery = $db->getQuery(true)
			->select(
				$db->quoteName('a.component') . ', ' .
					$db->quoteName('a.model') . ', ' .
					$db->quoteName('a.vendor') . ', ' .
					$db->quoteName('a.remark') . ', ' .
					$db->quoteName('a.lot') . ', ' .
					$db->quoteName('a.resort_nc') . ', ' .
					'DATE(' . $db->quoteName('a.date') . ') AS entry_date, ' .
					'SUM(' . $db->quoteName('nc.nc_quantity') . ') AS ttl_nc'
			)
			->from($db->quoteName('#__data_entry_nc', 'nc'))
			->join('INNER', $db->quoteName('#__data_entry', 'a') . ' ON ' . $db->quoteName('a.id') . ' = ' . $db->quoteName('nc.entry_id'))
			->where($db->quoteName('a.state') . ' = 1')
			->group(
				$db->quoteName('a.component') . ', ' .
					$db->quoteName('a.model') . ', ' .
					$db->quoteName('a.vendor') . ', ' .
					$db->quoteName('a.lot') . ', ' .
					$db->quoteName('a.resort_nc') . ', ' .
					$db->quoteName('a.remark') . ', DATE(' . $db->quoteName('a.date') . ')'
			);
		$this->applyEntryFilters($db, $ncQuery);

		$db->setQuery($ncQuery);

		$ncByKeyDate = array();

		foreach ($db->loadObjectList() ?: array() as $r) {
			$key       = $r->component . '|' . $r->model . '|' . $r->vendor . '|' . $r->remark . '|' . $r->lot . '|' . $r->resort_nc;
			$entryDate = (new \DateTime($r->entry_date))->format('Y-m-d');

			$ncByKeyDate[$key][$entryDate] = (float) $r->ttl_nc;
		}

		// Part id -> name, Model id -> name, vendor id -> name lookups.
		$partNames  = $this->getPartNameMap($db);
		$modelNames  = $this->getModelNameMap($db);
		$vendorNames = $this->getVendorNameMap($db);
		$remarkNames = $this->getRemarkNameMap($db);
		$resortNames = $this->getResortNameMap($db);

		$lotLabels = array(
			'0' => Text::_('COM_DATA_LOT_NORMAL'),
			'1' => Text::_('COM_DATA_LOT_RESORT'),
		);

		// --- Assemble rows: one per (part, model, vendor), NC% computed per day. ---
		$rows = array();

		foreach ($sortRows as $sr) {
			$key = $sr->component . '|' . $sr->model . '|' . $sr->vendor . '|' . $sr->remark . '|' . $sr->lot . '|' . $sr->resort_nc;

			// Normalize whatever format the driver returned into the exact same
			// 'Y-m-d' representation used to build $dates - guarantees the two
			// sides can never silently fail to match.
			$entryDate = (new \DateTime($sr->entry_date))->format('Y-m-d');

			if (!isset($rows[$key])) {
				$rows[$key] = (object) array(
					'part_id'     => $sr->component,
					'part'        => $partNames[$sr->component] ?? $sr->component,
					'model_id'    => $sr->model,
					'model'       => $modelNames[$sr->model] ?? $sr->model,
					'vendor_id'   => $sr->vendor,
					'vendor'      => $vendorNames[$sr->vendor] ?? $sr->vendor,
					'remark'      => $sr->remark,
					'remark_label' => $remarkNames[$sr->remark] ?? $sr->remark,
					'lot'         => $sr->lot,
					'lot_label'   => $lotLabels[$sr->lot] ?? $sr->lot,
					'resort_nc_id' => $sr->resort_nc,
					'resort_nc'   => $resortNames[$sr->resort_nc] ?? $sr->resort_nc,
					'by_date_pct' => array_fill_keys($dates, null),
				);
			}

			$daySort = (float) $sr->day_sort;
			$dayNc   = $ncByKeyDate[$key][$entryDate] ?? 0.0;

			if (array_key_exists($entryDate, $rows[$key]->by_date_pct)) {
				$rows[$key]->by_date_pct[$entryDate] = $daySort > 0 ? ($dayNc / $daySort) * 100 : 0.0;
			}
		}

		uasort(
			$rows,
			function ($a, $b) {
				return strcmp($a->part . $a->model . $a->vendor . $a->remark . $a->lot . $a->resort_nc, $b->part . $b->model . $b->vendor . $b->remark . $b->lot . $b->resort_nc);
			}
		);

		return (object) array(
			'dates' => $dates,
			'rows'  => array_values($rows),
		);
	}


	/**
	 * Build an id -> component_name lookup from #__product_components.
	 *
	 * @param   DatabaseInterface  $db  The database driver.
	 *
	 * @return  array
	 *
	 * @since   1.3.0
	 */
	protected function getPartNameMap(DatabaseInterface $db)
	{
		$query = $db->getQuery(true)
			->select($db->quoteName(array('id', 'component_name')))
			->from($db->quoteName('#__product_components'));

		$db->setQuery($query);

		$map = array();

		foreach ($db->loadObjectList() ?: array() as $r) {
			$map[$r->id] = $r->component_name;
		}


		return $map;
	}

	/**
	 * Build an id -> model_name lookup from #__product_catalogs.
	 *
	 * @param   DatabaseInterface  $db  The database driver.
	 *
	 * @return  array
	 *
	 * @since   1.3.0
	 */
	protected function getModelNameMap(DatabaseInterface $db)
	{
		$query = $db->getQuery(true)
			->select($db->quoteName(array('id', 'model_name')))
			->from($db->quoteName('#__product_catalogs'));

		$db->setQuery($query);

		$map = array();

		foreach ($db->loadObjectList() ?: array() as $r) {
			$map[$r->id] = $r->model_name;
		}

		return $map;
	}

	protected function getRemarkNameMap(DatabaseInterface $db)
	{
		$query = $db->getQuery(true)
			->select($db->quoteName(array('vd.id', 'vr.remark')))
			->from($db->quoteName('#__vendor_details', 'vd'))
			->join('INNER', $db->quoteName('#__vendor_remarks', 'vr') . ' ON ' . $db->quoteName('vr.id') . ' = ' . $db->quoteName('vd.remark'))
			->where($db->quoteName('vd.state') . ' = 1');

		$db->setQuery($query);

		$map = array();

		foreach ($db->loadObjectList() ?: array() as $r) {
			$map[$r->id] = $r->remark;
		}

		return $map;
	}

	protected function getResortNameMap(DatabaseInterface $db)
	{
		$query = $db->getQuery(true)
			->select($db->quoteName(array('id', 'nc')))
			->from($db->quoteName('#__nc_types'))
			->where($db->quoteName('state') . ' = 1');

		$db->setQuery($query);

		$map = array();

		foreach ($db->loadObjectList() ?: array() as $r) {
			$map[$r->id] = $r->nc;
		}

		return $map;
	}

	/**
	 * Build an id -> name lookup from #__users, for vendor display names.
	 *
	 * @param   DatabaseInterface  $db  The database driver.
	 *
	 * @return  array
	 *
	 * @since   1.3.0
	 */
	protected function getVendorNameMap(DatabaseInterface $db)
	{
		$query = $db->getQuery(true)
			->select($db->quoteName(array('id', 'name')))
			->from($db->quoteName('#__users'));

		$db->setQuery($query);

		$map = array();

		foreach ($db->loadObjectList() ?: array() as $r) {
			$map[$r->id] = $r->name;
		}

		return $map;
	}

	/**
	 * Apply the Part/Model/Vendor filters and the resolved Monday-Sunday
	 * week range, shared by every query in this model.
	 *
	 * @param   DatabaseInterface              $db     The database driver.
	 * @param   \Joomla\Database\DatabaseQuery  $query  The query to constrain.
	 *
	 * @return  void
	 *
	 * @since   1.3.0
	 */
	protected function applyEntryFilters(DatabaseInterface $db, $query, $alias = 'a', array $exclude = [])
	{
		// --- Access control ---
		$user = Factory::getApplication()->getIdentity();

		$userId       = (int) $user->get('id');
		$userGroupIds = array_map('intval', (array) $user->get('groups'));

		$params = ComponentHelper::getParams('com_data');

		$viewAllGroups         = array_map('intval', (array) $params->get('viewAll', []));
		$viewOwnOperatorGroups = array_map('intval', (array) $params->get('viewOwnOperator', []));
		$viewOwnVendorGroups   = array_map('intval', (array) $params->get('viewOwnVendor', []));
		$viewAllVendorGroups   = array_map('intval', (array) $params->get('viewAllVendor', []));

		$isSuperUser        = $user->authorise('core.admin');
		$canViewAll          = !empty(array_intersect($userGroupIds, $viewAllGroups));
		$canViewOwnOperator  = !empty(array_intersect($userGroupIds, $viewOwnOperatorGroups));
		$canViewOwnVendor    = !empty(array_intersect($userGroupIds, $viewOwnVendorGroups));
		$canViewAllVendor    = !empty(array_intersect($userGroupIds, $viewAllVendorGroups));

		if (!$userId) {
			$query->where('1 = 0'); // Guest - shouldn't normally reach here given DisplayController's login gate, but defended anyway.
		} elseif ($isSuperUser || $canViewAll) {
			// No restriction.
		} elseif ($canViewOwnOperator || $canViewOwnVendor || $canViewAllVendor) {
			$conditions = array();

			if ($canViewOwnOperator) {
				$conditions[] = $db->quoteName($alias . '.operator') . ' = ' . $userId;
			}

			if ($canViewOwnVendor || $canViewAllVendor) {
				// Vendor ids this user can see records for: themselves, plus
				// anyone listed under them as "Main Vendor" in #__vendor_access
				// (delegation - a main vendor can see their sub-vendors' records too).
				$vendorIds = array($userId);

				$accessQuery = $db->getQuery(true)
					->select($db->quoteName('vendors'))
					->from($db->quoteName('#__vendor_access'))
					->where($db->quoteName('main_vendor') . ' = ' . $userId)
					->where($db->quoteName('state') . ' = 1');

				$db->setQuery($accessQuery);
				$delegatedRows = $db->loadColumn() ?: array();

				foreach ($delegatedRows as $csv) {
					foreach (explode(',', (string) $csv) as $id) {
						$id = (int) $id;

						if ($id > 0) {
							$vendorIds[] = $id;
						}
					}
				}

				$vendorIds = array_unique($vendorIds);

				// FIND_IN_SET, not plain '=' - a.vendor can hold multiple comma-separated
				// vendor ids (same multi-value storage pattern as component/model).
				$vendorConditions = array();

				foreach ($vendorIds as $vendorId) {
					$vendorConditions[] = 'FIND_IN_SET(' . $vendorId . ', ' . $db->quoteName($alias . '.vendor') . ')';
				}

				$conditions[] = '(' . implode(' OR ', $vendorConditions) . ')';
			}

			$query->where('(' . implode(' OR ', $conditions) . ')');
		} else {
			$query->where('1 = 0'); // Authenticated, but in none of the configured groups.
		}

		if (
			$this->filterPart !== '' &&
			!in_array('part', $exclude, true)
		) {
			$query->where(
				$db->quoteName($alias . '.component') . ' = ' .
					$db->quote($this->filterPart)
			);
		}

		if (
			$this->filterModel !== '' &&
			!in_array('model', $exclude, true)
		) {
			$query->where(
				$db->quoteName($alias . '.model') . ' = ' .
					$db->quote($this->filterModel)
			);
		}

		if (
			$this->filterVendor !== '' &&
			!in_array('vendor', $exclude, true)
		) {
			$query->where(
				$db->quoteName($alias . '.vendor') . ' = ' .
					$db->quote($this->filterVendor)
			);
		}

		if (
			$this->filterLot !== '' &&
			!in_array('lot', $exclude, true)
		) {
			$query->where(
				$db->quoteName($alias . '.remark') . ' = ' .
					$db->quote($this->filterLot)
			);
		}

		$query->where(
			$db->quoteName($alias . '.date') .
				' BETWEEN ' .
				$db->quote($this->weekStart->format('Y-m-d H:i:s')) .
				' AND ' .
				$db->quote($this->weekEnd->format('Y-m-d H:i:s'))
		);
	}
}
