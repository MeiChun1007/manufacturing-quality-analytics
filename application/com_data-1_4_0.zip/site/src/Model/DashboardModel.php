<?php

/**
 * @version    CVS: 1.4.0
 * @package    Com_Data
 * @author     Mei Chun <qc.yolotech@gmail.com>
 * @copyright  2026 YOLO
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace Data\Component\Data\Site\Model;

// No direct access.
defined('_JEXEC') or die;

use \Joomla\CMS\Factory;
use \Joomla\CMS\MVC\Model\BaseDatabaseModel;
use \Joomla\Database\DatabaseInterface;
use \Joomla\CMS\Language\Text;
use \Joomla\CMS\Component\ComponentHelper;

/**
 * Model for the component overview dashboard: production (Total Sort) and
 * non-conformance (NC) trends and breakdowns across a selected date range,
 * optionally scoped to a single Model and/or Vendor.
 *
 * Access control: every query in this model is gated in applyEntryFilters(),
 * based on three usergrouplist params in com_data's component config -
 * viewAll, viewOwnOperator, viewOwnVendor. A user not covered by any of
 * these (and not core.admin) sees no data at all - this fails CLOSED, not
 * open, so a missing/misconfigured param means "nobody sees anything"
 * rather than "everybody sees everything".
 *
 * @since  1.3.0
 */
class DashboardModel extends BaseDatabaseModel
{
	/** @var string  'week' or 'month' */
	protected $filterPeriodType = 'week';

	/** @var int  Selected calendar/ISO year. */
	protected $filterYear;

	/** @var string  ISO year-week key, e.g. "2026-W30". */
	protected $filterWeek = '';

	/** @var string  "YYYY-MM". */
	protected $filterMonth = '';

	/** @var string  a.component value, or '' for all parts. */
	protected $filterPart = '';

	/**
	 * @var  string
	 * @since  1.3.0
	 */
	protected $filterModel = '';

	/**
	 * @var  string
	 * @since  1.2.0
	 */
	protected $filterNcCategory = '';

	/**
	 * @var  string
	 * @since  1.2.0
	 */
	protected $filterNcType = '';

	/**
	 * @var  string
	 * @since  1.3.0
	 */
	protected $filterVendor = '';

	/**
	 * @var  string
	 * @since  1.2.0
	 */
	protected $filterOperator = '';

	/**
	 * @var  string  Remark: Normal/Resort
	 * @since  1.2.0
	 */
	protected $filterRemark = '';

	/**
	 * @var  string  Lot
	 * @since  1.2.0
	 */
	protected $filterLot = '';


	/**
	 * @var  string  Y-m-d
	 * @since  1.3.0
	 */
	protected $filterDateFrom = '';

	/**
	 * @var  string  Y-m-d
	 * @since  1.3.0
	 */
	protected $filterDateTo = '';

	/** @var \DateTime  Start of the resolved period, 00:00:00. */
	protected $periodStart;

	/** @var \DateTime  End of the resolved period, 23:59:59. */
	protected $periodEnd;

	/**
	 * Constructor.
	 *
	 * @param   array  $config  An optional associative array of configuration settings.
	 *
	 * @since   1.3.0
	 */
	public function __construct($config = array())
	{
		parent::__construct($config);

		$this->populateState();
	}

	/**
	 * Read the Model/Vendor/Date Range filters from the request and persist
	 * them in the user state, defaulting to the trailing 30 days.
	 *
	 * @return  void
	 *
	 * @since   1.3.0
	 */
	protected function populateState()
	{
		$app     = Factory::getApplication();
		$context = 'com_data.dashboard.';
		$now = Factory::getDate('now', 'Asia/Kuala_Lumpur');

		// --- Clear Filters: wipe stored session state, then fall through to defaults ---
		if ($app->input->getInt('clearfilters', 0) === 1) {
			$keys = array('vendor', 'lot', 'remark', 'operator', 'part', 'model', 'nc_category', 'nc_type', 'year', 'week', 'period_type', 'date_from', 'date_to');

			foreach ($keys as $key) {
				$app->setUserState($context . 'filter.' . $key, null);
			}

			$app->input->set('filter_vendor', null);
			$app->input->set('filter_lot', null);
			$app->input->set('filter_remark', null);
			$app->input->set('filter_operator', null);
			$app->input->set('filter_part', null);
			$app->input->set('filter_model', null);
			$app->input->set('filter_nc_category', null);
			$app->input->set('filter_nc_type', null);
			$app->input->set('filter_date_from', null);
			$app->input->set('filter_date_to', null);
			$app->input->set('filter_year', null);
			$app->input->set('filter_week', null);
			$app->input->set('filter_period_type', null);
		}

		$defaultTo   = new \DateTime('now');
		$defaultFrom = (clone $defaultTo)->modify('-29 days');

		// 'week' / 'month' = quick presets that compute the range below.
		// 'custom' = trust filterDateFrom/filterDateTo as submitted/persisted.
		// Defaults to 'custom' so existing installs keep their current
		// trailing-30-day behaviour unless someone explicitly picks a preset.
		$this->filterPeriodType = (string) $app->getUserStateFromRequest($context . 'filter.period_type', 'filter_period_type', 'week', 'string');
		$this->filterYear       = (int) $app->getUserStateFromRequest($context . 'filter.year', 'filter_year', (int) $now->format('o'), 'int');
		$this->filterPart  		= (string) $app->getUserStateFromRequest($context . 'filter.part', 'filter_part', '', 'string');
		$this->filterModel      = (string) $app->getUserStateFromRequest($context . 'filter.model', 'filter_model', '', 'string');
		$this->filterVendor     = (string) $app->getUserStateFromRequest($context . 'filter.vendor', 'filter_vendor', '', 'string');
		$this->filterOperator 	= (string) $app->getUserStateFromRequest($context . 'filter.operator', 'filter_operator', '', 'string');
		$this->filterDateFrom   = (string) $app->getUserStateFromRequest($context . 'filter.date_from', 'filter_date_from', $defaultFrom->format('Y-m-d'), 'string');
		$this->filterDateTo     = (string) $app->getUserStateFromRequest($context . 'filter.date_to', 'filter_date_to', $defaultTo->format('Y-m-d'), 'string');
		$this->filterLot		= (string) $app->getUserStateFromRequest($context . 'filter.lot', 'filter_lot', '', 'string');
		$this->filterNcCategory	= (string) $app->getUserStateFromRequest($context . 'filter.nc_category', 'filter_nc_category', '', 'string');
		$this->filterNcType		= (string) $app->getUserStateFromRequest($context . 'filter.nc_type', 'filter_nc_type', '', 'string');
		$this->filterRemark 	= (string) $app->getUserStateFromRequest($context . 'filter.remark', 'filter_remark', '0', 'string');

		$rawWeek  = (string) $app->getUserStateFromRequest($context . 'filter.week', 'filter_week', '', 'string');
		$rawMonth = (string) $app->getUserStateFromRequest($context . 'filter.month', 'filter_month', '', 'string');

		// Empty (unselected) or explicit 'all' both mean "whole year" - see note above
		// re: this changing the previous "defaults to current week/month" behaviour.
		$this->filterWeek  = $rawWeek === 'all' ? 'all' : (int) $rawWeek;
		$this->filterMonth = $rawMonth === 'all' ? 'all' : (int) $rawMonth;


		if (!in_array($this->filterPeriodType, array('week', 'month', 'custom'), true)) {
			$this->filterPeriodType = 'custom';
		}

		if ($this->filterYear < 2000 || $this->filterYear > 2100) {
			$this->filterYear = (int) $now->format('o');
		}

		if ($this->filterWeek !== 'all' && ($this->filterWeek < 1 || $this->filterWeek > 53)) {
			$this->filterWeek = (int) $now->format('W');
		}

		if ($this->filterMonth !== 'all' && ($this->filterMonth < 1 || $this->filterMonth > 12)) {
			$this->filterMonth = (int) $now->format('n');
		}

		// Guard against an inverted or malformed custom range - only meaningful
		// when period_type is 'custom', but validated unconditionally so a stale
		// stored value can't cause a bad range if the user switches back to it later.
		if ($this->filterDateFrom === '' || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $this->filterDateFrom)) {
			$this->filterDateFrom = $defaultFrom->format('Y-m-d');
		}

		if ($this->filterDateTo === '' || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $this->filterDateTo)) {
			$this->filterDateTo = $defaultTo->format('Y-m-d');
		}

		if ($this->filterDateFrom > $this->filterDateTo) {
			list($this->filterDateFrom, $this->filterDateTo) = array($this->filterDateTo, $this->filterDateFrom);
		}

		// A preset overrides the working date range for THIS request only - it
		// never overwrites the persisted custom date_from/date_to user state, so
		// switching back to "Custom" later still shows whatever range someone
		// last set there, rather than losing it.

		if ($this->filterPeriodType === 'week') {
			if ($this->filterWeek === 'all') {
				$this->resolveYearPeriod();
			} else {
				$this->resolveWeekPeriod();
			}
			$this->filterDateFrom = $this->periodStart->format('Y-m-d');
			$this->filterDateTo   = $this->periodEnd->format('Y-m-d');
		} elseif ($this->filterPeriodType === 'month') {
			if ($this->filterMonth === 'all') {
				$this->resolveYearPeriod();
			} else {
				$this->resolveMonthPeriod();
			}
			$this->filterDateFrom = $this->periodStart->format('Y-m-d');
			$this->filterDateTo   = $this->periodEnd->format('Y-m-d');
		} else {
			$this->periodStart = new \DateTime($this->filterDateFrom);
			$this->periodEnd   = new \DateTime($this->filterDateTo);
		}

		// --- Default (and, for operator-restricted users, FORCE) the Operator
		// filter to "own account" - keyed off the same viewOwnOperator groups
		// applyEntryFilters() uses for the actual query-level restriction, so
		// the pre-selected filter and the enforced boundary never drift apart.
		// Super Users are exempt, matching applyEntryFilters()'s core.admin check.
		$user   = $app->getIdentity();
		$userId = (int) $user->get('id');

		if ($userId > 0) {
			$userGroupIds = array_map('intval', (array) $user->get('groups'));
			$params       = ComponentHelper::getParams('com_data');
			$viewOwnOperatorGroups = array_map('intval', (array) $params->get('viewOwnOperator', []));
			$viewOwnVendorGroups = array_map('intval', (array) $params->get('viewOwnVendor', []));

			$isSuperUser = $user->authorise('core.admin');

			if (!$isSuperUser && !empty(array_intersect($userGroupIds, $viewOwnOperatorGroups))) {
				$this->filterOperator = $userId;
			}

			if (!$isSuperUser && !empty(array_intersect($userGroupIds, $viewOwnVendorGroups))) {
				$this->filterVendor = $userId;
			}
		}
	}

	/**
	 * Resolve the selected (or default = current) ISO week into
	 * Monday 00:00:00 - Sunday 23:59:59.
	 *
	 * @return  void
	 *
	 * @since   1.3.0
	 */
	protected function resolveWeekPeriod()
	{
		$this->periodStart = new \DateTime();
		$this->periodStart->setISODate($this->filterYear, $this->filterWeek, 1)->setTime(0, 0, 0);

		$this->periodEnd = clone $this->periodStart;
		$this->periodEnd->modify('+6 days')->setTime(23, 59, 59);
	}

	/**
	 * Resolve the selected (or default = current) calendar month into
	 * the 1st 00:00:00 - last day 23:59:59.
	 *
	 * @return  void
	 *
	 * @since   1.3.0
	 */
	protected function resolveMonthPeriod()
	{
		$this->periodStart = new \DateTime();
		$this->periodStart->setDate($this->filterYear, $this->filterMonth, 1)->setTime(0, 0, 0);

		$this->periodEnd = clone $this->periodStart;
		$this->periodEnd->modify('last day of this month')->setTime(23, 59, 59);
	}

	/**
	 * Resolve the selected (or default = current) calendar year into
	 * Jan 1 00:00:00 - Dec 31 23:59:59. Used when period_type is 'week' or
	 * 'month' but no specific week/month is selected ('all' or unset).
	 *
	 * @return  void
	 *
	 * @since   1.5.0
	 */
	protected function resolveYearPeriod()
	{
		$this->periodStart = new \DateTime();
		$this->periodStart->setDate($this->filterYear, 1, 1)->setTime(0, 0, 0);

		$this->periodEnd = clone $this->periodStart;
		$this->periodEnd->setDate($this->filterYear, 12, 31)->setTime(23, 59, 59);
	}

	/**
	 * True when the resolved period is "whole year" — i.e. period_type is
	 * 'week'/'month' but the corresponding selector is 'all'.
	 *
	 * @return  boolean
	 *
	 * @since   1.5.0
	 */
	protected function isFullYearPeriod()
	{
		return ($this->filterPeriodType === 'week' && $this->filterWeek === 'all')
			|| ($this->filterPeriodType === 'month' && $this->filterMonth === 'all');
	}

	/**
	 * Decide whether the trend should bucket by day or by ISO week, based on
	 * the selected period type - shared by getTrend() and getCategoryTrend()
	 * so they always agree on the same bucketing.
	 *
	 * @return  boolean  True = bucket by week, false = bucket by day.
	 *
	 * @since   1.4.0
	 */
	protected function resolveBucketMode()
	{
		// Full-year view (week/month period type with 'all' selected) - always
		// bucket by calendar month so the trend reads as a 12-column overview.
		if ($this->isFullYearPeriod()) {
			if ($this->filterPeriodType === 'month') {
				return 'month';
			}
			if ($this->filterPeriodType === 'week') {
				return 'week';
			}
		}

		if ($this->filterPeriodType === 'month') {
			return 'week';
		}

		if ($this->filterPeriodType === 'week') {
			return 'day';
		}

		$from    = new \DateTime($this->filterDateFrom);
		$to      = new \DateTime($this->filterDateTo);
		$daySpan = $from->diff($to)->days + 1;

		return $daySpan > 30 ? 'week' : 'day';
	}

	/**
	 * SQL grouping expression for a bucket mode.
	 *
	 * @since  1.5.0
	 */
	protected function bucketExprFor($bucketMode, $dateExpr)
	{
		switch ($bucketMode) {
			case 'month':
				return "DATE_FORMAT($dateExpr, '%Y-%m')";
			case 'week':
				return "YEARWEEK($dateExpr, 3)";
			default:
				return $dateExpr;
		}
	}

	/**
	 * Reconstruct a real date from a bucket key when no NC row supplied one -
	 * only possible for day/month buckets, which already encode a real date;
	 * week buckets (YEARWEEK) have no reliable inverse without an anchor date.
	 *
	 * @since  1.5.0
	 */
	protected function fallbackBucketDate($bucketMode, $bucketKey)
	{
		if ($bucketMode === 'day') {
			return $bucketKey;
		}

		if ($bucketMode === 'month') {
			return $bucketKey . '-01';
		}

		return null;
	}

	/**
	 * Display label for a bucket, given its mode and anchor date.
	 *
	 * @since  1.5.0
	 */
	protected function bucketLabel($bucketMode, $dateStr)
	{
		if ($bucketMode === 'week') {
			return $this->weekLabelFromDate($dateStr);
		}

		if ($bucketMode === 'month') {
			return (new \DateTime($dateStr))->format('M');
		}

		return (new \DateTime($dateStr))->format('d M');
	}

	/**
	 * The currently active filters, so the view can re-populate the form.
	 *
	 * @return  object
	 *
	 * @since   1.3.0
	 */
	public function getActiveFilters()
	{
		$from = new \DateTime($this->filterDateFrom);
		$to   = new \DateTime($this->filterDateTo);

		return (object) array(
			'period_type' => $this->filterPeriodType,
			'year'        => $this->filterYear,
			'week'        => $this->filterWeek,
			'month'       => $this->filterMonth,
			'part'        => $this->filterPart,
			'model'       => $this->filterModel,
			'nc_category' => $this->filterNcCategory,
			'nc_type'     => $this->filterNcType,
			'vendor'      => $this->filterVendor,
			'operator'    => $this->filterOperator,
			'remark'      => $this->filterRemark,
			'lot'         => $this->filterLot,
			'date_from'   => $this->filterDateFrom,
			'date_to'     => $this->filterDateTo,
			'day_span'    => $from->diff($to)->days + 1,
		);
	}

	/**
	 * Years with data, newest first. Always includes the current year.
	 *
	 * @return  array  Plain list of ints, e.g. [2027, 2026, 2025]
	 */
	public function getYearOptions()
	{
		$db = Factory::getContainer()->get(DatabaseInterface::class);

		$query = $db->getQuery(true)
			->select('DISTINCT YEAR(' . $db->quoteName('date') . ') AS yr')
			->from($db->quoteName('#__data_entry'))
			->where($db->quoteName('date') . ' IS NOT NULL')
			->order('yr DESC');

		$db->setQuery($query);
		$years = array_map('intval', $db->loadColumn() ?: array());

		$currentYear = (int) (new \DateTime())->format('Y');

		if (!in_array($currentYear, $years, true)) {
			array_unshift($years, $currentYear);
			rsort($years);
		}

		return $years;
	}

	/**
	 * Recent months available for the Month Selector, newest first.
	 * Always includes the current month even with no data yet.
	 *
	 * @return  array  List of objects: { value: "2026-07", label: "July 2026" }
	 *
	 * @since   1.3.0
	 */
	public function getMonthOptions()
	{
		$db = Factory::getContainer()->get(DatabaseInterface::class);

		$query = $db->getQuery(true)
			->select('DISTINCT MONTH(' . $db->quoteName('date') . ') AS mo')
			->from($db->quoteName('#__data_entry'))
			->where('YEAR(' . $db->quoteName('date') . ') = ' . (int) $this->filterYear)
			->order('mo DESC');

		$db->setQuery($query);
		$months = array_map('intval', $db->loadColumn() ?: array());

		$now     = Factory::getDate('now', 'Asia/Kuala_Lumpur');


		if ((int) $now->format('Y') === $this->filterYear && !in_array((int) $now->format('n'), $months, true)) {
			$months[] = (int) $now->format('n');
		}

		if (empty($months) && $this->filterMonth !== 'all') {
			$months[] = $this->filterMonth;
		}

		rsort($months);

		$options = array();
		$options[] = (object) array('value' => 'all', 'label' => Text::_('COM_DATA_ALL_MONTHS'));


		foreach ($months as $m) {
			$d = Factory::getDate('now', 'Asia/Kuala_Lumpur');
			$d->setDate($this->filterYear, $m, 1);

			$options[] = (object) array(
				'value' => $m,
				'label' => $d->format('F'),
			);
		}

		return $options;
	}

	/**
	 * Distinct ISO weeks (Monday-Sunday, derived from the `date` field) available
	 * for the Week Selector, newest first. Always includes the current week.
	 *
	 * @return  array  List of objects: { value: "2026-W30", week: 30, year: 2026, label: "20 Jul - 26 Jul 2026" }
	 *
	 * @since   1.3.0
	 */
	public function getWeekOptions()
	{
		$db = Factory::getContainer()->get(DatabaseInterface::class);

		$query = $db->getQuery(true)
			->select('DISTINCT WEEK(' . $db->quoteName('date') . ', 3) AS wk') // mode 3 = ISO week, 1-53
			->from($db->quoteName('#__data_entry'))
			->where('YEAR(' . $db->quoteName('date') . ') = ' . (int) $this->filterYear)
			->order('wk DESC');

		$db->setQuery($query);
		$weeks = array_map('intval', $db->loadColumn() ?: array());

		$now = new \DateTime();

		if ((int) $now->format('o') === $this->filterYear && !in_array((int) $now->format('W'), $weeks, true)) {
			$weeks[] = (int) $now->format('W');
		}

		if (empty($weeks) && $this->filterWeek !== 'all') {
			$weeks[] = $this->filterWeek;
		}

		rsort($weeks);

		$options = array();
		$options[] = (object) array('value' => 'all', 'label' => Text::_('COM_DATA_ALL_WEEKS'));

		foreach ($weeks as $week) {
			$start = new \DateTime();
			$start->setISODate($this->filterYear, $week, 1);
			$end = (clone $start)->modify('+6 days');

			$options[] = (object) array(
				'value' => $week,
				'label' => sprintf('%s - %s', $start->format('d M'), $end->format('d M')),
			);
		}

		return $options;
	}

	/**
	 * Distinct Remark values (a.lot), for the "SELECT REMARK" filter.
	 *
	 * @return  array
	 *
	 * @since   1.3.0
	 */
	public function getLotOptions()
	{
		$db = Factory::getContainer()->get(DatabaseInterface::class);

		$query = $db->getQuery(true)
			->select(
				'DISTINCT ' . $db->quoteName('vr.id', 'value') . ', ' .
					$db->quoteName('vr.remark', 'text')
			)
			->from($db->quoteName('#__data_entry', 'a'))
			->join('INNER', $db->quoteName('#__vendor_details', 'vd') . ' ON ' . $db->quoteName('vd.id') . ' = ' . $db->quoteName('a.remark'))
			->join('INNER', $db->quoteName('#__vendor_remarks', 'vr') . ' ON ' . $db->quoteName('vr.id') . ' = ' . $db->quoteName('vd.remark'))
			->join('INNER', $db->quoteName('#__users', 'uv') . ' ON ' . $db->quoteName('uv.id') . ' = ' . $db->quoteName('a.vendor'))
			->where($db->quoteName('a.remark') . ' != ' . $db->quote(''))
			->where($db->quoteName('a.state') . ' = ' . $db->quote(1));

		// Apply selected filters, EXCEPT the current Lot filter
		$this->applyEntryFilters($db, $query, 'a', ['lot']);

		$query->order($db->quoteName('vr.remark') . ' ASC');

		$db->setQuery($query);

		return $db->loadObjectList() ?: array();
	}


	/**
	 * Distinct Part values (a.component), for the "SELECT PART" filter.
	 *
	 * @return  array
	 *
	 * @since   1.3.0
	 */
	public function getPartOptions()
	{
		$db = Factory::getContainer()->get(DatabaseInterface::class);

		$query = $db->getQuery(true)
			->select(
				'DISTINCT ' . $db->quoteName('a.component', 'value') . ', ' .
					$db->quoteName('pc.component_name', 'text')
			)
			->from($db->quoteName('#__data_entry', 'a'))
			->join('INNER', $db->quoteName('#__product_components', 'pc') . ' ON ' . $db->quoteName('pc.id') . ' = ' . $db->quoteName('a.component'))
			->where($db->quoteName('a.component') . ' != ' . $db->quote(''))
			->where($db->quoteName('a.state') . ' = ' . $db->quote(1))
			->order($db->quoteName('pc.component_name') . ' ASC');

		// Apply selected filters, EXCEPT the current Part filter
		$this->applyEntryFilters($db, $query, 'a', ['part']);

		$db->setQuery($query);

		return $db->loadObjectList() ?: array();
	}

	/**
	 * Distinct list of models available for the Model Selector.
	 *
	 * @return  array
	 *
	 * @since   1.3.0
	 */
	public function getModelOptions()
	{
		$db = Factory::getContainer()->get(DatabaseInterface::class);

		$query = $db->getQuery(true)
			->select(
				'DISTINCT ' . $db->quoteName('pm.id', 'value') . ', ' .
					$db->quoteName('pm.model_name', 'text')
			)
			->from($db->quoteName('#__data_entry', 'a'))
			->join('INNER', $db->quoteName('#__product_catalogs', 'pm') . ' ON ' . $db->quoteName('pm.id') . ' = ' . $db->quoteName('a.model'))
			->where($db->quoteName('a.model') . ' IS NOT NULL')
			->where($db->quoteName('a.state') . ' = 1');

		// Apply selected filters, EXCEPT the current Model filter
		$this->applyEntryFilters($db, $query, 'a', ['model']);

		$query->order($db->quoteName('pm.model_name') . ' ASC');

		$db->setQuery($query);

		return $db->loadObjectList() ?: array();
	}

	/**
	 * Distinct list of vendors available for the Vendor Selector.
	 *
	 * @return  array
	 *
	 * @since   1.3.0
	 */
	public function getVendorOptions()
	{
		$db = Factory::getContainer()->get(DatabaseInterface::class);

		$query = $db->getQuery(true)
			->select(
				'DISTINCT ' . $db->quoteName('a.vendor', 'key') . ', ' .
					$db->quoteName('uv.name', 'value')
			)
			->from($db->quoteName('#__data_entry', 'a'))
			->join('INNER', $db->quoteName('#__users', 'uv') . ' ON ' . $db->quoteName('uv.id') . ' = ' . $db->quoteName('a.vendor'))
			->where($db->quoteName('a.state') . ' = 1')
			->order($db->quoteName('uv.name') . ' ASC');

		// Apply selected filters, EXCEPT the current Vendor filter
		$this->applyEntryFilters($db, $query, 'a', ['vendor']);

		$db->setQuery($query);

		return $db->loadObjectList() ?: array();
	}

	/**
	 * Distinct list of operators available for the Operator Selector.
	 *
	 * @return  array
	 *
	 * @since   1.2.0
	 */
	public function getOperatorOptions()
	{
		$db = Factory::getContainer()->get(DatabaseInterface::class);

		$query = $db->getQuery(true)
			->select(
				'DISTINCT ' . $db->quoteName('a.operator', 'key') . ', ' .
					$db->quoteName('uv.name', 'value')
			)
			->from($db->quoteName('#__data_entry', 'a'))
			->join('INNER', $db->quoteName('#__users', 'uv') . ' ON ' . $db->quoteName('uv.id') . ' = ' . $db->quoteName('a.operator'))
			->where($db->quoteName('a.state') . ' = 1')
			->order($db->quoteName('uv.name') . ' ASC');

		// Apply selected filters, EXCEPT the current Vendor filter
		$this->applyEntryFilters($db, $query, 'a', ['operator']);

		$db->setQuery($query);

		return $db->loadObjectList() ?: array();
	}

	/**
	 * Distinct NC Category values in use, for the "SELECT NC CATEGORY" filter.
	 * Joined through #__data_entry_nc since nc_category lives there, not on
	 * #__data_entry itself - mirrors the com_data entries list's SQL field.
	 *
	 * @return  array
	 *
	 * @since   1.7.0
	 */
	public function getNCCategoryOptions()
	{
		$db = Factory::getContainer()->get(DatabaseInterface::class);

		$query = $db->getQuery(true)
			->select(
				'DISTINCT ' . $db->quoteName('cat.id', 'value') . ', ' .
					$db->quoteName('cat.category', 'text')
			)
			->from($db->quoteName('#__nc_category', 'cat'))
			->join(
				'INNER',
				$db->quoteName('#__data_entry_nc', 'nc') .
					' ON FIND_IN_SET(' . $db->quoteName('cat.id') . ', ' . $db->quoteName('nc.nc_category') . ')'
			)
			->join('INNER', $db->quoteName('#__data_entry', 'a') . ' ON ' . $db->quoteName('a.id') . ' = ' . $db->quoteName('nc.entry_id'))
			->where($db->quoteName('cat.state') . ' = 1')
			->where($db->quoteName('a.state') . ' = 1');


		// Apply selected filters, EXCEPT the current NC Category filter
		$this->applyEntryFilters($db, $query, 'a', ['nc_category']);

		$query->order($db->quoteName('cat.category') . ' ASC');

		$db->setQuery($query);

		return $db->loadObjectList() ?: array();
	}

	/**
	 * Distinct NC Type values in use, for the "SELECT NC TYPE" filter.
	 * Joined through #__data_entry_nc since nc_type lives there, not on
	 * #__data_entry itself - mirrors the com_data entries list's SQL field.
	 *
	 * @return  array
	 *
	 * @since   1.7.0
	 */
	public function getNCTypeOptions()
	{
		$db = Factory::getContainer()->get(DatabaseInterface::class);

		$query = $db->getQuery(true)
			->select(
				'DISTINCT ' . $db->quoteName('nt.id', 'value') . ', ' .
					$db->quoteName('nt.nc', 'text')
			)
			->from($db->quoteName('#__nc_types', 'nt'))
			->join(
				'INNER',
				$db->quoteName('#__data_entry_nc', 'nc') .
					' ON FIND_IN_SET(' . $db->quoteName('nt.id') . ', ' . $db->quoteName('nc.nc_type') . ')'
			)
			->join('INNER', $db->quoteName('#__data_entry', 'a') . ' ON ' . $db->quoteName('a.id') . ' = ' . $db->quoteName('nc.entry_id'))
			->where($db->quoteName('nt.state') . ' = 1')
			->where($db->quoteName('a.state') . ' = 1');

		// Apply selected filters, EXCEPT the current NC Type filter
		$this->applyEntryFilters($db, $query, 'a', ['nc_type']);

		$query->order($db->quoteName('nt.nc') . ' ASC');

		$db->setQuery($query);

		return $db->loadObjectList() ?: array();
	}

	public function getRemarkOptions()
	{
		$remarkOptions = array(
			'0' => Text::_('COM_DATA_LOT_NORMAL'),
			'1' => Text::_('COM_DATA_LOT_RESORT'),
		);

		return $remarkOptions;
	}

	/**
	 * The top summary cards: Total Sort, Total NC, Total Accepted, Yield%,
	 * Total NC%, plus entry/vendor/model counts - scoped to the selected
	 * date range (and Model/Vendor, if chosen).
	 *
	 * @return  object
	 *
	 * @since   1.3.0
	 */
	public function getSummary()
	{
		$db = Factory::getContainer()->get(DatabaseInterface::class);

		// Total Sort + counts: de-duplicated entry rows within the current scope.
		$entryQuery = $db->getQuery(true)
			->select(
				'COUNT(DISTINCT ' . $db->quoteName('a.id') . ') AS entry_count, ' .
					'COUNT(DISTINCT ' . $db->quoteName('a.vendor') . ') AS vendor_count, ' .
					'COUNT(DISTINCT ' . $db->quoteName('a.model') . ') AS model_count, ' .
					'SUM(' . $db->quoteName('a.total') . ') AS total_sort'
			)
			->from($db->quoteName('#__data_entry', 'a'))
			->where($db->quoteName('a.state') . ' = 1');
		$this->applyEntryFilters($db, $entryQuery, 'a', ['nc_category', 'nc_type']);

		$db->setQuery($entryQuery);
		$entryRow = $db->loadObject();

		$totalSort   = $entryRow ? (float) $entryRow->total_sort : 0.0;
		$entryCount  = $entryRow ? (int) $entryRow->entry_count : 0;
		$vendorCount = $entryRow ? (int) $entryRow->vendor_count : 0;
		$modelCount  = $entryRow ? (int) $entryRow->model_count : 0;

		// Total NC: sum of every NC row's quantity within the current scope.
		$ncQuery = $db->getQuery(true)
			->select('SUM(' . $db->quoteName('nc.nc_quantity') . ') AS total_nc')
			->from($db->quoteName('#__data_entry_nc', 'nc'))
			->join('INNER', $db->quoteName('#__data_entry', 'a') . ' ON ' . $db->quoteName('a.id') . ' = ' . $db->quoteName('nc.entry_id'))
			->where($db->quoteName('a.state') . ' = 1');
		$this->applyEntryFilters($db, $ncQuery, 'a', ['nc_category', 'nc_type']);

		// --- NEW: restrict the actual NC rows summed, not just which entries qualify ---
		if ($this->filterNcCategory !== '') {
			$ncQuery->where('FIND_IN_SET(' . $db->quote($this->filterNcCategory) . ', ' . $db->quoteName('nc.nc_category') . ')');
		}

		if ($this->filterNcType !== '') {
			$ncQuery->where('FIND_IN_SET(' . $db->quote($this->filterNcType) . ', ' . $db->quoteName('nc.nc_type') . ')');
		}
		// --- end NEW ---

		$db->setQuery($ncQuery);
		$totalNc = (float) $db->loadResult();

		$totalAccepted = $totalSort - $totalNc;
		$yieldPct      = $totalSort > 0 ? ($totalAccepted / $totalSort) * 100 : 0.0;
		$totalNcPct    = $totalSort > 0 ? ($totalNc / $totalSort) * 100 : 0.0;

		return (object) array(
			'total_sort'     => $totalSort,
			'total_nc'       => $totalNc,
			'total_accepted' => $totalAccepted,
			'yield_pct'      => $yieldPct,
			'total_nc_pct'   => $totalNcPct,
			'entry_count'    => $entryCount,
			'vendor_count'   => $vendorCount,
			'model_count'    => $modelCount,
		);
	}

	/**
	 * Sort vs. NC over time within the selected range. Buckets by day when
	 * the range is 45 days or less, otherwise by ISO week, so the chart
	 * stays readable for long ranges.
	 *
	 * @return  object  { bucket, points: [{ label, sort, nc, nc_pct }] }
	 *
	 * @since   1.3.0
	 */
	public function getTrend()
	{
		$db = Factory::getContainer()->get(DatabaseInterface::class);

		$bucketMode   = $this->resolveBucketMode();
		$sortByBucket = $this->getSortPerBucket($db, $bucketMode);

		$bucketExpr = $this->bucketExprFor($bucketMode, 'DATE(' . $db->quoteName('a.date') . ')');

		$ncQuery = $db->getQuery(true)
			->select(
				$bucketExpr . ' AS bucket, ' .
					'MIN(DATE(' . $db->quoteName('a.date') . ')) AS bucket_start, ' .
					'SUM(' . $db->quoteName('nc.nc_quantity') . ') AS nc_qty'
			)
			->from($db->quoteName('#__data_entry_nc', 'nc'))
			->join('INNER', $db->quoteName('#__data_entry', 'a') . ' ON ' . $db->quoteName('a.id') . ' = ' . $db->quoteName('nc.entry_id'))
			->where($db->quoteName('a.state') . ' = 1');
		$this->applyEntryFilters($db, $ncQuery, 'a', ['nc_category', 'nc_type']);

		// --- NEW: filter the actual NC rows being summed, not just which entries qualify ---
		if ($this->filterNcCategory !== '') {
			$ncQuery->where('FIND_IN_SET(' . $db->quote($this->filterNcCategory) . ', ' . $db->quoteName('nc.nc_category') . ')');
		}

		if ($this->filterNcType !== '') {
			$ncQuery->where('FIND_IN_SET(' . $db->quote($this->filterNcType) . ', ' . $db->quoteName('nc.nc_type') . ')');
		}
		// --- end NEW ---

		$db->setQuery($ncQuery);
		$ncRows = $db->loadObjectList() ?: array();

		$bucketDates = array();

		foreach ($ncRows as $r) {
			$bucketDates[(string) $r->bucket] = $r->bucket_start;
		}

		$allBucketKeys = array_unique(array_merge(array_keys($sortByBucket), array_keys($bucketDates)));
		sort($allBucketKeys);

		$ncByBucket = array();

		foreach ($ncRows as $r) {
			$ncByBucket[(string) $r->bucket] = (float) $r->nc_qty;
		}

		$points = array();

		foreach ($allBucketKeys as $bucketKey) {
			$sortQty = $sortByBucket[$bucketKey] ?? 0.0;
			$ncQty   = $ncByBucket[$bucketKey] ?? 0.0;

			$bucketStart = $bucketDates[$bucketKey] ?? $this->fallbackBucketDate($bucketMode, $bucketKey);

			if ($bucketStart === null) {
				continue;
			}

			$points[] = (object) array(
				'label'  => $this->bucketLabel($bucketMode, $bucketStart),
				'date'   => $bucketStart,
				'sort'   => $sortQty,
				'nc'     => $ncQty,
				'nc_pct' => $sortQty > 0 ? ($ncQty / $sortQty) * 100 : 0.0,
			);
		}

		return (object) array(
			'bucket' => $bucketMode,
			'points' => $points,
		);
	}

	/**
	 * De-duplicated Total Sort per bucket (day or week) - shared by getTrend()
	 * and getCategoryTrend() so both compute NC Rate against the exact same
	 * production volume figures.
	 *
	 * @param   DatabaseInterface  $db      The database driver.
	 * @param   boolean            $byWeek  True = bucket by ISO week, false = by day.
	 *
	 * @return  array  [bucketKey => sortQty]
	 *
	 * @since   1.4.0
	 */
	protected function getSortPerBucket(DatabaseInterface $db, $bucketMode)
	{
		$sortSubQuery = $db->getQuery(true)
			->select(
				'DISTINCT ' . $db->quoteName('a.id') . ', ' .
					$db->quoteName('a.total') . ', ' .
					'DATE(' . $db->quoteName('a.date') . ') AS entry_date'
			)
			->from($db->quoteName('#__data_entry', 'a'))
			->where($db->quoteName('a.state') . ' = 1');
		$this->applyEntryFilters($db, $sortSubQuery, 'a', ['nc_category', 'nc_type']);

		$bucketExpr = $this->bucketExprFor($bucketMode, 'entry_date');

		$sortQuery = $db->getQuery(true)
			->select($bucketExpr . ' AS bucket, SUM(total) AS sort_qty')
			->from('(' . (string) $sortSubQuery . ') AS dedup')
			->group('bucket');

		$db->setQuery($sortQuery);
		$rows = $db->loadObjectList() ?: array();

		$result = array();

		foreach ($rows as $r) {
			$result[(string) $r->bucket] = (float) $r->sort_qty;
		}

		return $result;
	}

	/**
	 * NC quantity per bucket (day or week, matching getTrend()'s bucketing),
	 * split by Category - the data behind the multi-line "NC by Category"
	 * trend chart. Limited to the top N categories by total volume within
	 * the current scope, with everything else rolled into "Other".
	 *
	 * @param   integer  $limit  Maximum number of individual category lines to return.
	 *
	 * @return  object  { buckets: [{ label, date }], categories: [{ label, values: [qty...] }] }
	 *
	 * @since   1.4.0
	 */
	public function getCategoryTrend($limit = 5)
	{
		$db         = Factory::getContainer()->get(DatabaseInterface::class);
		$bucketMode = $this->resolveBucketMode();

		$sortByBucket = $this->getSortPerBucket($db, $bucketMode);

		$bucketExpr = $this->bucketExprFor($bucketMode, 'DATE(' . $db->quoteName('a.date') . ')');

		$query = $db->getQuery(true)
			->select(
				$bucketExpr . ' AS bucket, ' .
					'MIN(DATE(' . $db->quoteName('a.date') . ')) AS bucket_start, ' .
					$db->quoteName('nc.nc_category', 'nc_category') . ', ' .
					'SUM(' . $db->quoteName('nc.nc_quantity') . ') AS qty'
			)
			->from($db->quoteName('#__data_entry_nc', 'nc'))
			->join('INNER', $db->quoteName('#__data_entry', 'a') . ' ON ' . $db->quoteName('a.id') . ' = ' . $db->quoteName('nc.entry_id'))
			->where($db->quoteName('a.state') . ' = 1')
			->group('bucket, ' . $db->quoteName('nc.nc_category'))
			->order('bucket ASC');
		$this->applyEntryFilters($db, $query, 'a', ['nc_category', 'nc_type']);

		// --- NEW ---
		if ($this->filterNcCategory !== '') {
			$query->where('FIND_IN_SET(' . $db->quote($this->filterNcCategory) . ', ' . $db->quoteName('nc.nc_category') . ')');
		}

		if ($this->filterNcType !== '') {
			$query->where('FIND_IN_SET(' . $db->quote($this->filterNcType) . ', ' . $db->quoteName('nc.nc_type') . ')');
		}
		// --- end NEW ---

		$db->setQuery($query);
		$raw = $db->loadObjectList() ?: array();

		$bucketOrder = array();
		$bucketStart = array();

		foreach ($raw as $r) {
			$key = (string) $r->bucket;

			if (!isset($bucketStart[$key])) {
				$bucketOrder[]     = $key;
				$bucketStart[$key] = $r->bucket_start;
			}
		}

		$buckets = array();

		foreach ($bucketOrder as $key) {
			$date = $bucketStart[$key];
			$sort = $sortByBucket[$key] ?? 0.0;
			$nc   = 0.0;

			foreach ($raw as $r) {
				if ((string) $r->bucket === $key) {
					$nc += (float) $r->qty;
				}
			}

			$buckets[] = (object) array(
				'label'    => $this->bucketLabel($bucketMode, $date),
				'date'     => $date,
				'sort'     => $sort,
				'total_nc' => $nc,
				'nc_rate'  => $sort > 0 ? round(($nc / $sort) * 100, 2) : 0.0,
			);
		}

		$totalByCategory = array();

		foreach ($raw as $r) {
			$catKey = (string) $r->nc_category;
			$totalByCategory[$catKey] = ($totalByCategory[$catKey] ?? 0.0) + (float) $r->qty;
		}

		arsort($totalByCategory);
		$topCategoryKeys = array_map('strval', array_slice(array_keys($totalByCategory), 0, $limit));

		$matrix = array();

		foreach ($raw as $r) {
			$catKey    = (string) $r->nc_category;
			$bucketKey = (string) $r->bucket;
			$rowKey    = in_array($catKey, $topCategoryKeys, true) ? $catKey : '__other__';

			$matrix[$rowKey][$bucketKey] = ($matrix[$rowKey][$bucketKey] ?? 0.0) + (float) $r->qty;
		}

		$buildRow = function ($catKey, $label) use ($matrix, $bucketOrder, $sortByBucket) {
			$values = array();

			foreach ($bucketOrder as $bucketKey) {
				$qty  = $matrix[$catKey][$bucketKey] ?? 0.0;
				$sort = $sortByBucket[$bucketKey] ?? 0.0;

				$values[] = (object) array(
					'qty'  => $qty,
					'rate' => $sort > 0 ? round(($qty / $sort) * 100, 2) : 0.0,
				);
			}

			return (object) array('label' => $label, 'values' => $values);
		};

		$categories = array();

		foreach ($topCategoryKeys as $catKey) {
			$categories[] = $buildRow($catKey, $this->resolveCategoryLabel($db, $catKey));
		}

		if (isset($matrix['__other__'])) {
			$categories[] = $buildRow('__other__', 'OTHER CATEGORIES');
		}

		return (object) array(
			'buckets'    => $buckets,
			'categories' => $categories,
		);
	}

	/**
	 * Human label for the ISO week containing the given date, e.g. "Wk 29 (13 Jul)".
	 *
	 * @param   string  $dateStr  Y-m-d date within the target week.
	 *
	 * @return  string
	 *
	 * @since   1.3.0
	 */
	protected function weekLabelFromDate($dateStr)
	{
		$date = new \DateTime($dateStr);

		return sprintf('Week %d (%s)', (int) $date->format('W'), $date->format('d M'));
	}

	public function gettotalSort()
	{
		$db = Factory::getContainer()->get(DatabaseInterface::class);

		$sortSubQuery = $db->getQuery(true)
			->select(
				'SUM(' . $db->quoteName('a.total') . ') AS total_sort'
			)
			->from($db->quoteName('#__data_entry', 'a'))
			->where($db->quoteName('a.state') . ' = 1');
		$this->applyEntryFilters($db, $sortSubQuery, 'a', ['nc_category', 'nc_type']);

		$db->setQuery($sortSubQuery);
		$totalSort = $db->loadResult();

		$fp = fopen("a_gettotalSort.txt", "w");
		$write["totalSort"] = $totalSort;
		fwrite($fp, print_r($write, true));
		fclose($fp);

		return $totalSort;
	}

	/**
	 * NC quantity broken down by Category, ranked by volume within the
	 * current scope. Limited to the top N categories, with any remainder
	 * rolled up into an "Other" row.
	 *
	 * @param   integer  $limit  Maximum number of individual categories to return.
	 *
	 * @return  array  Objects: { nc_category, qty, pct_of_nc }
	 *
	 * @since   1.3.0
	 */
	public function getCategoryBreakdown($limit = 8)
	{
		$db = Factory::getContainer()->get(DatabaseInterface::class);

		$query = $db->getQuery(true)
			->select(
				$db->quoteName('nc.nc_category', 'nc_category') . ', ' .
					'SUM(' . $db->quoteName('nc.nc_quantity') . ') AS qty'
			)
			->from($db->quoteName('#__data_entry_nc', 'nc'))
			->join('INNER', $db->quoteName('#__data_entry', 'a') . ' ON ' . $db->quoteName('a.id') . ' = ' . $db->quoteName('nc.entry_id'))
			->where($db->quoteName('a.state') . ' = 1')
			->group($db->quoteName('nc.nc_category'))
			->order('qty DESC');
		$this->applyEntryFilters($db, $query, 'a', ['nc_category', 'nc_type']);

		// --- NEW ---
		if ($this->filterNcCategory !== '') {
			$query->where('FIND_IN_SET(' . $db->quote($this->filterNcCategory) . ', ' . $db->quoteName('nc.nc_category') . ')');
		}

		if ($this->filterNcType !== '') {
			$query->where('FIND_IN_SET(' . $db->quote($this->filterNcType) . ', ' . $db->quoteName('nc.nc_type') . ')');
		}
		// --- end NEW ---

		$db->setQuery($query);
		$raw = $db->loadObjectList() ?: array();

		$totalNc = 0.0;

		foreach ($raw as $r) {
			$totalNc += (float) $r->qty;
		}

		$totalSort = $this->gettotalSort();

		$rows  = array();
		$other = 0.0;

		foreach ($raw as $i => $r) {
			if ($i < $limit) {
				$categoryLabel = $this->resolveCategoryLabel($db, $r->nc_category);

				$rows[] = (object) array(
					'nc_category' => $categoryLabel,
					'qty'         => (float) $r->qty,
					'pct_of_nc'   => $totalSort > 0 ? ((float) $r->qty / $totalSort) * 100 : 0.00,
					'pct_of_impact'   => $totalNc > 0 ? ((float) $r->qty / $totalNc) * 100 : 0.00,
				);
			} else {
				$other += (float) $r->qty;
			}
		}

		if ($other > 0) {
			$rows[] = (object) array(
				'nc_category' => 'OTHER CATEGORIES',
				'qty'         => $other,
				'pct_of_nc'   => $totalSort > 0 ? ($other / $totalSort) * 100 : 0.00,
				'pct_of_impact'   => $totalNc > 0 ? ($other / $totalNc) * 100 : 0.00,
			);
		}

		return $rows;
	}

	/**
	 * Resolve a stored NC category id/value to a display label via the
	 * lookup table, falling back to the raw stored value if it isn't found.
	 *
	 * @param   DatabaseInterface  $db   The database driver.
	 * @param   string             $raw  The stored nc_category value.
	 *
	 * @return  string
	 *
	 * @since   1.3.0
	 */
	protected function resolveCategoryLabel(DatabaseInterface $db, $raw)
	{
		if ($raw === null || $raw === '') {
			return '(Uncategorised)';
		}

		$query = $db->getQuery(true)
			->select($db->quoteName('category'))
			->from($db->quoteName('#__nc_category'))
			->where($db->quoteName('id') . ' = ' . $db->quote($raw));

		$db->setQuery($query);
		$label = $db->loadResult();

		return $label !== null && $label !== '' ? $label : $raw;
	}

	/**
	 * NC quantity broken down by Category, ranked by volume within the
	 * current scope. Limited to the top N categories, with any remainder
	 * rolled up into an "Other" row.
	 *
	 * @param   integer  $limit  Maximum number of individual categories to return.
	 *
	 * @return  array  Objects: { nc_category, qty, pct_of_nc }
	 *
	 * @since   1.3.0
	 */
	public function getNcTypeBreakdown($limit = 7)
	{
		$db = Factory::getContainer()->get(DatabaseInterface::class);

		$query = $db->getQuery(true)
			->select(
				$db->quoteName('nc.nc_type', 'nc_type') . ', ' .
					'SUM(' . $db->quoteName('nc.nc_quantity') . ') AS qty'
			)
			->from($db->quoteName('#__data_entry_nc', 'nc'))
			->join('INNER', $db->quoteName('#__data_entry', 'a') . ' ON ' . $db->quoteName('a.id') . ' = ' . $db->quoteName('nc.entry_id'))
			->where($db->quoteName('a.state') . ' = 1')
			->group($db->quoteName('nc.nc_type'))
			->order('qty DESC');
		$this->applyEntryFilters($db, $query, 'a', ['nc_category', 'nc_type']);

		// --- NEW ---
		if ($this->filterNcCategory !== '') {
			$query->where('FIND_IN_SET(' . $db->quote($this->filterNcCategory) . ', ' . $db->quoteName('nc.nc_category') . ')');
		}

		if ($this->filterNcType !== '') {
			$query->where('FIND_IN_SET(' . $db->quote($this->filterNcType) . ', ' . $db->quoteName('nc.nc_type') . ')');
		}
		// --- end NEW ---

		$db->setQuery($query);
		$raw = $db->loadObjectList() ?: array();

		$totalNc = 0.0;

		foreach ($raw as $r) {
			$totalNc += (float) $r->qty;
		}

		$totalSort = $this->gettotalSort();

		$rows  = array();
		$other = 0.0;

		foreach ($raw as $i => $r) {
			if ($i < $limit) {
				$ncTypeLabel = $this->resolveNcTypeLabel($db, $r->nc_type);

				$rows[] = (object) array(
					'nc_type' 	  => $ncTypeLabel,
					'qty'         => (float) $r->qty,
					'pct_of_nc'   => $totalSort > 0 ? ((float) $r->qty / $totalSort) * 100 : 0.00,
					'pct_of_impact'   => $totalNc > 0 ? ((float) $r->qty / $totalNc) * 100 : 0.00,
				);
			} else {
				$other += (float) $r->qty;
			}
		}

		if ($other > 0) {
			$rows[] = (object) array(
				'nc_type' 	  => 'OTHER TYPES',
				'qty'         => $other,
				'pct_of_nc'   => $totalSort > 0 ? ($other / $totalSort) * 100 : 0.00,
				'pct_of_impact'   => $totalNc > 0 ? ($other / $totalNc) * 100 : 0.00,
			);
		}

		return $rows;
	}

	/**
	 * Resolve a stored NC type id/value to a display label via the
	 * lookup table, falling back to the raw stored value if it isn't found.
	 *
	 * @param   DatabaseInterface  $db   The database driver.
	 * @param   string             $raw  The stored nc_type value.
	 *
	 * @return  string
	 *
	 * @since   1.3.0
	 */
	protected function resolveNcTypeLabel(DatabaseInterface $db, $raw)
	{
		if ($raw === null || $raw === '') {
			return '(Uncategorised)';
		}

		$query = $db->getQuery(true)
			->select($db->quoteName('nc'))
			->from($db->quoteName('#__nc_types'))
			->where($db->quoteName('id') . ' = ' . $db->quote($raw));

		$db->setQuery($query);
		$label = $db->loadResult();

		return $label !== null && $label !== '' ? $label : $raw;
	}

	/**
	 * Vendors ranked by NC% (high to low) within the current scope.
	 *
	 * @param   integer  $limit  Maximum number of vendors to return.
	 *
	 * @return  object  { rows: [{ label, total_sort, total_nc, nc_pct }], excluded: int }
	 *
	 * @since   1.3.0
	 */
	public function getVendorBreakdown($limit = 8)
	{
		return $this->getEntityBreakdown('a.vendor', '#__users', 'name', $limit);
	}

	/**
	 * Models ranked by NC% (high to low) within the current scope, each also
	 * carrying its most common associated Part for display.
	 *
	 * @param   integer  $limit  Maximum number of models to return.
	 *
	 * @return  object  { rows: [{ label, part_label, total_sort, total_nc, nc_pct }], excluded: int }
	 *
	 * @since   1.3.0
	 */
	public function getModelBreakdown($limit = 5)
	{
		return $this->getEntityBreakdown(
			'a.model',
			'#__product_catalogs',
			'model_name',
			$limit,
			'a.component',
			'#__product_components',
			'component_name'
		);
	}

	/**
	 * Shared implementation for the Vendor/Model breakdown tables: Total
	 * Sort (de-duplicated by entry) and Total NC per distinct value of the
	 * given column, joined to its lookup table for a display label.
	 *
	 * Ranked by NC% (high to low), not by volume - entities with less than
	 * $minSort total units sorted are excluded from the ranking entirely,
	 * since a tiny batch with one defect can otherwise show a misleadingly
	 * high NC% and crowd out entities with real, meaningful volume. The
	 * excluded count is returned alongside the rows so the UI can say so
	 * explicitly, rather than silently dropping entries with no explanation.
	 *
	 * An optional extra column (e.g. Part, for the Model breakdown) can be
	 * carried through and resolved to its own label. Since that extra column
	 * isn't guaranteed to be single-valued per entity (nothing in the schema
	 * enforces "one Model always has exactly one Part"), the MOST COMMON
	 * value across matching entries is used - not simply the first one found.
	 *
	 * @param   string       $column           Fully-qualified column on #__data_entry, e.g. 'a.vendor'.
	 * @param   string       $lookupTable      Lookup table holding the display name.
	 * @param   string       $labelField       Column on the lookup table holding the display name.
	 * @param   integer      $limit            Maximum number of rows to return.
	 * @param   string|null  $extraColumn      Optional second fully-qualified column to carry through, e.g. 'a.component'.
	 * @param   string|null  $extraLookupTable Lookup table for the extra column's label.
	 * @param   string|null  $extraLabelField  Column on the extra lookup table holding the display name.
	 *
	 * @return  object  { rows: [{ label, [extra_label,] total_sort, total_nc, nc_pct }], excluded: int }
	 *
	 * @since   1.3.0
	 */
	protected function getEntityBreakdown(
		$column,
		$lookupTable,
		$labelField,
		$limit,
		$extraColumn = null,
		$extraLookupTable = null,
		$extraLabelField = null
	) {
		$db = Factory::getContainer()->get(DatabaseInterface::class);

		// Total Sort per entity: de-duplicated entries first, then summed.
		// No SQL-level ORDER BY here - sorting happens after NC% is computed
		// below, since ranking is by NC rate, not by Total Sort.
		$selectCols = 'DISTINCT ' . $db->quoteName('a.id') . ', ' .
			$db->quoteName($column) . ' AS entity_key, ' .
			$db->quoteName('a.total');

		if ($extraColumn !== null) {
			$selectCols .= ', ' . $db->quoteName($extraColumn) . ' AS extra_key';
		}

		$sortSubQuery = $db->getQuery(true)
			->select($selectCols)
			->from($db->quoteName('#__data_entry', 'a'))
			->where($db->quoteName('a.state') . ' = 1')
			->where($db->quoteName($column) . ' IS NOT NULL');
		$this->applyEntryFilters($db, $sortSubQuery, 'a', ['nc_category', 'nc_type']);

		$sortQuery = $db->getQuery(true)
			->select('entity_key, SUM(total) AS total_sort')
			->from('(' . (string) $sortSubQuery . ') AS dedup')
			->group('entity_key');

		$db->setQuery($sortQuery);
		$sortRows = $db->loadObjectList() ?: array();

		// Total NC per entity, over the same scope.
		$ncQuery = $db->getQuery(true)
			->select(
				$db->quoteName($column) . ' AS entity_key, ' .
					'SUM(' . $db->quoteName('nc.nc_quantity') . ') AS total_nc'
			)
			->from($db->quoteName('#__data_entry_nc', 'nc'))
			->join('INNER', $db->quoteName('#__data_entry', 'a') . ' ON ' . $db->quoteName('a.id') . ' = ' . $db->quoteName('nc.entry_id'))
			->where($db->quoteName('a.state') . ' = 1')
			->where($db->quoteName($column) . ' IS NOT NULL')
			->group($db->quoteName($column));
		$this->applyEntryFilters($db, $ncQuery, 'a', ['nc_category', 'nc_type']);

		// --- NEW: restrict the actual NC rows summed, not just which entries qualify ---
		if ($this->filterNcCategory !== '') {
			$ncQuery->where('FIND_IN_SET(' . $db->quote($this->filterNcCategory) . ', ' . $db->quoteName('nc.nc_category') . ')');
		}

		if ($this->filterNcType !== '') {
			$ncQuery->where('FIND_IN_SET(' . $db->quote($this->filterNcType) . ', ' . $db->quoteName('nc.nc_type') . ')');
		}

		$db->setQuery($ncQuery);
		$ncRows = $db->loadObjectList() ?: array();

		$ncByKey = array();

		foreach ($ncRows as $r) {
			$ncByKey[(string) $r->entity_key] = (float) $r->total_nc;
		}

		// Replace the entire "most common extra_key" block with a direct lookup
		// of each entity's canonical extra value from the catalog itself.
		$extraByKey = array();

		if ($extraColumn !== null && $column === 'a.model') {
			$catalogQuery = $db->getQuery(true)
				->select($db->quoteName('id') . ', ' . $db->quoteName('component'))
				->from($db->quoteName('#__product_catalogs'))
				->where($db->quoteName('component') . ' IS NOT NULL');
			$db->setQuery($catalogQuery);

			foreach ($db->loadObjectList() as $r) {
				$extraByKey[(string) $r->id] = (string) $r->component;
			}
		}

		// Compute NC% for every entity first.
		$all = array();

		// $totalSort = $this->gettotalSort();

		foreach ($sortRows as $r) {
			$key       = (string) $r->entity_key;
			$totalSort = (float) $r->total_sort;
			$totalNc   = $ncByKey[$key] ?? 0.0;

			$all[] = (object) array(
				'entity_key' => $key,
				'extra_key'  => $extraByKey[$key] ?? null,
				'total_sort' => $totalSort,
				'total_nc'   => $totalNc,
				'nc_pct'     => $totalSort > 0 ? ($totalNc / $totalSort) * 100 : 0.0,
			);
		}

		$totalCandidates = count($all);

		// Drop entities with zero NC - "Top N by NC Rate" isn't meaningful
		// for rows that have no NC to rank in the first place.
		$all = array_values(
			array_filter(
				$all,
				function ($row) {
					return $row->total_nc > 0;
				}
			)
		);

		$excludedCount = $totalCandidates - count($all);

		usort(
			$all,
			function ($a, $b) {
				return $b->nc_pct <=> $a->nc_pct; // high to low
			}
		);

		$rows = array();

		foreach (array_slice($all, 0, $limit) as $r) {
			$labelQuery = $db->getQuery(true)
				->select($db->quoteName($labelField))
				->from($db->quoteName($lookupTable))
				->where($db->quoteName('id') . ' = ' . $db->quote($r->entity_key));
			$db->setQuery($labelQuery);
			$label = $db->loadResult();

			$row = array(
				'entity_id'  => $r->entity_key,          // model id (a.model)
				'part_id'    => $r->extra_key ?? null,   // part id (catalog component)
				'label'      => $label !== null && $label !== '' ? $label : $r->entity_key,
				'total_sort' => $r->total_sort,
				'total_nc'   => $r->total_nc,
				'nc_pct'     => $r->nc_pct,
			);

			if ($extraColumn !== null) {
				$extraLabel = null;

				if ($r->extra_key !== null) {
					$extraLabelQuery = $db->getQuery(true)
						->select($db->quoteName($extraLabelField))
						->from($db->quoteName($extraLookupTable))
						->where($db->quoteName('id') . ' = ' . $db->quote($r->extra_key));
					$db->setQuery($extraLabelQuery);
					$extraLabel = $db->loadResult();
				}

				$row['part_label'] = $extraLabel !== null && $extraLabel !== '' ? $extraLabel : $r->extra_key;
			}

			$rows[] = (object) $row;
		}

		return (object) array(
			'rows'     => $rows,
			'excluded' => $excludedCount,

		);
	}

	/**
	 * Recent "Kokeshi" entries - NC rows that have at least one uploaded
	 * photo, within the current scope (date range, Model/Vendor if selected).
	 * Newest first.
	 *
	 * @param   integer  $limit  Maximum number of rows to return.
	 *
	 * @return  array  Objects: { nc_id, entry_id, date, reference_no, component,
	 *                  model, vendor, nc_category, nc_quantity, total_sort,
	 *                  nc_rate, images }
	 *
	 * @since   1.4.0
	 */
	public function getKokeshiEntries()
	{
		$db = Factory::getContainer()->get(DatabaseInterface::class);

		$query = $db->getQuery(true)
			->select(
				$db->quoteName('nc.id', 'nc_id') . ', ' .
					$db->quoteName('nc.nc_category', 'nc_category_raw') . ', ' .
					$db->quoteName('nc.nc_type', 'nc_type_raw') . ', ' .
					$db->quoteName('nc.nc_quantity') . ', ' .
					$db->quoteName('nc.nc_percentage') . ', ' .
					$db->quoteName('a.id', 'entry_id') . ', ' .
					$db->quoteName('a.reference_no') . ', ' .
					$db->quoteName('a.date') . ', ' .
					$db->quoteName('a.total', 'total_sort') . ', ' .
					$db->quoteName('a.component') . ', ' .
					$db->quoteName('a.model') . ', ' .
					$db->quoteName('a.vendor')
			)
			->from($db->quoteName('#__data_entry_nc', 'nc'))
			->join('INNER', $db->quoteName('#__data_entry', 'a') . ' ON ' . $db->quoteName('a.id') . ' = ' . $db->quoteName('nc.entry_id'))
			->where($db->quoteName('a.state') . ' = 1')
			->where($db->quoteName('nc.nc_category') . ' = 8')
			->order($db->quoteName('nc.nc_percentage') . ' DESC');
		$this->applyEntryFilters($db, $query, 'a', ['nc_category', 'nc_type']);

		// --- NEW ---
		if ($this->filterNcCategory !== '') {
			$query->where('FIND_IN_SET(' . $db->quote($this->filterNcCategory) . ', ' . $db->quoteName('nc.nc_category') . ')');
		}

		if ($this->filterNcType !== '') {
			$query->where('FIND_IN_SET(' . $db->quote($this->filterNcType) . ', ' . $db->quoteName('nc.nc_type') . ')');
		}
		// --- end NEW ---

		$db->setQuery($query);
		$rows = $db->loadObjectList() ?: array();

		if (empty($rows)) {
			return array();
		}

		$componentIds = array_values(array_unique(array_filter(array_map(fn($r) => $r->component, $rows))));
		$modelIds     = array_values(array_unique(array_filter(array_map(fn($r) => $r->model, $rows))));
		$vendorIds    = array_values(array_unique(array_filter(array_map(fn($r) => $r->vendor, $rows))));
		$ncTypeIds    = array_values(array_unique(array_filter(array_map(fn($r) => $r->nc_type_raw, $rows))));
		$ncIds        = array_map(fn($r) => (int) $r->nc_id, $rows);

		$componentNames = $this->loadLabelMap($db, '#__product_components', 'id', 'component_name', $componentIds);
		$modelNames     = $this->loadLabelMap($db, '#__product_catalogs', 'id', 'model_name', $modelIds);
		$vendorNames    = $this->loadLabelMap($db, '#__users', 'id', 'name', $vendorIds);
		$ncTypes    	= $this->loadLabelMap($db, '#__nc_types', 'id', 'nc', $ncTypeIds);
		$imagesByNc     = $this->loadImagesForNcIds($db, $ncIds);

		$result = array();

		foreach ($rows as $r) {
			$totalSort = (float) $r->total_sort;
			$qty       = (float) $r->nc_quantity;

			$result[] = (object) array(
				'nc_id'       => (int) $r->nc_id,
				'entry_id'    => (int) $r->entry_id,
				'date'        => $r->date,
				'reference_no' => $r->reference_no,
				'component'   => $componentNames[$r->component] ?? $r->component,
				'model'       => $modelNames[$r->model] ?? $r->model,
				'vendor'      => $vendorNames[$r->vendor] ?? $r->vendor,
				'nc_category' => $this->resolveCategoryLabel($db, $r->nc_category_raw),
				'nc_type' 	  => $ncTypes[$r->nc_type_raw] ?? $r->nc_type_raw,
				'nc_quantity' => $qty,
				'total_sort'  => $totalSort,
				'nc_rate'     => $totalSort > 0 ? round(($qty / $totalSort) * 100, 2) : 0.0,
				'images'      => $imagesByNc[$r->nc_id] ?? array(),
			);
		}

		return $result;
	}

	/**
	 * Small id -> label lookup, shared across the breakdown/Kokeshi methods.
	 *
	 * @since   1.4.0
	 */
	protected function loadLabelMap(DatabaseInterface $db, $table, $keyCol, $labelCol, array $ids)
	{
		if (empty($ids)) {
			return array();
		}

		$query = $db->getQuery(true)
			->select($db->quoteName([$keyCol, $labelCol]))
			->from($db->quoteName($table))
			->where($db->quoteName($keyCol) . ' IN (' . implode(',', array_map('intval', $ids)) . ')');

		$db->setQuery($query);

		$map = array();

		foreach ($db->loadAssocList() as $row) {
			$map[$row[$keyCol]] = $row[$labelCol];
		}

		return $map;
	}

	/**
	 * Uploaded image URLs per NC row id.
	 *
	 * NOTE: this reads the 'image_path' column - if your table's actual
	 * column is named 'filepath' instead, update BOTH the select() and the
	 * $row->image_path reference below to match, or this will throw an
	 * "Unknown column" error the moment any Kokeshi row has images.
	 *
	 * @since   1.4.0
	 */
	protected function loadImagesForNcIds(DatabaseInterface $db, array $ncIds)
	{
		if (empty($ncIds)) {
			return array();
		}

		$query = $db->getQuery(true)
			->select($db->quoteName(['nc_id', 'filepath']))
			->from($db->quoteName('#__data_entry_nc_images'))
			->where($db->quoteName('nc_id') . ' IN (' . implode(',', array_map('intval', $ncIds)) . ')')
			->order($db->quoteName('ordering') . ' ASC, ' . $db->quoteName('id') . ' ASC');

		$db->setQuery($query);

		$map = array();

		foreach ($db->loadObjectList() as $row) {
			$map[$row->nc_id][] = rtrim(\Joomla\CMS\Uri\Uri::root(), '/') . '/' . ltrim($row->image_path, '/');
		}

		return $map;
	}

	/**
	 * Apply access control, then the Model/Vendor/etc. filters and the
	 * selected date range - shared by every query in this model. Assumes
	 * the base entry table is aliased $alias (default 'a').
	 *
	 * Access control is based on three usergrouplist params in com_data's
	 * component config: viewAll, viewOwnOperator, viewOwnVendor. This is
	 * NOT excludable via $exclude and NOT optional - every call site gets
	 * it, since it's a security boundary rather than a user-selectable
	 * filter. A user covered by none of the three groups (and not
	 * core.admin) is blocked entirely (1=0), matching the "fail closed"
	 * requirement - a missing/misconfigured param means nobody sees data,
	 * not everybody.
	 *
	 * @param   DatabaseInterface               $db      The database driver.
	 * @param   \Joomla\Database\DatabaseQuery  $query   The query to constrain.
	 * @param   string                           $alias   Alias of the #__data_entry table in $query.
	 * @param   array                            $exclude Filter keys to skip (e.g. ['lot'] when building the Lot dropdown itself).
	 *
	 * @return  void
	 *
	 * @since   1.3.0
	 */
	protected function applyEntryFilters(DatabaseInterface $db, $query, $alias = 'a', array $exclude = [])
	{
		// --- Access control ---
		$user = Factory::getApplication()->getIdentity();

		$userId       = (int) $user->get('id');
		$userGroupIds = array_map('intval', (array) $user->get('groups'));

		$params = ComponentHelper::getParams('com_data');

		$viewAllGroups         = array_map('intval', (array) $params->get('viewAll', []));
		$viewOwnOperatorGroups = array_map('intval', (array) $params->get('viewOwnOperator', []));
		$viewOwnVendorGroups   = array_map('intval', (array) $params->get('viewOwnVendor', []));
		$viewAllVendorGroups   = array_map('intval', (array) $params->get('viewAllVendor', []));

		$isSuperUser        = $user->authorise('core.admin');
		$canViewAll          = !empty(array_intersect($userGroupIds, $viewAllGroups));
		$canViewOwnOperator  = !empty(array_intersect($userGroupIds, $viewOwnOperatorGroups));
		$canViewOwnVendor    = !empty(array_intersect($userGroupIds, $viewOwnVendorGroups));
		$canViewAllVendor    = !empty(array_intersect($userGroupIds, $viewAllVendorGroups));

		if (!$userId) {
			$query->where('1 = 0'); // Guest - shouldn't normally reach here given DisplayController's login gate, but defended anyway.
		} elseif ($isSuperUser || $canViewAll) {
			// No restriction.
		} elseif ($canViewOwnOperator || $canViewOwnVendor || $canViewAllVendor) {
			$conditions = array();

			if ($canViewOwnOperator) {
				$conditions[] = $db->quoteName($alias . '.operator') . ' = ' . $userId;
			}

			if ($canViewOwnVendor || $canViewAllVendor) {
				// Vendor ids this user can see records for: themselves, plus
				// anyone listed under them as "Main Vendor" in #__vendor_access
				// (delegation - a main vendor can see their sub-vendors' records too).
				$vendorIds = array($userId);

				$accessQuery = $db->getQuery(true)
					->select($db->quoteName('vendors'))
					->from($db->quoteName('#__vendor_access'))
					->where($db->quoteName('main_vendor') . ' = ' . $userId)
					->where($db->quoteName('state') . ' = 1');

				$db->setQuery($accessQuery);
				$delegatedRows = $db->loadColumn() ?: array();

				foreach ($delegatedRows as $csv) {
					foreach (explode(',', (string) $csv) as $id) {
						$id = (int) $id;

						if ($id > 0) {
							$vendorIds[] = $id;
						}
					}
				}

				$vendorIds = array_unique($vendorIds);

				// FIND_IN_SET, not plain '=' - a.vendor can hold multiple comma-separated
				// vendor ids (same multi-value storage pattern as component/model).
				$vendorConditions = array();

				foreach ($vendorIds as $vendorId) {
					$vendorConditions[] = 'FIND_IN_SET(' . $vendorId . ', ' . $db->quoteName($alias . '.vendor') . ')';
				}

				$conditions[] = '(' . implode(' OR ', $vendorConditions) . ')';
			}

			$query->where('(' . implode(' OR ', $conditions) . ')');
		} else {
			$query->where('1 = 0'); // Authenticated, but in none of the configured groups.
		}

		// --- User-selectable filters ---
		if (
			$this->filterPart !== '' &&
			!in_array('part', $exclude, true)
		) {
			$query->where(
				$db->quoteName($alias . '.component') . ' = ' .
					$db->quote($this->filterPart)
			);
		}

		if (
			$this->filterModel !== '' &&
			!in_array('model', $exclude, true)
		) {
			$query->where(
				$db->quoteName($alias . '.model') . ' = ' .
					$db->quote($this->filterModel)
			);
		}

		if (
			$this->filterNcCategory !== '' &&
			!in_array('nc_category', $exclude, true)
		) {
			$query->where(
				'EXISTS (SELECT 1 FROM ' . $db->quoteName('#__data_entry_nc', 'ncfc') .
					' WHERE ' . $db->quoteName('ncfc.entry_id') . ' = ' . $db->quoteName($alias . '.id') .
					' AND FIND_IN_SET(' . $db->quote($this->filterNcCategory) . ', ' . $db->quoteName('ncfc.nc_category') . '))'
			);
		}

		if (
			$this->filterNcType !== '' &&
			!in_array('nc_type', $exclude, true)
		) {
			$query->where(
				'EXISTS (SELECT 1 FROM ' . $db->quoteName('#__data_entry_nc', 'ncft') .
					' WHERE ' . $db->quoteName('ncft.entry_id') . ' = ' . $db->quoteName($alias . '.id') .
					' AND FIND_IN_SET(' . $db->quote($this->filterNcType) . ', ' . $db->quoteName('ncft.nc_type') . '))'
			);
		}


		if (
			$this->filterVendor !== '' &&
			!in_array('vendor', $exclude, true)
		) {
			$query->where(
				$db->quoteName($alias . '.vendor') . ' = ' .
					$db->quote($this->filterVendor)
			);
		}

		if (
			$this->filterOperator !== '' &&
			!in_array('operator', $exclude, true)
		) {
			$query->where(
				$db->quoteName($alias . '.operator') . ' = ' .
					$db->quote($this->filterOperator)
			);
		}

		if (
			$this->filterRemark !== '' &&
			!in_array('remark', $exclude, true)
		) {
			$query->where(
				$db->quoteName($alias . '.lot') . ' = ' .
					$db->quote($this->filterRemark)
			);
		}

		if (
			$this->filterLot !== '' &&
			!in_array('lot', $exclude, true)
		) {
			$query->where(
				'EXISTS (SELECT 1 FROM ' . $db->quoteName('#__vendor_details', 'vdf') .
					' WHERE ' . $db->quoteName('vdf.id') . ' = ' . $db->quoteName($alias . '.remark') .
					' AND ' . $db->quoteName('vdf.remark') . ' = ' . $db->quote($this->filterLot) . ')'
			);
		}

		$query->where(
			$db->quoteName($alias . '.date') . ' BETWEEN ' .
				$db->quote($this->filterDateFrom . ' 00:00:00') . ' AND ' .
				$db->quote($this->filterDateTo . ' 23:59:59')
		);
	}
}
