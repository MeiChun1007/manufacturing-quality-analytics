<?php

/**
 * @version    CVS: 1.0.0
 * @package    Com_Data
 * @author     Mei Chun <qc.yolotech@gmail.com>
 * @copyright  2026 YOLO
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace Data\Component\Data\Site\Model;
// No direct access.
defined('_JEXEC') or die;

use \Joomla\CMS\Factory;
use \Joomla\Utilities\ArrayHelper;
use \Joomla\CMS\Language\Text;
use \Joomla\CMS\Table\Table;
use \Joomla\CMS\MVC\Model\FormModel;
use \Joomla\CMS\Object\CMSObject;
use \Joomla\CMS\Helper\TagsHelper;
use \Joomla\Database\DatabaseInterface;

/**
 * Data model.
 *
 * @since  1.0.0
 */
class EntryformModel extends FormModel
{
	private $item = null;





	/**
	 * Method to auto-populate the model state.
	 *
	 * Note. Calling getState in this method will result in recursion.
	 *
	 * @return  void
	 *
	 * @since   1.0.0
	 *
	 * @throws  Exception
	 */
	protected function populateState()
	{
		$app = Factory::getApplication('com_data');

		// Load state from the request userState on edit or from the passed variable on default
		if (Factory::getApplication()->input->get('layout') == 'edit') {
			$id = Factory::getApplication()->getUserState('com_data.edit.entry.id');
		} else {
			$id = Factory::getApplication()->input->get('id');
			Factory::getApplication()->setUserState('com_data.edit.entry.id', $id);
		}

		$this->setState('entry.id', $id);

		// Load the parameters.
		$params       = $app->getParams();
		$params_array = $params->toArray();

		if (isset($params_array['item_id'])) {
			$this->setState('entry.id', $params_array['item_id']);
		}

		$this->setState('params', $params);
	}

	/**
	 * Method to get an ojbect.
	 *
	 * @param   integer $id The id of the object to get.
	 *
	 * @return  Object|boolean Object on success, false on failure.
	 *
	 * @throws  Exception
	 */
	public function getItem($id = null)
	{
		if ($this->item === null) {
			$this->item = false;

			if (empty($id)) {
				$id = $this->getState('entry.id');
			}

			// Get a level row instance.
			$table = $this->getTable();
			$properties = $table->getProperties();
			$this->item = ArrayHelper::toObject($properties, CMSObject::class);

			if ($table !== false && $table->load($id) && !empty($table->id)) {
				$user = Factory::getApplication()->getIdentity();
				$id   = $table->id;


				$canEdit = $user->authorise('core.edit', 'com_data') || $user->authorise('core.create', 'com_data');

				if (!$canEdit && $user->authorise('core.edit.own', 'com_data')) {
					$canEdit = $user->id == $table->created_by;
				}

				if (!$canEdit) {
					throw new \Exception(Text::_('JERROR_ALERTNOAUTHOR'), 403);
				}

				// Check published state.
				if ($published = $this->getState('filter.published')) {
					if (isset($table->state) && $table->state != $published) {
						return $this->item;
					}
				}

				// Convert the Table to a clean CMSObject.
				$properties = $table->getProperties(1);
				$this->item = ArrayHelper::toObject($properties, CMSObject::class);
			}
		}

		return $this->item;
	}

	/**
	 * Method to get the table
	 *
	 * @param   string $type   Name of the Table class
	 * @param   string $prefix Optional prefix for the table class name
	 * @param   array  $config Optional configuration array for Table object
	 *
	 * @return  Table|boolean Table if found, boolean false on failure
	 */
	public function getTable($type = 'Entry', $prefix = 'Administrator', $config = array())
	{
		return parent::getTable($type, $prefix, $config);
	}

	/**
	 * Get an item by alias
	 *
	 * @param   string $alias Alias string
	 *
	 * @return int Element id
	 */
	public function getItemIdByAlias($alias)
	{
		$table      = $this->getTable();
		$properties = $table->getProperties();

		if (!in_array('alias', $properties)) {
			return null;
		}

		$table->load(array('alias' => $alias));
		$id = $table->id;


		return $id;
	}

	/**
	 * Method to check in an item.
	 *
	 * @param   integer $id The id of the row to check out.
	 *
	 * @return  boolean True on success, false on failure.
	 *
	 * @since   1.0.0
	 */
	public function checkin($id = null)
	{
		// Get the id.
		$id = (!empty($id)) ? $id : (int) $this->getState('entry.id');

		if ($id) {
			// Initialise the table
			$table = $this->getTable();

			// Attempt to check the row in.
			if (method_exists($table, 'checkin')) {
				if (!$table->checkin($id)) {
					return false;
				}
			}
		}

		return true;
	}

	/**
	 * Method to check out an item for editing.
	 *
	 * @param   integer $id The id of the row to check out.
	 *
	 * @return  boolean True on success, false on failure.
	 *
	 * @since   1.0.0
	 */
	public function checkout($id = null)
	{
		// Get the user id.
		$id = (!empty($id)) ? $id : (int) $this->getState('entry.id');

		if ($id) {
			// Initialise the table
			$table = $this->getTable();

			// Get the current user object.
			$user = Factory::getApplication()->getIdentity();

			// Attempt to check the row out.
			if (method_exists($table, 'checkout')) {
				if (!$table->checkout($user->get('id'), $id)) {
					return false;
				}
			}
		}

		return true;
	}

	/**
	 * Method to get the profile form.
	 *
	 * The base form is loaded from XML
	 *
	 * @param   array   $data     An optional array of data for the form to interogate.
	 * @param   boolean $loadData True if the form is to load its own data (default case), false if not.
	 *
	 * @return  Form    A Form object on success, false on failure
	 *
	 * @since   1.0.0
	 */
	public function getForm($data = array(), $loadData = true)
	{
		// Get the form.
		$form = $this->loadForm(
			'com_data.entry',
			'entryform',
			array(
				'control'   => 'jform',
				'load_data' => $loadData
			)
		);

		if (empty($form)) {
			return false;
		}

		return $form;
	}

	/**
	 * Method to get the data that should be injected in the form.
	 *
	 * @return  array  The default data is an empty array.
	 * @since   1.0.0
	 */
	protected function loadFormData()
	{
		$data = Factory::getApplication()->getUserState('com_data.edit.entry.data', array());

		if (empty($data)) {
			$data = $this->getItem();
		}

		if ($data) {
			// FIX: If $data is a standard array, convert it to an object so -> access works safely
			if (is_array($data)) {
				$data = (object) $data;
			}

			// Default the operator to the current logged-in user on new entries only
			if (empty($data->id)) {
				$data->operator = Factory::getApplication()->getIdentity()->id;
			}

			// Support for multiple or not foreign key field: component
			$array = array();
			$componentData = isset($data->component) ? (array) $data->component : array();

			foreach ($componentData as $value) {
				if (!is_array($value)) {
					$array[] = $value;
				}
			}
			if (!empty($array)) {
				$data->component = $array;
			}

			// Support for multiple or not foreign key field: model
			$array = array();
			$modelData = isset($data->model) ? (array) $data->model : array();

			foreach ($modelData as $value) {
				if (!is_array($value)) {
					$array[] = $value;
				}
			}
			if (!empty($array)) {
				$data->model = $array;
			}

			// Support for multiple or not foreign key field: vendor
			$array = array();
			$vendorData = isset($data->vendor) ? (array) $data->vendor : array();

			foreach ($vendorData as $value) {
				if (!is_array($value)) {
					$array[] = $value;
				}
			}
			if (!empty($array)) {
				$data->vendor = $array;
			}

			// Support for multiple foreign key field: resort_nc
			$array = array();
			$resortNcData = isset($data->resort_nc) ? (array) $data->resort_nc : array();

			foreach ($resortNcData as $value) {
				if (!is_array($value)) {
					$array[] = $value;
				}
			}
			if (!empty($array)) {
				$data->resort_nc = $array;
			}

			// Load the repeatable NC Data Entry rows
			if (!empty($data->id)) {
				$data->nc_entries = $this->loadNcEntries((int) $data->id);
			}

			return $data;
		}

		return array();
	}
	/**
	 * Load the repeatable "NC Data Entry" rows for an entry.
	 *
	 * @param   int  $entryId  The parent entry id.
	 *
	 * @return  array  List of associative arrays: nc_type, nc_category, nc_quantity, nc_percentage.
	 *
	 * @since   1.1.0
	 */
	protected function loadNcEntries($entryId)
	{
		$db = Factory::getContainer()->get(DatabaseInterface::class);

		$query = $db->getQuery(true)
			->select($db->quoteName(['nc_type', 'nc_quantity', 'nc_percentage']))
			->from($db->quoteName('#__data_entry_nc'))
			->where($db->quoteName('entry_id') . ' = ' . (int) $entryId)
			->order($db->quoteName('ordering') . ' ASC, ' . $db->quoteName('id') . ' ASC');

		$db->setQuery($query);

		return $db->loadAssocList() ?: array();
	}

	/**
	 * Replace all "NC Data Entry" rows belonging to an entry with the posted set.
	 *
	 * @param   int    $entryId  The parent entry id.
	 * @param   array  $rows     Rows posted from the nc_entries subform field.
	 *
	 * @return  void
	 *
	 * @since   1.1.0
	 */
	protected function saveNcEntries($entryId, $rows, $total)
	{
		//Grab the current Total from the form payload (fallback to 0)
		$parentTotal = isset($total) ? (float) $total : 0;

		$db = Factory::getContainer()->get(DatabaseInterface::class);

		$query = $db->getQuery(true)
			->delete($db->quoteName('#__data_entry_nc'))
			->where($db->quoteName('entry_id') . ' = ' . (int) $entryId);
		$db->setQuery($query)->execute();

		if (empty($rows) || !is_array($rows)) {
			return;
		}

		$ordering = 0;

		foreach ($rows as $row) {
			$type   = isset($row['nc_type']) ? trim((string) $row['nc_type']) : '';

			if (!empty($type)) {
				$db = Factory::getDbo();
				$query = $db->getQuery(true);
				$query
					->select($db->quoteName('category'))
					->from($db->quoteName('#__nc_types'))
					->where($db->quoteName('id') . '=' . $db->quote($type))
					->where($db->quoteName('state') . '=' . $db->quote(1));
				$db->setQuery($query);
				$category = $db->loadResult();
			}

			$quantity   = isset($row['nc_quantity']) ? (int) $row['nc_quantity'] : 0;

			// ====================================================================
			// AUTOGENERATE PERCENTAGE: Calculate based on parent total
			// ====================================================================
			$percentage = 0.00;
			if ($parentTotal > 0 && $quantity > 0) {
				$percentage = round(($quantity / $parentTotal) * 100, 2);
			}
			// ====================================================================

			// Skip rows the operator left completely empty.
			if ($type === '' && $quantity == 0 && $percentage == 0) {
				continue;
			}

			$query = $db->getQuery(true)
				->insert($db->quoteName('#__data_entry_nc'))
				->columns($db->quoteName(['entry_id', 'nc_type', 'nc_category', 'nc_quantity', 'nc_percentage', 'ordering']))
				->values(
					implode(
						',',
						array(
							(int) $entryId,
							$db->quote($type),
							$db->quote($category),
							(int) $quantity,
							(float) $percentage,
							(int) $ordering++,
						)
					)
				);

			$db->setQuery($query)->execute();
		}
	}

	/**
	 * Method to save the form data.
	 *
	 * @param   array $data The form data
	 *
	 * @return  bool
	 *
	 * @throws  Exception
	 * @since   1.0.0
	 */
	public function save($data)
	{
		$app             = Factory::getApplication();
		$submittedToken  = $app->input->getString('submit_token', '');
		$sessionToken    = $app->getUserState('com_data.entryform.submit_token', '');

		if ($submittedToken === '' || $sessionToken === '' || $submittedToken !== $sessionToken) {
			$app->enqueueMessage(Text::_('COM_DATA_ERROR_DUPLICATE_SUBMISSION'), 'warning');

			return false;
		}

		// Burn the token immediately - a second request racing in with the
		// same token (double-click, or a second tab) will now fail the check above.
		$app->setUserState('com_data.entryform.submit_token', '');

		$ncEntries = $data['nc_entries'] ?? array();
		unset($data['nc_entries']);

		// FIX: only trust the ID actually posted by the form. Falling back to the
		// session state (entry.id) made a NEW entry load the PREVIOUS row, so it
		// inherited that row's reference_no.
		$id    = !empty($data['id']) ? (int) $data['id'] : 0;
		$isNew = ($id === 0);
		$state = (!empty($data['state'])) ? 1 : 0;
		$user  = Factory::getApplication()->getIdentity();
		$total = isset($data['total']) ? (int) $data['total'] : 0;

		// The reference number is always generated server-side, never taken from the form.
		unset($data['reference_no']);

		// --- Sum of NC quantities must not exceed (or reach) the entry total ---
		$ncQuantitySum = 0;
		foreach ($ncEntries as $row) {
			$ncQuantitySum += isset($row['nc_quantity']) ? (int) $row['nc_quantity'] : 0;
		}

		if ($total > 0 && $ncQuantitySum >= $total) {
			Factory::getApplication()->enqueueMessage(
				Text::sprintf('COM_DATA_ERROR_NC_QUANTITY_EXCEEDS_TOTAL', $ncQuantitySum, $total),
				'error'
			);

			// let them retry with a fresh token instead of getting locked out
			$app->setUserState('com_data.entryform.submit_token', bin2hex(random_bytes(16)));

			return false;
		}

		// --- NC Type/Category must not repeat within the same entry ---
		$typeCounts = array();

		foreach ($ncEntries as $row) {
			$type = isset($row['nc_type']) ? trim((string) $row['nc_type']) : '';

			if ($type === '') {
				continue;
			}

			$typeCounts[$type] = ($typeCounts[$type] ?? 0) + 1;
		}

		$duplicateTypes = array_keys(array_filter($typeCounts, function ($count) {
			return $count > 1;
		}));

		if (!empty($duplicateTypes)) {
			Factory::getApplication()->enqueueMessage(
				Text::_('COM_DATA_ERROR_DUPLICATE_NC_CATEGORY'),
				'error'
			);

			$app->setUserState('com_data.entryform.submit_token', bin2hex(random_bytes(16)));

			return false;
		}

		if (!$isNew) {
			// Check the user can edit this item
			$authorised = $user->authorise('core.edit', 'com_data') || $user->authorise('core.edit.own', 'com_data');
		} else {
			// Check the user can create new items in this section
			$authorised = $user->authorise('core.create', 'com_data');
		}

		if ($authorised !== true) {
			throw new \Exception(Text::_('JERROR_ALERTNOAUTHOR'), 403);
		}

		// Operator group (10) can never submit a different operator value -
		// enforce server-side regardless of what the client sent, since
		// readonly/disabled fields are only a visual/client-side restriction.
		if (in_array(10, $user->getAuthorisedGroups())) {
			$data['operator'] = $user->id;
		}

		// resort_nc is a multiple="true" field - Joomla submits it as an array
		// (e.g. ['3','7']), but the DB column is a plain VARCHAR, so it must be
		// flattened to a comma-separated string before the Table tries to save it.
		if (isset($data['resort_nc']) && is_array($data['resort_nc'])) {
			$data['resort_nc'] = implode(',', array_filter($data['resort_nc']));
		}

		$table = $this->getTable();

		// Load an existing row only when editing; a new entry starts from a blank table.
		if (!$isNew) {
			$table->load($id);
		}

		// Force created date to current Kuala Lumpur local time on new records
		if ($isNew) {
			$data['date'] = Factory::getDate('now', 'Asia/Kuala_Lumpur')->format('Y-m-d H:i:s', true);
		}

		try {
			if ($table->save($data) === true) {
				$this->saveNcEntries((int) $table->id, $ncEntries, $total);

				// Generate the reference number for every new entry (or any row that
				// somehow has none). Editing an existing entry keeps its original reference.
				if ($isNew || empty($table->reference_no)) {
					$entryDate   = !empty($table->date) ? $table->date : Factory::getDate('now', 'Asia/Kuala_Lumpur')->toSql();
					$referenceNo = 'IR' . Factory::getDate($entryDate)->format('ymd') . '-' . str_pad($table->id, 4, '0', STR_PAD_LEFT);

					$db          = Factory::getDbo();
					$updateQuery = $db->getQuery(true)
						->update($db->quoteName('#__data_entry'))
						->set($db->quoteName('reference_no') . ' = ' . $db->quote($referenceNo))
						->where($db->quoteName('id') . ' = ' . (int) $table->id);
					$db->setQuery($updateQuery);
					$db->execute();
				}

				// Clear stale edit state so the next "add" form starts clean.
				$app->setUserState('com_data.edit.entry.id', null);
				$app->setUserState('com_data.edit.entry.data', null);

				return $table->id;
			} else {
				// Genuine save failure - regenerate a fresh token so the user
				// can legitimately retry, rather than being permanently locked out.
				$app->setUserState('com_data.entryform.submit_token', bin2hex(random_bytes(16)));

				Factory::getApplication()->enqueueMessage($table->getError(), 'error');
				return false;
			}
		} catch (\Exception $e) {
			$app->setUserState('com_data.entryform.submit_token', bin2hex(random_bytes(16)));

			Factory::getApplication()->enqueueMessage($e->getMessage(), 'error');
			return false;
		}
	}

	/**
	 * Method to delete data
	 *
	 * @param   int $pk Item primary key
	 *
	 * @return  int  The id of the deleted item
	 *
	 * @throws  Exception
	 *
	 * @since   1.0.0
	 */
	public function delete($id)
	{
		$user = Factory::getApplication()->getIdentity();


		if (empty($id)) {
			$id = (int) $this->getState('entry.id');
		}

		if ($id == 0 || $this->getItem($id) == null) {
			throw new \Exception(Text::_('COM_DATA_ITEM_DOESNT_EXIST'), 404);
		}

		if ($user->authorise('core.delete', 'com_data') !== true) {
			throw new \Exception(Text::_('JERROR_ALERTNOAUTHOR'), 403);
		}

		$table = $this->getTable();

		if ($table->delete($id) !== true) {
			throw new \Exception(Text::_('JERROR_FAILED'), 501);
		}

		return $id;
	}

	/**
	 * Check if data can be saved
	 *
	 * @return bool
	 */
	public function getCanSave()
	{
		$table = $this->getTable();

		return $table !== false;
	}

	/**
	 * Generate (or reuse) a one-time token for this form-load, so a duplicate
	 * POST - from a double-click or two tabs - can be rejected server-side
	 * even if the client-side disable-on-submit fails.
	 *
	 * @return  string
	 *
	 * @since   1.3.0
	 */
	public function getSubmitToken()
	{
		$app   = Factory::getApplication();
		$token = $app->getUserState('com_data.entryform.submit_token');

		if (empty($token)) {
			$token = bin2hex(random_bytes(16));
			$app->setUserState('com_data.entryform.submit_token', $token);
		}

		return $token;
	}
}
