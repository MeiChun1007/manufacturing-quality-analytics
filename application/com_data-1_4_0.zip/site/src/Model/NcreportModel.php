<?php

/**
 * @version    CVS: 1.2.0
 * @package    Com_Data
 * @author     Mei Chun <qc.yolotech@gmail.com>
 * @copyright  2026 YOLO
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace Data\Component\Data\Site\Model;
// No direct access.
defined('_JEXEC') or die;

use \Joomla\CMS\Factory;
use \Joomla\CMS\MVC\Model\BaseDatabaseModel;
use \Joomla\Database\DatabaseInterface;
use \Joomla\CMS\Language\Text;
use \Joomla\CMS\Component\ComponentHelper;


/**
 * Model for the weekly NC Report pivot: rows are (NC Category, NC Type)
 * combinations, columns are always the 7 calendar days (Monday-Sunday) of
 * one selected ISO week - built from #__data_entry_nc joined to its parent
 * #__data_entry record.
 *
 * @since  1.2.0
 */
class NcreportModel extends BaseDatabaseModel
{
	/** @var string  a.component value, or '' for all parts. */
	protected $filterPart = '';

	/**
	 * @var  string
	 * @since  1.2.0
	 */
	protected $filterModel = '';

	/**
	 * @var  string
	 * @since  1.2.0
	 */
	protected $filterNcCategory = '';

	/**
	 * @var  string
	 * @since  1.2.0
	 */
	protected $filterNcType = '';

	/**
	 * @var  string
	 * @since  1.2.0
	 */
	protected $filterVendor = '';

	/**
	 * @var  string
	 * @since  1.2.0
	 */
	protected $filterOperator = '';

	/** @var int  Selected calendar/ISO year. */
	protected $filterYear;

	/** @var  int  ISO week number within $filterYear (1-53). No longer embeds the year. */
	protected $filterWeek;

	/**
	 * @var  string  Remark: Normal/Resort
	 * @since  1.2.0
	 */
	protected $filterRemark = '';

	/**
	 * @var  string  Lot
	 * @since  1.2.0
	 */
	protected $filterLot = '';

	/**
	 * @var  string
	 * @since  1.2.0
	 */
	protected $filterSearch = '';

	/**
	 * @var  \DateTime  Monday 00:00:00 of the selected/default ISO week.
	 * @since  1.2.0
	 */
	protected $weekStart;

	/**
	 * @var  \DateTime  Sunday 23:59:59 of the selected/default ISO week.
	 * @since  1.2.0
	 */
	protected $weekEnd;

	/**
	 * Constructor.
	 *
	 * @param   array  $config  An optional associative array of configuration settings.
	 *
	 * @since   1.2.0
	 */
	public function __construct($config = array())
	{
		parent::__construct($config);

		$this->populateState();
	}

	/**
	 * Read the Model/Week/Search filters from the request, persist them in the
	 * user state, and resolve the selected (or default = current) ISO week
	 * into a concrete Monday-Sunday date range.
	 *
	 * @return  void
	 *
	 * @since   1.2.0
	 */
	protected function populateState()
	{
		$app     = Factory::getApplication();
		$context = 'com_data.ncreport.';
		$now     = Factory::getDate('now', 'Asia/Kuala_Lumpur');

		// --- Clear Filters: wipe stored session state, then fall through to defaults ---
		if ($app->input->getInt('clearfilters', 0) === 1) {
			$keys = array('part', 'model', 'vendor', 'operator', 'nc_category', 'nc_type', 'year', 'week', 'remark', 'lot', 'search');

			foreach ($keys as $key) {
				$app->setUserState($context . 'filter.' . $key, null);
			}

			// Also blank the just-submitted request values so getUserStateFromRequest()
			// doesn't read stale POST data back in on this same submit
			$app->input->set('filter_part', null);
			$app->input->set('filter_model', null);
			$app->input->set('filter_vendor', null);
			$app->input->set('filter_operator', null);
			$app->input->set('filter_year', null);
			$app->input->set('filter_week', null);
			$app->input->set('filter_remark', null);
			$app->input->set('filter_lot', null);
			$app->input->set('filter_search', null);
			$app->input->set('filter_nc_category', null);
			$app->input->set('filter_nc_type', null);
		}

		$this->filterPart   = (string) $app->getUserStateFromRequest($context . 'filter.part', 'filter_part', '', 'string');
		$this->filterModel  = (string) $app->getUserStateFromRequest($context . 'filter.model', 'filter_model', '', 'string');
		$this->filterVendor = (string) $app->getUserStateFromRequest($context . 'filter.vendor', 'filter_vendor', '', 'string');
		$this->filterOperator = (string) $app->getUserStateFromRequest($context . 'filter.operator', 'filter_operator', '', 'string');
		$this->filterYear   = (int) $app->getUserStateFromRequest($context . 'filter.year', 'filter_year', (int) $now->format('o'), 'int');
		$this->filterWeek   = (int) $app->getUserStateFromRequest($context . 'filter.week', 'filter_week', (int) $now->format('W'), 'int');
		$this->filterRemark = (string) $app->getUserStateFromRequest($context . 'filter.remark', 'filter_remark', '0', 'string');
		$this->filterLot	= (string) $app->getUserStateFromRequest($context . 'filter.lot', 'filter_lot', '', 'string');
		$this->filterNcCategory	= (string) $app->getUserStateFromRequest($context . 'filter.nc_category', 'filter_nc_category', '', 'string');
		$this->filterNcType		= (string) $app->getUserStateFromRequest($context . 'filter.nc_type', 'filter_nc_type', '', 'string');
		$this->filterSearch = (string) $app->getUserStateFromRequest($context . 'filter.search', 'filter_search', '', 'string');

		if ($this->filterYear < 2000 || $this->filterYear > 2100) {
			$this->filterYear = (int) $now->format('o');
		}

		if ($this->filterWeek < 1 || $this->filterWeek > 53) {
			$this->filterWeek = (int) $now->format('W');
		}

		$this->weekStart = new \DateTime();
		$this->weekStart->setISODate($this->filterYear, $this->filterWeek, 1)->setTime(0, 0, 0);

		$this->weekEnd = clone $this->weekStart;
		$this->weekEnd->modify('+6 days')->setTime(23, 59, 59);

		// --- Default (and, for operator-restricted users, FORCE) the Operator
		// filter to "own account" - keyed off the same viewOwnOperator groups
		// applyEntryFilters() uses for the actual query-level restriction, so
		// the pre-selected filter and the enforced boundary never drift apart.
		// Super Users are exempt, matching applyEntryFilters()'s core.admin check.
		$user   = $app->getIdentity();
		$userId = (int) $user->get('id');

		if ($userId > 0) {
			$userGroupIds = array_map('intval', (array) $user->get('groups'));
			$params       = ComponentHelper::getParams('com_data');
			$viewOwnOperatorGroups = array_map('intval', (array) $params->get('viewOwnOperator', []));
			$viewOwnVendorGroups = array_map('intval', (array) $params->get('viewOwnVendor', []));

			$isSuperUser = $user->authorise('core.admin');

			if (!$isSuperUser && !empty(array_intersect($userGroupIds, $viewOwnOperatorGroups))) {
				$this->filterOperator = $userId;
			}

			if (!$isSuperUser && !empty(array_intersect($userGroupIds, $viewOwnVendorGroups))) {
				$this->filterVendor = $userId;
			}
		}
	}

	/**
	 * The currently active filters, so the view can re-select them in the dropdowns.
	 *
	 * @return  object
	 *
	 * @since   1.2.0
	 */
	public function getActiveFilters()
	{
		return (object) array(
			'part'       => $this->filterPart,
			'model'      => $this->filterModel,
			'nc_category' => $this->filterNcCategory,
			'nc_type'     => $this->filterNcType,
			'vendor'      => $this->filterVendor,
			'operator'      => $this->filterOperator,
			'week'       => $this->filterWeek,
			'remark'       => $this->filterRemark,
			'lot'       => $this->filterLot,
			'search'     => $this->filterSearch,
			'week_start' => $this->weekStart->format('Y-m-d'),
			'week_end'   => $this->weekEnd->format('Y-m-d'),
		);
	}

	/**
	 * Distinct Remark values (a.lot), for the "SELECT REMARK" filter.
	 *
	 * @return  array
	 *
	 * @since   1.3.0
	 */
	public function getLotOptions()
	{
		$db = Factory::getContainer()->get(DatabaseInterface::class);

		$query = $db->getQuery(true)
			->select(
				'DISTINCT ' . $db->quoteName('vr.id', 'value') . ', ' .
					$db->quoteName('vr.remark', 'text')
			)
			->from($db->quoteName('#__data_entry', 'a'))
			->join('INNER', $db->quoteName('#__vendor_details', 'vd') . ' ON ' . $db->quoteName('vd.id') . ' = ' . $db->quoteName('a.remark'))
			->join('INNER', $db->quoteName('#__vendor_remarks', 'vr') . ' ON ' . $db->quoteName('vr.id') . ' = ' . $db->quoteName('vd.remark'))
			->join('INNER', $db->quoteName('#__users', 'uv') . ' ON ' . $db->quoteName('uv.id') . ' = ' . $db->quoteName('a.vendor'))
			->where($db->quoteName('a.remark') . ' != ' . $db->quote(''))
			->where($db->quoteName('a.state') . ' = ' . $db->quote(1));

		// Apply selected filters, EXCEPT the current Lot filter
		$this->applyEntryFilters($db, $query, 'a', ['lot']);

		$query->order($db->quoteName('vr.remark') . ' ASC');

		$db->setQuery($query);

		return $db->loadObjectList() ?: array();
	}


	/**
	 * Distinct Part values (a.component), for the "SELECT PART" filter.
	 *
	 * @return  array
	 *
	 * @since   1.3.0
	 */
	public function getPartOptions()
	{
		$db = Factory::getContainer()->get(DatabaseInterface::class);

		$query = $db->getQuery(true)
			->select(
				'DISTINCT ' . $db->quoteName('a.component', 'value') . ', ' .
					$db->quoteName('pc.component_name', 'text')
			)
			->from($db->quoteName('#__data_entry', 'a'))
			->join('INNER', $db->quoteName('#__product_components', 'pc') . ' ON ' . $db->quoteName('pc.id') . ' = ' . $db->quoteName('a.component'))
			->where($db->quoteName('a.component') . ' != ' . $db->quote(''))
			->where($db->quoteName('a.state') . ' = ' . $db->quote(1))
			->order($db->quoteName('pc.component_name') . ' ASC');

		// Apply selected filters, EXCEPT the current Lot filter
		$this->applyEntryFilters($db, $query, 'a', ['part']);

		$db->setQuery($query);

		return $db->loadObjectList() ?: array();
	}


	/**
	 * Distinct list of models available for the Model Selector.
	 *
	 * @return  array
	 *
	 * @since   1.2.0
	 */
	public function getModelOptions()
	{
		$db = Factory::getContainer()->get(DatabaseInterface::class);

		$query = $db->getQuery(true)
			->select(
				'DISTINCT ' . $db->quoteName('pm.id', 'value') . ', ' .
					$db->quoteName('pm.model_name', 'text')
			)
			->from($db->quoteName('#__data_entry', 'a'))
			->join('INNER', $db->quoteName('#__product_catalogs', 'pm') . ' ON ' . $db->quoteName('pm.id') . ' = ' . $db->quoteName('a.model'))
			->where($db->quoteName('a.model') . ' IS NOT NULL')
			->where($db->quoteName('a.state') . ' = 1');

		// Apply selected filters, EXCEPT the current Lot filter
		$this->applyEntryFilters($db, $query, 'a', ['model']);

		$query->order($db->quoteName('pm.model_name') . ' ASC');

		$db->setQuery($query);

		return $db->loadObjectList() ?: array();
	}

	/**
	 * Distinct list of vendors available for the Vendor Selector.
	 *
	 * @return  array
	 *
	 * @since   1.2.0
	 */
	public function getVendorOptions()
	{
		$db = Factory::getContainer()->get(DatabaseInterface::class);

		$query = $db->getQuery(true)
			->select(
				'DISTINCT ' . $db->quoteName('a.vendor', 'key') . ', ' .
					$db->quoteName('uv.name', 'value')
			)
			->from($db->quoteName('#__data_entry', 'a'))
			->join('INNER', $db->quoteName('#__users', 'uv') . ' ON ' . $db->quoteName('uv.id') . ' = ' . $db->quoteName('a.vendor'))
			->where($db->quoteName('a.state') . ' = 1')
			->order($db->quoteName('uv.name') . ' ASC');

		// Apply selected filters, EXCEPT the current Lot filter
		$this->applyEntryFilters($db, $query, 'a', ['vendor']);

		$db->setQuery($query);

		return $db->loadObjectList() ?: array();
	}

	/**
	 * Distinct list of operators available for the Operator Selector.
	 *
	 * @return  array
	 *
	 * @since   1.2.0
	 */
	public function getOperatorOptions()
	{
		$db = Factory::getContainer()->get(DatabaseInterface::class);

		$query = $db->getQuery(true)
			->select(
				'DISTINCT ' . $db->quoteName('a.operator', 'key') . ', ' .
					$db->quoteName('uv.name', 'value')
			)
			->from($db->quoteName('#__data_entry', 'a'))
			->join('INNER', $db->quoteName('#__users', 'uv') . ' ON ' . $db->quoteName('uv.id') . ' = ' . $db->quoteName('a.operator'))
			->where($db->quoteName('a.state') . ' = 1')
			->order($db->quoteName('uv.name') . ' ASC');

		if ($this->filterOperator !== '') {
			$query->where($db->quoteName('a.operator') . ' = ' . $db->quote($this->filterOperator));
		}

		$db->setQuery($query);

		return $db->loadObjectList() ?: array();
	}

	/**
	 * Years with data, newest first. Always includes the current year.
	 *
	 * @return  array  Plain list of ints, e.g. [2027, 2026, 2025]
	 *
	 * @since   1.3.0
	 */
	public function getYearOptions()
	{
		$db = Factory::getContainer()->get(DatabaseInterface::class);

		$query = $db->getQuery(true)
			->select('DISTINCT YEAR(' . $db->quoteName('date') . ') AS yr')
			->from($db->quoteName('#__data_entry'))
			->where($db->quoteName('date') . ' IS NOT NULL')
			->order('yr DESC');

		$db->setQuery($query);
		$years = array_map('intval', $db->loadColumn() ?: array());

		$currentYear = (int) (new \DateTime())->format('Y');

		if (!in_array($currentYear, $years, true)) {
			array_unshift($years, $currentYear);
			rsort($years);
		}

		return $years;
	}

	/**
	 * ISO weeks that have data within $filterYear, newest first. Always includes
	 * the current week if $filterYear is the current year.
	 *
	 * @return  array  List of objects: { value: 29, label: "13 Jul - 19 Jul" }
	 *
	 * @since   1.3.0
	 */
	public function getWeekOptions()
	{
		$db = Factory::getContainer()->get(DatabaseInterface::class);

		$query = $db->getQuery(true)
			->select('DISTINCT WEEK(' . $db->quoteName('date') . ', 3) AS wk') // mode 3 = ISO week
			->from($db->quoteName('#__data_entry'))
			->where('YEAR(' . $db->quoteName('date') . ') = ' . (int) $this->filterYear)
			->order('wk DESC');

		$db->setQuery($query);
		$weeks = array_map('intval', $db->loadColumn() ?: array());

		$now = new \DateTime();

		if ((int) $now->format('o') === $this->filterYear && !in_array((int) $now->format('W'), $weeks, true)) {
			$weeks[] = (int) $now->format('W');
		}

		if (empty($weeks)) {
			$weeks[] = $this->filterWeek; // keep the selected week choosable even with zero data
		}

		rsort($weeks);

		$options = array();

		foreach ($weeks as $week) {
			$start = new \DateTime();
			$start->setISODate($this->filterYear, $week, 1);
			$end = (clone $start)->modify('+6 days');

			$options[] = (object) array(
				'value' => $week,
				'label' => sprintf('%s - %s', $start->format('d M'), $end->format('d M')),
			);
		}

		return $options;
	}

	/**
	 * Distinct NC Category values in use, for the "SELECT NC CATEGORY" filter.
	 * Joined through #__data_entry_nc since nc_category lives there, not on
	 * #__data_entry itself - mirrors the com_data entries list's SQL field.
	 *
	 * @return  array
	 *
	 * @since   1.7.0
	 */
	public function getNCCategoryOptions()
	{
		$db = Factory::getContainer()->get(DatabaseInterface::class);

		$query = $db->getQuery(true)
			->select(
				'DISTINCT ' . $db->quoteName('cat.id', 'value') . ', ' .
					$db->quoteName('cat.category', 'text')
			)
			->from($db->quoteName('#__nc_category', 'cat'))
			->join(
				'INNER',
				$db->quoteName('#__data_entry_nc', 'nc') .
					' ON FIND_IN_SET(' . $db->quoteName('cat.id') . ', ' . $db->quoteName('nc.nc_category') . ')'
			)
			->join('INNER', $db->quoteName('#__data_entry', 'a') . ' ON ' . $db->quoteName('a.id') . ' = ' . $db->quoteName('nc.entry_id'))
			->where($db->quoteName('cat.state') . ' = 1')
			->where($db->quoteName('a.state') . ' = 1');


		// Apply selected filters, EXCEPT the current NC Category filter
		$this->applyEntryFilters($db, $query, 'a', ['nc_category']);

		$query->order($db->quoteName('cat.category') . ' ASC');

		$db->setQuery($query);

		return $db->loadObjectList() ?: array();
	}

	/**
	 * Distinct NC Type values in use, for the "SELECT NC TYPE" filter.
	 * Joined through #__data_entry_nc since nc_type lives there, not on
	 * #__data_entry itself - mirrors the com_data entries list's SQL field.
	 *
	 * @return  array
	 *
	 * @since   1.7.0
	 */
	public function getNCTypeOptions()
	{
		$db = Factory::getContainer()->get(DatabaseInterface::class);

		$query = $db->getQuery(true)
			->select(
				'DISTINCT ' . $db->quoteName('nt.id', 'value') . ', ' .
					$db->quoteName('nt.nc', 'text')
			)
			->from($db->quoteName('#__nc_types', 'nt'))
			->join(
				'INNER',
				$db->quoteName('#__data_entry_nc', 'nc') .
					' ON FIND_IN_SET(' . $db->quoteName('nt.id') . ', ' . $db->quoteName('nc.nc_type') . ')'
			)
			->join('INNER', $db->quoteName('#__data_entry', 'a') . ' ON ' . $db->quoteName('a.id') . ' = ' . $db->quoteName('nc.entry_id'))
			->where($db->quoteName('nt.state') . ' = 1')
			->where($db->quoteName('a.state') . ' = 1');

		// Apply selected filters, EXCEPT the current NC Type filter
		$this->applyEntryFilters($db, $query, 'a', ['nc_type']);

		$query->order($db->quoteName('nt.nc') . ' ASC');

		$db->setQuery($query);

		return $db->loadObjectList() ?: array();
	}

	public function getRemarkOptions()
	{
		$remarkOptions = array(
			'0' => Text::_('COM_DATA_LOT_NORMAL'),
			'1' => Text::_('COM_DATA_LOT_RESORT'),
		);

		return $remarkOptions;
	}

	/**
	 * The current default week key (this ISO week), used before any filter is applied.
	 *
	 * @return  string
	 *
	 * @since   1.2.0
	 */
	protected function defaultWeekKey()
	{
		$now = new \DateTime();

		return sprintf('%04d-W%02d', (int) $now->format('o'), (int) $now->format('W'));
	}

	/**
	 * The top summary cards: Total Sort, Total NC, Total Accepted, Yield%, Total NC%.
	 * Always scoped to the selected Monday-Sunday week (and Model, if chosen).
	 *
	 * @return  object
	 *
	 * @since   1.2.0
	 */
	public function getSummary()
	{
		$db = Factory::getContainer()->get(DatabaseInterface::class);

		// Total Sort: sum of the parent entry's `total` field within the current scope.
		$sortQuery = $db->getQuery(true)
			->select('SUM(' . $db->quoteName('a.total') . ') AS total_sort')
			->from($db->quoteName('#__data_entry', 'a'))
			->where($db->quoteName('a.state') . ' = 1');
		$this->applyEntryFilters($db, $sortQuery, 'a', ['nc_category', 'nc_type']);

		$db->setQuery($sortQuery);
		$totalSort = (float) $db->loadResult();

		// Total NC: sum of every NC row's quantity within the current scope.
		$ncQuery = $db->getQuery(true)
			->select('SUM(' . $db->quoteName('nc.nc_quantity') . ') AS total_nc')
			->from($db->quoteName('#__data_entry_nc', 'nc'))
			->join('INNER', $db->quoteName('#__data_entry', 'a') . ' ON ' . $db->quoteName('a.id') . ' = ' . $db->quoteName('nc.entry_id'))
			->where($db->quoteName('a.state') . ' = 1');
		$this->applyEntryFilters($db, $ncQuery, 'a', ['nc_category', 'nc_type']);
		$this->applyNcSearch($db, $ncQuery);

		// --- NEW: restrict the actual NC rows summed, not just which entries qualify ---
		if ($this->filterNcCategory !== '') {
			$ncQuery->where('FIND_IN_SET(' . $db->quote($this->filterNcCategory) . ', ' . $db->quoteName('nc.nc_category') . ')');
		}

		if ($this->filterNcType !== '') {
			$ncQuery->where('FIND_IN_SET(' . $db->quote($this->filterNcType) . ', ' . $db->quoteName('nc.nc_type') . ')');
		}
		// --- end NEW ---

		$db->setQuery($ncQuery);
		$totalNc = (float) $db->loadResult();

		$totalAccepted = $totalSort - $totalNc;
		$yieldPct      = $totalSort > 0 ? ($totalAccepted / $totalSort) * 100 : 0.0;
		$totalNcPct    = $totalSort > 0 ? ($totalNc / $totalSort) * 100 : 0.0;

		return (object) array(
			'total_sort'     => $totalSort,
			'total_nc'       => $totalNc,
			'total_accepted' => $totalAccepted,
			'yield_pct'      => $yieldPct,
			'total_nc_pct'   => $totalNcPct,
		);
	}

	/**
	 * Build the pivot: rows are (Category, Type), columns are always the 7
	 * calendar days (Monday-Sunday) of the selected week - present or not.
	 *
	 * Per-day/per-week percentages are the ACTUAL stored `nc_percentage`
	 * values from #__data_entry_nc, summed - not a recomputed share of that
	 * day's/week's total defect quantity. Total Sort is also broken out per
	 * day and for the week, computed from a de-duplicated subquery so an
	 * entry with multiple NC rows doesn't have its `total` counted more than once.
	 *
	 * @return  object  { dates, rows, day_totals, day_totals_pct, day_sort_totals,
	 *                    week_total_nc, week_total_nc_pct, week_total_sort }
	 *
	 * @since   1.2.0
	 */
	public function getPivot()
	{
		$db = Factory::getContainer()->get(DatabaseInterface::class);

		// Always show all 7 days of the selected week, in order, whether or not they have data.
		$dates = array();
		$cursor = clone $this->weekStart;

		for ($i = 0; $i < 7; $i++) {
			$dates[] = $cursor->format('Y-m-d');
			$cursor->modify('+1 day');
		}

		// --- Main pivot data: qty per (category, type, date) ---
		$query = $db->getQuery(true)
			->select(
				$db->quoteName('nc.nc_category', 'nc_category') . ', ' .
					$db->quoteName('nc.nc_type', 'nc_type') . ', ' .
					'DATE(' . $db->quoteName('a.date') . ') AS entry_date, ' .
					'SUM(' . $db->quoteName('nc.nc_quantity') . ') AS qty'
			)
			->from($db->quoteName('#__data_entry_nc', 'nc'))
			->join('INNER', $db->quoteName('#__data_entry', 'a') . ' ON ' . $db->quoteName('a.id') . ' = ' . $db->quoteName('nc.entry_id'))
			->where($db->quoteName('a.state') . ' = 1')
			->group($db->quoteName('nc.nc_category') . ', ' . $db->quoteName('nc.nc_type') . ', DATE(' . $db->quoteName('a.date') . ')');
		$this->applyEntryFilters($db, $query, 'a', ['nc_category', 'nc_type']);
		$this->applyNcSearch($db, $query);

		// --- NEW: restrict the actual NC rows summed, not just which entries qualify ---
		if ($this->filterNcCategory !== '') {
			$query->where('FIND_IN_SET(' . $db->quote($this->filterNcCategory) . ', ' . $db->quoteName('nc.nc_category') . ')');
		}

		if ($this->filterNcType !== '') {
			$query->where('FIND_IN_SET(' . $db->quote($this->filterNcType) . ', ' . $db->quoteName('nc.nc_type') . ')');
		}
		// --- end NEW ---


		$db->setQuery($query);
		$raw = $db->loadObjectList() ?: array();

		// --- Total Sort per day: de-duplicated first (one row per entry), THEN summed,
		// so an entry with several NC rows doesn't inflate the day's sort total. ---
		$sortSubQuery = $db->getQuery(true)
			->select(
				'DISTINCT ' . $db->quoteName('a.id') . ', ' .
					$db->quoteName('a.total') . ', ' .
					'DATE(' . $db->quoteName('a.date') . ') AS entry_date'
			)
			->from($db->quoteName('#__data_entry', 'a'))
			->where($db->quoteName('a.state') . ' = 1');
		$this->applyEntryFilters($db, $sortSubQuery, 'a', ['nc_category', 'nc_type']);

		$sortQuery = $db->getQuery(true)
			->select('entry_date, SUM(total) AS day_sort')
			->from('(' . (string) $sortSubQuery . ') AS dedup')
			->group('entry_date');

		$db->setQuery($sortQuery);
		$sortRows = $db->loadObjectList() ?: array();

		$daySortTotals = array_fill_keys($dates, 0.0);

		foreach ($sortRows as $sr) {
			if (isset($daySortTotals[$sr->entry_date])) {
				$daySortTotals[$sr->entry_date] = (float) $sr->day_sort;
			}
		}

		$weekTotalSort = array_sum($daySortTotals);

		// --- Total Sort per (category, type), for the whole week: the sum
		// of #__data_entry.total for every entry that had this specific NC
		// during the week - deduped by entry id, so an entry with more than
		// one row under the same category+type doesn't have its total
		// counted twice. This is the "a" (Total Sort) each row's per-day
		// percentage is calculated against. ---
		$rowSortSubQuery = $db->getQuery(true)
			->select(
				'DISTINCT ' .
					$db->quoteName('nc.nc_category') . ', ' .
					$db->quoteName('nc.nc_type') . ', ' .
					$db->quoteName('a.id', 'entry_id') . ', ' .
					$db->quoteName('a.total')
			)
			->from($db->quoteName('#__data_entry_nc', 'nc'))
			->join('INNER', $db->quoteName('#__data_entry', 'a') . ' ON ' . $db->quoteName('a.id') . ' = ' . $db->quoteName('nc.entry_id'))
			->where($db->quoteName('a.state') . ' = 1');
		$this->applyEntryFilters($db, $rowSortSubQuery, 'a', ['nc_category', 'nc_type']);

		$rowSortQuery = $db->getQuery(true)
			->select('nc_category, nc_type, SUM(total) AS week_sort')
			->from('(' . (string) $rowSortSubQuery . ') AS dedup')
			->group('nc_category, nc_type');

		$db->setQuery($rowSortQuery);
		$rowSortRows = $db->loadObjectList() ?: array();

		$weekSortByKey = array();

		foreach ($rowSortRows as $rs) {
			$weekSortByKey[$rs->nc_category . '|' . $rs->nc_type] = (float) $rs->week_sort;
		}

		// --- Assemble the (category, type) rows ---
		$rows        = array();
		$dayTotals   = array_fill_keys($dates, 0.0);
		$weekTotalNc = 0.0;

		foreach ($raw as $r) {
			$date = $r->entry_date;
			$qty  = (float) $r->qty;
			$key  = $r->nc_category . '|' . $r->nc_type;

			if (!isset($rows[$key])) {
				$catQuery = $db->getQuery(true)
					->select($db->quoteName('category'))
					->from($db->quoteName('#__nc_category'))
					->where($db->quoteName('id') . ' = ' . $db->quote($r->nc_category))
					->where($db->quoteName('state') . ' = ' . $db->quote(1));
				$db->setQuery($catQuery);
				$ncCat = $db->loadResult();

				$typeQuery = $db->getQuery(true)
					->select($db->quoteName('nc'))
					->from($db->quoteName('#__nc_types'))
					->where($db->quoteName('id') . ' = ' . $db->quote($r->nc_type))
					->where($db->quoteName('state') . ' = ' . $db->quote(1));
				$db->setQuery($typeQuery);
				$ncType = $db->loadResult();

				$hasImagesQuery = $db->getQuery(true)
					->select('1')
					->from($db->quoteName('#__data_entry_nc', 'nc2'))
					->join('INNER', $db->quoteName('#__data_entry', 'a2') . ' ON ' . $db->quoteName('a2.id') . ' = ' . $db->quoteName('nc2.entry_id'))
					->where($db->quoteName('a2.state') . ' = 1')
					->where($db->quoteName('nc2.nc_category') . ' = ' . $db->quote($r->nc_category))
					->where($db->quoteName('nc2.nc_type') . ' = ' . $db->quote($r->nc_type))
					->where(
						'EXISTS (SELECT 1 FROM ' . $db->quoteName('#__data_entry_nc_images', 'img') .
							' WHERE ' . $db->quoteName('img.nc_id') . ' = ' . $db->quoteName('nc2.id') . ')'
					)
					->setLimit(1);
				$this->applyEntryFilters($db, $hasImagesQuery, 'a2');
				$db->setQuery($hasImagesQuery);
				$hasImages = (bool) $db->loadResult();

				$rows[$key] = (object) array(
					'nc_category' => $ncCat,
					'nc_type'     => $ncType,
					'nc_category_id' => $r->nc_category,   // add this
					'nc_type_id'     => $r->nc_type,       // add this
					'has_images'     => $hasImages,   // add this
					'by_date'     => array_fill_keys($dates, 0.0),
					'by_date_pct' => array_fill_keys($dates, 0.0),
					'week_qty'    => 0.0,
					'week_sort'   => $weekSortByKey[$key] ?? 0.0,
					'week_pct'    => 0.0,
				);
			}

			// Ignore stray rows outside the 7 selected days (shouldn't normally happen,
			// since applyEntryFilters() already constrains a.date to this range).
			if (!isset($rows[$key]->by_date[$date])) {
				continue;
			}

			$rows[$key]->by_date[$date] += $qty;
			$rows[$key]->week_qty       += $qty;

			$dayTotals[$date] += $qty;
			$weekTotalNc      += $qty;
		}

		$weekTotalNcPct = $weekTotalSort > 0 ? ($weekTotalNc / $weekTotalSort) * 100 : 0.0;

		// by_date_pct[date] = c = (b / a) * 100, where:
		//   b = that day's qty for this row       (row->by_date[date])
		//   a = this row's Total Sort for the WEEK (row->week_sort)
		// Same divisor as week_pct - just applied per day instead of once for the week.
		foreach ($rows as $key => $row) {
			foreach ($dates as $date) {
				$row->by_date_pct[$date] = $daySortTotals[$date] > 0
					? ($row->by_date[$date] / $daySortTotals[$date]) * 100
					: 0.0;
			}

			$row->week_pct = $weekTotalSort > 0 ? ($row->week_qty / $weekTotalSort) * 100 : 0.00;
			$rows[$key]    = $row;
		}

		uasort(
			$rows,
			function ($a, $b) {
				return strcmp($a->nc_category . $a->nc_type, $b->nc_category . $b->nc_type);
			}
		);

		return (object) array(
			'dates'             => $dates,
			'rows'              => array_values($rows),
			'day_totals'        => $dayTotals,
			'day_sort_totals'   => $daySortTotals,
			'week_total_nc'     => $weekTotalNc,
			'week_total_sort'   => $weekTotalSort,
			'week_total_nc_pct' => $weekTotalNcPct,
		);
	}
	/**
	 * Apply the Model filter and the resolved Monday-Sunday week range,
	 * shared by every query in this model.
	 *
	 * @param   DatabaseInterface              $db     The database driver.
	 * @param   \Joomla\Database\DatabaseQuery  $query  The query to constrain.
	 *
	 * @return  void
	 *
	 * @since   1.2.0
	 */
	protected function applyEntryFilters(DatabaseInterface $db, $query, $alias = 'a', array $exclude = [])
	{
		// --- Access control ---
		$user = Factory::getApplication()->getIdentity();

		$userId       = (int) $user->get('id');
		$userGroupIds = array_map('intval', (array) $user->get('groups'));

		$params = ComponentHelper::getParams('com_data');

		$viewAllGroups         = array_map('intval', (array) $params->get('viewAll', []));
		$viewOwnOperatorGroups = array_map('intval', (array) $params->get('viewOwnOperator', []));
		$viewOwnVendorGroups   = array_map('intval', (array) $params->get('viewOwnVendor', []));
		$viewAllVendorGroups   = array_map('intval', (array) $params->get('viewAllVendor', []));

		$isSuperUser        = $user->authorise('core.admin');
		$canViewAll          = !empty(array_intersect($userGroupIds, $viewAllGroups));
		$canViewOwnOperator  = !empty(array_intersect($userGroupIds, $viewOwnOperatorGroups));
		$canViewOwnVendor    = !empty(array_intersect($userGroupIds, $viewOwnVendorGroups));
		$canViewAllVendor    = !empty(array_intersect($userGroupIds, $viewAllVendorGroups));

		if (!$userId) {
			$query->where('1 = 0'); // Guest - shouldn't normally reach here given DisplayController's login gate, but defended anyway.
		} elseif ($isSuperUser || $canViewAll) {
			// No restriction.
		} elseif ($canViewOwnOperator || $canViewOwnVendor || $canViewAllVendor) {
			$conditions = array();

			if ($canViewOwnOperator) {
				$conditions[] = $db->quoteName($alias . '.operator') . ' = ' . $userId;
			}

			if ($canViewOwnVendor || $canViewAllVendor) {
				// Vendor ids this user can see records for: themselves, plus
				// anyone listed under them as "Main Vendor" in #__vendor_access
				// (delegation - a main vendor can see their sub-vendors' records too).
				$vendorIds = array($userId);

				$accessQuery = $db->getQuery(true)
					->select($db->quoteName('vendors'))
					->from($db->quoteName('#__vendor_access'))
					->where($db->quoteName('main_vendor') . ' = ' . $userId)
					->where($db->quoteName('state') . ' = 1');

				$db->setQuery($accessQuery);
				$delegatedRows = $db->loadColumn() ?: array();

				foreach ($delegatedRows as $csv) {
					foreach (explode(',', (string) $csv) as $id) {
						$id = (int) $id;

						if ($id > 0) {
							$vendorIds[] = $id;
						}
					}
				}

				$vendorIds = array_unique($vendorIds);

				// FIND_IN_SET, not plain '=' - a.vendor can hold multiple comma-separated
				// vendor ids (same multi-value storage pattern as component/model).
				$vendorConditions = array();

				foreach ($vendorIds as $vendorId) {
					$vendorConditions[] = 'FIND_IN_SET(' . $vendorId . ', ' . $db->quoteName($alias . '.vendor') . ')';
				}

				$conditions[] = '(' . implode(' OR ', $vendorConditions) . ')';
			}

			$query->where('(' . implode(' OR ', $conditions) . ')');
		} else {
			$query->where('1 = 0'); // Authenticated, but in none of the configured groups.
		}

		if (
			$this->filterPart !== '' &&
			!in_array('part', $exclude, true)
		) {
			$query->where(
				$db->quoteName($alias . '.component') . ' = ' .
					$db->quote($this->filterPart)
			);
		}

		if (
			$this->filterModel !== '' &&
			!in_array('model', $exclude, true)
		) {
			$query->where(
				$db->quoteName($alias . '.model') . ' = ' .
					$db->quote($this->filterModel)
			);
		}

		if (
			$this->filterNcCategory !== '' &&
			!in_array('nc_category', $exclude, true)
		) {
			$query->where(
				'EXISTS (SELECT 1 FROM ' . $db->quoteName('#__data_entry_nc', 'ncfc') .
					' WHERE ' . $db->quoteName('ncfc.entry_id') . ' = ' . $db->quoteName($alias . '.id') .
					' AND FIND_IN_SET(' . $db->quote($this->filterNcCategory) . ', ' . $db->quoteName('ncfc.nc_category') . '))'
			);
		}

		if (
			$this->filterNcType !== '' &&
			!in_array('nc_type', $exclude, true)
		) {
			$query->where(
				'EXISTS (SELECT 1 FROM ' . $db->quoteName('#__data_entry_nc', 'ncft') .
					' WHERE ' . $db->quoteName('ncft.entry_id') . ' = ' . $db->quoteName($alias . '.id') .
					' AND FIND_IN_SET(' . $db->quote($this->filterNcType) . ', ' . $db->quoteName('ncft.nc_type') . '))'
			);
		}

		if (
			$this->filterVendor !== '' &&
			!in_array('vendor', $exclude, true)
		) {
			$query->where(
				$db->quoteName($alias . '.vendor') . ' = ' .
					$db->quote($this->filterVendor)
			);
		}

		if (
			$this->filterOperator !== '' &&
			!in_array('operator', $exclude, true)
		) {
			$query->where(
				$db->quoteName($alias . '.operator') . ' = ' .
					$db->quote($this->filterOperator)
			);
		}

		if (
			$this->filterRemark !== '' &&
			!in_array('remark', $exclude, true)
		) {
			$query->where(
				$db->quoteName($alias . '.lot') . ' = ' .
					$db->quote($this->filterRemark)
			);
		}

		if (
			$this->filterLot !== '' &&
			!in_array('lot', $exclude, true)
		) {
			$query->where(
				'EXISTS (SELECT 1 FROM ' . $db->quoteName('#__vendor_details', 'vdf') .
					' WHERE ' . $db->quoteName('vdf.id') . ' = ' . $db->quoteName($alias . '.remark') .
					' AND ' . $db->quoteName('vdf.remark') . ' = ' . $db->quote($this->filterLot) . ')'
			);
		}

		$query->where(
			$db->quoteName($alias . '.date') .
				' BETWEEN ' .
				$db->quote($this->weekStart->format('Y-m-d H:i:s')) .
				' AND ' .
				$db->quote($this->weekEnd->format('Y-m-d H:i:s'))
		);
	}

	/**
	 * Apply the category/type search filter (only relevant to NC-row queries).
	 *
	 * @param   DatabaseInterface              $db     The database driver.
	 * @param   \Joomla\Database\DatabaseQuery  $query  The query to constrain.
	 *
	 * @return  void
	 *
	 * @since   1.2.0
	 */
	protected function applyNcSearch(DatabaseInterface $db, $query)
	{
		if ($this->filterSearch === '') {
			return;
		}

		$search = $db->quote('%' . $db->escape($this->filterSearch, true) . '%');
		$query->where(
			'(' . $db->quoteName('nc.nc_category') . ' LIKE ' . $search .
				' OR ' . $db->quoteName('nc.nc_type') . ' LIKE ' . $search . ')'
		);
	}

	/**
	 * Every individual NC row for one (category, type) pivot cell, with the
	 * parent entry's details and any uploaded photos - respects whatever
	 * Part/Model/Vendor/Operator/Remark/Lot filters and month are currently
	 * active on the report (same $this->applyEntryFilters() every other query
	 * on this model uses).
	 *
	 * @param   string  $categoryId  Raw #__nc_category id (as stored on #__data_entry_nc.nc_category).
	 * @param   string  $typeId      Raw #__nc_types id (as stored on #__data_entry_nc.nc_type).
	 *
	 * @return  array  List of objects: reference_no, date, component, model,
	 *                 vendor, remark, lot, nc_quantity, nc_percentage, images[].
	 *
	 * @since   1.5.0
	 */
	public function getDrilldown($categoryId, $typeId)
	{
		$db = Factory::getContainer()->get(DatabaseInterface::class);

		$query = $db->getQuery(true)
			->select(
				$db->quoteName('nc.id', 'nc_id') . ', ' .
					$db->quoteName('nc.nc_quantity') . ', ' .
					$db->quoteName('nc.nc_percentage') . ', ' .
					$db->quoteName('a.id', 'entry_id') . ', ' .
					$db->quoteName('a.reference_no') . ', ' .
					$db->quoteName('a.date') . ', ' .
					$db->quoteName('a.lot') . ', ' .
					$db->quoteName('a.component') . ', ' .
					$db->quoteName('a.model') . ', ' .
					$db->quoteName('a.vendor') . ', ' .
					$db->quoteName('vr.remark', 'remark')
			)
			->from($db->quoteName('#__data_entry_nc', 'nc'))
			->join('INNER', $db->quoteName('#__data_entry', 'a') . ' ON ' . $db->quoteName('a.id') . ' = ' . $db->quoteName('nc.entry_id'))
			->join('LEFT', $db->quoteName('#__vendor_details', 'vd') . ' ON ' . $db->quoteName('vd.id') . ' = ' . $db->quoteName('a.remark'))
			->join('LEFT', $db->quoteName('#__vendor_remarks', 'vr') . ' ON ' . $db->quoteName('vr.id') . ' = ' . $db->quoteName('vd.remark'))
			->where($db->quoteName('a.state') . ' = 1')
			->where($db->quoteName('nc.nc_category') . ' = ' . $db->quote($categoryId))
			->where($db->quoteName('nc.nc_type') . ' = ' . $db->quote($typeId))
			->where(
				'EXISTS (SELECT 1 FROM ' . $db->quoteName('#__data_entry_nc_images', 'i') .
					' WHERE ' . $db->quoteName('i.nc_id') . ' = ' . $db->quoteName('nc.id') . ')'
			);

		$this->applyEntryFilters($db, $query);
		$query->order($db->quoteName('a.date') . ' ASC');

		$db->setQuery($query);
		$rows = $db->loadObjectList() ?: array();

		if (empty($rows)) {
			return array();
		}

		$componentIds = array_values(array_unique(array_filter(array_map(fn($r) => $r->component, $rows))));
		$modelIds     = array_values(array_unique(array_filter(array_map(fn($r) => $r->model, $rows))));
		$vendorIds    = array_values(array_unique(array_filter(array_map(fn($r) => $r->vendor, $rows))));
		$ncIds        = array_map(fn($r) => (int) $r->nc_id, $rows);

		$componentNames = $this->loadLabelMap($db, '#__product_components', 'id', 'component_name', $componentIds);
		$modelNames     = $this->loadLabelMap($db, '#__product_catalogs', 'id', 'model_name', $modelIds);
		$vendorNames    = $this->loadLabelMap($db, '#__users', 'id', 'name', $vendorIds);

		$imagesByNc     = $this->loadImagesForNcIds($ncIds);

		$result = array();

		foreach ($rows as $r) {
			$result[] = (object) array(
				'nc_id'         => (int) $r->nc_id,
				'entry_id'      => (int) $r->entry_id,
				'reference_no'  => $r->reference_no,
				'date'          => $r->date,
				'component'     => $componentNames[$r->component] ?? $r->component,
				'model'         => $modelNames[$r->model] ?? $r->model,
				'vendor'        => $vendorNames[$r->vendor] ?? $r->vendor,
				// "Remark" in the UI = Normal/Resort (a.lot); "Lot" in the UI = vendor's
				// own remark text (a.remark, resolved via vendor_details/vendor_remarks) -
				// matches the existing filter_remark / filter_lot selectors on this report.
				'remark'        => $r->lot === '1' ? Text::_('COM_DATA_LOT_RESORT') : Text::_('COM_DATA_LOT_NORMAL'),
				'lot'           => $r->remark,
				'nc_quantity'   => (float) $r->nc_quantity,
				'nc_percentage' => (float) $r->nc_percentage,
				'images'        => $imagesByNc[$r->nc_id] ?? array(),
			);
		}

		return $result;
	}

	/**
	 * @since  1.5.0
	 */
	protected function loadLabelMap(DatabaseInterface $db, $table, $keyCol, $labelCol, array $ids)
	{
		if (empty($ids)) {
			return array();
		}

		$query = $db->getQuery(true)
			->select($db->quoteName([$keyCol, $labelCol]))
			->from($db->quoteName($table))
			->where($db->quoteName($keyCol) . ' IN (' . implode(',', array_map('intval', $ids)) . ')');

		$db->setQuery($query);

		$map = array();

		foreach ($db->loadAssocList() as $row) {
			$map[$row[$keyCol]] = $row[$labelCol];
		}

		return $map;
	}

	/**
	 * @since  1.5.0
	 */
	protected function loadImagesForNcIds(array $ncIds)
	{
		$fp = fopen("a_loadImagesForNcIds.txt", "w");
		$write["ncIds"] = $ncIds;
		fwrite($fp, print_r($write, true));
		fclose($fp);

		if (empty($ncIds)) {
			return array();
		}

		$db = Factory::getDbo();
		$query = $db->getQuery(true)
			->select($db->quoteName(['nc_id', 'filepath']))
			->from($db->quoteName('#__data_entry_nc_images'))
			->where($db->quoteName('nc_id') . ' IN (' . implode(',', array_map('intval', $ncIds)) . ')');

		$db->setQuery($query);

		$map = array();

		foreach ($db->loadObjectList() as $row) {
			$map[$row->nc_id][] = rtrim(\Joomla\CMS\Uri\Uri::root(), '/') . '/' . ltrim($row->filepath, '/');
		}

		return $map;
	}
}
