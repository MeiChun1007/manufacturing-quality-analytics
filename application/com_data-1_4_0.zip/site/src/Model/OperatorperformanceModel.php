<?php

/**
 * @version    CVS: 1.8.0
 * @package    Com_Data
 * @author     Mei Chun <qc.yolotech@gmail.com>
 * @copyright  2026 YOLO
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace Data\Component\Data\Site\Model;

defined('_JEXEC') or die;

use \Joomla\CMS\Factory;
use \Joomla\CMS\Component\ComponentHelper;
use \Joomla\CMS\Language\Text;
use \Joomla\CMS\MVC\Model\BaseDatabaseModel;
use \Joomla\Database\DatabaseInterface;

/**
 * Manager-only "Operator Performance" page: Quality (NC%) and Production
 * (Total Sort) leaderboards, each with a trend arrow comparing the current
 * period against the immediately preceding equivalent period. Extends
 * OperatorperformanceModel purely to reuse its filter state, date-range resolution,
 * and getEntityBreakdown() - NOT its per-user visibility restriction, since
 * this page's whole purpose requires seeing every operator at once.
 *
 * As of 1.8.0, also provides getOperatorKpiBreakdown(): per-operator,
 * per-model sort output vs an OT/changeover-adjusted daily target, sourced
 * from #__product_catalogs.
 *
 * @since  1.6.0
 */
class OperatorperformanceModel extends BaseDatabaseModel
{

	/** @var string  'week' or 'month' */
	protected $filterPeriodType = 'week';

	/** @var int  Selected calendar/ISO year. */
	protected $filterYear;

	/** @var string  ISO year-week key, e.g. "2026-W30". */
	protected $filterWeek = '';

	/** @var string  "YYYY-MM". */
	protected $filterMonth = '';

	/** @var string  a.component value, or '' for all parts. */
	protected $filterPart = '';

	/**
	 * @var  string
	 * @since  1.3.0
	 */
	protected $filterModel = '';

	/**
	 * @var  string
	 * @since  1.3.0
	 */
	protected $filterVendor = '';

	/**
	 * @var  string
	 * @since  1.2.0
	 */
	protected $filterOperator = '';

	/**
	 * @var  string  Remark: Normal/Resort
	 * @since  1.2.0
	 */
	protected $filterRemark = '';

	/**
	 * @var  string
	 * @since  1.2.0
	 */
	protected $filterNcCategory = '';

	/**
	 * @var  string
	 * @since  1.2.0
	 */
	protected $filterNcType = '';

	/**
	 * @var  string  Lot
	 * @since  1.2.0
	 */
	protected $filterLot = '';


	/**
	 * @var  string  Y-m-d
	 * @since  1.3.0
	 */
	protected $filterDateFrom = '';

	/**
	 * @var  string  Y-m-d
	 * @since  1.3.0
	 */
	protected $filterDateTo = '';

	/** @var \DateTime  Start of the resolved period, 00:00:00. */
	protected $periodStart;

	/** @var \DateTime  End of the resolved period, 23:59:59. */
	protected $periodEnd;

	/** @var int  Same min-volume guard used elsewhere - not applied to scatter data (volume is directly visible on the X-axis), but IS applied to Biggest Movers below. */
	protected $minSort = 100;

	/**
	 * Constructor.
	 *
	 * @param   array  $config  An optional associative array of configuration settings.
	 *
	 * @since   1.3.0
	 */
	public function __construct($config = array())
	{
		parent::__construct($config);

		$this->populateState();
	}

	/**
	 * Read the Model/Vendor/Date Range filters from the request and persist
	 * them in the user state, defaulting to the trailing 30 days.
	 *
	 * @return  void
	 *
	 * @since   1.3.0
	 */
	protected function populateState()
	{
		$app     = Factory::getApplication();
		$context = 'com_data.operatorperformance.';
		$now = Factory::getDate('now', 'Asia/Kuala_Lumpur');

		// --- Clear Filters: wipe stored session state, then fall through to defaults ---
		if ($app->input->getInt('clearfilters', 0) === 1) {
			$keys = array('vendor', 'lot', 'remark', 'operator', 'part', 'model', 'nc_category', 'nc_type', 'year', 'week', 'period_type', 'date_from', 'date_to');

			foreach ($keys as $key) {
				$app->setUserState($context . 'filter.' . $key, null);
			}

			$app->input->set('filter_vendor', null);
			$app->input->set('filter_lot', null);
			$app->input->set('filter_remark', null);
			$app->input->set('filter_operator', null);
			$app->input->set('filter_part', null);
			$app->input->set('filter_model', null);
			$app->input->set('filter_nc_category', null);
			$app->input->set('filter_nc_type', null);
			$app->input->set('filter_date_from', null);
			$app->input->set('filter_date_to', null);
			$app->input->set('filter_year', null);
			$app->input->set('filter_week', null);
			$app->input->set('filter_period_type', null);
		}

		$defaultTo   = new \DateTime('now');
		$defaultFrom = (clone $defaultTo)->modify('-29 days');

		// 'week' / 'month' = quick presets that compute the range below.
		// 'custom' = trust filterDateFrom/filterDateTo as submitted/persisted.
		// Defaults to 'custom' so existing installs keep their current
		// trailing-30-day behaviour unless someone explicitly picks a preset.
		$this->filterPeriodType = (string) $app->getUserStateFromRequest($context . 'filter.period_type', 'filter_period_type', 'week', 'string');
		$this->filterYear       = (int) $app->getUserStateFromRequest($context . 'filter.year', 'filter_year', (int) $now->format('o'), 'int');
		$this->filterPart  		= (string) $app->getUserStateFromRequest($context . 'filter.part', 'filter_part', '', 'string');
		$this->filterModel      = (string) $app->getUserStateFromRequest($context . 'filter.model', 'filter_model', '', 'string');
		$this->filterVendor     = (string) $app->getUserStateFromRequest($context . 'filter.vendor', 'filter_vendor', '', 'string');
		$this->filterOperator 	= (string) $app->getUserStateFromRequest($context . 'filter.operator', 'filter_operator', '', 'string');
		$this->filterDateFrom   = (string) $app->getUserStateFromRequest($context . 'filter.date_from', 'filter_date_from', $defaultFrom->format('Y-m-d'), 'string');
		$this->filterDateTo     = (string) $app->getUserStateFromRequest($context . 'filter.date_to', 'filter_date_to', $defaultTo->format('Y-m-d'), 'string');
		$this->filterLot		= (string) $app->getUserStateFromRequest($context . 'filter.lot', 'filter_lot', '', 'string');
		$this->filterNcCategory	= (string) $app->getUserStateFromRequest($context . 'filter.nc_category', 'filter_nc_category', '', 'string');
		$this->filterNcType		= (string) $app->getUserStateFromRequest($context . 'filter.nc_type', 'filter_nc_type', '', 'string');
		$this->filterRemark 	= (string) $app->getUserStateFromRequest($context . 'filter.remark', 'filter_remark', '0', 'string');

		$rawWeek  = (string) $app->getUserStateFromRequest($context . 'filter.week', 'filter_week', '', 'string');
		$rawMonth = (string) $app->getUserStateFromRequest($context . 'filter.month', 'filter_month', '', 'string');

		// Empty (unselected) or explicit 'all' both mean "whole year" - see note above
		// re: this changing the previous "defaults to current week/month" behaviour.
		$this->filterWeek  = $rawWeek === 'all' ? 'all' : (int) $rawWeek;
		$this->filterMonth = $rawMonth === 'all' ? 'all' : (int) $rawMonth;


		if (!in_array($this->filterPeriodType, array('week', 'month', 'custom'), true)) {
			$this->filterPeriodType = 'custom';
		}

		if ($this->filterYear < 2000 || $this->filterYear > 2100) {
			$this->filterYear = (int) $now->format('o');
		}

		if ($this->filterWeek !== 'all' && ($this->filterWeek < 1 || $this->filterWeek > 53)) {
			$this->filterWeek = (int) $now->format('W');
		}

		if ($this->filterMonth !== 'all' && ($this->filterMonth < 1 || $this->filterMonth > 12)) {
			$this->filterMonth = (int) $now->format('n');
		}

		// Guard against an inverted or malformed custom range - only meaningful
		// when period_type is 'custom', but validated unconditionally so a stale
		// stored value can't cause a bad range if the user switches back to it later.
		if ($this->filterDateFrom === '' || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $this->filterDateFrom)) {
			$this->filterDateFrom = $defaultFrom->format('Y-m-d');
		}

		if ($this->filterDateTo === '' || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $this->filterDateTo)) {
			$this->filterDateTo = $defaultTo->format('Y-m-d');
		}

		if ($this->filterDateFrom > $this->filterDateTo) {
			list($this->filterDateFrom, $this->filterDateTo) = array($this->filterDateTo, $this->filterDateFrom);
		}

		// A preset overrides the working date range for THIS request only - it
		// never overwrites the persisted custom date_from/date_to user state, so
		// switching back to "Custom" later still shows whatever range someone
		// last set there, rather than losing it.

		if ($this->filterPeriodType === 'week') {
			if ($this->filterWeek === 'all') {
				$this->resolveYearPeriod();
			} else {
				$this->resolveWeekPeriod();
			}
			$this->filterDateFrom = $this->periodStart->format('Y-m-d');
			$this->filterDateTo   = $this->periodEnd->format('Y-m-d');
		} elseif ($this->filterPeriodType === 'month') {
			if ($this->filterMonth === 'all') {
				$this->resolveYearPeriod();
			} else {
				$this->resolveMonthPeriod();
			}
			$this->filterDateFrom = $this->periodStart->format('Y-m-d');
			$this->filterDateTo   = $this->periodEnd->format('Y-m-d');
		} else {
			$this->periodStart = new \DateTime($this->filterDateFrom);
			$this->periodEnd   = new \DateTime($this->filterDateTo);
		}

		// --- Default (and, for operator-restricted users, FORCE) the Operator
		// filter to "own account" - keyed off the same viewOwnOperator groups
		// applyEntryFilters() uses for the actual query-level restriction, so
		// the pre-selected filter and the enforced boundary never drift apart.
		// Super Users are exempt, matching applyEntryFilters()'s core.admin check.
		$user   = $app->getIdentity();
		$userId = (int) $user->get('id');

		if ($userId > 0) {
			$userGroupIds = array_map('intval', (array) $user->get('groups'));
			$params       = ComponentHelper::getParams('com_data');
			$viewOwnOperatorGroups = array_map('intval', (array) $params->get('viewOwnOperator', []));
			$viewOwnVendorGroups = array_map('intval', (array) $params->get('viewOwnVendor', []));

			$isSuperUser = $user->authorise('core.admin');

			if (!$isSuperUser && !empty(array_intersect($userGroupIds, $viewOwnOperatorGroups))) {
				$this->filterOperator = $userId;
			}

			if (!$isSuperUser && !empty(array_intersect($userGroupIds, $viewOwnVendorGroups))) {
				$this->filterVendor = $userId;
			}
		}
	}

	/**
	 * Resolve the selected (or default = current) ISO week into
	 * Monday 00:00:00 - Sunday 23:59:59.
	 *
	 * @return  void
	 *
	 * @since   1.3.0
	 */
	protected function resolveWeekPeriod()
	{
		$this->periodStart = new \DateTime();
		$this->periodStart->setISODate($this->filterYear, $this->filterWeek, 1)->setTime(0, 0, 0);

		$this->periodEnd = clone $this->periodStart;
		$this->periodEnd->modify('+6 days')->setTime(23, 59, 59);
	}

	/**
	 * Resolve the selected (or default = current) calendar month into
	 * the 1st 00:00:00 - last day 23:59:59.
	 *
	 * @return  void
	 *
	 * @since   1.3.0
	 */
	protected function resolveMonthPeriod()
	{
		$this->periodStart = new \DateTime();
		$this->periodStart->setDate($this->filterYear, $this->filterMonth, 1)->setTime(0, 0, 0);

		$this->periodEnd = clone $this->periodStart;
		$this->periodEnd->modify('last day of this month')->setTime(23, 59, 59);
	}

	/**
	 * Resolve the selected (or default = current) calendar year into
	 * Jan 1 00:00:00 - Dec 31 23:59:59. Used when period_type is 'week' or
	 * 'month' but no specific week/month is selected ('all' or unset).
	 *
	 * @return  void
	 *
	 * @since   1.5.0
	 */
	protected function resolveYearPeriod()
	{
		$this->periodStart = new \DateTime();
		$this->periodStart->setDate($this->filterYear, 1, 1)->setTime(0, 0, 0);

		$this->periodEnd = clone $this->periodStart;
		$this->periodEnd->setDate($this->filterYear, 12, 31)->setTime(23, 59, 59);
	}

	/**
	 * True when the resolved period is "whole year" — i.e. period_type is
	 * 'week'/'month' but the corresponding selector is 'all'.
	 *
	 * @return  boolean
	 *
	 * @since   1.5.0
	 */
	protected function isFullYearPeriod()
	{
		return ($this->filterPeriodType === 'week' && $this->filterWeek === 'all')
			|| ($this->filterPeriodType === 'month' && $this->filterMonth === 'all');
	}

	/**
	 * The currently active filters, so the view can re-populate the form.
	 *
	 * @return  object
	 *
	 * @since   1.3.0
	 */
	public function getActiveFilters()
	{
		$from = new \DateTime($this->filterDateFrom);
		$to   = new \DateTime($this->filterDateTo);

		return (object) array(
			'period_type' => $this->filterPeriodType,
			'year'        => $this->filterYear,
			'week'        => $this->filterWeek,
			'month'       => $this->filterMonth,
			'part'        => $this->filterPart,
			'model'       => $this->filterModel,
			'nc_category' => $this->filterNcCategory,
			'nc_type'     => $this->filterNcType,
			'vendor'      => $this->filterVendor,
			'operator'    => $this->filterOperator,
			'remark'      => $this->filterRemark,
			'lot'         => $this->filterLot,
			'date_from'   => $this->filterDateFrom,
			'date_to'     => $this->filterDateTo,
			'day_span'    => $from->diff($to)->days + 1,
		);
	}

	/**
	 * @return  array  [prevFromYmd, prevToYmd]
	 *
	 * @since   1.6.0
	 */
	protected function previousPeriodRange()
	{
		// Calendar-aware comparison for the 'week'/'month' presets, so
		// "September" compares against the whole of "August" rather than
		// an equal-length 30-day window that can drift into the wrong month.
		if ($this->filterPeriodType === 'month' && $this->filterMonth !== 'all') {
			$prevStart = new \DateTime();
			$prevStart->setDate($this->filterYear, $this->filterMonth, 1)
				->modify('-1 month')
				->setTime(0, 0, 0);

			$prevEnd = clone $prevStart;
			$prevEnd->modify('last day of this month')->setTime(23, 59, 59);

			return array($prevStart->format('Y-m-d'), $prevEnd->format('Y-m-d'));
		}

		if ($this->filterPeriodType === 'week' && $this->filterWeek !== 'all') {
			$prevStart = new \DateTime();
			$prevStart->setISODate($this->filterYear, $this->filterWeek, 1)
				->modify('-7 days')
				->setTime(0, 0, 0);

			$prevEnd = clone $prevStart;
			$prevEnd->modify('+6 days')->setTime(23, 59, 59);

			return array($prevStart->format('Y-m-d'), $prevEnd->format('Y-m-d'));
		}

		// 'custom' (and the full-year 'all' cases) fall back to an
		// equal-length adjacent window, since there's no calendar unit to anchor to.
		$from = new \DateTime($this->filterDateFrom);
		$to   = new \DateTime($this->filterDateTo);

		$daySpan = $from->diff($to)->days + 1;

		$prevTo   = (clone $from)->modify('-1 day');
		$prevFrom = (clone $prevTo)->modify('-' . ($daySpan - 1) . ' days');

		return array($prevFrom->format('Y-m-d'), $prevTo->format('Y-m-d'));
	}

	/**
	 * Years with data, newest first. Always includes the current year.
	 *
	 * @return  array  Plain list of ints, e.g. [2027, 2026, 2025]
	 */
	public function getYearOptions()
	{
		$db = Factory::getContainer()->get(DatabaseInterface::class);

		$query = $db->getQuery(true)
			->select('DISTINCT YEAR(' . $db->quoteName('date') . ') AS yr')
			->from($db->quoteName('#__data_entry'))
			->where($db->quoteName('date') . ' IS NOT NULL')
			->order('yr DESC');

		$db->setQuery($query);
		$years = array_map('intval', $db->loadColumn() ?: array());

		$currentYear = (int) (new \DateTime())->format('Y');

		if (!in_array($currentYear, $years, true)) {
			array_unshift($years, $currentYear);
			rsort($years);
		}

		return $years;
	}

	/**
	 * Recent months available for the Month Selector, newest first.
	 * Always includes the current month even with no data yet.
	 *
	 * @return  array  List of objects: { value: "2026-07", label: "July 2026" }
	 *
	 * @since   1.3.0
	 */
	public function getMonthOptions()
	{
		$db = Factory::getContainer()->get(DatabaseInterface::class);

		$query = $db->getQuery(true)
			->select('DISTINCT MONTH(' . $db->quoteName('date') . ') AS mo')
			->from($db->quoteName('#__data_entry'))
			->where('YEAR(' . $db->quoteName('date') . ') = ' . (int) $this->filterYear)
			->order('mo DESC');

		$db->setQuery($query);
		$months = array_map('intval', $db->loadColumn() ?: array());

		$now     = Factory::getDate('now', 'Asia/Kuala_Lumpur');


		if ((int) $now->format('Y') === $this->filterYear && !in_array((int) $now->format('n'), $months, true)) {
			$months[] = (int) $now->format('n');
		}

		if (empty($months) && $this->filterMonth !== 'all') {
			$months[] = $this->filterMonth;
		}

		rsort($months);

		$options = array();
		$options[] = (object) array('value' => 'all', 'label' => Text::_('COM_DATA_ALL_MONTHS'));


		foreach ($months as $m) {
			$d = Factory::getDate('now', 'Asia/Kuala_Lumpur');
			$d->setDate($this->filterYear, $m, 1);

			$options[] = (object) array(
				'value' => $m,
				'label' => $d->format('F'),
			);
		}

		return $options;
	}

	/**
	 * Distinct ISO weeks (Monday-Sunday, derived from the `date` field) available
	 * for the Week Selector, newest first. Always includes the current week.
	 *
	 * @return  array  List of objects: { value: "2026-W30", week: 30, year: 2026, label: "20 Jul - 26 Jul 2026" }
	 *
	 * @since   1.3.0
	 */
	public function getWeekOptions()
	{
		$db = Factory::getContainer()->get(DatabaseInterface::class);

		$query = $db->getQuery(true)
			->select('DISTINCT WEEK(' . $db->quoteName('date') . ', 3) AS wk') // mode 3 = ISO week, 1-53
			->from($db->quoteName('#__data_entry'))
			->where('YEAR(' . $db->quoteName('date') . ') = ' . (int) $this->filterYear)
			->order('wk DESC');

		$db->setQuery($query);
		$weeks = array_map('intval', $db->loadColumn() ?: array());

		$now = new \DateTime();

		if ((int) $now->format('o') === $this->filterYear && !in_array((int) $now->format('W'), $weeks, true)) {
			$weeks[] = (int) $now->format('W');
		}

		if (empty($weeks) && $this->filterWeek !== 'all') {
			$weeks[] = $this->filterWeek;
		}

		rsort($weeks);

		$options = array();
		$options[] = (object) array('value' => 'all', 'label' => Text::_('COM_DATA_ALL_WEEKS'));

		foreach ($weeks as $week) {
			$start = new \DateTime();
			$start->setISODate($this->filterYear, $week, 1);
			$end = (clone $start)->modify('+6 days');

			$options[] = (object) array(
				'value' => $week,
				'label' => sprintf('%s - %s', $start->format('d M'), $end->format('d M')),
			);
		}

		return $options;
	}

	/**
	 * The comparison period used for trend calculation, for display purposes.
	 *
	 * @return  object  { from: 'Y-m-d', to: 'Y-m-d' }
	 *
	 * @since   1.6.0
	 */
	public function getPreviousPeriodRange()
	{
		list($prevFrom, $prevTo) = $this->previousPeriodRange();

		return (object) array(
			'from' => $prevFrom,
			'to'   => $prevTo,
		);
	}

	/**
	 * Distinct Remark values (a.lot), for the "SELECT REMARK" filter.
	 *
	 * @return  array
	 *
	 * @since   1.3.0
	 */
	public function getLotOptions()
	{
		$db = Factory::getContainer()->get(DatabaseInterface::class);

		$query = $db->getQuery(true)
			->select(
				'DISTINCT ' . $db->quoteName('vr.id', 'value') . ', ' .
					$db->quoteName('vr.remark', 'text')
			)
			->from($db->quoteName('#__data_entry', 'a'))
			->join('INNER', $db->quoteName('#__vendor_details', 'vd') . ' ON ' . $db->quoteName('vd.id') . ' = ' . $db->quoteName('a.remark'))
			->join('INNER', $db->quoteName('#__vendor_remarks', 'vr') . ' ON ' . $db->quoteName('vr.id') . ' = ' . $db->quoteName('vd.remark'))
			->join('INNER', $db->quoteName('#__users', 'uv') . ' ON ' . $db->quoteName('uv.id') . ' = ' . $db->quoteName('a.vendor'))
			->where($db->quoteName('a.remark') . ' != ' . $db->quote(''))
			->where($db->quoteName('a.state') . ' = ' . $db->quote(1));

		// Apply selected filters, EXCEPT the current Lot filter
		$this->applyEntryFilters($db, $query, 'a', ['lot']);

		$query->order($db->quoteName('vr.remark') . ' ASC');

		$db->setQuery($query);

		return $db->loadObjectList() ?: array();
	}

	/**
	 * Distinct Part values (a.component), for the "SELECT PART" filter.
	 *
	 * @return  array
	 *
	 * @since   1.3.0
	 */
	public function getPartOptions()
	{
		$db = Factory::getContainer()->get(DatabaseInterface::class);

		$query = $db->getQuery(true)
			->select(
				'DISTINCT ' . $db->quoteName('a.component', 'value') . ', ' .
					$db->quoteName('pc.component_name', 'text')
			)
			->from($db->quoteName('#__data_entry', 'a'))
			->join('INNER', $db->quoteName('#__product_components', 'pc') . ' ON ' . $db->quoteName('pc.id') . ' = ' . $db->quoteName('a.component'))
			->where($db->quoteName('a.component') . ' != ' . $db->quote(''))
			->where($db->quoteName('a.state') . ' = ' . $db->quote(1))
			->order($db->quoteName('pc.component_name') . ' ASC');

		// Apply selected filters, EXCEPT the current Part filter
		$this->applyEntryFilters($db, $query, 'a', ['part']);

		$db->setQuery($query);

		return $db->loadObjectList() ?: array();
	}

	/**
	 * Distinct list of models available for the Model Selector.
	 *
	 * @return  array
	 *
	 * @since   1.3.0
	 */
	public function getModelOptions()
	{
		$db = Factory::getContainer()->get(DatabaseInterface::class);

		$query = $db->getQuery(true)
			->select(
				'DISTINCT ' . $db->quoteName('pm.id', 'value') . ', ' .
					$db->quoteName('pm.model_name', 'text')
			)
			->from($db->quoteName('#__data_entry', 'a'))
			->join('INNER', $db->quoteName('#__product_catalogs', 'pm') . ' ON ' . $db->quoteName('pm.id') . ' = ' . $db->quoteName('a.model'))
			->where($db->quoteName('a.model') . ' IS NOT NULL')
			->where($db->quoteName('a.state') . ' = 1');

		// Apply selected filters, EXCEPT the current Model filter
		$this->applyEntryFilters($db, $query, 'a', ['model']);

		$query->order($db->quoteName('pm.model_name') . ' ASC');

		$db->setQuery($query);

		return $db->loadObjectList() ?: array();
	}

	/**
	 * Distinct list of vendors available for the Vendor Selector.
	 *
	 * @return  array
	 *
	 * @since   1.3.0
	 */
	public function getVendorOptions()
	{
		$db = Factory::getContainer()->get(DatabaseInterface::class);

		$query = $db->getQuery(true)
			->select(
				'DISTINCT ' . $db->quoteName('a.vendor', 'key') . ', ' .
					$db->quoteName('uv.name', 'value')
			)
			->from($db->quoteName('#__data_entry', 'a'))
			->join('INNER', $db->quoteName('#__users', 'uv') . ' ON ' . $db->quoteName('uv.id') . ' = ' . $db->quoteName('a.vendor'))
			->where($db->quoteName('a.state') . ' = 1')
			->order($db->quoteName('uv.name') . ' ASC');

		// Apply selected filters, EXCEPT the current Vendor filter
		$this->applyEntryFilters($db, $query, 'a', ['vendor']);

		$db->setQuery($query);

		return $db->loadObjectList() ?: array();
	}

	/**
	 * Distinct list of operators available for the Operator Selector.
	 *
	 * @return  array
	 *
	 * @since   1.2.0
	 */
	public function getOperatorOptions()
	{
		$db = Factory::getContainer()->get(DatabaseInterface::class);

		$query = $db->getQuery(true)
			->select(
				'DISTINCT ' . $db->quoteName('a.operator', 'key') . ', ' .
					$db->quoteName('uv.name', 'value')
			)
			->from($db->quoteName('#__data_entry', 'a'))
			->join('INNER', $db->quoteName('#__users', 'uv') . ' ON ' . $db->quoteName('uv.id') . ' = ' . $db->quoteName('a.operator'))
			->where($db->quoteName('a.state') . ' = 1')
			->order($db->quoteName('uv.name') . ' ASC');

		// Apply selected filters, EXCEPT the current Vendor filter
		$this->applyEntryFilters($db, $query, 'a', ['operator']);

		$db->setQuery($query);

		return $db->loadObjectList() ?: array();
	}

	public function getRemarkOptions()
	{
		$remarkOptions = array(
			'0' => Text::_('COM_DATA_LOT_NORMAL'),
			'1' => Text::_('COM_DATA_LOT_RESORT'),
		);

		return $remarkOptions;
	}

	/**
	 * Distinct NC Category values in use, for the "SELECT NC CATEGORY" filter.
	 * Joined through #__data_entry_nc since nc_category lives there, not on
	 * #__data_entry itself - mirrors the com_data entries list's SQL field.
	 *
	 * @return  array
	 *
	 * @since   1.7.0
	 */
	public function getNCCategoryOptions()
	{
		$db = Factory::getContainer()->get(DatabaseInterface::class);

		$query = $db->getQuery(true)
			->select(
				'DISTINCT ' . $db->quoteName('cat.id', 'value') . ', ' .
					$db->quoteName('cat.category', 'text')
			)
			->from($db->quoteName('#__nc_category', 'cat'))
			->join(
				'INNER',
				$db->quoteName('#__data_entry_nc', 'nc') .
					' ON FIND_IN_SET(' . $db->quoteName('cat.id') . ', ' . $db->quoteName('nc.nc_category') . ')'
			)
			->join('INNER', $db->quoteName('#__data_entry', 'a') . ' ON ' . $db->quoteName('a.id') . ' = ' . $db->quoteName('nc.entry_id'))
			->where($db->quoteName('cat.state') . ' = 1')
			->where($db->quoteName('a.state') . ' = 1');


		// Apply selected filters, EXCEPT the current NC Category filter
		// $this->applyEntryFilters($db, $query, 'nc', ['nc_category']);

		$query->order($db->quoteName('cat.category') . ' ASC');

		$db->setQuery($query);

		return $db->loadObjectList() ?: array();
	}

	/**
	 * Distinct NC Type values in use, for the "SELECT NC TYPE" filter.
	 * Joined through #__data_entry_nc since nc_type lives there, not on
	 * #__data_entry itself - mirrors the com_data entries list's SQL field.
	 *
	 * @return  array
	 *
	 * @since   1.7.0
	 */
	public function getNCTypeOptions()
	{
		$db = Factory::getContainer()->get(DatabaseInterface::class);

		$query = $db->getQuery(true)
			->select(
				'DISTINCT ' . $db->quoteName('nt.id', 'value') . ', ' .
					$db->quoteName('nt.nc', 'text')
			)
			->from($db->quoteName('#__nc_types', 'nt'))
			->join(
				'INNER',
				$db->quoteName('#__data_entry_nc', 'nc') .
					' ON FIND_IN_SET(' . $db->quoteName('nt.id') . ', ' . $db->quoteName('nc.nc_type') . ')'
			)
			->join('INNER', $db->quoteName('#__data_entry', 'a') . ' ON ' . $db->quoteName('a.id') . ' = ' . $db->quoteName('nc.entry_id'))
			->where($db->quoteName('nt.state') . ' = 1')
			->where($db->quoteName('a.state') . ' = 1');

		// Apply selected filters, EXCEPT the current NC Type filter
		$this->applyEntryFilters($db, $query, 'a', ['nc_type']);

		$query->order($db->quoteName('nt.nc') . ' ASC');

		$db->setQuery($query);

		return $db->loadObjectList() ?: array();
	}

	/**
	 * Confirm the current user is actually allowed to view this page at
	 * all - separate from operatorperformanceModel's row-level access control, since
	 * this page needs an all-or-nothing gate, not per-row filtering.
	 *
	 * @return  boolean
	 *
	 * @since   1.6.0
	 */
	public function canViewPerformance()
	{
		$user = Factory::getApplication()->getIdentity();

		if ($user->authorise('core.admin')) {
			return true;
		}

		$params        = ComponentHelper::getParams('com_data');
		$allowedGroups = array_map('intval', (array) $params->get('viewOperatorPerformance', []));
		$userGroupIds  = array_map('intval', (array) $user->get('groups'));

		return !empty(array_intersect($userGroupIds, $allowedGroups));
	}

	/**
	 * @param   integer  $limit  Maximum number of rows to return.
	 *
	 * @return  object
	 *
	 * @since   1.6.0
	 */
	public function getQualityRanking($limit = 20)
	{
		return $this->getRankingWithTrend('nc_pct', $limit);
	}

	/**
	 * @param   integer  $limit  Maximum number of rows to return.
	 *
	 * @return  object
	 *
	 * @since   1.6.0
	 */
	public function getProductionRanking($limit = 20)
	{
		return $this->getRankingWithTrend('total_sort', $limit);
	}

	/**
	 * @param   string   $sortBy  'nc_pct' or 'total_sort'.
	 * @param   integer  $limit   Maximum number of rows to return.
	 *
	 * @return  object
	 *
	 * @since   1.6.0
	 */
	protected function getRankingWithTrend($sortBy, $limit)
	{
		$current = $this->getEntityBreakdown(
			'a.operator',
			'#__users',
			'name',
			$limit,
			null,
			null,
			null,
			$sortBy
		);

		list($prevFrom, $prevTo) = $this->previousPeriodRange();

		$previous = $this->getEntityBreakdown(
			'a.operator',
			'#__users',
			'name',
			1000,
			null,
			null,
			null,
			$sortBy,
			$prevFrom,
			$prevTo
		);

		$previousByOperator = array();

		foreach ($previous->rows as $row) {
			$previousByOperator[$row->entity_id] = $row;
		}

		foreach ($current->rows as $row) {
			$prevRow = $previousByOperator[$row->entity_id] ?? null;

			if ($prevRow === null) {
				$row->trend = null;
				continue;
			}

			$currentValue  = $sortBy === 'total_sort' ? $row->total_sort : $row->nc_pct;
			$previousValue = $sortBy === 'total_sort' ? $prevRow->total_sort : $prevRow->nc_pct;

			if ($currentValue > $previousValue) {
				$row->trend = 'up';
			} elseif ($currentValue < $previousValue) {
				$row->trend = 'down';
			} else {
				$row->trend = 'flat';
			}
		}

		return $current;
	}

	/**
	 * Shared implementation for the Vendor/Model breakdown tables: Total
	 * Sort (de-duplicated by entry) and Total NC per distinct value of the
	 * given column, joined to its lookup table for a display label.
	 *
	 * Ranked by NC% (high to low), not by volume - entities with less than
	 * $minSort total units sorted are excluded from the ranking entirely,
	 * since a tiny batch with one defect can otherwise show a misleadingly
	 * high NC% and crowd out entities with real, meaningful volume. The
	 * excluded count is returned alongside the rows so the UI can say so
	 * explicitly, rather than silently dropping entries with no explanation.
	 *
	 * An optional extra column (e.g. Part, for the Model breakdown) can be
	 * carried through and resolved to its own label. Since that extra column
	 * isn't guaranteed to be single-valued per entity (nothing in the schema
	 * enforces "one Model always has exactly one Part"), the MOST COMMON
	 * value across matching entries is used - not simply the first one found.
	 *
	 * @param   string       $column           Fully-qualified column on #__data_entry, e.g. 'a.vendor'.
	 * @param   string       $lookupTable      Lookup table holding the display name.
	 * @param   string       $labelField       Column on the lookup table holding the display name.
	 * @param   integer      $limit            Maximum number of rows to return.
	 * @param   string|null  $extraColumn      Optional second fully-qualified column to carry through, e.g. 'a.component'.
	 * @param   string|null  $extraLookupTable Lookup table for the extra column's label.
	 * @param   string|null  $extraLabelField  Column on the extra lookup table holding the display name.
	 *
	 * @return  object  { rows: [{ label, [extra_label,] total_sort, total_nc, nc_pct }], excluded: int }
	 *
	 * @since   1.3.0
	 */
	protected function getEntityBreakdown(
		$column,
		$lookupTable,
		$labelField,
		$limit,
		$extraColumn = null,
		$extraLookupTable = null,
		$extraLabelField = null,
		$sortBy = 'nc_pct',
		$dateFrom = null,
		$dateTo = null
	) {
		$all = $this->fetchEntityStats($column, $lookupTable, $labelField, $extraColumn, $extraLookupTable, $extraLabelField, $dateFrom, $dateTo);

		$minSort = $this->minSort;

		$totalCandidates = count($all);
		$all = array_values(array_filter($all, fn($row) => $row->total_sort >= $minSort));
		$excludedCount = $totalCandidates - count($all);

		usort($all, fn($a, $b) => $b->$sortBy <=> $a->$sortBy);

		return (object) array(
			'rows'     => array_slice($all, 0, $limit),
			'excluded' => $excludedCount,
		);
	}

	/**
	 * Shared raw fetch: de-duplicated Total Sort and Total NC per distinct
	 * value of $column, with labels resolved in ONE batch query each (via
	 * loadLabelMap()) rather than one query per row - this also fixes a
	 * latent N+1 query pattern that existed in the old getEntityBreakdown().
	 * No filtering, sorting, or limiting happens here - that's each caller's
	 * own job, since minSort exclusion and ranking behavior genuinely differ
	 * between the two current callers.
	 *
	 * @return  array  Unsorted objects: { entity_id, label, [part_label,]
	 *                 total_sort, total_nc, nc_pct }
	 *
	 * @since   1.7.0
	 */
	protected function fetchEntityStats(
		$column,
		$lookupTable,
		$labelField,
		$extraColumn = null,
		$extraLookupTable = null,
		$extraLabelField = null,
		$dateFrom = null,
		$dateTo = null
	) {
		$db = Factory::getContainer()->get(DatabaseInterface::class);

		$selectCols = 'DISTINCT ' . $db->quoteName('a.id') . ', ' .
			$db->quoteName($column) . ' AS entity_key, ' .
			$db->quoteName('a.total');

		if ($extraColumn !== null) {
			$selectCols .= ', ' . $db->quoteName($extraColumn) . ' AS extra_key';
		}

		$sortSubQuery = $db->getQuery(true)
			->select($selectCols)
			->from($db->quoteName('#__data_entry', 'a'))
			->where($db->quoteName('a.state') . ' = 1')
			->where($db->quoteName($column) . ' IS NOT NULL');
		$this->applyEntryFilters($db, $sortSubQuery, 'a', [], $dateFrom, $dateTo);

		$sortQuery = $db->getQuery(true)
			->select('entity_key, SUM(total) AS total_sort')
			->from('(' . (string) $sortSubQuery . ') AS dedup')
			->group('entity_key');

		$db->setQuery($sortQuery);
		$sortRows = $db->loadObjectList() ?: array();

		$ncQuery = $db->getQuery(true)
			->select(
				$db->quoteName($column) . ' AS entity_key, ' .
					'SUM(' . $db->quoteName('nc.nc_quantity') . ') AS total_nc'
			)
			->from($db->quoteName('#__data_entry_nc', 'nc'))
			->join('INNER', $db->quoteName('#__data_entry', 'a') . ' ON ' . $db->quoteName('a.id') . ' = ' . $db->quoteName('nc.entry_id'))
			->where($db->quoteName('a.state') . ' = 1')
			->where($db->quoteName($column) . ' IS NOT NULL')
			->group($db->quoteName($column));
		$this->applyEntryFilters($db, $ncQuery, 'a', [], $dateFrom, $dateTo);

		$db->setQuery($ncQuery);
		$ncRows = $db->loadObjectList() ?: array();

		$ncByKey = array();

		foreach ($ncRows as $r) {
			$ncByKey[(string) $r->entity_key] = (float) $r->total_nc;
		}

		$extraByKey = array();

		if ($extraColumn !== null) {
			$countSubQuery = $db->getQuery(true)
				->select($selectCols)
				->from($db->quoteName('#__data_entry', 'a'))
				->where($db->quoteName('a.state') . ' = 1')
				->where($db->quoteName($column) . ' IS NOT NULL')
				->where($db->quoteName($extraColumn) . ' IS NOT NULL');
			$this->applyEntryFilters($db, $countSubQuery, 'a', [], $dateFrom, $dateTo);

			$extraCountQuery = $db->getQuery(true)
				->select('entity_key, extra_key, COUNT(*) AS occurrences')
				->from('(' . (string) $countSubQuery . ') AS dedup')
				->group('entity_key, extra_key')
				->order('entity_key ASC, occurrences DESC');

			$db->setQuery($extraCountQuery);
			$extraCountRows = $db->loadObjectList() ?: array();

			foreach ($extraCountRows as $r) {
				$key = (string) $r->entity_key;

				if (!isset($extraByKey[$key])) {
					$extraByKey[$key] = (string) $r->extra_key;
				}
			}
		}

		// Batch-resolve every label in one query, instead of one query per row
		// (the old getEntityBreakdown() only avoided this by slicing to $limit
		// BEFORE resolving labels - fine when limited, but queryOperatorStats
		// needs every row's label, which would have meant N individual queries).
		$entityIds = array_map(fn($r) => (int) $r->entity_key, $sortRows);
		$labelMap  = $this->loadLabelMap($db, $lookupTable, 'id', $labelField, $entityIds);

		$extraLabelMap = array();

		if ($extraColumn !== null && !empty($extraByKey)) {
			$extraIds       = array_map('intval', array_unique(array_values($extraByKey)));
			$extraLabelMap  = $this->loadLabelMap($db, $extraLookupTable, 'id', $extraLabelField, $extraIds);
		}

		$all = array();

		foreach ($sortRows as $r) {
			$key       = (string) $r->entity_key;
			$totalSort = (float) $r->total_sort;
			$totalNc   = $ncByKey[$key] ?? 0.0;

			$row = array(
				'entity_id'  => (int) $key,
				'label'      => $labelMap[(int) $key] ?? $key,
				'total_sort' => $totalSort,
				'total_nc'   => $totalNc,
				'nc_pct'     => $totalSort > 0 ? ($totalNc / $totalSort) * 100 : 0.0,
			);

			if ($extraColumn !== null) {
				$extraKey        = $extraByKey[$key] ?? null;
				$row['part_label'] = $extraKey !== null ? ($extraLabelMap[(int) $extraKey] ?? $extraKey) : null;
			}

			$all[] = (object) $row;
		}

		return $all;
	}

	/**
	 * Every operator with any activity in the current scope - unfiltered by
	 * $minSort, since the scatter's X-axis already makes low-volume operators
	 * visually obvious without needing to hide them.
	 *
	 * @return  array  Objects: { operator_id, label, total_sort, total_nc, nc_pct }
	 *
	 * @since   1.6.0
	 */
	public function getScatterData()
	{
		return $this->queryOperatorStats();
	}

	/**
	 * Same stats, for an explicit date range instead of the currently active
	 * filter - used to fetch the previous period for Biggest Movers, without
	 * disturbing $this->filterDateFrom/$this->filterDateTo for anything else
	 * running in the same request.
	 *
	 * @param   string  $dateFrom  Y-m-d
	 * @param   string  $dateTo    Y-m-d
	 *
	 * @return  array
	 *
	 * @since   1.6.0
	 */
	protected function getOperatorStatsForRange($dateFrom, $dateTo)
	{
		$originalFrom = $this->filterDateFrom;
		$originalTo   = $this->filterDateTo;

		$this->filterDateFrom = $dateFrom;
		$this->filterDateTo   = $dateTo;

		try {
			$points = $this->queryOperatorStats();
		} finally {
			$this->filterDateFrom = $originalFrom;
			$this->filterDateTo   = $originalTo;
		}

		return $points;
	}

	/**
	 * Shared query: Total Sort (de-duplicated by entry) and Total NC per
	 * operator, using whatever $this->filterDateFrom/$this->filterDateTo
	 * currently hold when called.
	 *
	 * @return  array  Objects: { operator_id, label, total_sort, total_nc, nc_pct }
	 *
	 * @since   1.6.0
	 */
	protected function queryOperatorStats()
	{
		return $this->fetchEntityStats('a.operator', '#__users', 'name');
	}

	/**
	 * The operators whose NC% moved the most (in either direction) versus the
	 * immediately preceding equivalent period. Only compares operators who
	 * had at least $minSort volume in BOTH periods, so "0 units then, 50
	 * units now" doesn't register as a dramatic swing - that's a volume
	 * change, not a quality trend.
	 *
	 * @param   integer  $limit  Max entries per direction (improved/declined).
	 *
	 * @return  object  { improved: [...], declined: [...] }
	 *
	 * @since   1.6.0
	 */
	public function getBiggestMovers($limit = 3)
	{
		$current = $this->getScatterData();

		list($prevFrom, $prevTo) = $this->previousPeriodRange();
		$previous = $this->getOperatorStatsForRange($prevFrom, $prevTo);

		$previousByOperator = array();

		foreach ($previous as $row) {
			$previousByOperator[$row->operator_id] = $row;
		}

		$movers = array();

		foreach ($current as $row) {
			$prevRow = $previousByOperator[$row->operator_id] ?? null;

			if ($prevRow === null || $prevRow->total_sort < $this->minSort || $row->total_sort < $this->minSort) {
				continue;
			}

			// Positive delta = NC% got worse; negative = improved.
			$delta = $row->nc_pct - $prevRow->nc_pct;

			$movers[] = (object) array(
				'operator_id'  => $row->operator_id,
				'label'        => $row->label,
				'current_pct'  => $row->nc_pct,
				'previous_pct' => $prevRow->nc_pct,
				'delta'        => $delta,
			);
		}

		$improved = array_values(array_filter($movers, function ($m) {
			return $m->delta < 0;
		}));
		$declined = array_values(array_filter($movers, function ($m) {
			return $m->delta > 0;
		}));

		usort($improved, function ($a, $b) {
			return $a->delta <=> $b->delta;
		}); // most negative first
		usort($declined, function ($a, $b) {
			return $b->delta <=> $a->delta;
		}); // most positive first

		return (object) array(
			'improved' => array_slice($improved, 0, $limit),
			'declined' => array_slice($declined, 0, $limit),
		);
	}

	/**
	 * Per-operator, per-model KPI: sort output vs an overtime and
	 * changeover-adjusted daily target, pulled from #__product_catalogs
	 * (normal_hours_output / ot_hours_output).
	 *
	 * Always computed per calendar day internally, since OT and the
	 * changeover penalty are inherently daily concepts (a.model is treated
	 * as a single foreign key here - confirmed one inspection record only
	 * ever selects one model, unlike component/vendor which can be CSV
	 * multi-value). When the active filter spans more than one day, the
	 * per-day rows are rolled up into one row per operator+model, summing
	 * both sort output and each day's already-adjusted target - never
	 * re-deriving the target from a summed output, since that would lose
	 * the per-day OT/changeover context.
	 *
	 * OT rule: an operator-day's LAST record determines OT. If that
	 * timestamp is at or before 17:30, no OT (this 30-minute buffer past
	 * the 17:00 OT-window start exists specifically to avoid mis-flagging
	 * a normal-shift record that was simply logged a few minutes late).
	 * Past 17:30, OT hours are measured from 17:00 and floored to complete
	 * 30-minute blocks. The OT bump applies only to whichever model that
	 * last record belongs to.
	 *
	 * Changeover rule: every model after the first one an operator works in
	 * a day (ordered by that model's earliest record time that day) has its
	 * target reduced by half an hour's worth of its own base rate
	 * (normal_hours_output / 7.5 * 0.5).
	 *
	 * NOTE: the floor-to-30-minute OT rounding is this implementation's
	 * best interpretation of the examples worked through during spec
	 * discussion and has not been confirmed against a real OT_hours > 0.5
	 * case - verify with the policy owner before relying on it in production.
	 *
	 * @param   integer  $limit  Maximum number of rows to return.
	 *
	 * @return  object  {
	 *     rows: [{ operator_id, operator_label, part_label, model_id,
	 *              model_label, sort_output, target, pct_of_target,
	 *              status ('on_track'|'acceptable'|'below_target'), last_record,
	 *              ot_hours, days_count }],
	 *     is_single_day: boolean
	 * }
	 *
	 * @since   1.8.0
	 */
	public function getOperatorKpiBreakdown($limit = 200)
	{
		$db = Factory::getContainer()->get(DatabaseInterface::class);

		$isSingleDay = ($this->filterDateFrom === $this->filterDateTo);

		$entries = $this->fetchKpiEntries($db);

		if (empty($entries)) {
			return (object) array('rows' => array(), 'is_single_day' => $isSingleDay);
		}

		// Group raw entries by operator + calendar day - OT and model
		// ordering both need every entry for that operator on that day
		// available together.
		$byOperatorDay = array();

		foreach ($entries as $r) {
			$key = $r->operator . '|' . $r->entry_day;
			$byOperatorDay[$key][] = $r;
		}

		// Batch-fetch the target/OT-rate catalog for every distinct model seen.
		$modelIds = array_values(array_unique(array_map(fn($r) => (int) $r->model, $entries)));
		$catalog  = $this->loadModelCatalogMap($db, $modelIds);

		$dailyRows = array();

		foreach ($byOperatorDay as $group) {
			usort($group, fn($a, $b) => strtotime($a->date) <=> strtotime($b->date));

			$lastEntry     = end($group);
			$lastTimestamp = strtotime($lastEntry->date);
			$lastModelId   = (int) $lastEntry->model;
			$otHours       = $this->calculateOtHours($lastTimestamp);

			// Group this operator-day's entries by model, in the order each
			// model was FIRST worked (PHP arrays preserve insertion order,
			// and $group is already sorted by a.date ascending above).
			$byModel = array();

			foreach ($group as $r) {
				$byModel[(int) $r->model][] = $r;
			}

			$modelIndex = 0;

			foreach ($byModel as $modelId => $modelEntries) {
				$modelIndex++;

				$sortSum = 0.0;

				foreach ($modelEntries as $e) {
					$sortSum += (float) $e->total;
				}

				$catalogRow = $catalog[$modelId] ?? null;
				$base       = $catalogRow->normal_hours_output ?? 0.0;
				$otRate     = $catalogRow->ot_hours_output ?? 0.0;

				$target = $base;

				// Changeover penalty: every model after the 1st worked that day.
				if ($modelIndex > 1 && $base > 0) {
					$target -= ($base / 7.5) * 0.5;
				}

				// OT bump: only on the model tied to the day's last record.
				$isOtModel = ($modelId === $lastModelId && $otHours > 0);

				if ($isOtModel) {
					$target += $otRate * $otHours;
				}

				$dailyRows[] = (object) array(
					'operator_id' => (int) $modelEntries[0]->operator,
					'part_id'     => (int) $modelEntries[0]->component,
					'model_id'    => $modelId,
					'day'         => $modelEntries[0]->entry_day,
					'sort_output' => $sortSum,
					'target'      => $target,
					'last_record' => ($modelId === $lastModelId) ? date('H:i', $lastTimestamp) : null,
					'ot_hours'    => $isOtModel ? $otHours : 0.0,
				);
			}
		}

		// Roll up across days when the filter spans more than one day - sum
		// sort output and each day's already-adjusted target, never
		// re-derive the target from the summed output.
		if ($isSingleDay) {
			$rows = $dailyRows;

			foreach ($rows as $r) {
				$r->days_count = 1;
			}
		} else {
			$rolled = array();

			foreach ($dailyRows as $r) {
				$key = $r->operator_id . '|' . $r->model_id;

				if (!isset($rolled[$key])) {
					$rolled[$key] = (object) array(
						'operator_id' => $r->operator_id,
						'part_id'     => $r->part_id,
						'model_id'    => $r->model_id,
						'sort_output' => 0.0,
						'target'      => 0.0,
						'days_count'  => 0,
						'last_record' => null,
						'ot_hours'    => 0.0,
					);
				}

				$rolled[$key]->sort_output += $r->sort_output;
				$rolled[$key]->target      += $r->target;
				$rolled[$key]->days_count  += 1;
			}

			$rows = array_values($rolled);
		}

		// Resolve labels in one batch each, same pattern as fetchEntityStats().
		$operatorIds = array_values(array_unique(array_map(fn($r) => $r->operator_id, $rows)));
		$partIds     = array_values(array_unique(array_filter(array_map(fn($r) => $r->part_id, $rows))));

		$operatorLabels = $this->loadLabelMap($db, '#__users', 'id', 'name', $operatorIds);
		$operatorUsernames = $this->loadLabelMap($db, '#__users', 'id', 'username', $operatorIds);
		$modelLabels    = $this->loadLabelMap($db, '#__product_catalogs', 'id', 'model_name', $modelIds);
		$partLabels     = $this->loadLabelMap($db, '#__product_components', 'id', 'component_name', $partIds);

		foreach ($rows as $r) {
			$r->operator_label = $operatorLabels[$r->operator_id] ?? (string) $r->operator_id;
			$r->operator_username = $operatorUsernames[$r->operator_id] ?? (string) $r->operator_id;
			$r->model_label    = $modelLabels[$r->model_id] ?? (string) $r->model_id;
			$r->part_label     = $partLabels[$r->part_id] ?? '';
			$r->pct_of_target  = $r->target > 0 ? ($r->sort_output / $r->target) * 100 : 0.0;

			// Three states, per spec: NC-based status is intentionally NOT
			// folded in here.
			// - on_track:   met or exceeded target
			// - acceptable: below target, but the shortfall is <= 5% of
			//               target (i.e. pct_of_target is in [95, 100))
			// - below_target: shortfall is more than 5% of target
			if ($r->sort_output >= $r->target) {
				$r->status = 'on_track';
			} elseif ($r->target > 0 && $r->pct_of_target >= 94.5) {
				$r->status = 'acceptable';
			} else {
				$r->status = 'below_target';
			}
		}

		// Group by operator so every model row belonging to the same
		// operator stays adjacent in the final list - a plain global sort
		// by pct_of_target scatters an operator's rows apart whenever they
		// have one very-low model and one moderate one. Operators are
		// ranked by their WORST (lowest) model's % of target, so the
		// operator needing the most attention still surfaces first; within
		// each operator's group, models are ordered worst-first too.
		$byOperator = array();

		foreach ($rows as $r) {
			$byOperator[$r->operator_id][] = $r;
		}

		$operatorWorstPct = array();

		foreach ($byOperator as $operatorId => $operatorRows) {
			usort($operatorRows, fn($a, $b) => $a->pct_of_target <=> $b->pct_of_target);
			$byOperator[$operatorId]      = $operatorRows;
			$operatorWorstPct[$operatorId] = $operatorRows[0]->pct_of_target;
		}

		asort($operatorWorstPct);

		$rows = array();

		foreach (array_keys($operatorWorstPct) as $operatorId) {
			foreach ($byOperator[$operatorId] as $r) {
				$rows[] = $r;
			}
		}

		return (object) array(
			'rows'          => array_slice($rows, 0, $limit),
			'is_single_day' => $isSingleDay,
		);
	}

	/**
	 * Raw #__data_entry rows needed for the KPI breakdown: operator, model,
	 * component (Part), the exact record datetime, and the calendar day it
	 * falls on. Filtered by the same access-control + user-selectable
	 * filters as every other query in this model.
	 *
	 * @return  array  Objects: { operator, model, component, total, date, entry_day }
	 *
	 * @since   1.8.0
	 */
	protected function fetchKpiEntries(DatabaseInterface $db)
	{
		$query = $db->getQuery(true)
			->select(array(
				$db->quoteName('a.operator'),
				$db->quoteName('a.model'),
				$db->quoteName('a.component'),
				$db->quoteName('a.total'),
				$db->quoteName('a.date'),
				'DATE(' . $db->quoteName('a.date') . ') AS entry_day',
			))
			->from($db->quoteName('#__data_entry', 'a'))
			->where($db->quoteName('a.state') . ' = 1')
			->where($db->quoteName('a.model') . ' IS NOT NULL')
			->where($db->quoteName('a.operator') . ' IS NOT NULL');

		$this->applyEntryFilters($db, $query, 'a');

		$query->order($db->quoteName('a.operator') . ' ASC, entry_day ASC, ' . $db->quoteName('a.date') . ' ASC');

		$db->setQuery($query);

		return $db->loadObjectList() ?: array();
	}

	/**
	 * Batch id -> {normal_hours_output, ot_hours_output} lookup against
	 * #__product_catalogs, for every model id referenced in a KPI breakdown
	 * call - avoids one query per distinct model.
	 *
	 * @param   array  $modelIds  Model catalog ids.
	 *
	 * @return  array  [id => object{normal_hours_output, ot_hours_output}]
	 *
	 * @since   1.8.0
	 */
	protected function loadModelCatalogMap(DatabaseInterface $db, array $modelIds)
	{
		if (empty($modelIds)) {
			return array();
		}

		$query = $db->getQuery(true)
			->select($db->quoteName(array('id', 'normal_hours_output', 'ot_hours_output')))
			->from($db->quoteName('#__product_catalogs'))
			->where($db->quoteName('id') . ' IN (' . implode(',', array_map('intval', $modelIds)) . ')');

		$db->setQuery($query);

		$map = array();

		foreach ($db->loadObjectList() as $row) {
			$map[(int) $row->id] = (object) array(
				'normal_hours_output' => (float) $row->normal_hours_output,
				'ot_hours_output'     => (float) $row->ot_hours_output,
			);
		}

		return $map;
	}

	/**
	 * OT hours for an operator-day, based on that day's LAST record
	 * timestamp. Triggered only when that timestamp is after 17:30 - a
	 * 30-minute buffer past the 17:00 OT-window start, specifically to
	 * avoid counting a normal-shift record that was simply logged a few
	 * minutes late as overtime. Once triggered, hours are measured from
	 * 17:00 (not from 17:30, and not from shift-end 16:30) and floored to
	 * complete 30-minute blocks.
	 *
	 * @param   integer  $timestamp  Unix timestamp of the operator-day's last record.
	 *
	 * @return  float  OT hours, in 0.5-hour increments (0.0 if not triggered).
	 *
	 * @since   1.8.0
	 */
	protected function calculateOtHours($timestamp)
	{
		$day = date('Y-m-d', $timestamp);

		$otWindowStart = strtotime($day . ' 17:00:00');
		$otThreshold   = strtotime($day . ' 17:30:00');

		if ($timestamp <= $otThreshold) {
			return 0.0;
		}

		$minutesPastWindowStart = ($timestamp - $otWindowStart) / 60;

		return floor($minutesPastWindowStart / 30) * 0.5;
	}

	/**
	 * Small id -> label lookup, shared across the entity-stats fetch.
	 *
	 * @since   1.7.0
	 */
	protected function loadLabelMap(DatabaseInterface $db, $table, $keyCol, $labelCol, array $ids)
	{
		if (empty($ids)) {
			return array();
		}

		$query = $db->getQuery(true)
			->select($db->quoteName([$keyCol, $labelCol]))
			->from($db->quoteName($table))
			->where($db->quoteName($keyCol) . ' IN (' . implode(',', array_map('intval', $ids)) . ')');

		$db->setQuery($query);

		$map = array();

		foreach ($db->loadAssocList() as $row) {
			$map[$row[$keyCol]] = $row[$labelCol];
		}

		return $map;
	}

	/**
	 * Apply access control, then the Model/Vendor/etc. filters and the
	 * selected date range - shared by every query in this model. Assumes
	 * the base entry table is aliased $alias (default 'a').
	 *
	 * Access control is based on three usergrouplist params in com_data's
	 * component config: viewAll, viewOwnOperator, viewOwnVendor. This is
	 * NOT excludable via $exclude and NOT optional - every call site gets
	 * it, since it's a security boundary rather than a user-selectable
	 * filter. A user covered by none of the three groups (and not
	 * core.admin) is blocked entirely (1=0), matching the "fail closed"
	 * requirement - a missing/misconfigured param means nobody sees data,
	 * not everybody.
	 *
	 * @param   DatabaseInterface               $db      The database driver.
	 * @param   \Joomla\Database\DatabaseQuery  $query   The query to constrain.
	 * @param   string                           $alias   Alias of the #__data_entry table in $query.
	 * @param   array                            $exclude Filter keys to skip (e.g. ['lot'] when building the Lot dropdown itself).
	 *
	 * @return  void
	 *
	 * @since   1.3.0
	 */
	protected function applyEntryFilters(
		DatabaseInterface $db,
		$query,
		$alias = 'a',
		array $exclude = [],
		$dateFrom = null,
		$dateTo = null
	) {
		// --- Access control ---
		$user = Factory::getApplication()->getIdentity();

		$userId       = (int) $user->get('id');
		$userGroupIds = array_map('intval', (array) $user->get('groups'));

		$params = ComponentHelper::getParams('com_data');

		$viewAllGroups         = array_map('intval', (array) $params->get('viewAll', []));
		$viewOwnOperatorGroups = array_map('intval', (array) $params->get('viewOwnOperator', []));
		$viewOwnVendorGroups   = array_map('intval', (array) $params->get('viewOwnVendor', []));

		$isSuperUser        = $user->authorise('core.admin');
		$canViewAll          = !empty(array_intersect($userGroupIds, $viewAllGroups));
		$canViewOwnOperator  = !empty(array_intersect($userGroupIds, $viewOwnOperatorGroups));
		$canViewOwnVendor    = !empty(array_intersect($userGroupIds, $viewOwnVendorGroups));

		if (!$userId) {
			$query->where('1 = 0'); // Guest - shouldn't normally reach here given DisplayController's login gate, but defended anyway.
		} elseif ($isSuperUser || $canViewAll) {
			// No restriction.
		} elseif ($canViewOwnOperator || $canViewOwnVendor) {
			$conditions = array();

			if ($canViewOwnOperator) {
				$conditions[] = $db->quoteName($alias . '.operator') . ' = ' . $userId;
			}

			if ($canViewOwnVendor) {
				// FIND_IN_SET, not plain '=' - a.vendor can hold multiple comma-separated
				// vendor ids (same multi-value storage pattern as component/model).
				$conditions[] = 'FIND_IN_SET(' . $userId . ', ' . $db->quoteName($alias . '.vendor') . ')';
			}

			$query->where('(' . implode(' OR ', $conditions) . ')');
		} else {
			$query->where('1 = 0'); // Authenticated, but in none of the configured groups.
		}

		// --- User-selectable filters ---
		if (
			$this->filterPart !== '' &&
			!in_array('part', $exclude, true)
		) {
			$query->where(
				$db->quoteName($alias . '.component') . ' = ' .
					$db->quote($this->filterPart)
			);
		}

		if (
			$this->filterModel !== '' &&
			!in_array('model', $exclude, true)
		) {
			$query->where(
				$db->quoteName($alias . '.model') . ' = ' .
					$db->quote($this->filterModel)
			);
		}

		if (
			$this->filterNcCategory !== '' &&
			!in_array('nc_category', $exclude, true)
		) {
			$query->where(
				'EXISTS (SELECT 1 FROM ' . $db->quoteName('#__data_entry_nc', 'ncfc') .
					' WHERE ' . $db->quoteName('ncfc.entry_id') . ' = ' . $db->quoteName($alias . '.id') .
					' AND FIND_IN_SET(' . $db->quote($this->filterNcCategory) . ', ' . $db->quoteName('ncfc.nc_category') . '))'
			);
		}

		if (
			$this->filterNcType !== '' &&
			!in_array('nc_type', $exclude, true)
		) {
			$query->where(
				'EXISTS (SELECT 1 FROM ' . $db->quoteName('#__data_entry_nc', 'ncft') .
					' WHERE ' . $db->quoteName('ncft.entry_id') . ' = ' . $db->quoteName($alias . '.id') .
					' AND FIND_IN_SET(' . $db->quote($this->filterNcType) . ', ' . $db->quoteName('ncft.nc_type') . '))'
			);
		}

		if (
			$this->filterVendor !== '' &&
			!in_array('vendor', $exclude, true)
		) {
			$query->where(
				$db->quoteName($alias . '.vendor') . ' = ' .
					$db->quote($this->filterVendor)
			);
		}

		if (
			$this->filterOperator !== '' &&
			!in_array('operator', $exclude, true)
		) {
			$query->where(
				$db->quoteName($alias . '.operator') . ' = ' .
					$db->quote($this->filterOperator)
			);
		}

		if (
			$this->filterRemark !== '' &&
			!in_array('remark', $exclude, true)
		) {
			$query->where(
				$db->quoteName($alias . '.lot') . ' = ' .
					$db->quote($this->filterRemark)
			);
		}

		if (
			$this->filterLot !== '' &&
			!in_array('lot', $exclude, true)
		) {
			$query->where(
				'EXISTS (SELECT 1 FROM ' . $db->quoteName('#__vendor_details', 'vdf') .
					' WHERE ' . $db->quoteName('vdf.id') . ' = ' . $db->quoteName($alias . '.remark') .
					' AND ' . $db->quoteName('vdf.remark') . ' = ' . $db->quote($this->filterLot) . ')'
			);
		}

		$query->where(
			$db->quoteName($alias . '.date') . ' BETWEEN ' .
				$db->quote(($dateFrom ?? $this->filterDateFrom) . ' 00:00:00') . ' AND ' .
				$db->quote(($dateTo ?? $this->filterDateTo) . ' 23:59:59')
		);
	}
}
