<?php

/**
 * @version    CVS: 1.0.0
 * @package    Com_Data
 * @author     Mei Chun <qc.yolotech@gmail.com>
 * @copyright  2026 YOLO
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace Data\Component\Data\Site\Model;
// No direct access.
defined('_JEXEC') or die;

use \Joomla\CMS\Factory;
use \Joomla\CMS\Language\Text;
use \Joomla\CMS\MVC\Model\ListModel;
use \Joomla\Component\Fields\Administrator\Helper\FieldsHelper;
use \Joomla\CMS\Helper\TagsHelper;
use \Joomla\CMS\Layout\FileLayout;
use \Joomla\Database\ParameterType;
use \Joomla\Utilities\ArrayHelper;
use \Data\Component\Data\Site\Helper\DataHelper;
use \Joomla\Database\DatabaseInterface;
use Joomla\CMS\Component\ComponentHelper;

/**
 * Methods supporting a list of Data records.
 *
 * @since  1.0.0
 */
class EntriesModel extends ListModel
{
	/**
	 * Constructor.
	 *
	 * @param   array  $config  An optional associative array of configuration settings.
	 *
	 * @see    JController
	 * @since  1.0.0
	 */

	/**
	 * @var  \DateTime  Monday 00:00:00 of the selected/default ISO week.
	 * @since  1.2.0
	 */
	protected $weekStart;

	/**
	 * @var  \DateTime  Sunday 23:59:59 of the selected/default ISO week.
	 * @since  1.2.0
	 */
	protected $weekEnd;

	/**
	 * @var  \DateTime 
	 * @since  1.2.0
	 */
	protected $monthStart;

	/**
	 * @var  \DateTime  
	 * @since  1.2.0
	 */
	protected $monthEnd;

	/**
	 * @var  \DateTime 
	 * @since  1.2.0
	 */
	protected $yearStart;

	/**
	 * @var  \DateTime  
	 * @since  1.2.0
	 */
	protected $yearEnd;

	/**
	 * @var  \DateTime|null
	 * @since  1.2.0
	 */
	protected $dateFrom;

	/**
	 * @var  \DateTime|null
	 * @since  1.2.0
	 */
	protected $dateTo;


	public function __construct($config = array())
	{
		if (empty($config['filter_fields'])) {
			$config['filter_fields'] = array(
				'id',
				'a.id',
				'state',
				'a.state',
				'ordering',
				'a.ordering',
				'created_by',
				'a.created_by',
				'modified_by',
				'a.modified_by',
				'custom_field_1',
				'a.custom_field_1',
				'custom_field_2',
				'a.custom_field_2',
				'custom_field_3',
				'a.custom_field_3',
				'custom_field_4',
				'a.custom_field_4',
				'custom_field_5',
				'a.custom_field_5',
				'date',
				'a.date',
				'week',
				'a.week',
				'component',
				'a.component',
				'model',
				'a.model',
				'vendor',
				'a.vendor',
				'operator',
				'a.operator',
				'total',
				'a.total',
				'work_order_no',
				'a.work_order_no',
				'nc_entry_count',
				'nc_entry_count',
				'nc_quantity_total',
				'nc_quantity_total',
				'lot',
				'a.lot',
				'remark',
				'a.remark',
				'reference_no',
				'a.reference_no',
			);
		}

		parent::__construct($config);
	}



	/**
	 * Method to auto-populate the model state.
	 *
	 * Note. Calling getState in this method will result in recursion.
	 *
	 * @param   string  $ordering   Elements order
	 * @param   string  $direction  Order direction
	 *
	 * @return  void
	 *
	 * @throws  Exception
	 *
	 * @since   1.0.0
	 */
	protected function populateState($ordering = null, $direction = null)
	{
		// List state information.
		parent::populateState("a.id", "DESC");

		$app = Factory::getApplication();
		$list = $app->getUserState($this->context . '.list');

		$value = $app->getUserState($this->context . '.list.limit', $app->get('list_limit', 25));
		$list['limit'] = $value;

		$this->setState('list.limit', $value);

		$value = $app->input->get('limitstart', 0, 'uint');
		$this->setState('list.start', $value);

		$ordering  = $this->getUserStateFromRequest($this->context . '.filter_order', 'filter_order', "a.id");
		$direction = strtoupper($this->getUserStateFromRequest($this->context . '.filter_order_Dir', 'filter_order_Dir', "DESC"));

		// Default the year filter to the current year on first load
		$year = $this->getUserStateFromRequest($this->context . '.filter.year', 'filter_year', date('Y'), 'int');
		$this->setState('filter.year', $year);

		// Default the month filter to the current month on first load
		// $month = $this->getUserStateFromRequest($this->context . '.filter.month', 'filter_month', date('n'), 'int');
		// $this->setState('filter.month', $month);

		// Default the week filter to the current ISO week on first load
		$week = $this->getUserStateFromRequest($this->context . '.filter.week', 'filter_week', date('W'), 'int');
		$this->setState('filter.week', $week);

		// --- Week range ---
		if (!empty($week) && $week !== 'all') {
			$this->weekStart = new \DateTime();
			$this->weekStart->setISODate((int) $year, (int) $week, 1)->setTime(0, 0, 0);

			$this->weekEnd = clone $this->weekStart;
			$this->weekEnd->modify('+6 days')->setTime(23, 59, 59);

			$this->setState('filter.weekStart', $this->weekStart);
			$this->setState('filter.weekEnd', $this->weekEnd);
		} else {
			$this->setState('filter.weekStart', null);
			$this->setState('filter.weekEnd', null);
		}

		// --- Month range (used as fallback display when week = 'all') ---
		if (!empty($month) && $month !== 'all') {
			$this->monthStart = new \DateTime();
			$this->monthStart->setDate((int) $year, (int) $month, 1)->setTime(0, 0, 0);

			$this->monthEnd = clone $this->monthStart;
			$this->monthEnd->modify('last day of this month')->setTime(23, 59, 59);

			$this->setState('filter.monthStart', $this->monthStart);
			$this->setState('filter.monthEnd', $this->monthEnd);
		} else {
			$this->setState('filter.monthStart', null);
			$this->setState('filter.monthEnd', null);
		}

		// --- Year range ---
		if (!empty($year)) {
			$this->yearStart = new \DateTime();
			$this->yearStart->setDate((int) $year, 1, 1)->setTime(0, 0, 0);

			$this->yearEnd = clone $this->yearStart;
			$this->yearEnd->setDate((int) $year, 12, 31)->setTime(23, 59, 59);

			$this->setState('filter.yearStart', $this->yearStart);
			$this->setState('filter.yearEnd', $this->yearEnd);
		} else {
			$this->setState('filter.yearStart', null);
			$this->setState('filter.yearEnd', null);
		}

		// --- Custom date range (from/to) — takes priority over week/month/year for display ---
		$dateFrom = $this->getUserStateFromRequest($this->context . '.filter.date_from', 'filter_date_from');
		$dateTo   = $this->getUserStateFromRequest($this->context . '.filter.date_to', 'filter_date_to');

		$this->setState('filter.date_from', $dateFrom);
		$this->setState('filter.date_to', $dateTo);

		if (!empty($dateFrom)) {
			$this->dateFrom = \DateTime::createFromFormat('Y-m-d', $dateFrom);
			if ($this->dateFrom) {
				$this->dateFrom->setTime(0, 0, 0);
			}
			$this->setState('filter.dateFromObj', $this->dateFrom);
		} else {
			$this->setState('filter.dateFromObj', null);
		}

		if (!empty($dateTo)) {
			$this->dateTo = \DateTime::createFromFormat('Y-m-d', $dateTo);
			if ($this->dateTo) {
				$this->dateTo->setTime(23, 59, 59);
			}
			$this->setState('filter.dateToObj', $this->dateTo);
		} else {
			$this->setState('filter.dateToObj', null);
		}

		// --- Validate date range against week/month/year filters ---
		$conflictDetected = false;

		// Case 1: dateFrom is after dateTo
		if (!empty($this->dateFrom) && !empty($this->dateTo) && $this->dateFrom > $this->dateTo) {
			$conflictDetected = true;
			$app->enqueueMessage(
				Text::_('COM_DATA_FILTER_DATE_FROM_AFTER_TO'),
				'warning'
			);
		}

		// Case 1b: dateTo falls outside the selected week's range
		if (!$conflictDetected && !empty($this->dateTo) && !empty($this->weekStart) && !empty($this->weekEnd)) {
			if ($this->dateTo < $this->weekStart || $this->dateTo > $this->weekEnd) {
				$conflictDetected = true;
				$app->enqueueMessage(
					Text::sprintf(
						'COM_DATA_FILTER_DATE_OUTSIDE_WEEK',
						$this->dateTo->format('Y-m-d'),
						$this->weekStart->format('Y-m-d'),
						$this->weekEnd->format('Y-m-d')
					),
					'warning'
				);
			}
		}

		// Case 1c: dateFrom falls outside the selected week's range
		if (!$conflictDetected && !empty($this->dateFrom) && !empty($this->weekStart) && !empty($this->weekEnd)) {
			if ($this->dateFrom < $this->weekStart || $this->dateFrom > $this->weekEnd) {
				$conflictDetected = true;
				$app->enqueueMessage(
					Text::sprintf(
						'COM_DATA_FILTER_DATE_OUTSIDE_WEEK',
						$this->dateFrom->format('Y-m-d'),
						$this->weekStart->format('Y-m-d'),
						$this->weekEnd->format('Y-m-d')
					),
					'warning'
				);
			}
		}


		// Case 2: dateTo falls outside the selected month's range
		if (!$conflictDetected && !empty($this->dateTo) && !empty($this->monthStart) && !empty($this->monthEnd)) {
			if ($this->dateTo < $this->monthStart || $this->dateTo > $this->monthEnd) {
				$conflictDetected = true;
				$app->enqueueMessage(
					Text::sprintf(
						'COM_DATA_FILTER_DATE_OUTSIDE_MONTH',
						$this->dateTo->format('Y-m-d'),
						$this->monthStart->format('F Y')
					),
					'warning'
				);
			}
		}

		// Case 3: dateFrom falls outside the selected month's range
		if (!$conflictDetected && !empty($this->dateFrom) && !empty($this->monthStart) && !empty($this->monthEnd)) {
			if ($this->dateFrom < $this->monthStart || $this->dateFrom > $this->monthEnd) {
				$conflictDetected = true;
				$app->enqueueMessage(
					Text::sprintf(
						'COM_DATA_FILTER_DATE_OUTSIDE_MONTH',
						$this->dateFrom->format('Y-m-d'),
						$this->monthStart->format('F Y')
					),
					'warning'
				);
			}
		}

		// Case 4: date range falls entirely outside the selected year
		if (!$conflictDetected && !empty($this->yearStart) && !empty($this->yearEnd)) {
			$outOfYear = (!empty($this->dateFrom) && ($this->dateFrom < $this->yearStart || $this->dateFrom > $this->yearEnd))
				|| (!empty($this->dateTo) && ($this->dateTo < $this->yearStart || $this->dateTo > $this->yearEnd));

			if ($outOfYear) {
				$app->enqueueMessage(
					Text::sprintf('COM_DATA_FILTER_DATE_OUTSIDE_YEAR', $this->yearStart->format('Y')),
					'warning'
				);
			}
		}


		$filters = $app->getUserState($this->context . '.filter', array());

		if (empty($filters['year'])) {
			$filters['year'] = $year;
			$app->setUserState($this->context . '.filter', $filters);
		}

		if (empty($filters['month'])) {
			$filters['month'] = $month;
			$app->setUserState($this->context . '.filter', $filters);
		}

		if (empty($filters['week'])) {
			$filters['week'] = $week;
			$app->setUserState($this->context . '.filter', $filters);
		}

		if (!empty($ordering) || !empty($direction)) {
			$list['fullordering'] = $ordering . ' ' . $direction;
		}

		$app->setUserState($this->context . '.list', $list);



		$context = $this->getUserStateFromRequest($this->context . '.filter.search', 'filter_search');
		$this->setState('filter.search', $context);

		// Split context into component and optional section
		if (!empty($context)) {
			$parts = FieldsHelper::extract($context);

			if ($parts) {
				$this->setState('filter.component', $parts[0]);
				$this->setState('filter.section', $parts[1]);
			}
		}

		// --- Default the Vendor filter to "own account" for Vendor-group users ---
		// Note: this only affects what the filter dropdown shows pre-selected.
		// The actual hard access restriction is enforced separately and
		// unconditionally in getListQuery() below, regardless of this filter.
		// Uses the same configured 'viewOwnVendor' groups as EntriesModel, so the
		// two lists never need to be kept in sync by hand.
		$user     = $app->getIdentity();
		$userId   = (int) $user->get('id');
		$userGrps = (array) $user->get('groups');

		$params              = ComponentHelper::getParams('com_data');
		$viewOwnVendorGroups = array_map('intval', (array) $params->get('viewOwnVendor', []));
		$userGroupIds        = array_map('intval', array_keys($userGrps));
		$canViewOwnVendor    = !empty(array_intersect($userGroupIds, $viewOwnVendorGroups));

		if ($userId > 0 && $canViewOwnVendor) {
			$vendorFilter = $this->getUserStateFromRequest($this->context . '.filter.vendor', 'filter_vendor', $userId);
			$this->setState('filter.vendor', $vendorFilter);

			$filters = (array) $app->getUserState($this->context . '.filter', array());

			if (empty($filters['vendor'])) {
				$filters['vendor'] = $vendorFilter;
				$app->setUserState($this->context . '.filter', $filters);
			}
		}
	}

	/**
	 * Build an SQL query to load the list data.
	 *
	 * @return  DatabaseQuery
	 *
	 * @since   1.0.0
	 */
	protected function getListQuery()
	{
		// Create a new query object.
		$db    = Factory::getContainer()->get(DatabaseInterface::class);
		$query = $db->getQuery(true);

		// Select the required fields from the table.
		$query->select(
			$this->getState(
				'list.select',
				'DISTINCT a.*'
			)
		);

		$query->from('`#__data_entry` AS a');

		// Join over the users for the checked out user.
		$query->select('uc.name AS uEditor');
		$query->join('LEFT', '#__users AS uc ON uc.id=a.checked_out');

		// NOTE: component/model/vendor name search is handled via EXISTS
		// subqueries further down (not JOINs), to avoid duplicating rows
		// for entries that have multiple comma-separated component/model/
		// vendor IDs. DISTINCT a.* alone cannot safely dedupe that fan-out
		// if extra per-match columns were selected via a JOIN.

		// Summarise the repeatable "NC Data Entry" rows for this entry
		$query->select('(SELECT COUNT(*) FROM #__data_entry_nc AS nc WHERE nc.entry_id = a.id) AS nc_entry_count');
		$query->select('(SELECT SUM(nc.nc_quantity) FROM #__data_entry_nc AS nc WHERE nc.entry_id = a.id) AS nc_quantity_total');

		if (!Factory::getApplication()->getIdentity()->authorise('core.edit', 'com_data')) {
			$query->where('a.state = 1');
		} else {
			$query->where('(a.state IN (0, 1))');
		}


		// --- Access Control Logic Starts Here ---
		$user       = Factory::getApplication()->getIdentity();
		$userId   = (int) $user->get('id');
		$userGrps = $user->get('groups');

		$params = ComponentHelper::getParams('com_data');

		$viewAllGroups         = array_map('intval', (array) $params->get('viewAll', []));
		$viewOwnOperatorGroups = array_map('intval', (array) $params->get('viewOwnOperator', []));
		$viewOwnVendorGroups   = array_map('intval', (array) $params->get('viewOwnVendor', []));
		$viewAllVendorGroups   = array_map('intval', (array) $params->get('viewAllVendor', []));

		$userGroupIds = array_map('intval', array_keys($userGrps));

		$isSuperUser        = $user->authorise('core.admin');
		$canViewAll          = !empty(array_intersect($userGroupIds, $viewAllGroups));
		$canViewOwnOperator  = !empty(array_intersect($userGroupIds, $viewOwnOperatorGroups));
		$canViewOwnVendor    = !empty(array_intersect($userGroupIds, $viewOwnVendorGroups));
		$canViewAllVendor    = !empty(array_intersect($userGroupIds, $viewAllVendorGroups));

		if (!$userId) {
			$query->where('1 = 0'); // Guest block
		} elseif ($isSuperUser || $canViewAll) {
			// Super Users and View All groups can see everything - no extra WHERE.
		} elseif ($canViewOwnOperator || $canViewOwnVendor || $canViewAllVendor) {
			$conditions = array();

			if ($canViewOwnOperator) {
				$conditions[] = $db->quoteName('a.operator') . ' = ' . $userId;
			}

			if ($canViewOwnVendor || $canViewAllVendor) {
				// Vendor ids this user can see records for: themselves, plus
				// anyone listed under them as "Main Vendor" in #__vendor_access
				// (delegation - a main vendor can see their sub-vendors' records too).
				$vendorIds = array($userId);

				$accessQuery = $db->getQuery(true)
					->select($db->quoteName('vendors'))
					->from($db->quoteName('#__vendor_access'))
					->where($db->quoteName('main_vendor') . ' = ' . $userId)
					->where($db->quoteName('state') . ' = 1');

				$db->setQuery($accessQuery);
				$delegatedRows = $db->loadColumn() ?: array();

				foreach ($delegatedRows as $csv) {
					foreach (explode(',', (string) $csv) as $id) {
						$id = (int) $id;

						if ($id > 0) {
							$vendorIds[] = $id;
						}
					}
				}

				$vendorIds = array_unique($vendorIds);

				// FIND_IN_SET, not plain '=' - see note below about EntriesModel's version.
				$vendorConditions = array();

				foreach ($vendorIds as $vendorId) {
					$vendorConditions[] = 'FIND_IN_SET(' . $vendorId . ', ' . $db->quoteName('a.vendor') . ')';
				}

				$conditions[] = '(' . implode(' OR ', $vendorConditions) . ')';
			}

			$query->where('(' . implode(' OR ', $conditions) . ')');
		} else {
			$query->where('1 = 0'); // No viewing permission
		}

		// Filter by search
		$search = $this->getState('filter.search');

		if (!empty($search)) {
			if (stripos($search, 'id:') === 0) {
				$query->where('a.id = ' . (int) substr($search, 3));
			} else {
				$escaped = $db->Quote('%' . $db->escape($search, true) . '%');
				$query->where(
					'(' . $db->quoteName('a.work_order_no') . ' LIKE ' . $escaped .
						' OR ' . $db->quoteName('a.reference_no') . ' LIKE ' . $escaped .
						' OR EXISTS (SELECT 1 FROM ' . $db->quoteName('#__vendor_details', 'vd') .
						' INNER JOIN ' . $db->quoteName('#__vendor_remarks', 'vr') . ' ON ' . $db->quoteName('vr.id') . ' = ' . $db->quoteName('vd.remark') .
						' WHERE FIND_IN_SET(' . $db->quoteName('vd.id') . ', ' . $db->quoteName('a.remark') . ')' .
						' AND ' . $db->quoteName('vr.remark') . ' LIKE ' . $escaped . ')' .
						' OR EXISTS (SELECT 1 FROM ' . $db->quoteName('#__product_components', 'pc_s') .
						' WHERE FIND_IN_SET(' . $db->quoteName('pc_s.id') . ', ' . $db->quoteName('a.component') . ')' .
						' AND ' . $db->quoteName('pc_s.component_name') . ' LIKE ' . $escaped . ')' .
						' OR EXISTS (SELECT 1 FROM ' . $db->quoteName('#__product_catalogs', 'pcat_s') .
						' WHERE FIND_IN_SET(' . $db->quoteName('pcat_s.id') . ', ' . $db->quoteName('a.model') . ')' .
						' AND ' . $db->quoteName('pcat_s.model_name') . ' LIKE ' . $escaped . ')' .
						' OR EXISTS (SELECT 1 FROM ' . $db->quoteName('#__users', 'ven_s') .
						' WHERE FIND_IN_SET(' . $db->quoteName('ven_s.id') . ', ' . $db->quoteName('a.vendor') . ')' .
						' AND ' . $db->quoteName('ven_s.name') . ' LIKE ' . $escaped . ')' .
						' OR EXISTS (SELECT 1 FROM ' . $db->quoteName('#__users', 'op_s') .
						' WHERE FIND_IN_SET(' . $db->quoteName('op_s.id') . ', ' . $db->quoteName('a.operator') . ')' .
						' AND ' . $db->quoteName('op_s.name') . ' LIKE ' . $escaped . ')' .
						')'
				);
			}
		}


		// Filtering component
		$filter_component = $this->state->get("filter.component");
		if (is_array($filter_component)) {
			$filter_component = array_values(array_filter($filter_component, function ($v) {
				return $v !== "" && $v !== null;
			}));
		}
		if ((is_array($filter_component) && count($filter_component) > 0) || (!is_array($filter_component) && $filter_component !== "" && $filter_component !== null)) {
			if (is_array($filter_component)) {
				$__vals = array_map([$db, "quote"], $filter_component);
				$query->where($db->quoteName("a.component") . " IN (" . implode(",", $__vals) . ")");
			} else {
				$query->where($db->quoteName("a.component") . " = " . $db->quote($filter_component));
			}
		}

		// Filtering model
		$filter_model = $this->state->get("filter.model");
		if (is_array($filter_model)) {
			$filter_model = array_values(array_filter($filter_model, function ($v) {
				return $v !== "" && $v !== null;
			}));
		}
		if ((is_array($filter_model) && count($filter_model) > 0) || (!is_array($filter_model) && $filter_model !== "" && $filter_model !== null)) {
			if (is_array($filter_model)) {
				$__vals = array_map([$db, "quote"], $filter_model);
				$query->where($db->quoteName("a.model") . " IN (" . implode(",", $__vals) . ")");
			} else {
				$query->where($db->quoteName("a.model") . " = " . $db->quote($filter_model));
			}
		}

		// Filtering vendor
		$filter_vendor = $this->state->get("filter.vendor");
		if (is_array($filter_vendor)) {
			$filter_vendor = array_values(array_filter($filter_vendor, function ($v) {
				return $v !== "" && $v !== null;
			}));
		}
		if ((is_array($filter_vendor) && count($filter_vendor) > 0) || (!is_array($filter_vendor) && $filter_vendor !== "" && $filter_vendor !== null)) {
			if (is_array($filter_vendor)) {
				$__vals = array_map([$db, "quote"], $filter_vendor);
				$query->where($db->quoteName("a.vendor") . " IN (" . implode(",", $__vals) . ")");
			} else {
				$query->where($db->quoteName("a.vendor") . " = " . $db->quote($filter_vendor));
			}
		}

		// Filtering lot
		$filter_lot = $this->state->get('filter.lot');
		if ($filter_lot !== null && $filter_lot !== '') {
			$query->where($db->quoteName('a.lot') . ' = ' . (int) $filter_lot);
		}

		// Filtering resort_nc
		$filter_resort_nc = $this->state->get("filter.resort_nc");
		if (is_array($filter_resort_nc)) {
			$filter_resort_nc = array_values(array_filter($filter_resort_nc, function ($v) {
				return $v !== "" && $v !== null;
			}));
		}
		if ((is_array($filter_resort_nc) && count($filter_resort_nc) > 0) || (!is_array($filter_resort_nc) && $filter_resort_nc !== "" && $filter_resort_nc !== null)) {
			if (is_array($filter_resort_nc)) {
				$__conditions = array();
				foreach ($filter_resort_nc as $__val) {
					$__conditions[] = 'FIND_IN_SET(' . (int) $__val . ', ' . $db->quoteName('a.resort_nc') . ')';
				}
				$query->where('(' . implode(' OR ', $__conditions) . ')');
			} else {
				$query->where('FIND_IN_SET(' . (int) $filter_resort_nc . ', ' . $db->quoteName('a.resort_nc') . ')');
			}
		}

		// Filtering week
		$week = $this->state->get('filter.week');
		if (!empty($week) && $week !== 'all') {
			$query->where('a.week = ' . (int) $week);
		}

		// Filtering month
		$month = $this->state->get('filter.month');
		if (!empty($month) && $month !== 'all') {
			$query->where('MONTH(a.date) = ' . (int) $month);
		}

		// Filtering year
		$year = $this->state->get('filter.year');
		if (!empty($year)) {
			$query->where('YEAR(a.date) = ' . (int) $year);
		}
		
		// Filtering date range
		$dateFrom = $this->state->get('filter.date_from');
		$dateTo   = $this->state->get('filter.date_to');

		if (!empty($dateFrom)) {
			$query->where('DATE(a.date) >= ' . $db->quote($dateFrom));
		}

		if (!empty($dateTo)) {
			$query->where('DATE(a.date) <= ' . $db->quote($dateTo));
		}

		// Add the list ordering clause.
		$orderCol  = $this->state->get('list.ordering', "a.id");
		$orderDirn = $this->state->get('list.direction', "DESC");

		if ($orderCol && $orderDirn) {
			$query->order($db->escape($orderCol . ' ' . $orderDirn));
		}

		return $query;
	}

	/**
	 * Method to get an array of data items
	 *
	 * @return  mixed An array of data on success, false on failure.
	 */
	public function getItems()
	{
		$items = parent::getItems();

		foreach ($items as $item) {
			if (isset($item->component)) {
				$values    = explode(',', $item->component);
				$textValue = array();

				foreach ($values as $value) {
					if (!empty($value)) {
						$db    = Factory::getContainer()->get(DatabaseInterface::class);
						$query = $db->getQuery(true)
							->select($db->quoteName('component_name'))
							->from($db->quoteName('#__product_components'))
							->where($db->quoteName('id') . ' = ' . $db->quote((int) $value));

						$db->setQuery($query);

						// FIX: loadResult() returns the text string directly instead of an object
						$componentName = $db->loadResult();

						if ($componentName) {
							$textValue[] = $componentName;
						}
					}
				}

				$item->component = !empty($textValue) ? implode(', ', $textValue) : $item->component;
			}

			if (!empty($item->model)) {
				// Split out commas if multiple IDs are saved (e.g., "1,2") and clean up integers
				$modelIds = array_filter(array_map('intval', explode(',', $item->model)));

				if (!empty($modelIds)) {
					$db = Factory::getContainer()->get(\Joomla\Database\DatabaseInterface::class);

					// Build a clean query to translate model IDs into human-readable model names
					$query = $db->getQuery(true)
						->select($db->quoteName('model_name'))         // Fetches the text value column
						->from($db->quoteName('#__product_catalogs'))     // Targets your models table
						->where($db->quoteName('id') . ' IN (' . implode(',', $modelIds) . ')');

					$db->setQuery($query);

					// Fetches all matching model names in one single trip to the database
					$modelNames = $db->loadColumn();

					if (!empty($modelNames)) {
						// Replaces the numeric ID with the readable string (e.g., "BLMT501L, BLMT501R")
						$item->model = implode(', ', $modelNames);
					}
				}
			}
			if (!empty($item->vendor)) {
				// Split out commas if multiple IDs are saved (e.g., "1,2") and sanitize
				$vendorIds = array_filter(array_map('intval', explode(',', $item->vendor)));

				if (!empty($vendorIds)) {
					$db = Factory::getContainer()->get(\Joomla\Database\DatabaseInterface::class);

					// Build a query to translate vendor IDs into human-readable vendor names
					$query = $db->getQuery(true)
						->select($db->quoteName('name'))         // Replace 'vendor_name' with your actual column name
						->from($db->quoteName('#__users'))     // Replace with your actual vendors table name
						->where($db->quoteName('id') . ' IN (' . implode(',', $vendorIds) . ')');

					$db->setQuery($query);

					// Fetches matching vendor names in a single query
					$vendorNames = $db->loadColumn();

					if (!empty($vendorNames)) {
						// Replaces "1, 2" with "Vendor A, Vendor B"
						$item->vendor = implode(', ', $vendorNames);
					}
				}
			}

			if (isset($item->lot) && $item->lot !== '') {
				$lotOptions = array(
					'0' => Text::_('COM_DATA_LOT_NORMAL'),
					'1' => Text::_('COM_DATA_LOT_RESORT'),
				);

				$item->lot_raw = $item->lot;
				$item->lot     = $lotOptions[$item->lot] ?? $item->lot;
			}

			if (!empty($item->remark)) {
				$remarkIds = array_filter(array_map('intval', explode(',', $item->remark)));

				if (!empty($remarkIds)) {
					$db = Factory::getContainer()->get(\Joomla\Database\DatabaseInterface::class);

					$query = $db->getQuery(true)
						->select($db->quoteName('vr.remark'))
						->from($db->quoteName('#__vendor_details', 'vd'))
						->join('INNER', $db->quoteName('#__vendor_remarks', 'vr') . ' ON ' . $db->quoteName('vr.id') . ' = ' . $db->quoteName('vd.remark'))
						->where($db->quoteName('vd.id') . ' IN (' . implode(',', $remarkIds) . ')');

					$db->setQuery($query);

					$remarkNames = $db->loadColumn();

					if (!empty($remarkNames)) {
						$item->remark = implode(', ', $remarkNames);
					}
				}
			}

			if (!empty($item->resort_nc)) {
				$resortNcIds = array_filter(array_map('intval', explode(',', $item->resort_nc)));

				if (!empty($resortNcIds)) {
					$db = Factory::getContainer()->get(\Joomla\Database\DatabaseInterface::class);

					$query = $db->getQuery(true)
						->select($db->quoteName('nc'))
						->from($db->quoteName('#__nc_types'))
						->where($db->quoteName('id') . ' IN (' . implode(',', $resortNcIds) . ')');

					$db->setQuery($query);

					$resortNcNames = $db->loadColumn();

					if (!empty($resortNcNames)) {
						$item->resort_nc = implode(', ', $resortNcNames);
					}
				}
			}
		}

		return $items;
	}

	/**
	 * Overrides the default function to check Date fields format, identified by
	 * "_dateformat" suffix, and erases the field if it's not correct.
	 *
	 * @return void
	 */
	protected function loadFormData()
	{
		$app              = Factory::getApplication();
		$filters          = $app->getUserState($this->context . '.filter', array());
		$error_dateformat = false;

		foreach ($filters as $key => $value) {
			if (strpos($key, '_dateformat') && !empty($value) && $this->isValidDate($value) == null) {
				$filters[$key]    = '';
				$error_dateformat = true;
			}
		}

		if ($error_dateformat) {
			$app->enqueueMessage(Text::_("COM_DATA_SEARCH_FILTER_DATE_FORMAT"), "warning");
			$app->setUserState($this->context . '.filter', $filters);
		}

		return parent::loadFormData();
	}

	/**
	 * Checks if a given date is valid and in a specified format (YYYY-MM-DD)
	 *
	 * @param   string  $date  Date to be checked
	 *
	 * @return bool
	 */
	private function isValidDate($date)
	{
		$date = str_replace('/', '-', $date);
		return (date_create($date)) ? Factory::getDate($date)->format("Y-m-d") : null;
	}
}
