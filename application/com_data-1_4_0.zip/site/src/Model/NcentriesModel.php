<?php

/**
 * @version    CVS: 1.2.0
 * @package    Com_Data
 * @author     Mei Chun <qc.yolotech@gmail.com>
 * @copyright  2026 YOLO
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace Data\Component\Data\Site\Model;
// No direct access.
defined('_JEXEC') or die;

use \Joomla\CMS\Factory;
use \Joomla\CMS\Language\Text;
use \Joomla\CMS\MVC\Model\ListModel;
use \Joomla\Component\Fields\Administrator\Helper\FieldsHelper;
use \Joomla\CMS\Helper\TagsHelper;
use \Joomla\CMS\Layout\FileLayout;
use \Joomla\Database\ParameterType;
use \Joomla\Utilities\ArrayHelper;
use \Data\Component\Data\Site\Helper\DataHelper;
use \Joomla\Database\DatabaseInterface;
use Joomla\CMS\Component\ComponentHelper;


/**
 * Methods supporting a flat, frontend, read-only list of "NC Data Entry" rows
 * (#__data_entry_nc), across every "Total Data Entry" record.
 *
 * @since  1.2.0
 */
class NcentriesModel extends ListModel
{
	/**
	 * Constructor.
	 *
	 * @param   array  $config  An optional associative array of configuration settings.
	 *
	 * @since  1.2.0
	 */

	/**
	 * @var  \DateTime  Monday 00:00:00 of the selected/default ISO week.
	 * @since  1.2.0
	 */
	protected $weekStart;

	/**
	 * @var  \DateTime  Sunday 23:59:59 of the selected/default ISO week.
	 * @since  1.2.0
	 */
	protected $weekEnd;

	/**
	 * @var  \DateTime 
	 * @since  1.2.0
	 */
	protected $monthStart;

	/**
	 * @var  \DateTime  
	 * @since  1.2.0
	 */
	protected $monthEnd;

	/**
	 * @var  \DateTime 
	 * @since  1.2.0
	 */
	protected $yearStart;

	/**
	 * @var  \DateTime  
	 * @since  1.2.0
	 */
	protected $yearEnd;

	/**
	 * @var  \DateTime|null
	 * @since  1.2.0
	 */
	protected $dateFrom;

	/**
	 * @var  \DateTime|null
	 * @since  1.2.0
	 */
	protected $dateTo;

	public function __construct($config = array())
	{
		if (empty($config['filter_fields'])) {
			$config['filter_fields'] = array(
				'id',
				'nc.id',
				'entry_id',
				'nc.entry_id',
				'nc_category',
				'nc.nc_category',
				'nc_type',
				'nc.nc_type',
				'nc_quantity',
				'nc.nc_quantity',
				'nc_percentage',
				'nc.nc_percentage',
				'entry_date',
				'a.date',
				'entry_work_order_no',
				'a.work_order_no',
				'entry_reference_no',
				'a.reference_no',
				'entry_remark',
				'a.remark',
				'entry_lot',
				'a.lot',
				'resort_nc',
				'entry_resort_nc',
				'a.resort_nc',
			);
		}

		parent::__construct($config);
	}

	/**
	 * Method to auto-populate the model state.
	 *
	 * @param   string  $ordering   Elements order
	 * @param   string  $direction  Order direction
	 *
	 * @return  void
	 *
	 * @since   1.2.0
	 */
	protected function populateState($ordering = null, $direction = null)
	{
		parent::populateState('nc.entry_id', 'DESC');
		// parent::populateState('nc.id', 'DESC');

		$app = Factory::getApplication();

		$limit = $app->getUserState($this->context . '.list.limit', $app->get('list_limit', 25));
		$this->setState('list.limit', $limit);

		$limitstart = $app->input->get('limitstart', 0, 'uint');
		$this->setState('list.start', $limitstart);

		$context = $this->getUserStateFromRequest($this->context . '.filter.search', 'filter_search');
		$this->setState('filter.search', $context);

		$entryId = $app->input->getInt('entry_id', 0);
		$this->setState('filter.entry_id', $entryId);

		// Default the year filter to the current year on first load only when $entryId is empty
		if (empty($entryId)) {
			$year = $this->getUserStateFromRequest($this->context . '.filter.year', 'filter_year', date('Y'), 'int');
			$this->setState('filter.year', $year);

			// Default the month filter to the current month on first load
			// $month = $this->getUserStateFromRequest($this->context . '.filter.month', 'filter_month', date('n'), 'int');
			// $this->setState('filter.month', $month);

			// Default the week filter to the current ISO week on first load
			$week = $this->getUserStateFromRequest($this->context . '.filter.week', 'filter_week', date('W'), 'int');
			$this->setState('filter.week', $week);

			// --- Week range ---
			if (!empty($week) && $week !== 'all') {
				$this->weekStart = new \DateTime();
				$this->weekStart->setISODate((int) $year, (int) $week, 1)->setTime(0, 0, 0);

				$this->weekEnd = clone $this->weekStart;
				$this->weekEnd->modify('+6 days')->setTime(23, 59, 59);

				$this->setState('filter.weekStart', $this->weekStart);
				$this->setState('filter.weekEnd', $this->weekEnd);
			} else {
				$this->setState('filter.weekStart', null);
				$this->setState('filter.weekEnd', null);
			}

			// --- Month range (used as fallback display when week = 'all') ---
			if (!empty($month) && $month !== 'all') {
				$this->monthStart = new \DateTime();
				$this->monthStart->setDate((int) $year, (int) $month, 1)->setTime(0, 0, 0);

				$this->monthEnd = clone $this->monthStart;
				$this->monthEnd->modify('last day of this month')->setTime(23, 59, 59);

				$this->setState('filter.monthStart', $this->monthStart);
				$this->setState('filter.monthEnd', $this->monthEnd);
			} else {
				$this->setState('filter.monthStart', null);
				$this->setState('filter.monthEnd', null);
			}

			// --- Year range ---
			if (!empty($year)) {
				$this->yearStart = new \DateTime();
				$this->yearStart->setDate((int) $year, 1, 1)->setTime(0, 0, 0);

				$this->yearEnd = clone $this->yearStart;
				$this->yearEnd->setDate((int) $year, 12, 31)->setTime(23, 59, 59);

				$this->setState('filter.yearStart', $this->yearStart);
				$this->setState('filter.yearEnd', $this->yearEnd);
			} else {
				$this->setState('filter.yearStart', null);
				$this->setState('filter.yearEnd', null);
			}

			// --- Custom date range (from/to) — takes priority over week/month/year for display ---
			$dateFrom = $this->getUserStateFromRequest($this->context . '.filter.date_from', 'filter_date_from');
			$dateTo   = $this->getUserStateFromRequest($this->context . '.filter.date_to', 'filter_date_to');

			$this->setState('filter.date_from', $dateFrom);
			$this->setState('filter.date_to', $dateTo);

			if (!empty($dateFrom)) {
				$this->dateFrom = \DateTime::createFromFormat('Y-m-d', $dateFrom);
				if ($this->dateFrom) {
					$this->dateFrom->setTime(0, 0, 0);
				}
				$this->setState('filter.dateFromObj', $this->dateFrom);
			} else {
				$this->setState('filter.dateFromObj', null);
			}

			if (!empty($dateTo)) {
				$this->dateTo = \DateTime::createFromFormat('Y-m-d', $dateTo);
				if ($this->dateTo) {
					$this->dateTo->setTime(23, 59, 59);
				}
				$this->setState('filter.dateToObj', $this->dateTo);
			} else {
				$this->setState('filter.dateToObj', null);
			}

			// --- Validate date range against week/month/year filters ---
			$conflictDetected = false;

			// Case 1: dateFrom is after dateTo
			if (!empty($this->dateFrom) && !empty($this->dateTo) && $this->dateFrom > $this->dateTo) {
				$conflictDetected = true;
				$app->enqueueMessage(
					Text::_('COM_DATA_FILTER_DATE_FROM_AFTER_TO'),
					'warning'
				);
			}

			// Case 1b: dateTo falls outside the selected week's range
			if (!$conflictDetected && !empty($this->dateTo) && !empty($this->weekStart) && !empty($this->weekEnd)) {
				if ($this->dateTo < $this->weekStart || $this->dateTo > $this->weekEnd) {
					$conflictDetected = true;
					$app->enqueueMessage(
						Text::sprintf(
							'COM_DATA_FILTER_DATE_OUTSIDE_WEEK',
							$this->dateTo->format('Y-m-d'),
							$this->weekStart->format('Y-m-d'),
							$this->weekEnd->format('Y-m-d')
						),
						'warning'
					);
				}
			}

			// Case 1c: dateFrom falls outside the selected week's range
			if (!$conflictDetected && !empty($this->dateFrom) && !empty($this->weekStart) && !empty($this->weekEnd)) {
				if ($this->dateFrom < $this->weekStart || $this->dateFrom > $this->weekEnd) {
					$conflictDetected = true;
					$app->enqueueMessage(
						Text::sprintf(
							'COM_DATA_FILTER_DATE_OUTSIDE_WEEK',
							$this->dateFrom->format('Y-m-d'),
							$this->weekStart->format('Y-m-d'),
							$this->weekEnd->format('Y-m-d')
						),
						'warning'
					);
				}
			}


			// Case 2: dateTo falls outside the selected month's range
			if (!$conflictDetected && !empty($this->dateTo) && !empty($this->monthStart) && !empty($this->monthEnd)) {
				if ($this->dateTo < $this->monthStart || $this->dateTo > $this->monthEnd) {
					$conflictDetected = true;
					$app->enqueueMessage(
						Text::sprintf(
							'COM_DATA_FILTER_DATE_OUTSIDE_MONTH',
							$this->dateTo->format('Y-m-d'),
							$this->monthStart->format('F Y')
						),
						'warning'
					);
				}
			}

			// Case 3: dateFrom falls outside the selected month's range
			if (!$conflictDetected && !empty($this->dateFrom) && !empty($this->monthStart) && !empty($this->monthEnd)) {
				if ($this->dateFrom < $this->monthStart || $this->dateFrom > $this->monthEnd) {
					$conflictDetected = true;
					$app->enqueueMessage(
						Text::sprintf(
							'COM_DATA_FILTER_DATE_OUTSIDE_MONTH',
							$this->dateFrom->format('Y-m-d'),
							$this->monthStart->format('F Y')
						),
						'warning'
					);
				}
			}

			// Case 4: date range falls entirely outside the selected year
			if (!$conflictDetected && !empty($this->yearStart) && !empty($this->yearEnd)) {
				$outOfYear = (!empty($this->dateFrom) && ($this->dateFrom < $this->yearStart || $this->dateFrom > $this->yearEnd))
					|| (!empty($this->dateTo) && ($this->dateTo < $this->yearStart || $this->dateTo > $this->yearEnd));

				if ($outOfYear) {
					$app->enqueueMessage(
						Text::sprintf('COM_DATA_FILTER_DATE_OUTSIDE_YEAR', $this->yearStart->format('Y')),
						'warning'
					);
				}
			}
		}

		$filters = (array) $app->getUserState(
			$this->context . '.filter',
			array()
		);

		if (empty($filters['year'])) {
			$filters['year'] = $year;
			$app->setUserState($this->context . '.filter', $filters);
		}

		if (empty($filters['month'])) {
			$filters['month'] = $month;
			$app->setUserState($this->context . '.filter', $filters);
		}

		if (empty($filters['week'])) {
			$filters['week'] = $week;
			$app->setUserState($this->context . '.filter', $filters);
		}


		if (!empty($ordering) || !empty($direction)) {
			$list['fullordering'] = $ordering . ' ' . $direction;
		}

		// --- Default the Vendor filter to "own account" for Vendor-group users ---
		// Note: this only affects what the filter dropdown shows pre-selected.
		// The actual hard access restriction is enforced separately and
		// unconditionally in getListQuery() below, regardless of this filter.
		// Uses the same configured 'viewOwnVendor' groups as EntriesModel, so the
		// two lists never need to be kept in sync by hand.
		$user     = $app->getIdentity();
		$userId   = (int) $user->get('id');
		$userGrps = (array) $user->get('groups');

		$params              = ComponentHelper::getParams('com_data');
		$viewOwnVendorGroups = array_map('intval', (array) $params->get('viewOwnVendor', []));
		$userGroupIds        = array_map('intval', array_keys($userGrps));
		$canViewOwnVendor    = !empty(array_intersect($userGroupIds, $viewOwnVendorGroups));

		if ($userId > 0 && $canViewOwnVendor) {
			$vendorFilter = $this->getUserStateFromRequest($this->context . '.filter.vendor', 'filter_vendor', $userId);
			$this->setState('filter.vendor', $vendorFilter);

			$filters = (array) $app->getUserState($this->context . '.filter', array());

			if (empty($filters['vendor'])) {
				$filters['vendor'] = $vendorFilter;
				$app->setUserState($this->context . '.filter', $filters);
			}
		}
	}

	/**
	 * Method to get a store id based on model configuration state.
	 *
	 * @param   string  $id  A prefix for the store id.
	 *
	 * @return  string  A store id.
	 *
	 * @since   1.2.0
	 */
	protected function getStoreId($id = '')
	{
		$id .= ':' . $this->getState('filter.search');

		return parent::getStoreId($id);
	}

	/**
	 * Build an SQL query to load the list data.
	 *
	 * @return  \Joomla\Database\DatabaseQuery
	 *
	 * @since   1.2.0
	 */
	protected function getListQuery()
	{
		$db    = Factory::getContainer()->get(DatabaseInterface::class);
		$query = $db->getQuery(true);

		$query->select(
			$this->getState(
				'list.select',
				'DISTINCT nc.id AS id, nc.entry_id AS entry_id, nc.nc_category AS nc_category, ' .
					'nc.nc_quantity AS nc_quantity, nc.nc_percentage AS nc_percentage, nc.ordering AS ordering'
			)
		);
		$query->from($db->quoteName('#__data_entry_nc', 'nc'));

		$query->select(
			'a.date AS entry_date, a.week AS entry_week, a.work_order_no AS entry_work_order_no, ' .
				'a.component AS entry_component, a.model AS entry_model, a.vendor AS entry_vendor, ' .
				'a.operator AS entry_operator, a.total AS entry_total, a.state AS entry_state, a.week AS entry_week, a.id AS entry_id, a.total AS entry_total,' .
				'a.created_by AS entry_created_by, a.reference_no AS entry_reference_no, a.lot AS entry_lot, a.remark AS entry_remark, a.resort_nc AS entry_resort_nc'
		);
		$query->join('INNER', $db->quoteName('#__data_entry', 'a') . ' ON ' . $db->quoteName('a.id') . ' = ' . $db->quoteName('nc.entry_id'));

		// --- NEW CODE ADDED HERE ---
		// Only fetch records where the parent entry's state is active/published (state = 1)
		$query->where($db->quoteName('a.state') . ' = 1');
		// ---------------------------

		$query->select($db->quoteName('op.name', 'operator_name'));
		$query->join('LEFT', $db->quoteName('#__users', 'op') . ' ON ' . $db->quoteName('op.id') . ' = ' . $db->quoteName('a.operator'));

		$query->select($db->quoteName('nctype.nc', 'nc_code'));
		$query->select($db->quoteName('cat.category', 'nc_category_name'));
		$query->join('LEFT', $db->quoteName('#__nc_types', 'nctype') . ' ON ' . $db->quoteName('nctype.id') . ' = ' . $db->quoteName('nc.nc_type'));
		$query->join('LEFT', $db->quoteName('#__nc_category', 'cat') . ' ON ' . $db->quoteName('cat.id') . ' = ' . $db->quoteName('nctype.category'));

		$query->select(
			'(SELECT COUNT(*) FROM ' . $db->quoteName('#__data_entry_nc_images') . ' WHERE ' .
				$db->quoteName('nc_id') . ' = ' . $db->quoteName('nc.id') . ') AS ' . $db->quoteName('image_count')
		);

		// Only show entries the current user is allowed to see, mirroring the Entries list.
		$user = Factory::getApplication()->getIdentity();

		if (!$user->authorise('core.edit', 'com_data')) {
			$query->where($db->quoteName('a.state') . ' = 1');
		} else {
			$query->where($db->quoteName('a.state') . ' IN (0, 1)');
		}

		// --- Access Control Logic Starts Here ---
		$user       = Factory::getApplication()->getIdentity();
		$userId   = (int) $user->get('id');
		$userGrps = $user->get('groups');

		$params = ComponentHelper::getParams('com_data');

		$viewAllGroups         = array_map('intval', (array) $params->get('viewAll', []));
		$viewOwnOperatorGroups = array_map('intval', (array) $params->get('viewOwnOperator', []));
		$viewOwnVendorGroups   = array_map('intval', (array) $params->get('viewOwnVendor', []));
		$viewAllVendorGroups   = array_map('intval', (array) $params->get('viewAllVendor', []));

		$userGroupIds = array_map('intval', array_keys($userGrps));

		$isSuperUser        = $user->authorise('core.admin');
		$canViewAll          = !empty(array_intersect($userGroupIds, $viewAllGroups));
		$canViewOwnOperator  = !empty(array_intersect($userGroupIds, $viewOwnOperatorGroups));
		$canViewOwnVendor    = !empty(array_intersect($userGroupIds, $viewOwnVendorGroups));
		$canViewAllVendor    = !empty(array_intersect($userGroupIds, $viewAllVendorGroups));

		if (!$userId) {
			$query->where('1 = 0'); // Guest block
		} elseif ($isSuperUser || $canViewAll) {
			// Super Users and View All groups can see everything - no extra WHERE.
		} elseif ($canViewOwnOperator || $canViewOwnVendor || $canViewAllVendor) {
			$conditions = array();

			if ($canViewOwnOperator) {
				$conditions[] = $db->quoteName('a.operator') . ' = ' . $userId;
			}

			if ($canViewOwnVendor || $canViewAllVendor) {
				// Vendor ids this user can see records for: themselves, plus
				// anyone listed under them as "Main Vendor" in #__vendor_access
				// (delegation - a main vendor can see their sub-vendors' records too).
				$vendorIds = array($userId);

				$accessQuery = $db->getQuery(true)
					->select($db->quoteName('vendors'))
					->from($db->quoteName('#__vendor_access'))
					->where($db->quoteName('main_vendor') . ' = ' . $userId)
					->where($db->quoteName('state') . ' = 1');

				$db->setQuery($accessQuery);
				$delegatedRows = $db->loadColumn() ?: array();

				foreach ($delegatedRows as $csv) {
					foreach (explode(',', (string) $csv) as $id) {
						$id = (int) $id;

						if ($id > 0) {
							$vendorIds[] = $id;
						}
					}
				}

				$vendorIds = array_unique($vendorIds);

				// FIND_IN_SET, not plain '=' - see note below about EntriesModel's version.
				$vendorConditions = array();

				foreach ($vendorIds as $vendorId) {
					$vendorConditions[] = 'FIND_IN_SET(' . $vendorId . ', ' . $db->quoteName('a.vendor') . ')';
				}

				$conditions[] = '(' . implode(' OR ', $vendorConditions) . ')';
			}

			$query->where('(' . implode(' OR ', $conditions) . ')');
		} else {
			$query->where('1 = 0'); // No viewing permission
		}

		// ------------------------------------------------------
		// ==========================================
		// ADD THIS BLOCK: Filter by Parent Entry ID
		// ==========================================
		$entryId = $this->getState('filter.entry_id');
		if ($entryId > 0) {
			$query->where($db->quoteName('nc.entry_id') . ' = ' . (int) $entryId);
		}
		// ==========================================

		$search = $this->getState('filter.search');

		if (!empty($search)) {
			if (stripos($search, 'id:') === 0) {
				$query->where('a.id = ' . (int) substr($search, 3));
			} else {
				$escaped = $db->Quote('%' . $db->escape($search, true) . '%');
				$query->where(
					'(' . $db->quoteName('a.work_order_no') . ' LIKE ' . $escaped .
						' OR ' . $db->quoteName('a.reference_no') . ' LIKE ' . $escaped .
						' OR EXISTS (SELECT 1 FROM ' . $db->quoteName('#__product_components', 'pc_s') .
						' WHERE FIND_IN_SET(' . $db->quoteName('pc_s.id') . ', ' . $db->quoteName('a.component') . ')' .
						' AND ' . $db->quoteName('pc_s.component_name') . ' LIKE ' . $escaped . ')' .
						' OR EXISTS (SELECT 1 FROM ' . $db->quoteName('#__product_catalogs', 'pcat_s') .
						' WHERE FIND_IN_SET(' . $db->quoteName('pcat_s.id') . ', ' . $db->quoteName('a.model') . ')' .
						' AND ' . $db->quoteName('pcat_s.model_name') . ' LIKE ' . $escaped . ')' .
						' OR EXISTS (SELECT 1 FROM ' . $db->quoteName('#__users', 'ven_s') .
						' WHERE FIND_IN_SET(' . $db->quoteName('ven_s.id') . ', ' . $db->quoteName('a.vendor') . ')' .
						' AND ' . $db->quoteName('ven_s.name') . ' LIKE ' . $escaped . ')' .
						' OR EXISTS (SELECT 1 FROM ' . $db->quoteName('#__users', 'op_s') .
						' WHERE FIND_IN_SET(' . $db->quoteName('op_s.id') . ', ' . $db->quoteName('a.operator') . ')' .
						' AND ' . $db->quoteName('op_s.name') . ' LIKE ' . $escaped . ')' .
						' OR EXISTS (SELECT 1 FROM ' . $db->quoteName('#__nc_types', 'nctype') .
						' WHERE FIND_IN_SET(' . $db->quoteName('nctype.id') . ', ' . $db->quoteName('nc.nc_type') . ')' .
						' AND ' . $db->quoteName('nctype.nc') . ' LIKE ' . $escaped . ')' .
						' OR EXISTS (SELECT 1 FROM ' . $db->quoteName('#__nc_category', 'cat') .
						' WHERE FIND_IN_SET(' . $db->quoteName('cat.id') . ', ' . $db->quoteName('nctype.category') . ')' .
						' AND ' . $db->quoteName('cat.category') . ' LIKE ' . $escaped . ')' .
						')'
				);
			}
		}

		// Filtering component
		$filter_component = $this->state->get("filter.component");
		if (is_array($filter_component)) {
			$filter_component = array_values(array_filter($filter_component, function ($v) {
				return $v !== "" && $v !== null;
			}));
		}
		if ((is_array($filter_component) && count($filter_component) > 0) || (!is_array($filter_component) && $filter_component !== "" && $filter_component !== null)) {
			if (is_array($filter_component)) {
				$__vals = array_map([$db, "quote"], $filter_component);
				$query->where($db->quoteName("a.component") . " IN (" . implode(",", $__vals) . ")");
			} else {
				$query->where($db->quoteName("a.component") . " = " . $db->quote($filter_component));
			}
		}

		// Filtering model
		$filter_model = $this->state->get("filter.model");
		if (is_array($filter_model)) {
			$filter_model = array_values(array_filter($filter_model, function ($v) {
				return $v !== "" && $v !== null;
			}));
		}
		if ((is_array($filter_model) && count($filter_model) > 0) || (!is_array($filter_model) && $filter_model !== "" && $filter_model !== null)) {
			if (is_array($filter_model)) {
				$__vals = array_map([$db, "quote"], $filter_model);
				$query->where($db->quoteName("a.model") . " IN (" . implode(",", $__vals) . ")");
			} else {
				$query->where($db->quoteName("a.model") . " = " . $db->quote($filter_model));
			}
		}

		// Filtering lot
		$filter_lot = $this->state->get('filter.lot');
		if ($filter_lot !== null && $filter_lot !== '') {
			$query->where($db->quoteName('a.lot') . ' = ' . (int) $filter_lot);
		}

		// Filtering resort_nc
		$filter_resort_nc = $this->state->get("filter.resort_nc");
		if (is_array($filter_resort_nc)) {
			$filter_resort_nc = array_values(array_filter($filter_resort_nc, function ($v) {
				return $v !== "" && $v !== null;
			}));
		}
		if ((is_array($filter_resort_nc) && count($filter_resort_nc) > 0) || (!is_array($filter_resort_nc) && $filter_resort_nc !== "" && $filter_resort_nc !== null)) {
			if (is_array($filter_resort_nc)) {
				$__conditions = array();
				foreach ($filter_resort_nc as $__val) {
					$__conditions[] = 'FIND_IN_SET(' . (int) $__val . ', ' . $db->quoteName('a.resort_nc') . ')';
				}
				$query->where('(' . implode(' OR ', $__conditions) . ')');
			} else {
				$query->where('FIND_IN_SET(' . (int) $filter_resort_nc . ', ' . $db->quoteName('a.resort_nc') . ')');
			}
		}

		// Filtering nc category
		$filter_nc_cat = $this->state->get('filter.nc_category');
		if ($filter_nc_cat !== null && $filter_nc_cat !== '') {
			$query->where($db->quoteName('nc.nc_category') . ' = ' . (int) $filter_nc_cat);
		}

		// Filtering nc type
		$filter_nc_type = $this->state->get('filter.nc_type');
		if ($filter_nc_type !== null && $filter_nc_type !== '') {
			$query->where($db->quoteName('nc.nc_type') . ' = ' . (int) $filter_nc_type);
		}

		// Filtering vendor
		$filter_vendor = $this->state->get("filter.vendor");
		if (is_array($filter_vendor)) {
			$filter_vendor = array_values(array_filter($filter_vendor, function ($v) {
				return $v !== "" && $v !== null;
			}));
		}
		if ((is_array($filter_vendor) && count($filter_vendor) > 0) || (!is_array($filter_vendor) && $filter_vendor !== "" && $filter_vendor !== null)) {
			if (is_array($filter_vendor)) {
				$__vals = array_map([$db, "quote"], $filter_vendor);
				$query->where($db->quoteName("a.vendor") . " IN (" . implode(",", $__vals) . ")");
			} else {
				$query->where($db->quoteName("a.vendor") . " = " . $db->quote($filter_vendor));
			}
		}

		// Filtering week
		$week = $this->state->get('filter.week');
		if (!empty($week) && $week !== 'all') {
			$query->where('a.week = ' . (int) $week);
		}

		// Filtering month
		$month = $this->state->get('filter.month');
		if (!empty($month) && $month !== 'all') {
			$query->where('MONTH(a.date) = ' . (int) $month);
		}

		// Filtering year
		$year = $this->state->get('filter.year');
		if (!empty($year)) {
			$query->where('YEAR(a.date) = ' . (int) $year);
		}

		// Filtering date range
		$dateFrom = $this->state->get('filter.date_from');
		$dateTo   = $this->state->get('filter.date_to');

		if (!empty($dateFrom)) {
			$query->where('DATE(a.date) >= ' . $db->quote($dateFrom));
		}

		if (!empty($dateTo)) {
			$query->where('DATE(a.date) <= ' . $db->quote($dateTo));
		}


		$orderCol  = $this->state->get('list.ordering', 'nc.entry_id');
		$orderDirn = $this->state->get('list.direction', 'DESC');

		if ($orderCol && $orderDirn) {
			$query->order($db->escape($orderCol . ' ' . $orderDirn));
		}

		return $query;
	}

	/**
	 * Get an array of data items, resolving component/model/vendor ids into readable labels.
	 *
	 * @return  mixed  Array of data items on success, false on failure.
	 *
	 * @since   1.2.0
	 */
	public function getItems()
	{
		$items = parent::getItems();

		$db = Factory::getContainer()->get(DatabaseInterface::class);

		foreach ($items as $item) {

			if (!empty($item->entry_component)) {
				$componentIds = array_filter(array_map('intval', explode(',', $item->entry_component)));

				if (!empty($componentIds)) {
					$query = $db->getQuery(true)
						->select($db->quoteName('component_name'))
						->from($db->quoteName('#__product_components'))
						->where($db->quoteName('id') . ' IN (' . implode(',', $componentIds) . ')');
					$db->setQuery($query);
					$names = $db->loadColumn();

					if (!empty($names)) {
						$item->entry_component = implode(', ', $names);
					}
				}
			}

			if (!empty($item->entry_model)) {
				$modelIds = array_filter(array_map('intval', explode(',', $item->entry_model)));

				if (!empty($modelIds)) {
					$query = $db->getQuery(true)
						->select($db->quoteName('model_name'))
						->from($db->quoteName('#__product_catalogs'))
						->where($db->quoteName('id') . ' IN (' . implode(',', $modelIds) . ')');
					$db->setQuery($query);
					$names = $db->loadColumn();

					if (!empty($names)) {
						$item->entry_model = implode(', ', $names);
					}
				}
			}

			if (!empty($item->entry_vendor)) {
				$vendorIds = array_filter(array_map('intval', explode(',', $item->entry_vendor)));

				if (!empty($vendorIds)) {
					$query = $db->getQuery(true)
						->select($db->quoteName('name'))
						->from($db->quoteName('#__users'))
						->where($db->quoteName('id') . ' IN (' . implode(',', $vendorIds) . ')');
					$db->setQuery($query);
					$names = $db->loadColumn();

					if (!empty($names)) {
						$item->entry_vendor = implode(', ', $names);
					}
				}
			}

			if (!empty($item->entry_remark)) {
				$remarkIds = array_filter(array_map('intval', explode(',', $item->entry_remark)));

				if (!empty($remarkIds)) {
					$db = Factory::getContainer()->get(\Joomla\Database\DatabaseInterface::class);

					$query = $db->getQuery(true)
						->select($db->quoteName('vr.remark'))
						->from($db->quoteName('#__vendor_details', 'vd'))
						->join('INNER', $db->quoteName('#__vendor_remarks', 'vr') . ' ON ' . $db->quoteName('vr.id') . ' = ' . $db->quoteName('vd.remark'))
						->where($db->quoteName('vd.id') . ' IN (' . implode(',', $remarkIds) . ')');

					$db->setQuery($query);

					$remarkNames = $db->loadColumn();

					if (!empty($remarkNames)) {
						$item->entry_remark = implode(', ', $remarkNames);
					}
				}
			}

			if (isset($item->entry_lot) && $item->entry_lot !== '') {
				$lotOptions = array(
					'0' => Text::_('COM_DATA_LOT_NORMAL'),
					'1' => Text::_('COM_DATA_LOT_RESORT'),
				);

				// Keep the raw value for reliable comparisons elsewhere (e.g. in templates),
				// since entry_lot below gets overwritten with the translated label for display.
				$item->entry_lot_raw = $item->entry_lot;
				$item->entry_lot     = $lotOptions[$item->entry_lot] ?? $item->entry_lot;
			}

			if (!empty($item->entry_resort_nc)) {
				$resortNcIds = array_filter(array_map('intval', explode(',', $item->entry_resort_nc)));

				if (!empty($resortNcIds)) {
					$db = Factory::getContainer()->get(\Joomla\Database\DatabaseInterface::class);

					$query = $db->getQuery(true)
						->select($db->quoteName('nc'))
						->from($db->quoteName('#__nc_types'))
						->where($db->quoteName('id') . ' IN (' . implode(',', $resortNcIds) . ')');

					$db->setQuery($query);

					$resortNcNames = $db->loadColumn();

					if (!empty($resortNcNames)) {
						$item->entry_resort_nc = implode(', ', $resortNcNames);
					}
				}
			}
		}

		return $items;
	}
}
