<?php

/**
 * @version    CVS: 1.3.0
 * @package    Com_Data
 * @author     Mei Chun <qc.yolotech@gmail.com>
 * @copyright  2026 YOLO
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace Data\Component\Data\Site\View\Ncdailysummary;
// No direct access
defined('_JEXEC') or die;

use \Joomla\CMS\MVC\View\HtmlView as BaseHtmlView;
use \Joomla\CMS\Factory;
use \Joomla\CMS\Language\Text;

/**
 * View class for the public Daily NC% Summary report.
 *
 * @since  1.3.0
 */
class HtmlView extends BaseHtmlView
{
	/** @var object  { dates, rows } */
	protected $pivot;

	/** @var array  Distinct Part values for the Part Selector. */
	protected $partOptions;

	/** @var array  Model options { value, text } for the Model Selector. */
	protected $modelOptions;

	/** @var array  Vendor options { key, value } for the Vendor Selector. */
	protected $vendorOptions;

	/** @var array  Years with data, for the Year Selector. */
	protected $yearOptions;

	/** @var array  ISO weeks within the selected year, for the Week Selector. */
	protected $weekOptions;

	/** @var array  Lot options. */
	protected $lotOptions;

	/** @var object  { part, model, vendor, year, week, week_start, week_end } */
	protected $activeFilters;

	/** @var \Joomla\Registry\Registry */
	protected $params;

	/**
	 * Display the view
	 *
	 * @param   string  $tpl  Template name
	 *
	 * @return void
	 *
	 * @throws Exception
	 */
	public function display($tpl = null)
	{
		$app = Factory::getApplication();

		$this->pivot         = $this->get('Pivot');
		$this->partOptions   = $this->get('PartOptions');
		$this->modelOptions  = $this->get('ModelOptions');
		$this->vendorOptions = $this->get('VendorOptions');
		$this->yearOptions   = $this->get('YearOptions');
		$this->weekOptions   = $this->get('WeekOptions');
		$this->lotOptions = $this->get('LotOptions');
		$this->activeFilters = $this->get('ActiveFilters');
		$this->params        = $app->getParams('com_data');

		if (count($errors = $this->get('Errors'))) {
			throw new \Exception(implode("\n", $errors));
		}

		$this->_prepareDocument();

		$this->document = Factory::getApplication()->getDocument();
		$this->document->setTitle('Daily NC% Summary');

		parent::display($tpl);
	}

	/**
	 * Prepares the document
	 *
	 * @return void
	 *
	 * @throws Exception
	 */
	protected function _prepareDocument()
	{
		$app   = Factory::getApplication();
		$menus = $app->getMenu();
		$menu  = $menus->getActive();

		if ($menu) {
			$this->params->def('page_heading', $this->params->get('page_title', $menu->title));
		} else {
			$this->params->def('page_heading', Text::_('COM_DATA_TITLE_NCDAILYSUMMARY'));
		}

		$title = $this->params->get('page_title', '');

		if (empty($title)) {
			$title = $app->get('sitename');
		} elseif ($app->get('sitename_pagetitles', 0) == 1) {
			$title = Text::sprintf('JPAGETITLE', $app->get('sitename'), $title);
		} elseif ($app->get('sitename_pagetitles', 0) == 2) {
			$title = Text::sprintf('JPAGETITLE', $title, $app->get('sitename'));
		}

		$this->document->setTitle($title);
	}
}
