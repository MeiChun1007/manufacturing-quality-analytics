<?php

/**
 * @version    CVS: 1.8.0
 * @package    Com_Data
 * @author     Mei Chun <qc.yolotech@gmail.com>
 * @copyright  2026 YOLO
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace Data\Component\Data\Site\View\Operatorperformance;

defined('_JEXEC') or die;

use \Joomla\CMS\MVC\View\HtmlView as BaseHtmlView;
use \Joomla\CMS\Factory;
use \Joomla\CMS\Language\Text;

/**
 * @since  1.6.0
 */
class HtmlView extends BaseHtmlView
{
	protected $qualityRanking;

	protected $productionRanking;

	protected $scatterData;

	// protected $biggestMovers;

	/**
	 * Per-operator, per-model sort output vs OT/changeover-adjusted daily
	 * target. { rows: [...], is_single_day: boolean }
	 *
	 * @var  object
	 * @since  1.8.0
	 */
	protected $kpiBreakdown;

	protected $activeFilters;

	protected $previousPeriod;

	protected $weekOptions;

	protected $monthOptions;

	protected $yearOptions;

	protected $partOptions;

	protected $modelOptions;

	protected $nccategoryOptions;

	protected $nctypeOptions;

	protected $vendorOptions;

	protected $operatorOptions;

	protected $remarkOptions;

	protected $lotOptions;

	protected $params;

	public function display($tpl = null)
	{
		$app = Factory::getApplication();

		/** @var \Data\Component\Data\Site\Model\OperatorperformanceModel $model */
		$model = $this->getModel();

		if (!$model->canViewPerformance()) {
			throw new \Exception(Text::_('COM_DATA_OPERATORPERFORMANCE_NO_ACCESS'), 403);
		}

		$this->qualityRanking    = $model->getQualityRanking();
		$this->productionRanking = $model->getProductionRanking();
		$this->kpiBreakdown      = $model->getOperatorKpiBreakdown();
		$this->partOptions  	 = $this->get('PartOptions');
		$this->modelOptions      = $this->get('ModelOptions');
		$this->vendorOptions     = $this->get('VendorOptions');
		$this->operatorOptions   = $this->get('OperatorOptions');
		$this->nccategoryOptions = $this->get('NCCategoryOptions');
		$this->nctypeOptions  	 = $this->get('NCTypeOptions');
		$this->remarkOptions  	 = $this->get('RemarkOptions');
		$this->lotOptions  		 = $this->get('LotOptions');
		$this->activeFilters     = $model->getActiveFilters();
		$this->weekOptions   	 = $this->get('WeekOptions');
		$this->monthOptions  	 = $this->get('MonthOptions');
		$this->yearOptions       = $model->getYearOptions();
		$this->previousPeriod    = $this->get('PreviousPeriodRange');
		$this->scatterData   	 = $this->get('ScatterData');
		// $this->biggestMovers 	 = $this->get('BiggestMovers');
		$this->params            = $app->getParams('com_data');

		if (count($errors = $this->get('Errors'))) {
			throw new \Exception(implode("\n", $errors));
		}

		$this->_prepareDocument();
		parent::display($tpl);
	}

	protected function _prepareDocument()
	{
		$app   = Factory::getApplication();
		$menus = $app->getMenu();
		$menu  = $menus->getActive();

		if ($menu) {
			$this->params->def('page_heading', $this->params->get('page_title', $menu->title));
		} else {
			$this->params->def('page_heading', Text::_('COM_DATA_TITLE_OPERATORPERFORMANCE'));
		}

		$this->document->setTitle(Text::_('COM_DATA_TITLE_OPERATORPERFORMANCE'));
	}
}