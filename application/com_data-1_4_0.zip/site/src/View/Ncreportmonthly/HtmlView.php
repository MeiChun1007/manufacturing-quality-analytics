<?php

/**
 * @version    CVS: 1.2.0
 * @package    Com_Data
 * @author     Mei Chun <qc.yolotech@gmail.com>
 * @copyright  2026 YOLO
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace Data\Component\Data\Site\View\Ncreportmonthly;
// No direct access
defined('_JEXEC') or die;

use \Joomla\CMS\MVC\View\HtmlView as BaseHtmlView;
use \Joomla\CMS\Factory;
use \Joomla\CMS\Language\Text;

/**
 * View class for the Monthly NC Report pivot.
 *
 * @since  1.2.0
 */
class HtmlView extends BaseHtmlView
{
	protected $activeFilters;
	protected $pivot;
	protected $summary;
	protected $partOptions;
	protected $modelOptions;
	protected $yearOptions;
	protected $vendorOptions;
	protected $operatorOptions;
	protected $monthOptions;
	protected $remarkOptions;
	protected $lotOptions;
	protected $params;
	protected $nccategoryOptions;
	protected $nctypeOptions;

	/**
	 * Display the view
	 *
	 * @param   string  $tpl  Template name
	 *
	 * @return  void
	 *
	 * @throws  \Exception
	 *
	 * @since   1.2.0
	 */
	public function display($tpl = null)
	{
		$app = Factory::getApplication();

		$this->activeFilters 	= $this->get('ActiveFilters');
		$this->pivot         	= $this->get('Pivot');
		$this->summary       	= $this->get('Summary');
		$this->partOptions  	= $this->get('PartOptions');
		$this->modelOptions  	= $this->get('ModelOptions');
		$this->yearOptions  	= $this->get('YearOptions');
		$this->vendorOptions 	= $this->get('VendorOptions');
		$this->operatorOptions  = $this->get('OperatorOptions');
		$this->nccategoryOptions = $this->get('NCCategoryOptions');
		$this->nctypeOptions  	 = $this->get('NCTypeOptions');
		$this->monthOptions  	= $this->get('MonthOptions');
		$this->remarkOptions  	= $this->get('RemarkOptions');
		$this->lotOptions  		= $this->get('LotOptions');
		$this->params        	= $app->getParams('com_data');

		if (count($errors = $this->get('Errors'))) {
			throw new \Exception(implode("\n", $errors));
		}

		$this->_prepareDocument();


		$this->document = Factory::getApplication()->getDocument();
		$this->document->setTitle('NC Report Monthly');

		parent::display($tpl);
	}

	/**
	 * Prepares the document title/meta.
	 *
	 * @return  void
	 *
	 * @since   1.2.0
	 */
	protected function _prepareDocument()
	{
		$app   = Factory::getApplication();
		$menus = $app->getMenu();
		$menu  = $menus->getActive();

		if ($menu) {
			$this->params->def('page_heading', $this->params->get('page_title', $menu->title));
		} else {
			$this->params->def('page_heading', Text::_('COM_DATA_TITLE_NCREPORTMONTHLY'));
		}

		$title = $this->params->get('page_title', '');

		if (empty($title)) {
			$title = $app->get('sitename');
		} elseif ($app->get('sitename_pagetitles', 0) == 1) {
			$title = Text::sprintf('JPAGETITLE', $app->get('sitename'), $title);
		} elseif ($app->get('sitename_pagetitles', 0) == 2) {
			$title = Text::sprintf('JPAGETITLE', $title, $app->get('sitename'));
		}

		$this->document->setTitle($title);
	}
}
