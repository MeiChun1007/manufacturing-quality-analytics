<?php

/**
 * @version    CVS: 1.3.0
 * @package    Com_Data
 * @author     Mei Chun <qc.yolotech@gmail.com>
 * @copyright  2026 YOLO
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace Data\Component\Data\Site\View\Ncmodelsummary;
// No direct access
defined('_JEXEC') or die;

use \Joomla\CMS\MVC\View\HtmlView as BaseHtmlView;
use \Joomla\CMS\Factory;
use \Joomla\CMS\Language\Text;

/**
 * View class for the public Model Summary report.
 *
 * @since  1.3.0
 */
class HtmlView extends BaseHtmlView
{
	/** @var array  Full (Part, Model) summary rows, sorted by NC% descending. */
	protected $summaryRows;

	/** @var array  Top N (Part, Model) rows by NC%, above the minimum Total Sort threshold. */
	protected $topNc;

	/** @var array  Distinct Part values for the Part Selector. */
	protected $partOptions;

	/** @var array  Distinct models for the Model Selector. */
	protected $modelOptions;

	/** @var array  ISO week options for the Week Selector. */
	protected $weekOptions;

	/** @var array  Calendar month options for the Month Selector. */
	protected $monthOptions;

	/** @var int  Selected calendar/ISO year. */
	protected $yearOptions;

	/** @var object  { period_type, week, month, part, top_limit, min_sort, period_start, period_end } */
	protected $activeFilters;

	/** @var  string Vendor Options*/
	protected $vendorOptions = '';

	/** @var array  Distinct operators for the Operator Selector. */
	protected $operatorOptions;

	/** @var array  Distinct remarks for the Remark Selector. */
	protected $remarkOptions;

	/** @var array  Distinct lots for the Lot Selector. */
	protected $lotOptions;

	/** @var \Joomla\Registry\Registry */
	protected $params;

	/**
	 * Display the view
	 *
	 * @param   string  $tpl  Template name
	 *
	 * @return void
	 *
	 * @throws Exception
	 */
	public function display($tpl = null)
	{
		$app = Factory::getApplication();

		$this->summaryRows   	= $this->get('SummaryRows');
		$this->topNc         	= $this->get('TopNc');
		$this->partOptions  	= $this->get('PartOptions');
		$this->modelOptions  	= $this->get('ModelOptions');
		$this->weekOptions   	= $this->get('WeekOptions');
		$this->monthOptions  	= $this->get('MonthOptions');
		$this->yearOptions   	= $this->get('YearOptions');
		$this->vendorOptions  	= $this->get('VendorOptions');
		$this->operatorOptions  = $this->get('OperatorOptions');
		$this->remarkOptions  	= $this->get('RemarkOptions');
		$this->lotOptions  		= $this->get('LotOptions');
		$this->activeFilters 	= $this->get('ActiveFilters');
		$this->params        	= $app->getParams('com_data');

		// Check for errors.
		if (count($errors = $this->get('Errors'))) {
			throw new \Exception(implode("\n", $errors));
		}

		$this->_prepareDocument();
		$this->document = Factory::getApplication()->getDocument();
		$this->document->setTitle('Model Summary');
		parent::display($tpl);
	}

	/**
	 * Prepares the document
	 *
	 * @return void
	 *
	 * @throws Exception
	 */
	protected function _prepareDocument()
	{
		$app   = Factory::getApplication();
		$menus = $app->getMenu();
		$menu  = $menus->getActive();

		if ($menu) {
			$this->params->def('page_heading', $this->params->get('page_title', $menu->title));
		} else {
			$this->params->def('page_heading', Text::_('COM_DATA_TITLE_MODELSUMMARY'));
		}

		$title = $this->params->get('page_title', '');

		if (empty($title)) {
			$title = $app->get('sitename');
		} elseif ($app->get('sitename_pagetitles', 0) == 1) {
			$title = Text::sprintf('JPAGETITLE', $app->get('sitename'), $title);
		} elseif ($app->get('sitename_pagetitles', 0) == 2) {
			$title = Text::sprintf('JPAGETITLE', $title, $app->get('sitename'));
		}

		$this->document->setTitle($title);
	}
}
