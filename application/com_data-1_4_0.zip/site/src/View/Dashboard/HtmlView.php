<?php

/**
 * @version    CVS: 1.3.0
 * @package    Com_Data
 * @author     Mei Chun <qc.yolotech@gmail.com>
 * @copyright  2026 YOLO
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace Data\Component\Data\Site\View\Dashboard;
// No direct access
defined('_JEXEC') or die;

use \Joomla\CMS\MVC\View\HtmlView as BaseHtmlView;
use \Joomla\CMS\Factory;
use \Joomla\CMS\Language\Text;

/**
 * View class for the public overview Dashboard: production and NC trends
 * and breakdowns across a selected date range.
 *
 * @since  1.3.0
 */
class HtmlView extends BaseHtmlView
{
	/** @var object  { total_sort, total_nc, total_accepted, yield_pct, total_nc_pct, entry_count, vendor_count, model_count } */
	protected $summary;

	/** @var object  { bucket, points } */
	protected $trend;

	/** @var object  { bucket, points } */
	protected $categoryTrend;

	/** @var array  Top NC categories by volume. */
	protected $categoryBreakdown;

	/** @var array  Top NC Types by volume. */
	protected $ncTypeBreakdown;

	/** @var array  Top vendors by volume. */
	protected $vendorBreakdown;

	/** @var array  Top models by volume. */
	protected $modelBreakdown;

	/** @var array  Distinct models for the Model Selector. */
	protected $modelOptions;

	/** @var array  Distinct vendors for the Vendor Selector. */
	protected $vendorOptions;

	/** @var object  { model, vendor, date_from, date_to, day_span } */
	protected $activeFilters;

	/** @var array  ISO week options for the Week Selector. */
	protected $weekOptions;

	/** @var array  Calendar month options for the Month Selector. */
	protected $monthOptions;

	/** @var int  Selected calendar/ISO year. */
	protected $yearOptions;

	/** @var \Joomla\Registry\Registry */
	protected $params;

	/** @var array  Distinct parts for the Part Selector. */
	protected $partOptions;

	/** @var array  Distinct operators for the Operator Selector. */
	protected $operatorOptions;

	/** @var array  Distinct remarks for the Remark Selector. */
	protected $remarkOptions;

	/** @var array  Distinct lots for the Lot Selector. */
	protected $lotOptions;

	/** @var array  KOKESHI Entries */
	protected $kokeshiEntries;

	/** @var array  Distinct NC Categories for the NC Categorie Selector. */
	protected $nccategoryOptions;

	/** @var array  Distinct NC Types for the NC Types Selector. */
	protected $nctypeOptions;

	/**
	 * Display the view
	 *
	 * @param   string  $tpl  Template name
	 *
	 * @return void
	 *
	 * @throws Exception
	 */
	public function display($tpl = null)
	{
		$app = Factory::getApplication();

		$this->summary           = $this->get('Summary');
		$this->trend             = $this->get('Trend');
		$this->categoryTrend     = $this->get('CategoryTrend');
		$this->categoryBreakdown = $this->get('CategoryBreakdown');
		$this->ncTypeBreakdown 	 = $this->get('NcTypeBreakdown');
		$this->vendorBreakdown   = $this->get('VendorBreakdown');
		$this->modelBreakdown    = $this->get('ModelBreakdown');
		$this->kokeshiEntries 	 = $this->get('KokeshiEntries');
		$this->partOptions  	 = $this->get('PartOptions');
		$this->modelOptions      = $this->get('ModelOptions');
		$this->vendorOptions     = $this->get('VendorOptions');
		$this->operatorOptions   = $this->get('OperatorOptions');
		$this->remarkOptions  	 = $this->get('RemarkOptions');
		$this->nccategoryOptions = $this->get('NCCategoryOptions');
		$this->nctypeOptions  	 = $this->get('NCTypeOptions');
		$this->lotOptions  		 = $this->get('LotOptions');
		$this->activeFilters     = $this->get('ActiveFilters');
		$this->weekOptions   	 = $this->get('WeekOptions');
		$this->monthOptions  	 = $this->get('MonthOptions');
		$this->yearOptions  	 = $this->get('YearOptions');
		$this->params            = $app->getParams('com_data');

		if (count($errors = $this->get('Errors'))) {
			throw new \Exception(implode("\n", $errors));
		}

		$this->_prepareDocument();

		parent::display($tpl);
	}

	/**
	 * Prepares the document
	 *
	 * @return void
	 *
	 * @throws Exception
	 */
	protected function _prepareDocument()
	{
		$app   = Factory::getApplication();
		$menus = $app->getMenu();
		$menu  = $menus->getActive();

		if ($menu) {
			$this->params->def('page_heading', $this->params->get('page_title', $menu->title));
		} else {
			$this->params->def('page_heading', Text::_('COM_DATA_TITLE_DASHBOARD'));
		}

		$title = $this->params->get('page_title', '');

		if (empty($title)) {
			$title = $app->get('sitename');
		} elseif ($app->get('sitename_pagetitles', 0) == 1) {
			$title = Text::sprintf('JPAGETITLE', $app->get('sitename'), $title);
		} elseif ($app->get('sitename_pagetitles', 0) == 2) {
			$title = Text::sprintf('JPAGETITLE', $title, $app->get('sitename'));
		}

		$this->document->setTitle($title);
	}
}
