<?php

/**
 * @version    CVS: 1.2.0
 * @package    Com_Data
 * @author     Mei Chun <qc.yolotech@gmail.com>
 * @copyright  2026 YOLO
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace Data\Component\Data\Site\View\Ncentries;
// No direct access
defined('_JEXEC') or die;

use \Joomla\CMS\MVC\View\HtmlView as BaseHtmlView;
use \Joomla\CMS\Factory;
use \Joomla\CMS\Language\Text;

/**
 * View class for the standalone, frontend, read-only list of NC Data Entry rows.
 *
 * @since  1.2.0
 */
class HtmlView extends BaseHtmlView
{
	protected $items;

	protected $pagination;

	protected $state;

	protected $params;

	public $filterForm;

	public $activeFilters;

	protected $weekStart;

	protected $weekEnd;

	protected $monthStart;

	protected $monthEnd;

	protected $yearStart;

	protected $yearEnd;

	protected $dateFrom;

	protected $dateTo;


	/**
	 * Display the view
	 *
	 * @param   string  $tpl  Template name
	 *
	 * @return void
	 *
	 * @throws \Exception
	 */
	public function display($tpl = null)
	{
		$app = Factory::getApplication();

		$this->state         = $this->get('State');
		$this->items         = $this->get('Items');
		$this->pagination     = $this->get('Pagination');
		$this->params         = $app->getParams('com_data');
		$this->filterForm     = $this->get('FilterForm');
		$this->activeFilters  = $this->get('ActiveFilters');
		$this->weekStart = $this->state->get('filter.weekStart');
		$this->weekEnd   = $this->state->get('filter.weekEnd');
		$this->monthStart = $this->state->get('filter.monthStart');
		$this->monthEnd   = $this->state->get('filter.monthEnd');
		$this->yearStart = $this->state->get('filter.yearStart');
		$this->yearEnd   = $this->state->get('filter.yearEnd');
		$this->dateFrom  = $this->state->get('filter.dateFromObj');
		$this->dateTo      = $this->state->get('filter.dateToObj');
		
		if (count($errors = $this->get('Errors'))) {
			throw new \Exception(implode("\n", $errors));
		}

		$this->_prepareDocument();
		parent::display($tpl);
	}

	/**
	 * Prepares the document title/meta.
	 *
	 * @return void
	 *
	 * @throws \Exception
	 */
	protected function _prepareDocument()
	{
		$app   = Factory::getApplication();
		$menus = $app->getMenu();
		$menu  = $menus->getActive();

		if ($menu) {
			$this->params->def('page_heading', $this->params->get('page_title', $menu->title));
		} else {
			$this->params->def('page_heading', Text::_('COM_DATA_TITLE_NCENTRIES'));
		}

		$title = $this->params->get('page_title', '');

		if (empty($title)) {
			$title = $app->get('sitename');
		} elseif ($app->get('sitename_pagetitles', 0) == 1) {
			$title = Text::sprintf('JPAGETITLE', $app->get('sitename'), $title);
		} elseif ($app->get('sitename_pagetitles', 0) == 2) {
			$title = Text::sprintf('JPAGETITLE', $title, $app->get('sitename'));
		}

		$this->document->setTitle($title);
	}

	/**
	 * Check if state is set
	 *
	 * @param   mixed  $state  State
	 *
	 * @return bool
	 */
	public function getState($state)
	{
		return isset($this->state->{$state}) ? $this->state->{$state} : false;
	}
}
