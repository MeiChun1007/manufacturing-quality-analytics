<?php

/**
 * @version    CVS: 1.2.0
 * @package    Com_Data
 * @author     Mei Chun <qc.yolotech@gmail.com>
 * @copyright  2026 YOLO
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace Data\Component\Data\Site\View\Ncreport;
// No direct access
defined('_JEXEC') or die;

use \Joomla\CMS\MVC\View\HtmlView as BaseHtmlView;
use \Joomla\CMS\Factory;
use \Joomla\CMS\Language\Text;

/**
 * View class for the public weekly NC Report pivot.
 *
 * @since  1.2.0
 */
class HtmlView extends BaseHtmlView
{
	/**
	 * @var  object  { total_sort, total_nc, total_accepted, yield_pct, total_nc_pct }
	 */
	protected $summary;

	/**
	 * @var  object  { dates, rows, day_totals, week_total_nc }
	 */
	protected $pivot;

	/**
	 * @var  array  Distinct models for the Model Selector.
	 */
	protected $modelOptions;

	/**
	 * @var  array  Distinct models for the Model Selector.
	 */
	protected $vendorOptions;

	/**
	 * @var  array  Distinct models for the Model Selector.
	 */
	protected $operatorOptions;

	/**
	 * @var  array  Distinct models for the Model Selector.
	 */
	protected $remarkOptions;

	/** @var int  Selected calendar/ISO year. */
	protected $yearOptions;

	/**
	 * @var  array  Distinct weeks for the Week Selector.
	 */
	protected $weekOptions;

	/** @var array  Distinct parts for the Part Selector. */
	protected $partOptions;

	/** @var array  Distinct lots for the Lot Selector. */
	protected $lotOptions;

	/** @var array  Distinct NC Categories for the NC Categorie Selector. */
	protected $nccategoryOptions;

	/** @var array  Distinct NC Types for the NC Types Selector. */
	protected $nctypeOptions;

	/**
	 * @var  object  { model, week, search, week_start, week_end }
	 */
	protected $activeFilters;

	/**
	 * @var  \Joomla\Registry\Registry
	 */
	protected $params;

	/**
	 * Display the view
	 *
	 * @param   string  $tpl  Template name
	 *
	 * @return void
	 *
	 * @throws Exception
	 */
	public function display($tpl = null)
	{
		$app = Factory::getApplication();

		$this->summary       	 = $this->get('Summary');
		$this->pivot         	 = $this->get('Pivot');
		$this->partOptions  	 = $this->get('PartOptions');
		$this->modelOptions  	 = $this->get('ModelOptions');
		$this->vendorOptions  	 = $this->get('VendorOptions');
		$this->operatorOptions   = $this->get('OperatorOptions');
		$this->nccategoryOptions = $this->get('NCCategoryOptions');
		$this->nctypeOptions  	 = $this->get('NCTypeOptions');
		$this->lotOptions  		 = $this->get('LotOptions');
		$this->remarkOptions  	 = $this->get('RemarkOptions');
		$this->yearOptions  	 = $this->get('YearOptions');
		$this->weekOptions   	 = $this->get('WeekOptions');
		$this->activeFilters 	 = $this->get('ActiveFilters');
		$this->params        	 = $app->getParams('com_data');

		$this->_prepareDocument();

		$this->document = Factory::getApplication()->getDocument();
		$this->document->setTitle('NC Report Weekly');

		parent::display($tpl);
	}

	/**
	 * Prepares the document
	 *
	 * @return void
	 *
	 * @throws Exception
	 */
	protected function _prepareDocument()
	{
		$app   = Factory::getApplication();
		$menus = $app->getMenu();
		$menu  = $menus->getActive();

		if ($menu) {
			$this->params->def('page_heading', $this->params->get('page_title', $menu->title));
		} else {
			$this->params->def('page_heading', Text::_('COM_DATA_TITLE_NCREPORT'));
		}

		$title = $this->params->get('page_title', '');

		if (empty($title)) {
			$title = $app->get('sitename');
		} elseif ($app->get('sitename_pagetitles', 0) == 1) {
			$title = Text::sprintf('JPAGETITLE', $app->get('sitename'), $title);
		} elseif ($app->get('sitename_pagetitles', 0) == 2) {
			$title = Text::sprintf('JPAGETITLE', $title, $app->get('sitename'));
		}

		$this->document->setTitle($title);
	}
}
