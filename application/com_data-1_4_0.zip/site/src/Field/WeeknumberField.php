<?php

/**
 * @version    CVS: 1.0.0
 * @package    Com_Data
 * @author     Mei Chun <qc.yolotech@gmail.com>
 * @copyright  2026 YOLO
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace Data\Component\Data\Site\Field;

defined('JPATH_BASE') or die;

use \Joomla\CMS\Factory;
use \Joomla\CMS\Form\FormField;
use \Joomla\CMS\HTML\HTMLHelper;

/**
 * Custom field to auto-generate and display the ISO-8601 week number
 *
 * @since  1.0.0
 */
class WeeknumberField extends FormField
{
    /**
     * The form field type.
     *
     * @var    string
     */
    protected $type = 'weeknumber';

    /**
     * Method to get the field input markup.
     *
     * @return  string  The field input markup.
     */
    protected function getInput()
    {
        $html = array();
        $dateValue = $this->value;

        // 1. If the value is already a saved week number (between 1 and 53), use it directly
        if (is_numeric($dateValue) && $dateValue > 0 && $dateValue <= 53) {
            // Pad single digits (e.g., turns 9 into 09) to keep formatting clean
            $weekNumber = sprintf('%02d', $dateValue);
        }
        // 2. Otherwise, it's a new entry or a full date string, so calculate the week from the date
        else {
            if (empty($dateValue) || $dateValue == Factory::getDbo()->getNullDate()) {
                $dateValue = Factory::getDate()->toSql();
            }

            $jDate = Factory::getDate($dateValue);
            $weekNumber = $jDate->format('W');
        }

        // Always store the correct week number in the hidden input
        $html[] = '<input type="hidden" name="' . $this->name . '" value="' . $weekNumber . '" />';

        // Display the user-friendly format
        $hidden = (bool) $this->element['hidden'];
        if (!$hidden) {
            $display = "Week " . $weekNumber;
            $html[]  = "<div>" . $display . "</div>";
        }

        return implode('', $html);
    }
}
