<?php

/**
 * @version    CVS: 1.0.0
 * @package    Com_Data
 * @author     Mei Chun <qc.yolotech@gmail.com>
 * @copyright  2026 YOLO
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace Data\Component\Data\Site\Field;

defined('JPATH_BASE') or die;

use \Joomla\CMS\Form\Field\ListField;
use \Joomla\CMS\Factory;
use \Joomla\CMS\Component\ComponentHelper;

/**
 * Vendor dropdown field. Behaves like a normal "sql" list field, but appends
 * a configurable suffix (e.g. "(FOR CALIPER BRMT200L ONLY)") to specific
 * vendor names — both the list of vendor names and the suffix text itself
 * are controlled from the component's Options screen, rather than hardcoded.
 *
 * @since  1.0.0
 */
class VendorField extends ListField
{
	/**
	 * The form field type.
	 *
	 * @var    string
	 * @since  1.0.0
	 */
	protected $type = 'Vendor';

	/**
	 * Method to get the field options.
	 *
	 * @return  array  The field option objects.
	 *
	 * @since   1.0.0
	 */
	protected function getOptions()
	{
		$db    = Factory::getDbo();
		$query = $db->getQuery(true)
			->select($db->quoteName('u.id', 'value'))
			->select($db->quoteName('u.name', 'text'))
			->from($db->quoteName('#__users', 'u'))
			->join('INNER', $db->quoteName('#__user_usergroup_map', 'm') . ' ON ' . $db->quoteName('m.user_id') . ' = ' . $db->quoteName('u.id'))
			->where($db->quoteName('m.group_id') . ' = 11')
			->where($db->quoteName('u.block') . ' = 0')
			->order($db->quoteName('u.id') . ' ASC');

		$db->setQuery($query);
		$rows = $db->loadObjectList();

		// Read the configurable suffix rules from component Options. Each rule
		// is an independent {vendors: [...], suffix_text: "..."} pair, so
		// different vendor groups can carry different suffix notes.
		$params = ComponentHelper::getParams('com_data');
		$rules  = $params->get('vendor_suffix_rules', array());

		// Build a lookup: vendor id => array of matching suffix texts
		$suffixesByVendorId = array();

		foreach ((array) $rules as $rule) {
			$rule = (array) $rule;

			$suffixText = trim((string) ($rule['suffix_text'] ?? ''));

			if ($suffixText === '') {
				continue;
			}

			$vendorIds = array_map('intval', (array) ($rule['vendors'] ?? array()));

			foreach ($vendorIds as $vendorId) {
				$suffixesByVendorId[$vendorId][] = $suffixText;
			}
		}

		$options = parent::getOptions();

		foreach ($rows as $row) {
			$label = $row->text;

			if (!empty($suffixesByVendorId[(int) $row->value])) {
				$label .= ' ' . implode(' ', $suffixesByVendorId[(int) $row->value]);
			}

			$options[] = (object) array(
				'value' => $row->value,
				'text'  => $label,
			);
		}

		return $options;
	}
}