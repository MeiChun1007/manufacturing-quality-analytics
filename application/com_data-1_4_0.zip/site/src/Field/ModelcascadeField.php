<?php

/**
 * @version    CVS: 1.0.0
 * @package    Com_Data
 * @author     Mei Chun <qc.yolotech@gmail.com>
 * @copyright  2026 YOLO
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace Data\Component\Data\Site\Field;

// No direct access
defined('_JEXEC') or die;

use \Joomla\CMS\Form\Field\ListField;
use \Joomla\CMS\Factory;
use \Joomla\CMS\HTML\HTMLHelper;
use \Joomla\Database\DatabaseInterface;

/**
 * Model filter dropdown, scoped to the currently selected Component/Part filter.
 *
 * @since  1.0.0
 */
class ModelcascadeField extends ListField
{
	protected $type = 'Modelcascade';

	protected function getOptions()
	{
		$options = parent::getOptions();

		$app     = Factory::getApplication();
		$context = 'com_data.entries.'; // confirmed to match EntriesModel's context

		$filterComponent = $app->getUserState($context . 'filter.component');

		// filter.component can be a single value or an array (multi-select), same as EntriesModel
		if (is_array($filterComponent)) {
			$filterComponent = array_values(array_filter($filterComponent, function ($v) {
				return $v !== '' && $v !== null;
			}));
		}

		$db = Factory::getContainer()->get(DatabaseInterface::class);

		$query = $db->getQuery(true)
			->select('DISTINCT ' . $db->quoteName('pm.id', 'value') . ', ' . $db->quoteName('pm.model_name', 'text'))
			->from($db->quoteName('#__product_catalogs', 'pm'))
			->where($db->quoteName('pm.state') . ' = 1');

		$hasComponentFilter = (is_array($filterComponent) && count($filterComponent) > 0)
			|| (!is_array($filterComponent) && $filterComponent !== '' && $filterComponent !== null);

		if ($hasComponentFilter) {
			// Both a.component and a.model are single-ID columns (confirmed), so a
			// plain equality join scopes the Model list to only models that have
			// actually appeared together with the selected Component in an entry.
			$query->join(
				'INNER',
				$db->quoteName('#__data_entry', 'a') . ' ON ' . $db->quoteName('a.model') . ' = ' . $db->quoteName('pm.id')
			);

			if (is_array($filterComponent)) {
				$__vals = array_map(function ($v) use ($db) {
					return $db->quote($v);
				}, $filterComponent);

				$query->where($db->quoteName('a.component') . ' IN (' . implode(',', $__vals) . ')');
			} else {
				$query->where($db->quoteName('a.component') . ' = ' . $db->quote($filterComponent));
			}
		}

		$query->order($db->quoteName('pm.model_name') . ' ASC');

		$db->setQuery($query);
		$models = $db->loadObjectList();

		foreach ($models as $model) {
			$options[] = HTMLHelper::_('select.option', $model->value, $model->text);
		}

		return $options;
	}
}