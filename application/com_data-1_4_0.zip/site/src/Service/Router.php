<?php

/**
 * @version    CVS: 1.0.0
 * @package    Com_Data
 * @author     Mei Chun <qc.yolotech@gmail.com>
 * @copyright  2026 YOLO
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace Data\Component\Data\Site\Service;

// No direct access
defined('_JEXEC') or die;

use Joomla\CMS\Component\Router\RouterViewConfiguration;
use Joomla\CMS\Component\Router\RouterView;
use Joomla\CMS\Component\Router\Rules\StandardRules;
use Joomla\CMS\Component\Router\Rules\NomenuRules;
use Joomla\CMS\Component\Router\Rules\MenuRules;
use Joomla\CMS\Factory;
use Joomla\CMS\Categories\Categories;
use Joomla\CMS\Application\SiteApplication;
use Joomla\CMS\Categories\CategoryFactoryInterface;
use Joomla\CMS\Categories\CategoryInterface;
use Joomla\Database\DatabaseInterface;
use Joomla\CMS\Menu\AbstractMenu;
use Joomla\CMS\Component\ComponentHelper;

/**
 * Class DataRouter
 *
 */
class Router extends RouterView
{
	private $noIDs;
	/**
	 * The category factory
	 *
	 * @var    CategoryFactoryInterface
	 *
	 * @since  1.0.0
	 */
	private $categoryFactory;

	/**
	 * The category cache
	 *
	 * @var    array
	 *
	 * @since  1.0.0
	 */
	private $categoryCache = [];

	public function __construct(SiteApplication $app, AbstractMenu $menu, CategoryFactoryInterface $categoryFactory, DatabaseInterface $db)
	{
		$params = ComponentHelper::getParams('com_data');
		$this->noIDs = (bool) $params->get('sef_ids');
		$this->categoryFactory = $categoryFactory;


		$entries = new RouterViewConfiguration('entries');
		$this->registerView($entries);
		$ccEntry = new RouterViewConfiguration('entry');
		$ccEntry->setKey('id')->setParent($entries);
		$this->registerView($ccEntry);
		$entryform = new RouterViewConfiguration('entryform');
		$entryform->setKey('id');
		$this->registerView($entryform);

		$ncentries = new RouterViewConfiguration('ncentries');
		$this->registerView($ncentries);

		$operatorPerformance = new RouterViewConfiguration('operatorperformance');
		$this->registerView($operatorPerformance);

		parent::__construct($app, $menu);

		$this->attachRule(new MenuRules($this));
		$this->attachRule(new StandardRules($this));
		$this->attachRule(new NomenuRules($this));
	}



	/**
	 * Method to get the segment(s) for an entry
	 *
	 * @param   string  $id     ID of the entry to retrieve the segments for
	 * @param   array   $query  The request that is built right now
	 *
	 * @return  array|string  The segments of this item
	 */
	public function getEntrySegment($id, $query)
	{
		return array((int) $id => $id);
	}
	/**
	 * Method to get the segment(s) for an entryform
	 *
	 * @param   string  $id     ID of the entryform to retrieve the segments for
	 * @param   array   $query  The request that is built right now
	 *
	 * @return  array|string  The segments of this item
	 */
	public function getEntryformSegment($id, $query)
	{
		return $this->getEntrySegment($id, $query);
	}


	/**
	 * Method to get the segment(s) for an entry
	 *
	 * @param   string  $segment  Segment of the entry to retrieve the ID for
	 * @param   array   $query    The request that is parsed right now
	 *
	 * @return  mixed   The id of this item or false
	 */
	public function getEntryId($segment, $query)
	{
		return (int) $segment;
	}
	/**
	 * Method to get the segment(s) for an entryform
	 *
	 * @param   string  $segment  Segment of the entryform to retrieve the ID for
	 * @param   array   $query    The request that is parsed right now
	 *
	 * @return  mixed   The id of this item or false
	 */
	public function getEntryformId($segment, $query)
	{
		return $this->getEntryId($segment, $query);
	}

	/**
	 * Method to get categories from cache
	 *
	 * @param   array  $options   The options for retrieving categories
	 *
	 * @return  CategoryInterface  The object containing categories
	 *
	 * @since   1.0.0
	 */
	private function getCategories(array $options = []): CategoryInterface
	{
		$key = serialize($options);

		if (!isset($this->categoryCache[$key])) {
			$this->categoryCache[$key] = $this->categoryFactory->createCategory($options);
		}

		return $this->categoryCache[$key];
	}
}
