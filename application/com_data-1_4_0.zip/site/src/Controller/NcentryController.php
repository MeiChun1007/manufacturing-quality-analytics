<?php

/**
 * @version    CVS: 1.4.0
 * @package    Com_Data
 * @author     Mei Chun <qc.yolotech@gmail.com>
 * @copyright  2026 YOLO
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace Data\Component\Data\Site\Controller;
// No direct access.
defined('_JEXEC') or die;

use \Joomla\CMS\Factory;
use \Joomla\CMS\MVC\Controller\BaseController;
use \Joomla\CMS\Language\Text;
use \Joomla\CMS\Session\Session;
use \Joomla\CMS\Component\ComponentHelper;

/**
 * AJAX controller for NC entry image upload/list (front-end). There is
 * deliberately no delete() task here at all - deletion is admin-only,
 * enforced by this controller simply not exposing a route to do it.
 *
 * @since  1.4.0
 */
class NcentryController extends BaseController
{
	/**
	 * List the images attached to an NC entry row.
	 *
	 * @return  void
	 *
	 * @since   1.4.0
	 */
	public function list()
	{
		$app = Factory::getApplication();

		$ncId = $app->input->getInt('nc_id', 0);

		/** @var \Data\Component\Data\Site\Model\NcentryimageModel $model */
		$model  = $this->getModel('Ncentryimage', 'Site');
		$images = $model->getImages($ncId);

		$this->sendJson(true, array('images' => $images));
	}

	/**
	 * Upload one or more images against an NC entry row.
	 *
	 * @return  void
	 *
	 * @since   1.4.0
	 */
	public function upload()
	{
		$app = Factory::getApplication();

		// A POST that exceeded post_max_size arrives with an empty $_POST/$_FILES
		// but Content-Length still shows the real (oversized) payload - PHP gives
		// no other signal that this happened. Catch it before the CSRF check,
		// which would otherwise report a misleading "invalid token" instead.
		$contentLength = (int) ($_SERVER['CONTENT_LENGTH'] ?? 0);

		if (empty($_POST) && empty($_FILES) && $contentLength > 0) {
			$this->sendJson(false, array(), Text::_('COM_DATA_NCIMAGE_ERROR_PAYLOAD_TOO_LARGE'), 413);

			return;
		}

		if (!$this->checkUploadPermission()) {
			return;
		}

		if (!Session::checkToken('post')) {


			$this->sendJson(false, array(), Text::_('JINVALID_TOKEN'), 403);

			return;
		}

		$ncId = $app->input->getInt('nc_id', 0);
		$files     = $app->input->files->get('images', array(), 'raw');


		/** @var \Data\Component\Data\Site\Model\NcentryimageModel $model */
		$model  = $this->getModel('Ncentryimage', 'Site');
		$result = $model->uploadImages($ncId, $files);

		$this->sendJson(empty($result['errors']), $result);
	}

	/**
	 * Delete a single image. Uses the same permission check as uploading
	 * ('upload_image' group membership, or core.admin) - a Supervisor who
	 * can upload on the front-end can also delete there.
	 *
	 * @return  void
	 *
	 * @since   1.4.0
	 */
	public function delete()
	{
		$app  = Factory::getApplication();

		if (!$this->checkUploadPermission()) {
			return;
		}

		if (!Session::checkToken('post')) {
			$this->sendJson(false, array(), Text::_('JINVALID_TOKEN'), 403);

			return;
		}

		$imageId = $app->input->getInt('image_id', 0);

		/** @var \Data\Component\Data\Site\Model\NcentryimageModel $model */
		$model   = $this->getModel('Ncentryimage', 'Site');
		$deleted = $model->deleteImage($imageId);

		$this->sendJson($deleted, array(), $deleted ? '' : Text::_('COM_DATA_NCIMAGE_ERROR_DELETE_FAILED'));
	}

	/**
	 * Shared permission check - the 'com_data.nc.upload' custom ACL action,
	 * typically granted to the 'Supervisor' group. Guests and any group
	 * without this permission are rejected before any file handling happens.
	 *
	 * @return  boolean
	 *
	 * @since   1.4.0
	 */
	protected function checkUploadPermission()
	{
		$user = Factory::getApplication()->getIdentity();

		if ($user->guest) {
			$this->sendJson(false, array(), Text::_('JGLOBAL_YOU_MUST_LOGIN_FIRST'), 401);

			return false;
		}

		$userGroups    = (array) $user->get('groups');
		$allowedGroups = (array) ComponentHelper::getParams('com_data')->get('upload_image', array());
		$canUploadImages = $user->authorise('core.admin') || !empty(array_intersect($userGroups, $allowedGroups));

		if ($canUploadImages) {
			return true;
		}

		$this->sendJson(false, array(), Text::_('JERROR_ALERTNOAUTHOR'), 403);

		return false;
	}

	/**
	 * Send a JSON response and close the request - this controller never renders HTML.
	 *
	 * @param   boolean  $success     Whether the operation succeeded.
	 * @param   array    $data        Payload to merge into the response.
	 * @param   string   $message     Optional error/status message.
	 * @param   integer  $httpStatus  HTTP status code to send.
	 *
	 * @return  void
	 *
	 * @since   1.4.0
	 */
	protected function sendJson($success, array $data = array(), $message = '', $httpStatus = 200)
	{
		$app = Factory::getApplication();

		if ($httpStatus !== 200) {
			http_response_code($httpStatus);
		}

		$app->setHeader('Content-Type', 'application/json; charset=utf-8', true);
		$app->sendHeaders();

		echo json_encode(
			array_merge(
				array('success' => (bool) $success, 'message' => $message),
				$data
			)
		);

		$app->close();
	}

	/**
	 * AJAX: every NC row for one pivot cell (category + type), for the
	 * currently active month/filters. Responds as JSON.
	 *
	 * @return  void
	 *
	 * @since   1.5.0
	 */
	public function drilldown()
	{
		$app = Factory::getApplication();

		$categoryId = $app->input->getString('category_id', '');
		$typeId     = $app->input->getString('type_id', '');

		/** @var \Data\Component\Data\Site\Model\NcreportmonthlyModel $model */
		$model = $this->getModel('Ncreportmonthly', 'Site');

		// Force populateState() to run first, so it can't overwrite the values below
		$model->getState();

		foreach (array('year', 'month', 'part', 'model', 'vendor', 'lot', 'remark', 'operator') as $name) {
			$model->setState('filter.' . $name, $app->input->getString('filter_' . $name, ''));
		}

		$rows = $model->getDrilldown($categoryId, $typeId);

		$app->setHeader('Content-Type', 'application/json; charset=utf-8', true);
		$app->sendHeaders();
		echo json_encode(array('success' => true, 'rows' => $rows));
		$app->close();
	}

	/**
	 * AJAX: every NC row for one pivot cell (category + type), for the
	 * currently active month/filters. Responds as JSON.
	 *
	 * @return  void
	 *
	 * @since   1.5.0
	 */
	public function drilldownweekly()
	{
		$app = Factory::getApplication();

		$categoryId = $app->input->getString('category_id', '');
		$typeId     = $app->input->getString('type_id', '');

		/** @var \Data\Component\Data\Site\Model\NcreportModel $model */
		$model = $this->getModel('Ncreport', 'Site');

		$model->getState();

		foreach (array('year', 'week', 'part', 'model', 'vendor', 'lot', 'remark', 'operator') as $name) {
			$model->setState('filter.' . $name, $app->input->getString('filter_' . $name, ''));
		}

		$rows = $model->getDrilldown($categoryId, $typeId);

		$app->setHeader('Content-Type', 'application/json; charset=utf-8', true);
		$app->sendHeaders();
		echo json_encode(array('success' => true, 'rows' => $rows));
		$app->close();
	}
}
