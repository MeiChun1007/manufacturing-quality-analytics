<?php

/**
 * @version    CVS: 1.0.0
 * @package    Com_Data
 * @author     Mei Chun <qc.yolotech@gmail.com>
 * @copyright  2026 YOLO
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

// No direct access
defined('_JEXEC') or die;

use \Joomla\CMS\HTML\HTMLHelper;
use \Joomla\CMS\Factory;
use \Joomla\CMS\Uri\Uri;
use \Joomla\CMS\Router\Route;
use \Joomla\CMS\Language\Text;
use \Joomla\CMS\Session\Session;
use Joomla\Utilities\ArrayHelper;
use \Joomla\CMS\Layout\LayoutHelper;

$canEdit = Factory::getApplication()->getIdentity()->authorise('core.edit', 'com_data');

if (!$canEdit && Factory::getApplication()->getIdentity()->authorise('core.edit.own', 'com_data')) {
	$canEdit = Factory::getApplication()->getIdentity()->id == $this->item->created_by;
}
?>

<div class="item_fields">
	<?php if ($this->params->get('show_page_heading')) : ?>
		<div class="page-header">
			<h1> <?php echo $this->escape($this->params->get('page_heading')); ?> </h1>
		</div>
	<?php endif; ?>
	<table class="table">

		<tr>
			<th><?php echo Text::_('COM_DATA_ENTRIES_REFERENCE_NO'); ?></th>
			<td><?php echo $this->item->reference_no; ?></td>
		</tr>

		<tr>
			<th><?php echo Text::_('COM_DATA_FORM_LBL_ENTRY_DATE'); ?></th>
			<td><?php echo $this->item->date; ?></td>
		</tr>

		<tr>
			<th><?php echo Text::_('COM_DATA_FORM_LBL_ENTRY_WEEK'); ?></th>
			<td><?php echo $this->item->week; ?></td>
		</tr>

		<tr>
			<th><?php echo Text::_('COM_DATA_FORM_LBL_ENTRY_OPERATOR'); ?></th>
			<td><?php echo $this->item->operator; ?></td>
		</tr>

		<tr>
			<th><?php echo Text::_('COM_DATA_FORM_LBL_ENTRY_COMPONENT'); ?></th>
			<td><?php echo $this->item->component; ?></td>
		</tr>

		<tr>
			<th><?php echo Text::_('COM_DATA_FORM_LBL_ENTRY_MODEL'); ?></th>
			<td><?php echo $this->item->model; ?></td>
		</tr>

		<tr>
			<th><?php echo Text::_('COM_DATA_FORM_LBL_ENTRY_VENDOR'); ?></th>
			<td><?php echo $this->item->vendor;
				if (!empty($this->item->remark)) {
					echo " (" . $this->item->remark . ")";
				}; ?></td>
		</tr>

		<tr>
			<th><?php echo Text::_('COM_DATA_FORM_LBL_ENTRY_LOT'); ?></th>
			<td><?php echo $this->item->lot; ?><br>
				<?php if (isset($this->item->lot_raw) && $this->item->lot_raw === '1') : ?>
					<?php if (!empty($this->item->resort_nc)) : ?>
						<small class="text-muted"><?php echo $this->escape($this->item->resort_nc); ?></small>
					<?php endif; ?>
				<?php endif; ?>
			</td>
		</tr>

		<tr>
			<th><?php echo Text::_('COM_DATA_FORM_LBL_ENTRY_WORK_ORDER_NO'); ?></th>
			<td><?php echo $this->item->work_order_no; ?></td>
		</tr>

		<tr>
			<th><?php echo Text::_('COM_DATA_FORM_LBL_ENTRY_TOTAL'); ?></th>
			<td><?php echo $this->item->total; ?></td>
		</tr>

		<tr>
			<th><?php echo Text::_('COM_DATA_FORM_LBL_ENTRY_NC_ENTRIES'); ?></th>
			<td>
				<?php if (!empty($this->item->nc_entries)) : ?>
					<table class="table table-sm">
						<thead>
							<tr>
								<th><?php echo Text::_('COM_DATA_FORM_LBL_ENTRY_NC_CATEGORY'); ?></th>
								<th><?php echo Text::_('COM_DATA_FORM_LBL_ENTRY_NC_QUANTITY'); ?></th>
								<th><?php echo Text::_('COM_DATA_FORM_LBL_ENTRY_NC_PERCENTAGE') . "%"; ?></th>
							</tr>
						</thead>
						<tbody>
							<?php $ncQtySum = 0;
							$ncPctSum = 0; ?>
							<?php foreach ($this->item->nc_entries as $ncRow) : ?>
								<?php
								$ncQtySum += (int) $ncRow->nc_quantity;
								$ncPctSum += (float) $ncRow->nc_percentage;
								?>
								<tr>
									<td>
										<?php
										$ncType = $this->escape($ncRow->nc_type);
										$db = JFactory::getDbo();
										$query = $db->getQuery(true);

										$concatenatedFields = $query->concatenate(array(
											$db->quoteName('t.nc'),
											$db->quote(' ['),
											$db->quoteName('c.category'),
											$db->quote(']')
										));

										$query
											->select($concatenatedFields)
											->from($db->quoteName('#__nc_types') . ' AS t')
											->join('LEFT', $db->quoteName('#__nc_category') . ' AS c ON c.id = t.category')
											->where($db->quoteName('t.id') . ' = ' . $db->quote($ncType))
											->where($db->quoteName('t.state') . ' = ' . $db->quote(1));

										$db->setQuery($query);
										echo $expresult = $db->loadResult();
										?>
									</td>
									<td><?php echo $this->escape($ncRow->nc_quantity); ?></td>
									<td><?php echo $this->escape($ncRow->nc_percentage); ?></td>
								</tr>
							<?php endforeach; ?>
						</tbody>
						<tfoot>
							<tr class="total-row">
								<th><?php echo Text::_('Overall NC'); ?></th>
								<th><?php echo number_format($ncQtySum, 0); ?></th>
								<th><?php echo number_format($ncPctSum, 2) . "%"; ?></th>
							</tr>
						</tfoot>
					</table>
				<?php else : ?>
					&#8212;
				<?php endif; ?>
			</td>
		</tr>

		<tr class="total-row">
			<th><?php echo Text::_('Total ACC'); ?></th>
			<td><strong><?php echo number_format((int) $this->item->total - $ncQtySum, 0); ?></strong></td>
		</tr>
		<tr class="total-row">
			<th><?php echo Text::_('ACC Percentage%'); ?></th>
			<td><strong><?php echo number_format(100 - $ncPctSum, 2) . "%"; ?></strong></td>
		</tr>

	</table>

</div>

<div class="button d-flex w-100 mb-3" style="padding-top: 10px; gap:3px">

	<!-- Delete button -->
	<?php if (Factory::getApplication()->getIdentity()->authorise('core.delete', 'com_data.entry.' . $this->item->id)) : ?>

		<a class="btn btn-danger" rel="noopener noreferrer" href="#deleteModal" role="button" data-bs-toggle="modal">
			<i class="fas fa-trash me-1"></i><?php echo Text::_("COM_DATA_DELETE_ITEM"); ?>
		</a>

		<?php echo HTMLHelper::_(
			'bootstrap.renderModal',
			'deleteModal',
			array(
				'title'  => Text::_('COM_DATA_DELETE_ITEM'),
				'height' => '50%',
				'width'  => '20%',
				'modalWidth'  => '50',
				'bodyHeight'  => '100',
				'footer' => '<button class="btn btn-outline-primary" data-bs-dismiss="modal">Close</button><a href="' . Route::_('index.php?option=com_data&task=entry.remove&id=' . $this->item->id, false, 2) . '" class="btn btn-danger">' . Text::_('COM_DATA_DELETE_ITEM') . '</a>'
			),
			Text::sprintf('COM_DATA_DELETE_CONFIRM', $this->item->id)
		); ?>

	<?php endif; ?>

	<!-- Edit button -->
	<?php if ($canEdit): ?>

		<a class="btn btn-outline-primary" href="<?php echo Route::_('index.php?option=com_data&task=entry.edit&id=' . $this->item->id); ?>">
			<i class="fas fa-pen me-1"></i><?php echo Text::_("COM_DATA_EDIT_ITEM"); ?>
		</a>

	<?php endif; ?>

	<!-- Done button -->
	<a class="btn btn-success ms-auto" href="<?php echo Route::_('index.php?option=com_data&view=entries'); ?>">
		<i class="fas fa-check me-1"></i><?php echo Text::_("Done"); ?>
	</a>
</div>