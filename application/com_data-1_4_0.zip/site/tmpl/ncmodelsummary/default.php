<?php

/**
 * @version    CVS: 1.3.0
 * @package    Com_Data
 * @author     Mei Chun <qc.yolotech@gmail.com>
 * @copyright  2026 YOLO
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

// No direct access
defined('_JEXEC') or die;

use \Joomla\CMS\HTML\HTMLHelper;
use \Joomla\CMS\Router\Route;
use \Joomla\CMS\Language\Text;
use Joomla\CMS\Component\ComponentHelper;

HTMLHelper::_('bootstrap.tooltip');

$wa = $this->document->getWebAssetManager();
$wa->useStyle('com_data.list');
$wa->useStyle('com_data.dashboard');
$wa->useStyle('com_data.ncreport');
$wa->useScript('choicesjs');
$wa->useStyle('choicesjs');
$wa->useScript('com_data.ncreport');


$filters = $this->activeFilters;

/**
 * This is an aggregate report, not a row-per-record CRUD list, so it has no
 * add/edit/delete actions here - drill into an individual "Total Data Entry"
 * record from the Entries list to change the underlying data.
 */

// Same NC% thresholds used on the weekly report's hotspot cells, so the two
// reports read consistently. Tune to your actual QC targets.

$params = ComponentHelper::getParams('com_data');

$dangerThreshold = (float) $params->get('danger_ncpct_threshold');
$warningThreshold = (float) $params->get('warning_ncpct_threshold');


$ncPctClass = function ($pct) use ($dangerThreshold, $warningThreshold) {
	if ($pct > $dangerThreshold) {
		return 'text-danger fw-bold';
	}

	if ($pct > $warningThreshold) {
		return 'text-warning-emphasis fw-semibold';
	}

	if ($pct <= $warningThreshold) {
		return 'text-good-emphasis fw-semibold';
	}

	return '';
};

?>

<?php if ($this->params->get('show_page_heading')) : ?>
	<div class="page-header">
		<h1><?php echo $this->escape($this->params->get('page_heading')); ?></h1>
	</div>
<?php endif; ?>

<form action="<?php echo Route::_('index.php?option=com_data&view=ncmodelsummary'); ?>" method="post" name="adminForm" id="adminForm">

	<div class="ncreport-header mb-4">
		<h1 class="ncreport-header__title"><?php echo Text::_('COM_DATA_TITLE_MODELSUMMARY'); ?></h1>
		<p class="ncreport-header__subtitle"><?php echo Text::_('COM_DATA_MODELSUMMARY_SUBTITLE'); ?></p>
		<p class="text-muted">
			<?php echo HTMLHelper::_('date', $filters->period_start, Text::_('DATE_FORMAT_LC4')); ?>
			&ndash;
			<?php echo HTMLHelper::_('date', $filters->period_end, Text::_('DATE_FORMAT_LC4')); ?>
		</p>
	</div>

	<div class="selectors row">
		<div class="selector col-md-4">
			<label><?php echo Text::_('COM_DATA_MODELSUMMARY_PERIOD_TYPE'); ?></label>
			<div class="btn-group d-block" role="group">
				<input type="radio" class="btn-check" name="filter_period_type" id="period_month" value="month"
					<?php echo $filters->period_type === 'month' ? 'checked' : ''; ?> onchange="this.form.submit();">
				<label class="btn btn-period" for="period_month"><?php echo Text::_('COM_DATA_MODELSUMMARY_MONTH'); ?></label>

				<input type="radio" class="btn-check" name="filter_period_type" id="period_week" value="week"
					<?php echo $filters->period_type === 'week' ? 'checked' : ''; ?> onchange="this.form.submit();">
				<label class="btn btn-period" for="period_week"><?php echo Text::_('COM_DATA_MODELSUMMARY_WEEK'); ?></label>

				<input type="radio" class="btn-check" name="filter_period_type" id="period_date" value="custom"
					<?php echo $filters->period_type === 'custom' ? 'checked' : ''; ?> onchange="this.form.submit();">
				<label class="btn btn-period" for="period_date"><?php echo Text::_('COM_DATA_MODELSUMMARY_DATE'); ?></label>
			</div>
		</div>

		<div class="selector col-md-4">
			<?php if ($filters->period_type === 'week') : ?>
				<label for="filter_year"><?php echo Text::_('COM_DATA_MODELSUMMARY_YEAR_SELECTOR'); ?></label>
				<select name="filter_year" id="filter_year" class="form-select" onchange="this.form.submit();">
					<?php foreach ($this->yearOptions as $yearOption) : ?>
						<option value="<?php echo (int) $yearOption; ?>" <?php echo (int) $filters->year === (int) $yearOption ? 'selected="selected"' : ''; ?>>
							<?php echo (int) $yearOption; ?>
						</option>
					<?php endforeach; ?>
				</select>

				<div style="padding-top:10px;">
					<label for="filter_week">
						<?php echo Text::_('COM_DATA_NCREPORT_WEEK_SELECTOR'); ?>
					</label>

					<select name="filter_week" id="filter_week" class="form-select" onchange="this.form.submit();">
						<?php foreach ($this->weekOptions as $weekOption) : ?>
							<option value="<?php echo (string) $weekOption->value; ?>"
								<?php echo (string) $filters->week === (string) $weekOption->value ? 'selected="selected"' : ''; ?>>
								<?php echo $weekOption->value === 'all'
									? $this->escape($weekOption->label)
									: Text::sprintf('COM_DATA_NCREPORT_WEEK_N', $weekOption->value, $weekOption->label); ?>
							</option>
						<?php endforeach; ?>
					</select>
				</div>

			<?php elseif ($filters->period_type === 'month') : ?>
				<label for="filter_year"><?php echo Text::_('COM_DATA_MODELSUMMARY_YEAR_SELECTOR'); ?></label>
				<select name="filter_year" id="filter_year" class="form-select" onchange="this.form.submit();">
					<?php foreach ($this->yearOptions as $yearOption) : ?>
						<option value="<?php echo (int) $yearOption; ?>" <?php echo (int) $filters->year === (int) $yearOption ? 'selected="selected"' : ''; ?>>
							<?php echo (int) $yearOption; ?>
						</option>
					<?php endforeach; ?>
				</select>

				<div style="padding-top:10px;">
					<label for="filter_month">
						<?php echo Text::_('COM_DATA_MODELSUMMARY_MONTH_SELECTOR'); ?>
					</label>

					<select name="filter_month" id="filter_month" class="form-select" onchange="this.form.submit();">
						<?php foreach ($this->monthOptions as $monthOption) : ?>
							<option value="<?php echo $this->escape((string) $monthOption->value); ?>"
								<?php echo (string) $filters->month === (string) $monthOption->value ? 'selected="selected"' : ''; ?>>
								<?php echo $this->escape($monthOption->label); ?>
							</option>
						<?php endforeach; ?>
					</select>
				</div>

			<?php elseif ($filters->period_type === 'custom') : ?>
				<div style="padding-top:10px;">
					<label for="filter_date_from">
						<?php echo Text::_('COM_DATA_DASHBOARD_DATE_FROM'); ?>
					</label>
					<input type="date" name="filter_date_from" id="filter_date_from" class="form-control"
						value="<?php echo $this->escape($filters->date_from); ?>" onchange="this.form.submit();" />
				</div>

				<div style="padding-top:10px;">
					<label for="filter_date_to">
						<?php echo Text::_('COM_DATA_DASHBOARD_DATE_TO'); ?>
					</label>
					<input type="date" name="filter_date_to" id="filter_date_to" class="form-control"
						value="<?php echo $this->escape($filters->date_to); ?>" onchange="this.form.submit();" />
				</div>
			<?php endif; ?>
		</div>
	</div>

	<div id="dashboard-filters">
		<div class="selectors row mb-5">
			<div class="selector col-md-3">
				<label for="filter_part"><?php echo Text::_('COM_DATA_MODELSUMMARY_PART_SELECTOR'); ?></label>
				<select name="filter_part" id="filter_part" class="form-select js-choices" onchange="this.form.submit();">
					<option value=""><?php echo Text::_('COM_DATA_MODELSUMMARY_ALL_PARTS'); ?></option>
					<?php foreach ($this->partOptions as $partOption) : ?>
						<option value="<?php echo $this->escape($partOption->value); ?>" <?php echo (string) $filters->part === (string) $partOption->value ? 'selected="selected"' : ''; ?>>
							<?php echo $this->escape($partOption->text); ?>
						</option>
					<?php endforeach; ?>
				</select>
				<div style="padding-top: 20px" ;>
					<label for="filter_model"><?php echo Text::_('COM_DATA_DASHBOARD_MODEL_SELECTOR'); ?></label>
					<select name="filter_model" id="filter_model" class="form-select js-choices" onchange="this.form.submit();">
						<option value=""><?php echo Text::_('COM_DATA_DASHBOARD_ALL_MODELS'); ?></option>
						<?php foreach ($this->modelOptions as $modelOption) : ?>
							<option value="<?php echo $this->escape($modelOption->value); ?>" <?php echo (string) $filters->model === (string) $modelOption->value ? 'selected="selected"' : ''; ?>>
								<?php echo $this->escape($modelOption->text); ?>
							</option>
						<?php endforeach; ?>
					</select>
				</div>
			</div>

			<div class="selector col-md-3">
				<label for="filter_vendor"><?php echo Text::_('COM_DATA_DASHBOARD_VENDOR_SELECTOR'); ?></label>
				<select name="filter_vendor" id="filter_vendor" class="form-select" onchange="this.form.submit();">
					<option value=""><?php echo Text::_('COM_DATA_DASHBOARD_ALL_VENDORS'); ?></option>
					<?php foreach ($this->vendorOptions as $vendorOption) : ?>
						<option value="<?php echo $this->escape($vendorOption->key); ?>" <?php echo (string) $filters->vendor === (string) $vendorOption->key ? 'selected="selected"' : ''; ?>>
							<?php echo $this->escape($vendorOption->value); ?>
						</option>
					<?php endforeach; ?>
				</select>
				<div style="padding-top: 20px" ;>
					<label for="filter_lot"><?php echo Text::_('COM_DATA_NCREPORT_LOT_SELECTOR'); ?></label>
					<select name="filter_lot" id="filter_lot" class="form-select" onchange="this.form.submit();">
						<option value=""><?php echo Text::_('COM_DATA_NCREPORT_ALL_LOT'); ?></option>
						<?php foreach ($this->lotOptions as $lotOption) : ?>
							<option value="<?php echo $this->escape($lotOption->value); ?>" <?php echo (string) $filters->lot === (string) $lotOption->value ? 'selected="selected"' : ''; ?>>
								<?php echo $this->escape($lotOption->text); ?>
							</option>
						<?php endforeach; ?>
					</select>
				</div>
			</div>

			<div class="selector col-md-3">
				<label for="filter_remark"><?php echo Text::_('COM_DATA_NCREPORT_REMARK_SELECTOR'); ?></label>
				<select name="filter_remark" id="filter_remark" class="form-select" onchange="this.form.submit();">
					<option value=""><?php echo Text::_('COM_DATA_NCREPORT_ALL_REMARKS'); ?></option>
					<?php foreach ($this->remarkOptions as $remarkKey => $remarkLabel) : ?>
						<option value="<?php echo $this->escape($remarkKey); ?>" <?php echo (string) $filters->remark === (string) $remarkKey ? 'selected="selected"' : ''; ?>>
							<?php echo $this->escape($remarkLabel); ?>
						</option>
					<?php endforeach; ?>
				</select>
				<div style="padding-top: 20px" ;>
					<label for="filter_operator"><?php echo Text::_('COM_DATA_NCREPORT_OPERATOR_SELECTOR'); ?></label>
					<select name="filter_operator" id="filter_operator" class="form-select js-choices" onchange="this.form.submit();">
						<option value=""><?php echo Text::_('COM_DATA_NCREPORT_ALL_OPERATORS'); ?></option>
						<?php foreach ($this->operatorOptions as $operatorOption) : ?>
							<option value="<?php echo $this->escape($operatorOption->key); ?>" <?php echo (string) $filters->operator === (string) $operatorOption->key ? 'selected="selected"' : ''; ?>>
								<?php echo $this->escape($operatorOption->value); ?>
							</option>
						<?php endforeach; ?>
					</select>
				</div>
			</div>

			<div class="selector col-md-3">
				<label for="filter_top_limit"><?php echo Text::_('COM_DATA_MODELSUMMARY_TOP_LIMIT'); ?></label>
				<select name="filter_top_limit" id="filter_top_limit" class="form-select" onchange="this.form.submit();">
					<?php foreach (array(3, 5, 10, 15, 20) as $n) : ?>
						<option value="<?php echo $n; ?>" <?php echo (int) $filters->top_limit === $n ? 'selected="selected"' : ''; ?>>
							<?php echo Text::sprintf('COM_DATA_MODELSUMMARY_TOP_N', $n); ?>
						</option>
					<?php endforeach; ?>
				</select>
			</div>
		</div>

		<div class="row mb-3">
			<div class="col-md-12 text-end">
				<button type="button" id="btn-clear-filters" class="btn btn-link btn-sm text-muted">
					<span class="icon-undo" aria-hidden="true"></span>
					<?php echo Text::_('COM_DATA_NCREPORT_CLEAR_FILTERS'); ?>
				</button>
			</div>
		</div>
	</div>


	<div class="filter-toggle-row">
		<div class="filter-toggle-title text-muted">
			<span id="filter-toggle-text">Less Filters</span>
		</div>

		<button type="button"
			id="btn-toggle-filters"
			class="filter-toggle-btn"
			aria-expanded="true"
			aria-controls="dashboard-filters">
			<span id="filter-toggle-icon" class="icon-chevron-up" aria-hidden="true"></span>
		</button>
	</div>


	<!-- Top N leaderboard -->
	<div class="nc-leaderboard mb-5">
		<h5><?php echo Text::sprintf('COM_DATA_MODELSUMMARY_TOP5_TITLE', $filters->top_limit); ?>

			<?php if ($filters->period_type === 'week') : ?>
				<?php echo "(Week " . $filters->week . ")"; ?>
			<?php else : ?>
				<?php
				$monthDate = new \DateTime();
				$monthDate->setDate((int) $filters->year, (int) $filters->month, 1);
				?>
				<?php echo "(" . $monthDate->format('F') . ")"; ?>
			<?php endif; ?>

		</h5>


		<div class="nc-leaderboard__grid">
			<?php foreach ($this->topNc as $rank => $row) : ?>
				<div class="card text-center">
					<div class="card-body">
						<div class="badge bg-secondary mb-1">#<?php echo $rank + 1; ?></div>
						<div class="fw-semibold"><?php echo $this->escape($row->model); ?></div>
						<div class="text-muted small"><?php echo $this->escape($row->part); ?></div>
						<div class="text-muted small">
							<?php echo $this->escape($row->vendor); ?>
							<?php if (!empty($row->remark_label)) : ?>
								<?php echo " (" . $this->escape($row->remark_label) . ")"; ?>
							<?php endif; ?>
						</div>
						<div class="fs-4 <?php echo $ncPctClass($row->nc_pct); ?>">
							<?php echo number_format($row->nc_pct, 1); ?>%
						</div>
						<div class="text-muted small">
							<?php echo Text::sprintf('COM_DATA_MODELSUMMARY_TOP_CARD_HINT', (int) $row->ttl_nc, (int) $row->ttl_sort); ?>
						</div>
					</div>
				</div>
			<?php endforeach; ?>
		</div>
	</div>

	<!-- Full summary table -->
	<?php if (empty($this->summaryRows)) : ?>
		<div class="alert alert-info">
			<?php echo Text::_('COM_DATA_MODELSUMMARY_EMPTY'); ?>
		</div>
	<?php else : ?>
		<div class="table-responsive">
			<table class="table table-bordered table-striped" id="modelSummaryList">
				<thead>
					<tr class="title">
						<th><?php echo Text::_('COM_DATA_MODELSUMMARY_LAST_UPDATE'); ?></th>
						<th><?php echo Text::_('COM_DATA_MODELSUMMARY_PART'); ?></th>
						<th><?php echo Text::_('COM_DATA_MODELSUMMARY_MODEL'); ?></th>
						<th><?php echo Text::_('COM_DATA_MODELSUMMARY_VENDOR'); ?></th>
						<th><?php echo Text::_('COM_DATA_MODELSUMMARY_REMARK'); ?></th>
						<th class="text-center"><?php echo Text::_('COM_DATA_MODELSUMMARY_TTL_SORTING'); ?></th>
						<th class="text-center"><?php echo Text::_('COM_DATA_MODELSUMMARY_TTL_ACC'); ?></th>
						<th class="text-center"><?php echo Text::_('COM_DATA_MODELSUMMARY_ACC_PCT'); ?></th>
						<th class="text-center"><?php echo Text::_('COM_DATA_MODELSUMMARY_TTL_NC'); ?></th>
						<th class="text-center"><?php echo Text::_('COM_DATA_MODELSUMMARY_NC_PCT'); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ($this->summaryRows as $row) : ?>
						<tr>
							<td><?php echo (new \DateTime($row->last_update))->format('Y-m-d'); ?></td>
							<td><?php echo $this->escape($row->part); ?></td>
							<td><?php echo $this->escape($row->model); ?></td>
							<td>
								<?php echo $this->escape($row->vendor); ?>
								<?php if (!empty($row->remark_label)) : ?>
									<?php echo " (" . $this->escape($row->remark_label) . ")"; ?>
								<?php endif; ?>
							</td>
							<td>
								<?php echo $this->escape($row->lot_label); ?>
								<?php if ($row->lot == 1) : ?>
									<br><small class="text-muted"><?php echo $this->escape($row->resort_nc); ?></small>
								<?php endif; ?>
							</td>
							<td class="text-center"><?php echo (int) $row->ttl_sort; ?></td>
							<td class="text-center"><?php echo (int) $row->ttl_acc; ?></td>
							<td class="text-center"><?php echo number_format($row->acc_pct, 1); ?>%</td>
							<td class="text-center"><?php echo (int) $row->ttl_nc; ?></td>
							<td class="text-center <?php echo $ncPctClass($row->nc_pct); ?>"><?php echo number_format($row->nc_pct, 1); ?>%</td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		</div>
	<?php endif; ?>

	<input type="hidden" name="clearfilters" id="clearfilters" value="0" />
	<input type="hidden" name="task" value="" />
	<?php echo HTMLHelper::_('form.token'); ?>
</form>