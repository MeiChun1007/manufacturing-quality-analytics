<?php

/**
 * @version    CVS: 1.3.0
 * @package    Com_Data
 * @author     Mei Chun <qc.yolotech@gmail.com>
 * @copyright  2026 YOLO
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

// No direct access
defined('_JEXEC') or die;

use \Joomla\CMS\HTML\HTMLHelper;
use \Joomla\CMS\Router\Route;
use \Joomla\CMS\Language\Text;
use Joomla\CMS\Component\ComponentHelper;

HTMLHelper::_('bootstrap.tooltip');

$wa = $this->document->getWebAssetManager();
$wa->useStyle('com_data.list');
$wa->useScript('choicesjs');
$wa->useStyle('choicesjs');
$wa->useScript('com_data.ncreport');

$filters = $this->activeFilters;
$pivot   = $this->pivot;

/**
 * This is a pivot/aggregate report, not a row-per-record CRUD list, so it
 * has no add/edit/delete actions here.
 *
 * Cell shading uses the SAME >=5% / >=2% thresholds as the weekly NC Report
 * and Model Summary's leaderboard, so all three reports read consistently.
 * Tune these to your actual QC targets if they ever change.
 */

$params = ComponentHelper::getParams('com_data');

$dangerThreshold = (float) $params->get('danger_ncpct_threshold');
$warningThreshold = (float) $params->get('warning_ncpct_threshold');

$ncPctCellClass = function ($pct) use ($dangerThreshold, $warningThreshold) {
	if ($pct === null) {
		return '';
	}

	if ($pct > $dangerThreshold) {
		return 'nc-cell-danger';
	}

	if ($pct > $warningThreshold) {
		return 'nc-cell-warning';
	}

	if ($pct <= $warningThreshold) {
		return 'nc-cell-good';
	}

	return '';
};

?>

<?php if ($this->params->get('show_page_heading')) : ?>
	<div class="page-header">
		<h1><?php echo $this->escape($this->params->get('page_heading')); ?></h1>
	</div>
<?php endif; ?>

<form action="<?php echo Route::_('index.php?option=com_data&view=ncdailysummary'); ?>" method="post" name="adminForm" id="adminForm">

	<div class="ncreport-header mb-4">
		<h1 class="ncreport-header__title"><?php echo Text::_('COM_DATA_TITLE_NCDAILYSUMMARY'); ?></h1>
		<p class="ncreport-header__subtitle"><?php echo Text::_('COM_DATA_NCDAILYSUMMARY_SUBTITLE'); ?></p>
		<p class="text-muted">
			<?php echo HTMLHelper::_('date', $filters->week_start, Text::_('DATE_FORMAT_LC4')); ?>
			&ndash;
			<?php echo HTMLHelper::_('date', $filters->week_end, Text::_('DATE_FORMAT_LC4')); ?>
		</p>
	</div>

	<div class="selectors row mb-3">
		<div class="selector col-md-4">
			<label for="filter_year"><?php echo Text::_('COM_DATA_NCREPORT_YEAR_SELECTOR'); ?></label>
			<select name="filter_year" id="filter_year" class="form-select" onchange="this.form.submit();">
				<?php foreach ($this->yearOptions as $yearOption) : ?>
					<option value="<?php echo (int) $yearOption; ?>" <?php echo (int) $filters->year === (int) $yearOption ? 'selected="selected"' : ''; ?>>
						<?php echo (int) $yearOption; ?>
					</option>
				<?php endforeach; ?>
			</select>
			<div style="padding-top: 20px" ;>
				<label for="filter_week"><?php echo Text::_('COM_DATA_NCREPORT_WEEK_SELECTOR'); ?></label>
				<select name="filter_week" id="filter_week" class="form-select" onchange="this.form.submit();">
					<?php foreach ($this->weekOptions as $weekOption) : ?>
						<option value="<?php echo (int) $weekOption->value; ?>" <?php echo (int) $filters->week === (int) $weekOption->value ? 'selected="selected"' : ''; ?>>
							<?php echo Text::sprintf('COM_DATA_NCREPORT_WEEK_N', $weekOption->value, $weekOption->label); ?>
						</option>
					<?php endforeach; ?>
				</select>
			</div>
		</div>
		<div class="selector col-md-4">
			<label for="filter_part"><?php echo Text::_('COM_DATA_MODELSUMMARY_PART_SELECTOR'); ?></label>
			<select name="filter_part" id="filter_part" class="form-select js-choices" onchange="this.form.submit();">
				<option value=""><?php echo Text::_('COM_DATA_MODELSUMMARY_ALL_PARTS'); ?></option>
				<?php foreach ($this->partOptions as $partOption) : ?>
					<option value="<?php echo $this->escape($partOption->value); ?>" <?php echo (string) $filters->part === (string) $partOption->value ? 'selected="selected"' : ''; ?>>
						<?php echo $this->escape($partOption->text); ?>
					</option>
				<?php endforeach; ?>
			</select>
			<div style="padding-top: 20px" ;>
				<label for="filter_model"><?php echo Text::_('COM_DATA_NCREPORT_MODEL_SELECTOR'); ?></label>
				<select name="filter_model" id="filter_model" class="form-select js-choices" onchange="this.form.submit();">
					<option value=""><?php echo Text::_('COM_DATA_NCREPORT_ALL_MODELS'); ?></option>
					<?php foreach ($this->modelOptions as $modelOption) : ?>
						<option value="<?php echo $this->escape($modelOption->value); ?>" <?php echo (string) $filters->model === (string) $modelOption->value ? 'selected="selected"' : ''; ?>>
							<?php echo $this->escape($modelOption->text); ?>
						</option>
					<?php endforeach; ?>
				</select>
			</div>
		</div>
		<div class="selector col-md-4">
			<label for="filter_vendor"><?php echo Text::_('COM_DATA_NCREPORT_VENDOR_SELECTOR'); ?></label>
			<select name="filter_vendor" id="filter_vendor" class="form-select" onchange="this.form.submit();">
				<option value=""><?php echo Text::_('COM_DATA_NCREPORT_ALL_VENDORS'); ?></option>
				<?php foreach ($this->vendorOptions as $vendorOption) : ?>
					<option value="<?php echo $this->escape($vendorOption->key); ?>" <?php echo (string) $filters->vendor === (string) $vendorOption->key ? 'selected="selected"' : ''; ?>>
						<?php echo $this->escape($vendorOption->value); ?>
					</option>
				<?php endforeach; ?>
			</select>
			<div style="padding-top: 20px" ;>
				<label for="filter_lot"><?php echo Text::_('COM_DATA_NCREPORT_REMARK_SELECTOR'); ?></label>
				<select name="filter_lot" id="filter_lot" class="form-select" onchange="this.form.submit();">
					<option value=""><?php echo Text::_('COM_DATA_NCREPORT_ALL_REMARK'); ?></option>
					<?php foreach ($this->lotOptions as $lotKey => $lotLabel) : ?>
						<option value="<?php echo $this->escape($lotKey); ?>" <?php echo (string) $filters->lot === (string) $lotKey ? 'selected="selected"' : ''; ?>>
							<?php echo $this->escape($lotLabel); ?>
						</option>
					<?php endforeach; ?>
				</select>
			</div>
		</div>
	</div>

	<div class="row mb-3">
		<div class="col-md-12 text-end">
			<button type="button" id="btn-clear-filters" class="btn btn-link btn-sm text-muted">
				<span class="icon-undo" aria-hidden="true"></span>
				<?php echo Text::_('COM_DATA_NCREPORT_CLEAR_FILTERS'); ?>
			</button>
		</div>
	</div>

	<?php if (empty($pivot->rows)) : ?>
		<div class="alert alert-info">
			<?php echo Text::_('COM_DATA_NCDAILYSUMMARY_EMPTY'); ?>
		</div>
	<?php else : ?>
		<div class="table-responsive">
			<table class="table table-bordered table-striped" id="ncDailySummaryList">
				<thead>
					<tr class="title">
						<th><?php echo Text::_('COM_DATA_MODELSUMMARY_PART'); ?></th>
						<th><?php echo Text::_('COM_DATA_MODELSUMMARY_MODEL'); ?></th>
						<th><?php echo Text::_('COM_DATA_NCDAILYSUMMARY_VENDOR'); ?></th>
						<th><?php echo Text::_('COM_DATA_NCDAILYSUMMARY_REMARK'); ?></th>
						<?php foreach ($pivot->dates as $date) : ?>
							<th class="text-center"><?php echo strtoupper(HTMLHelper::_('date', $date, 'd/n/Y')); ?></th>
						<?php endforeach; ?>
					</tr>
				</thead>
				<tbody>
					<?php foreach ($pivot->rows as $row) : ?>
						<tr>
							<td><?php echo $this->escape($row->part); ?></td>
							<td><?php echo $this->escape($row->model); ?></td>
							<td>
								<?php echo $this->escape($row->vendor); ?>
								<?php if (!empty($row->remark_label)) : ?>
									<?php echo "(" . $this->escape($row->remark_label) . ")"; ?>
								<?php endif; ?>
							</td>
							<td>
								<?php echo $this->escape($row->lot_label); ?>
								<?php if (!empty($row->resort_nc)) : ?><br>
									<?php echo "(" . $this->escape($row->resort_nc) . ")"; ?>
								<?php endif; ?>
							</td>
							<?php foreach ($pivot->dates as $date) : ?>
								<?php $pct = $row->by_date_pct[$date]; ?>
								<td class="text-center <?php echo $ncPctCellClass($pct); ?>">
									<?php echo $pct === null ? '' : number_format($pct, 2) . "%"; ?>
								</td>
							<?php endforeach; ?>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		</div>
	<?php endif; ?>

	<input type="hidden" name="clearfilters" id="clearfilters" value="0" />
	<input type="hidden" name="task" value="" />
	<?php echo HTMLHelper::_('form.token'); ?>
</form>