<?php

/**
 * @version    CVS: 1.0.0
 * @package    Com_Data
 * @author     Mei Chun <qc.yolotech@gmail.com>
 * @copyright  2026 YOLO
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */
// No direct access
defined('_JEXEC') or die;

use \Joomla\CMS\HTML\HTMLHelper;
use \Joomla\CMS\Factory;
use \Joomla\CMS\Uri\Uri;
use \Joomla\CMS\Router\Route;
use \Joomla\CMS\Language\Text;
use \Joomla\CMS\Layout\LayoutHelper;
use \Joomla\CMS\Session\Session;
use \Joomla\CMS\User\UserFactoryInterface;
use Joomla\CMS\Component\ComponentHelper;

HTMLHelper::_('bootstrap.tooltip');
HTMLHelper::_('behavior.multiselect');

$user       = Factory::getApplication()->getIdentity();
$userId     = $user->get('id');
$listOrder  = $this->state->get('list.ordering');
$listDirn   = $this->state->get('list.direction');
$canCreate  = $user->authorise('core.create', 'com_data') && file_exists(JPATH_COMPONENT . DIRECTORY_SEPARATOR . 'forms' . DIRECTORY_SEPARATOR . 'entryform.xml');
$canEdit    = $user->authorise('core.edit', 'com_data') && file_exists(JPATH_COMPONENT .  DIRECTORY_SEPARATOR . 'forms' . DIRECTORY_SEPARATOR . 'entryform.xml');
$canCheckin = $user->authorise('core.manage', 'com_data');
$canChange  = $user->authorise('core.edit.state', 'com_data');
$canDelete  = $user->authorise('core.delete', 'com_data');

// Import CSS
$wa = $this->document->getWebAssetManager();
$wa->useStyle('com_data.list');

// Get current user details
$user     = JFactory::getUser();
$userId   = (int) $user->get('id');
$userGrps = $user->get('groups');

// Get com_data configuration
$params = ComponentHelper::getParams('com_data');

// Get configured groups
$editGroups   = (array) $params->get('canEdit', []);
$deleteGroups = (array) $params->get('canDelete', []);
$exportGroups = (array) $params->get('canExport', []);
$editOwnGroups = (array) $params->get('canEditOwn', []);

// Convert group IDs to integers
$editGroups    = array_map('intval', $editGroups);
$editOwnGroups = array_map('intval', $editOwnGroups);
$deleteGroups  = array_map('intval', $deleteGroups);
$exportGroups  = array_map('intval', $exportGroups);

// User's group IDs
$userGroupIds = array_map('intval', array_keys($userGrps));

// Super User is determined by Joomla ACL, not hardcoded group ID
$isSuperUser = $user->authorise('core.admin');

// Check configured permissions
$canEditGroup    = !empty(array_intersect($userGroupIds, $editGroups));
$canEditOwnGroup = !empty(array_intersect($userGroupIds, $editOwnGroups));
$canDeleteGroup  = !empty(array_intersect($userGroupIds, $deleteGroups));
$canExportGroup  = !empty(array_intersect($userGroupIds, $exportGroups));

// Initialize action flags
$canEdit   = false;
$canDelete = false;
$canExport = false;
?>

<?php if ($this->params->get('show_page_heading')) : ?>
	<div class="page-header">
		<h1> <?php echo $this->escape($this->params->get('page_heading')); ?> </h1>
	</div>
<?php endif; ?>

<?php
$userFullname  = $user->get('name');
?>
<div class="welcome-banner">
	<i class="fas fa-user-circle welcome-icon"></i>
	<span class="welcome-text">Welcome, <strong><?php echo $userFullname; ?></strong>!</span>
</div>


<form action="<?php echo htmlspecialchars(Uri::getInstance()->toString()); ?>" method="post"
	name="adminForm" id="adminForm">
	<div class="ncentries-header mb-4">
		<h1 class="header__title"><?php echo Text::_('COM_DATA_TITLE_LIST_VIEW_ENTRIES'); ?></h1>
		<p class="header__subtitle"><?php echo Text::_('COM_DATA_TITLE_LIST_VIEW_ENTRIES_DESC'); ?></p>
		<?php
		$displayStart = null;
		$displayEnd   = null;

		// Resolve start: explicit dateFrom wins, else fall back through week → month → year
		if (!empty($this->dateFrom)) {
			$displayStart = $this->dateFrom;
		} elseif (!empty($this->weekStart)) {
			$displayStart = $this->weekStart;
		} elseif (!empty($this->monthStart)) {
			$displayStart = $this->monthStart;
		} elseif (!empty($this->yearStart)) {
			$displayStart = $this->yearStart;
		}

		// Resolve end: explicit dateTo wins, else fall back through week → month → year
		if (!empty($this->dateTo)) {
			$displayEnd = $this->dateTo;
		} elseif (!empty($this->weekEnd)) {
			$displayEnd = $this->weekEnd;
		} elseif (!empty($this->monthEnd)) {
			$displayEnd = $this->monthEnd;
		} elseif (!empty($this->yearEnd)) {
			$displayEnd = $this->yearEnd;
		}
		?>

		<?php if (!empty($displayStart) || !empty($displayEnd)): ?>
			<div class="text-muted">
				<?php echo !empty($displayStart) ? $displayStart->format('Y-m-d') : Text::_('COM_DATA_DATE_FROM_BEGINNING'); ?>
				&ndash;
				<?php echo !empty($displayEnd) ? $displayEnd->format('Y-m-d') : Text::_('COM_DATA_DATE_TO_PRESENT'); ?>
			</div>
		<?php endif; ?>
	</div>
	<?php if (!empty($this->filterForm)) {
		echo LayoutHelper::render('joomla.searchtools.default', array('view' => $this));
	} ?>
	<div class="button d-flex justify-content-end w-100 mb-3 " style="padding: 10px 28px; gap: 8px" ;>
		<?php if ($isSuperUser || $canExportGroup) : ?>
			<a href="#" class="btn btn-primary btn-small button-export">
				<i class="icon-download"></i>
				<?php echo Text::_('COM_DATA_DASHBOARD_EXPORT_REPORT'); ?>
			</a>
		<?php endif; ?>

		<?php if ($canCreate) : ?>
			<a href="<?php echo Route::_('index.php?option=com_data&task=entryform.edit&id=0', false, 0); ?>"
				class="btn btn-success btn-small"><i
					class="icon-plus"></i>
				<?php echo Text::_('COM_DATA_ADD_ITEM'); ?></a>
		<?php endif; ?>

	</div>
	<div class="table-responsive">
		<table class="table table-striped" id="entryList">
			<thead>
				<tr>

					<th class=''>
						<?php echo HTMLHelper::_('grid.sort',  'COM_DATA_ENTRIES_REFERENCE_NO', 'a.id', $listDirn, $listOrder); ?>
					</th>

					<th class="center">
						<?php echo Text::_('COM_DATA_ENTRIES_ACTIONS'); ?>
					</th>

					<th class=''>
						<?php echo HTMLHelper::_('grid.sort',  'COM_DATA_ENTRIES_COMPONENT', 'a.component', $listDirn, $listOrder); ?>
					</th>

					<th class=''>
						<?php echo HTMLHelper::_('grid.sort',  'COM_DATA_ENTRIES_MODEL', 'a.model', $listDirn, $listOrder); ?>
					</th>

					<th class=''>
						<?php echo HTMLHelper::_('grid.sort',  'COM_DATA_ENTRIES_VENDOR', 'a.vendor', $listDirn, $listOrder); ?>
					</th>

					<th class=''>
						<?php echo HTMLHelper::_('grid.sort',  'COM_DATA_FORM_LBL_ENTRY_LOT', 'a.lot', $listDirn, $listOrder); ?>
					</th>

					<th class=''>
						<?php echo HTMLHelper::_('grid.sort',  'COM_DATA_ENTRIES_OPERATOR', 'a.operator', $listDirn, $listOrder); ?>
					</th>

					<th class=''>
						<?php echo HTMLHelper::_('grid.sort',  'COM_DATA_ENTRIES_TOTAL', 'a.total', $listDirn, $listOrder); ?>
					</th>

					<th class=''>
						<?php echo HTMLHelper::_('grid.sort',  'COM_DATA_ENTRIES_NC_QUANTITY_TOTAL', 'nc_quantity_total', $listDirn, $listOrder); ?>
					</th>

				</tr>
			</thead>
			<tfoot>
				<tr>
					<td colspan="<?php echo isset($this->items[0]) ? count(get_object_vars($this->items[0])) : 10; ?>">
						<div class="pagination">
							<?php echo $this->pagination->getPagesLinks(); ?>
						</div>
					</td>
				</tr>
			</tfoot>
			<tbody>
				<?php
				$sumTotal = 0;
				$sumNcQtyTotal = 0;

				foreach ($this->items as $item) {
					$sumTotal += (float) $item->total;
					$sumNcQtyTotal += (float) $item->nc_quantity_total;
				}
				?>
				<?php foreach ($this->items as $i => $item) : ?>
					<?php $canEdit = $user->authorise('core.edit', 'com_data'); ?>
					<?php if (!$canEdit && $user->authorise('core.edit.own', 'com_data')): ?>
						<?php $canEdit = Factory::getApplication()->getIdentity()->id == $item->created_by; ?>
					<?php endif; ?>

					<tr class="row<?php echo $i % 2; ?>">

						<td>
							<!-- <?php echo $item->id; ?> -->
							<strong><?php echo $item->reference_no; ?></strong> <br><br>
							<?php echo "Week " . $item->week; ?> <br>
							<?php $date = new DateTime($item->date);
							echo $date->format('Y-m-d H:i'); ?>

						</td>

						<td class="center">
							<div style="display: flex; flex-direction: column; align-items: center; gap: 6px;">
								<!-- VIEW BUTTON (Eye Icon) -->
								<a href="<?php echo Route::_('index.php?option=com_data&view=ncentries&entry_id=' . (int)$item->id); ?>"
									class="btn btn-mini"
									type="button">
									<i class="icon-eye"></i>
								</a>
								<?php
								$canEdit   = false;
								$canDelete = false;

								if ($isSuperUser) {

									$canEdit   = true;
									$canDelete = true;
								} else {

									// Can edit any record
									if ($canEditGroup) {
										$canEdit = true;
									}

									// Can edit own/operator record only
									if ($canEditOwnGroup && $userId === (int) $item->operator) {
										$canEdit = true;
									}

									// Can delete
									if ($canDeleteGroup) {
										$canDelete = true;
									}
								}
								?>
								<?php if ($canEdit || $canDelete): ?>
									<?php if ($canEdit):
									?>
										<a href="<?php echo Route::_('index.php?option=com_data&task=entry.edit&id=' . $item->id, false, 2); ?>" class="btn btn-mini" type="button"><i class="icon-edit"></i></a>
									<?php endif;
									?>
									<?php if ($canDelete): ?>
										<a href="<?php echo Route::_('index.php?option=com_data&task=entryform.remove&id=' . $item->id, false, 2); ?>" class="btn btn-mini delete-button" type="button"><i class="icon-trash"></i></a>
									<?php endif; ?>
								<?php endif; ?>
							</div>
						</td>

						<td>
							<?php echo $item->component; ?>
						</td>
						<td>
							<?php echo $item->model; ?>
						</td>
						<td>
							<?php echo $item->vendor;

							if ($item->remark) {
								echo "(" . $item->remark . ")";
							}; ?>
						</td>
						<td>
							<?php echo $item->lot; ?><br>
							<?php if (isset($item->lot_raw) && $item->lot_raw === '1') : ?>
								<?php if (!empty($item->resort_nc)) : ?>
									<small class="text-muted"><?php echo $this->escape($item->resort_nc); ?></small>
								<?php endif; ?>
							<?php endif; ?>
						</td>
						<td>
							<?php $container = \Joomla\CMS\Factory::getContainer();
							$userFactory = $container->get(UserFactoryInterface::class); ?>
							<?php $user = $userFactory->loadUserById($item->operator); ?>
							<?php echo $user->name; ?>
						</td>
						<td>
							<?php echo $item->total; ?>
						</td>
						<td>
							<?php echo ((int) $item->nc_quantity_total !== null ? (int) $item->nc_quantity_total : 0); ?>
							<?php echo "(" . (int) $item->nc_entry_count . " NC)"; ?>
						</td>
					</tr>
				<?php endforeach; ?>
			</tbody>
			<tfoot>
				<tr class="total-row">
					<th colspan="7" style="text-align:right;"><?php echo Text::_('Overall Total: '); ?></th>
					<th><?php echo number_format($sumTotal, 0); ?></th>
					<th><?php echo number_format($sumNcQtyTotal, 0); ?></th>
				</tr>



			</tfoot>
		</table>
	</div>
	</table>
	</div>

	<?php
	// Distinct years that actually exist in the data, newest first
	$db    = Factory::getDbo();
	$query = $db->getQuery(true)
		->select('DISTINCT YEAR(' . $db->quoteName('date') . ') AS year')
		->from($db->quoteName('#__data_entry'))
		->where($db->quoteName('date') . ' IS NOT NULL')
		->order('year DESC');
	$db->setQuery($query);
	$existingYears = $db->loadColumn() ?: array();

	// Fallback so the dropdown isn't empty on a brand new install with no entries yet
	if (empty($existingYears)) {
		$existingYears = array((int) Factory::getDate()->format('Y'));
	}
	?>

	<div id="ExportReportModal" class="modal" tabindex="-1" role="dialog">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header"
					style="position: static; text-align: center; display: flex; justify-content: center; align-items: center;">
					<h5 class="modal-title">Select Month & Year</h5>
				</div>
				<div class="modal-body"
					style="display: flex; justify-content: center; align-items: center; flex-direction: column; padding: 20px; gap: 15px;">

					<div class="form-group" style="width: 100%; max-width: 300px; text-align: center;">
						<label for="ExportMonth" style="margin-bottom: 8px; display: block;">Month:</label>
						<select id="ExportMonth" name="month" class="form-control"
							style="width: 100%; padding: 8px; font-size: 16px; text-align: center; border: 1px solid #ccc; border-radius: 4px;">
							<option value="">All Months</option>
							<?php
							$monthNames = array(
								1 => 'January',
								2 => 'February',
								3 => 'March',
								4 => 'April',
								5 => 'May',
								6 => 'June',
								7 => 'July',
								8 => 'August',
								9 => 'September',
								10 => 'October',
								11 => 'November',
								12 => 'December',
							);
							$currentMonth = (int) Factory::getDate()->format('n');

							foreach ($monthNames as $num => $label) :
							?>
								<option value="<?php echo $num; ?>" <?php echo ($num === $currentMonth) ? 'selected' : ''; ?>>
									<?php echo $label; ?>
								</option>
							<?php endforeach; ?>
						</select>
					</div>

					<div class="form-group" style="width: 100%; max-width: 300px; text-align: center;">
						<label for="ExportYear" style="margin-bottom: 8px; display: block;">Year:</label>
						<select id="ExportYear" name="year" class="form-control"
							style="width: 100%; padding: 8px; font-size: 16px; text-align: center; border: 1px solid #ccc; border-radius: 4px;">
							<?php foreach ($existingYears as $y) : ?>
								<option value="<?php echo (int) $y; ?>"><?php echo (int) $y; ?></option>
							<?php endforeach; ?>
						</select>
					</div>

				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-primary" onclick="exportReport()">Export</button>
					<button type="button" class="btn btn-secondary" onclick="closeExportReportModal()">Close</button>
				</div>
			</div>
		</div>
	</div>

	<input type="hidden" name="task" value="" />
	<input type="hidden" name="boxchecked" value="0" />
	<input type="hidden" name="filter_order" value="" />
	<input type="hidden" name="filter_order_Dir" value="" />
	<?php echo HTMLHelper::_('form.token'); ?>
</form>

<?php
if ($canDelete) {
	$wa->addInlineScript("
			jQuery(document).ready(function () {
				jQuery('.delete-button').click(deleteItem);
			});

			function deleteItem() {

				if (!confirm(\"" . Text::_('COM_DATA_DELETE_MESSAGE') . "\")) {
					return false;
				}
			}
		", [], [], ["jquery"]);
}
?>

<script>
	document.addEventListener('DOMContentLoaded', function() {
		// Adjust the breakpoint (768px) to match your site's mobile breakpoint
		if (window.matchMedia('(max-width: 768px)').matches) {
			var filterBar = document.querySelector('.js-stools-container-filters');
			if (filterBar) {
				filterBar.classList.remove('js-stools-container-filters-visible');
			}
		}
	});

	jQuery(".button-export").click(function(event) {
		event.preventDefault();
		openExportReportModal();
	});

	function openExportReportModal() {
		document.getElementById('ExportReportModal').style.display = 'flex';
	}

	function closeExportReportModal() {
		document.getElementById('ExportReportModal').style.display = 'none';
	}

	function exportReport() {
		var month = document.getElementById('ExportMonth').value;
		var year = document.getElementById('ExportYear').value;

		var url = 'index.php?option=com_ajax&plugin=export&group=ajax&format=raw' +
			'&month=' + encodeURIComponent(month) +
			'&year=' + encodeURIComponent(year);

		closeExportReportModal();
		window.location.href = url;
	}
</script>

<style>
	#ExportReportModal {
		position: fixed;
		top: 0;
		left: 0;
		width: 100%;
		height: 100%;
		background: rgba(0, 0, 0, 0.5);
		z-index: 1050;
		display: none;
	}

	#ExportReportModal .modal-dialog {
		position: absolute;
		top: 50%;
		left: 50%;
		transform: translate(-50%, -50%);
		margin: 0;
		max-width: 400px;
		width: 90%;
	}

	#ExportReportModal .modal-content {
		border-radius: 8px;
		box-shadow: 0 10px 40px rgba(0, 0, 0, 0.3);
	}
</style>