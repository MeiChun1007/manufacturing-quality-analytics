<?php

/**
 * @version    CVS: 1.2.0
 * @package    Com_Data
 * @author     Mei Chun <qc.yolotech@gmail.com>
 * @copyright  2026 YOLO
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

// No direct access
defined('_JEXEC') or die;

use \Joomla\CMS\HTML\HTMLHelper;
use \Joomla\CMS\Router\Route;
use \Joomla\CMS\Layout\LayoutHelper;
use \Joomla\CMS\Language\Text;
use \Joomla\CMS\Factory;
use \Joomla\CMS\Uri\Uri;

$user       = Factory::getApplication()->getIdentity();
$userId     = $user->get('id');
$listOrder = $this->state->get('list.ordering');
$listDirn  = $this->state->get('list.direction');
$isSuperUser = !$user->guest && $user->authorise('core.admin');
$userGroups    = (array) $user->get('groups');
$allowedGroups = (array) $this->params->get('upload_image', array());
$canUploadImages = $user->authorise('core.admin') || !empty(array_intersect($userGroups, $allowedGroups));

$wa = $this->document->getWebAssetManager();
$wa->useStyle('com_data.list');

?>

<div class="ncentries-list">
	<?php if ($this->params->get('show_page_heading')) : ?>
		<div class="page-header">
			<h1><?php echo $this->escape($this->params->get('page_heading')); ?></h1>
		</div>
	<?php endif; ?>

	<form action="<?php echo Route::_('index.php?option=com_data&view=ncentries'); ?>" method="post" name="adminForm" id="adminForm">

		<div class="ncentries-header mb-4">
			<h1 class="header__title"><?php echo Text::_('COM_DATA_TITLE_NCENTRIES'); ?></h1>
			<p class="header__subtitle"><?php echo Text::_('COM_DATA_TITLE_LIST_VIEW_NCENTRIES_DESC'); ?></p>
			<?php
			$displayStart = null;
			$displayEnd   = null;

			// Resolve start: explicit dateFrom wins, else fall back through week → month → year
			if (!empty($this->dateFrom)) {
				$displayStart = $this->dateFrom;
			} elseif (!empty($this->weekStart)) {
				$displayStart = $this->weekStart;
			} elseif (!empty($this->monthStart)) {
				$displayStart = $this->monthStart;
			} elseif (!empty($this->yearStart)) {
				$displayStart = $this->yearStart;
			}

			// Resolve end: explicit dateTo wins, else fall back through week → month → year
			if (!empty($this->dateTo)) {
				$displayEnd = $this->dateTo;
			} elseif (!empty($this->weekEnd)) {
				$displayEnd = $this->weekEnd;
			} elseif (!empty($this->monthEnd)) {
				$displayEnd = $this->monthEnd;
			} elseif (!empty($this->yearEnd)) {
				$displayEnd = $this->yearEnd;
			}
			?>

			<?php if (!empty($displayStart) || !empty($displayEnd)): ?>
				<div class="text-muted">
					<?php echo !empty($displayStart) ? $displayStart->format('Y-m-d') : Text::_('COM_DATA_DATE_FROM_BEGINNING'); ?>
					&ndash;
					<?php echo !empty($displayEnd) ? $displayEnd->format('Y-m-d') : Text::_('COM_DATA_DATE_TO_PRESENT'); ?>
				</div>
			<?php endif; ?>
		</div>


		<?php if (!empty($this->filterForm)) {
			echo LayoutHelper::render('joomla.searchtools.default', array('view' => $this));
		} ?>

		<div class="button d-flex justify-content-end w-100 mb-3 " style="padding: 10px 28px" ;>
			<!-- Back Button -->
			<a href="<?php echo Route::_('index.php?option=com_data&view=entries'); ?>"
				class="btn btn-danger btn-small">
				<i class="icon-arrow-left"></i> <?php echo Text::_('Back'); ?>
			</a>
		</div>
		<div class="table-responsive">

			<table class="table" id="ncentryList">
				<thead>
					<tr>
						<th class='left' style="width: 150px;">
							<!-- <?php echo HTMLHelper::_('grid.sort', 'COM_DATA_ENTRIES_WORK_ORDER_NO', 'a.work_order_no', $listDirn, $listOrder); ?> -->
							<?php echo HTMLHelper::_('grid.sort', 'COM_DATA_ENTRIES_REFERENCE_NO', 'nc.entry_id', $listDirn, $listOrder); ?>
						</th>

						<th class='left'><?php echo Text::_('COM_DATA_NCIMAGE_TITLE'); ?></th>

						<th class='left'><?php echo Text::_('COM_DATA_ENTRIES_OPERATOR'); ?></th>
						<th class='left'><?php echo Text::_('COM_DATA_ENTRIES_COMPONENT'); ?></th>
						<th class='left'><?php echo Text::_('COM_DATA_ENTRIES_MODEL') . '-' . Text::_('COM_DATA_ENTRIES_VENDOR'); ?></th>
						<th class=''>
							<?php echo HTMLHelper::_('grid.sort',  'COM_DATA_FORM_LBL_ENTRY_LOT', 'a.lot', $listDirn, $listOrder); ?>
						</th>
						<th class='left'>
							<?php echo HTMLHelper::_('grid.sort', 'COM_DATA_ENTRIES_NC_CATEGORY', 'nc.nc_category', $listDirn, $listOrder); ?>
						</th>
						<th class='left'>
							<?php echo HTMLHelper::_('grid.sort', 'COM_DATA_ENTRIES_NC_TYPE', 'nc.nc_type', $listDirn, $listOrder); ?>
						</th>
						<th class='left'><?php echo Text::_('COM_DATA_ENTRIES_TOTAL'); ?></th>
						<th class='left'>
							<?php echo HTMLHelper::_('grid.sort', 'COM_DATA_ENTRIES_NC_QUANTITY', 'nc.nc_quantity', $listDirn, $listOrder); ?>
						</th>
						<th class='left'>
							<?php echo HTMLHelper::_('grid.sort', 'COM_DATA_ENTRIES_NC_PERCENTAGE', 'nc.nc_percentage', $listDirn, $listOrder); ?>
						</th>
					</tr>
				</thead>
				<tfoot>
					<tr>
						<td colspan="<?php echo isset($this->items[0]) ? count(get_object_vars($this->items[0])) : 10; ?>">
							<div class="pagination">
								<?php echo $this->pagination->getPagesLinks(); ?>
							</div>
						</td>
					</tr>
				</tfoot>
				<tbody>
					<?php
					$ncQtySum   = 0;
					$ncPctSum   = 0;
					$sortSum    = 0;
					$seenEntryIds = array();

					foreach ($this->items as $item) {
						$ncQtySum += (int) $item->nc_quantity;

						// Only add this entry's Total Sort once, even if it has multiple NC rows.
						if (!in_array($item->entry_id, $seenEntryIds, true)) {
							$seenEntryIds[] = $item->entry_id;
							$sortSum += (float) $item->entry_total;
						}

						$ncPctSum = ($ncQtySum / $sortSum) * 100;
					}
					?>
					<?php if (empty($this->items)) : ?>
						<tr>
							<td colspan="9" class="text-center"><?php echo Text::_('JGLOBAL_NO_MATCHING_RESULTS'); ?></td>
						</tr>
					<?php endif; ?>

					<?php
					$groupIndex  = -1;
					$prevEntryId = null;
					foreach ($this->items as $i => $item) :
						if ($item->entry_id !== $prevEntryId) {
							$groupIndex++;
							$prevEntryId = $item->entry_id;
						}
						$rowClass = ($groupIndex % 2 === 0) ? 'group-shade' : '';
					?>
						<tr class="<?php echo $rowClass; ?>">
							<td><strong><?php echo $this->escape($item->entry_reference_no); ?></strong><br><br>
								<?php echo "Week " . $this->escape($item->entry_week); ?> <br>
								<?php $date = new DateTime($item->entry_date);
								echo $date->format('Y-m-d H:i'); ?>
							</td>

							<td>
								<button type="button" class="btn btn-sm btn-outline-secondary nc-image-btn"
									data-nc-id="<?php echo (int) $item->id; ?>"
									data-bs-toggle="modal" data-bs-target="#ncImageModal">
									<i class="fas fa-camera"></i> <?php echo (int) $item->image_count; ?>
								</button>
							</td>

							<td><?php echo $this->escape($item->operator_name); ?></td>
							<td><?php echo $this->escape($item->entry_component); ?></td>
							<td>
								<?php echo $this->escape($item->entry_model);
								if (!empty($item->entry_vendor)) {
									echo "-" . $this->escape($item->entry_vendor);
									if ($item->entry_remark) {
										echo "(" . $this->escape($item->entry_remark) . ")";
									}
								};
								?>
							</td>
							<td>
								<?php echo $item->entry_lot; ?><br>
								<?php if (isset($item->entry_lot_raw) && $item->entry_lot_raw === '1') : ?>
									<?php if (!empty($item->entry_resort_nc)) : ?>
										<small class="text-muted"><?php echo $this->escape($item->entry_resort_nc); ?></small>
									<?php endif; ?>
								<?php endif; ?>
							</td>
							<td><?php echo $this->escape($item->nc_category_name); ?></td>
							<td><?php echo $this->escape($item->nc_code); ?></td>
							<td><?php echo $this->escape($item->entry_total); ?></td>
							<td><?php echo $this->escape($item->nc_quantity); ?></td>
							<td><?php echo $this->escape($item->nc_percentage); ?>%</td>
						</tr>
					<?php endforeach; ?>
				</tbody>
				<tfoot>
					<tr class="total-row">
						<th colspan="7"></th>
						<th colspan="2" style="text-align:left;"><?php echo Text::_('Overall Total SORT: '); ?></th>
						<th><?php echo $sortSum; ?></th>
						<th></th>
					</tr>

					<tr class="total-row">
						<th colspan="7"></th>
						<th colspan="2" style="text-align:left;"><?php echo Text::_('Overall Total NC: '); ?></th>
						<th><?php echo number_format($ncQtySum, 0); ?></th>
						<th><?php echo number_format($ncPctSum, 2) . "%"; ?></th>
					</tr>

					<tr class="total-row">
						<th colspan="7"></th>
						<th colspan="2" style="text-align:left;"><?php echo Text::_('Overall Total ACC: '); ?></th>
						<th><?php echo number_format($sortSum - $ncQtySum, 0); ?></th>
						<th><?php echo number_format(100 - $ncPctSum, 2) . "%"; ?></th>
					</tr>

				</tfoot>
			</table>
		</div>

		<div class="modal fade nc-image-modal" id="ncImageModal" tabindex="-1" aria-labelledby="ncImageModalLabel" aria-hidden="true">
			<div class="modal-dialog modal-dialog-centered modal-lg">
				<div class="modal-content">

					<div class="modal-header">
						<div>
							<h5 class="modal-title" id="ncImageModalLabel"><?php echo Text::_('COM_DATA_NCIMAGE_MODAL_TITLE'); ?></h5>
							<p class="nc-image-modal__meta" id="ncImageContext"></p>
						</div>
						<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="<?php echo Text::_('JCLOSE'); ?>"></button>
					</div>

					<div class="modal-body">

						<!-- Existing photos -->
						<div id="ncImageGrid" class="nc-image-grid"></div>
						<div id="ncImageEmpty" class="nc-image-empty d-none">
							<svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
								<rect x="3" y="3" width="18" height="18" rx="2" />
								<circle cx="9" cy="9" r="2" />
								<path d="m21 15-5-5L5 21" />
							</svg>
							<p><?php echo Text::_('COM_DATA_NCIMAGE_NONE_YET'); ?></p>
						</div>

						<?php if ($canUploadImages) : ?>
							<hr class="nc-image-divider">

							<!-- Dropzone -->
							<label for="ncImageFileInput" class="nc-image-dropzone" id="ncImageDropzone">
								<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
									<path d="M12 16V4M12 4 7 9M12 4l5 5" />
									<path d="M4 16v3a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-3" />
								</svg>
								<span class="nc-image-dropzone__text">
									<strong><?php echo Text::_('COM_DATA_NCIMAGE_DROPZONE_CTA'); ?></strong>
									<?php echo Text::_('COM_DATA_NCIMAGE_SELECT_FILES'); ?>
								</span>
								<input type="file" id="ncImageFileInput" class="nc-image-dropzone__input" accept="image/jpeg,image/png,image/webp" multiple hidden>
							</label>

							<!-- Pending files, selected but not yet uploaded -->
							<ul id="ncImageFileList" class="nc-image-filelist"></ul>

							<div id="ncImageErrors" class="nc-image-errors" role="alert"></div>

							<div class="nc-image-upload__actions">
								<button type="button" id="ncImageUploadBtn" class="btn btn-primary" disabled>
									<span class="spinner-border spinner-border-sm nc-image-upload__spinner d-none" role="status" aria-hidden="true"></span>
									<?php echo Text::_('COM_DATA_NCIMAGE_UPLOAD_BTN'); ?>
								</button>
							</div>
						<?php endif; ?>

					</div>

					<div class="modal-footer">
						<button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo Text::_('JCLOSE'); ?></button>
					</div>

				</div>
			</div>
		</div>

		<div class="nc-lightbox" id="ncLightbox" aria-hidden="true">
			<button type="button" class="nc-lightbox__close" id="ncLightboxClose" aria-label="<?php echo Text::_('JCLOSE'); ?>">&times;</button>
			<button type="button" class="nc-lightbox__nav nc-lightbox__nav--prev" id="ncLightboxPrev" aria-label="<?php echo Text::_('JPREVIOUS'); ?>">&#8249;</button>

			<figure class="nc-lightbox__figure">
				<img src="" alt="" id="ncLightboxImg">
				<figcaption class="nc-lightbox__counter" id="ncLightboxCounter"></figcaption>
			</figure>

			<button type="button" class="nc-lightbox__nav nc-lightbox__nav--next" id="ncLightboxNext" aria-label="<?php echo Text::_('JNEXT'); ?>">&#8250;</button>
		</div>

		<input type="hidden" name="task" value="" />
		<input type="hidden" name="boxchecked" value="0" />
		<input type="hidden" name="filter_order" value="" />
		<input type="hidden" name="filter_order_Dir" value="" />
		<?php echo HTMLHelper::_('form.token'); ?>
	</form>
</div>

<script>
	document.addEventListener('DOMContentLoaded', function() {
		// Adjust the breakpoint (768px) to match your site's mobile breakpoint
		if (window.matchMedia('(max-width: 768px)').matches) {
			var filterBar = document.querySelector('.js-stools-container-filters');
			if (filterBar) {
				filterBar.classList.remove('js-stools-container-filters-visible');
			}
		}

		var allowDelete = <?php echo $canUploadImages ? 'true' : 'false'; ?>;
		var csrfToken = '<?php echo \Joomla\CMS\Session\Session::getFormToken(); ?>';
		var currentEntryId = null;
		var ncAjaxBase = <?php echo json_encode(rtrim(Uri::root(), '/') . '/index.php'); ?>;
		// Add these three lines:
		var fileInput = document.getElementById('ncImageFileInput');
		var fileList = document.getElementById('ncImageFileList');
		var uploadBtn = document.getElementById('ncImageUploadBtn'); // moved up from further down

		function ajaxUrl(task) {
			return ncAjaxBase + '?option=com_data&task=ncentry.' + task;
		}

		function renderImages(images) {
			var grid = document.getElementById('ncImageGrid');
			var empty = document.getElementById('ncImageEmpty');
			grid.innerHTML = '';

			if (!images.length) {
				empty.classList.remove('d-none');
				return;
			}
			empty.classList.add('d-none');

			images.forEach(function(img) {
				var thumb = document.createElement('div');
				thumb.className = 'nc-image-thumb';
				thumb.setAttribute('data-full', img.url);

				var imgEl = document.createElement('img');
				imgEl.src = img.thumb_url || img.url; // falls back to the full image if you don't generate thumbnails server-side
				imgEl.alt = '';
				imgEl.loading = 'lazy';
				imgEl.className = 'nc-image-thumb__img';
				thumb.appendChild(imgEl);

				if (allowDelete) {
					var removeBtn = document.createElement('span');
					removeBtn.className = 'nc-image-thumb__remove';
					removeBtn.setAttribute('data-id', img.id);
					removeBtn.innerHTML = '&times;';
					removeBtn.addEventListener('click', function(e) {
						e.stopPropagation(); // don't also trigger the lightbox open
						if (!confirm('<?php echo Text::_('COM_DATA_NCIMAGE_DELETE_CONFIRM'); ?>')) return;

						var fd = new FormData();
						fd.append('image_id', img.id);
						fd.append(csrfToken, '1');

						fetch(ajaxUrl('delete'), {
								method: 'POST',
								body: fd,
								credentials: 'same-origin'
							})
							.then(function(r) {
								return r.json();
							})
							.then(function() {
								loadImages(currentEntryId);
							});
					});
					thumb.appendChild(removeBtn);
				}

				grid.appendChild(thumb);
			});
		}

		function loadImages(ncId) {
			fetch(ajaxUrl('list') + '&nc_id=' + ncId)
				.then(function(r) {
					return r.json();
				})
				.then(function(data) {
					renderImages(data.images || []);
				});
		}

		document.querySelectorAll('.nc-image-btn').forEach(function(btn) {
			btn.addEventListener('click', function() {
				currentEntryId = btn.dataset.ncId;
				loadImages(currentEntryId);

				// Reset the upload form for the newly-opened row.
				if (fileInput) fileInput.value = '';
				if (fileList) fileList.innerHTML = '';
				if (uploadBtn) uploadBtn.disabled = true;
				document.getElementById('ncImageErrors').innerHTML = '';
			});
		});

		if (fileInput) {
			fileInput.addEventListener('change', function() {
				var files = fileInput.files;

				// Enable/disable the Upload button based on whether anything is selected.
				uploadBtn.disabled = !files.length;

				// Show the pending files as removable chips.
				fileList.innerHTML = '';

				Array.prototype.forEach.call(files, function(file) {
					var li = document.createElement('li');
					li.textContent = file.name + ' (' + Math.round(file.size / 1024) + ' KB)';
					fileList.appendChild(li);
				});
			});
		}

		if (uploadBtn) {
			uploadBtn.addEventListener('click', function() {
				var input = document.getElementById('ncImageFileInput');
				var errBox = document.getElementById('ncImageErrors');
				var spinner = uploadBtn.querySelector('.nc-image-upload__spinner');
				errBox.innerHTML = '';

				if (!input.files.length) {
					errBox.innerHTML = '<?php echo Text::_('COM_DATA_NCIMAGE_ERROR_NO_FILE'); ?>';
					return;
				}

				// Guard against double-tap re-entry.
				if (uploadBtn.disabled) {
					return;
				}

				uploadBtn.disabled = true;
				if (spinner) spinner.classList.remove('d-none');

				var files = Array.from(input.files);
				var batchSize = 3; // tune based on your typical phone-photo size and post_max_size
				var batches = [];

				for (var i = 0; i < files.length; i += batchSize) {
					batches.push(files.slice(i, i + batchSize));
				}

				var allErrors = [];

				function uploadBatch(index) {
					if (index >= batches.length) {
						// All batches done.
						uploadBtn.disabled = false;
						if (spinner) spinner.classList.add('d-none');

						if (allErrors.length) {
							errBox.innerHTML = allErrors.join('<br>');
						}

						input.value = '';
						if (typeof fileList !== 'undefined' && fileList) fileList.innerHTML = '';
						loadImages(currentEntryId);
						return;
					}

					var fd = new FormData();
					batches[index].forEach(function(file) {
						fd.append('images[]', file);
					});
					fd.append('nc_id', currentEntryId);
					fd.append(csrfToken, '1');

					fetch(ajaxUrl('upload'), {
							method: 'POST',
							body: fd,
							credentials: 'same-origin'
						})
						.then(function(response) {
							return response.json().catch(function() {
								throw new Error('Server returned an unexpected response (HTTP ' + response.status + ').');
							}).then(function(data) {
								return {
									httpStatus: response.status,
									data: data
								};
							});
						})
						.then(function(resp) {
							var data = resp.data;

							if (data.success === false) {
								allErrors.push((data.message || 'Batch ' + (index + 1) + ' was rejected.') + ' (batch ' + (index + 1) + ' of ' + batches.length + ')');
							} else if (data.errors && data.errors.length) {
								allErrors = allErrors.concat(data.errors);
							}

							uploadBatch(index + 1);
						})
						.catch(function(err) {
							console.error(err);
							allErrors.push('Batch ' + (index + 1) + ' failed - please try again.');
							uploadBatch(index + 1);
						});
				}

				uploadBatch(0);
			});
		}

		(function() {
			var lightbox = document.getElementById('ncLightbox');
			var lightImg = document.getElementById('ncLightboxImg');
			var counter = document.getElementById('ncLightboxCounter');
			var btnClose = document.getElementById('ncLightboxClose');
			var btnPrev = document.getElementById('ncLightboxPrev');
			var btnNext = document.getElementById('ncLightboxNext');
			var grid = document.getElementById('ncImageGrid');

			var items = []; // full-size URLs of the images currently in the modal
			var index = 0;

			function refreshItems() {
				items = Array.prototype.map.call(
					grid.querySelectorAll('.nc-image-thumb'),
					function(el) {
						return el.getAttribute('data-full');
					}
				);
			}

			function show(i) {
				if (!items.length) return;
				index = (i + items.length) % items.length;
				lightImg.src = items[index];
				counter.textContent = (index + 1) + ' / ' + items.length;
				btnPrev.disabled = items.length < 2;
				btnNext.disabled = items.length < 2;
			}

			function open(i) {
				refreshItems();
				show(i);
				lightbox.classList.add('is-open');
				lightbox.setAttribute('aria-hidden', 'false');
			}

			function close() {
				lightbox.classList.remove('is-open');
				lightbox.setAttribute('aria-hidden', 'true');
				lightImg.src = '';
			}

			// Open on thumbnail click (event delegation so it keeps working after uploads/deletes)
			grid.addEventListener('click', function(e) {
				var thumb = e.target.closest('.nc-image-thumb');
				if (!thumb || e.target.classList.contains('nc-image-thumb__remove')) return;

				refreshItems();
				var all = Array.prototype.slice.call(grid.querySelectorAll('.nc-image-thumb'));
				open(all.indexOf(thumb));
			});

			btnClose.addEventListener('click', close);
			btnPrev.addEventListener('click', function() {
				show(index - 1);
			});
			btnNext.addEventListener('click', function() {
				show(index + 1);
			});

			lightbox.addEventListener('click', function(e) {
				if (e.target === lightbox) close();
			});

			document.addEventListener('keydown', function(e) {
				if (!lightbox.classList.contains('is-open')) return;
				if (e.key === 'Escape') close();
				if (e.key === 'ArrowLeft') show(index - 1);
				if (e.key === 'ArrowRight') show(index + 1);
			});
		})();

	});
</script>