<?php

/**
 * @version    CVS: 1.2.0
 * @package    Com_Data
 * @author     Mei Chun <qc.yolotech@gmail.com>
 * @copyright  2026 YOLO
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

// No direct access
defined('_JEXEC') or die;

use \Joomla\CMS\HTML\HTMLHelper;
use \Joomla\CMS\Router\Route;
use \Joomla\CMS\Language\Text;
use Joomla\CMS\Component\ComponentHelper;

HTMLHelper::_('bootstrap.tooltip');

$wa = $this->document->getWebAssetManager();
$wa->useStyle('com_data.list');
$wa->useStyle('choicesjs');
$wa->useStyle('com_data.ncreport');
$wa->useScript('com_data.ncreport');

$filters = $this->activeFilters;
$pivot   = $this->pivot;
$summary = $this->summary;

$params = ComponentHelper::getParams('com_data');

$dangerThreshold = (float) $params->get('danger_ncpct_threshold');
$warningThreshold = (float) $params->get('warning_ncpct_threshold');

$ncPctClass = function ($pct) use ($dangerThreshold, $warningThreshold) {
	if ($pct > $dangerThreshold) {
		return 'text-danger fw-bold';
	}

	if ($pct > $warningThreshold) {
		return 'text-warning-emphasis fw-semibold';
	}

	return '';
};

/**
 * This is a pivot/aggregate report, not a row-per-record CRUD list, so it has
 * no add/edit/delete actions here - drill into an individual "Total Data
 * Entry" record from the Entries list to change the underlying data.
 */

?>

<?php if ($this->params->get('show_page_heading')) : ?>
	<div class="page-header">
		<h1><?php echo $this->escape($this->params->get('page_heading')); ?></h1>
	</div>
<?php endif; ?>

<form action="<?php echo Route::_('index.php?option=com_data&view=ncreportmonthly'); ?>" method="post" name="adminForm" id="adminForm">

	<div class="ncreport-header mb-4">
		<h1 class="ncreport-header__title"><?php echo Text::_('COM_DATA_TITLE_NCREPORTMONTHLY'); ?></h1>
		<p class="ncreport-header__subtitle"><?php echo Text::_('COM_DATA_NCREPORTMONTHLY_SUBTITLE'); ?></p>
		<p class="text-muted">
			<?php echo HTMLHelper::_('date', $filters->month_start, Text::_('DATE_FORMAT_LC4')); ?>
			&ndash;
			<?php echo HTMLHelper::_('date', $filters->month_end, Text::_('DATE_FORMAT_LC4')); ?>
		</p>
	</div>

	<div class="selectors row">
		<div class="selector col-md-3">
			<label for="filter_year"><?php echo Text::_('COM_DATA_MODELSUMMARY_YEAR_SELECTOR'); ?></label>
			<select name="filter_year" id="filter_year" class="form-select" onchange="this.form.submit();">
				<?php foreach ($this->yearOptions as $yearOption) : ?>
					<option value="<?php echo (int) $yearOption; ?>" <?php echo (int) $filters->year === (int) $yearOption ? 'selected="selected"' : ''; ?>>
						<?php echo (int) $yearOption; ?>
					</option>
				<?php endforeach; ?>
			</select>
		</div>
		<div class="selector col-md-3">
			<label for="filter_month"><?php echo Text::_('COM_DATA_NCREPORTMONTHLY_MONTH_SELECTOR'); ?></label>
			<select name="filter_month" id="filter_month" class="form-select" onchange="this.form.submit();">
				<?php foreach ($this->monthOptions as $monthOption) : ?>
					<option value="<?php echo $this->escape($monthOption->value); ?>" <?php echo $filters->month === $monthOption->value ? 'selected="selected"' : ''; ?>>
						<?php echo $this->escape($monthOption->label); ?>
					</option>
				<?php endforeach; ?>
			</select>
		</div>
	</div>

	<div id="dashboard-filters">

		<div class="selectors row mb-3">
			<div class="selector col-md-3">
				<label for="filter_part"><?php echo Text::_('COM_DATA_MODELSUMMARY_PART_SELECTOR'); ?></label>
				<select name="filter_part" id="filter_part" class="form-select js-choices" onchange="this.form.submit();">
					<option value=""><?php echo Text::_('COM_DATA_MODELSUMMARY_ALL_PARTS'); ?></option>
					<?php foreach ($this->partOptions as $partOption) : ?>
						<option value="<?php echo $this->escape($partOption->value); ?>" <?php echo (string) $filters->part === (string) $partOption->value ? 'selected="selected"' : ''; ?>>
							<?php echo $this->escape($partOption->text); ?>
						</option>
					<?php endforeach; ?>
				</select>
				<div style="padding-top: 20px;">
					<label for="filter_model"><?php echo Text::_('COM_DATA_NCREPORT_MODEL_SELECTOR'); ?></label>
					<select name="filter_model" id="filter_model" class="form-select js-choices" onchange="this.form.submit();">
						<option value=""><?php echo Text::_('COM_DATA_NCREPORT_ALL_MODELS'); ?></option>
						<?php foreach ($this->modelOptions as $modelOption) : ?>
							<option value="<?php echo $this->escape($modelOption->value); ?>" <?php echo (string) $filters->model === (string) $modelOption->value ? 'selected="selected"' : ''; ?>>
								<?php echo $this->escape($modelOption->text); ?>
							</option>
						<?php endforeach; ?>
					</select>
				</div>
			</div>
			<div class="selector col-md-3">
				<label for="filter_vendor"><?php echo Text::_('COM_DATA_NCREPORT_VENDOR_SELECTOR'); ?></label>
				<select name="filter_vendor" id="filter_vendor" class="form-select" onchange="this.form.submit();">
					<option value=""><?php echo Text::_('COM_DATA_NCREPORT_ALL_VENDORS'); ?></option>
					<?php foreach ($this->vendorOptions as $vendorOption) : ?>
						<option value="<?php echo $this->escape($vendorOption->key); ?>" <?php echo (string) $filters->vendor === (string) $vendorOption->key ? 'selected="selected"' : ''; ?>>
							<?php echo $this->escape($vendorOption->value); ?>
						</option>
					<?php endforeach; ?>
				</select>
				<div style="padding-top: 20px" ;>
					<label for="filter_lot"><?php echo Text::_('COM_DATA_NCREPORT_LOT_SELECTOR'); ?></label>
					<select name="filter_lot" id="filter_lot" class="form-select" onchange="this.form.submit();">
						<option value=""><?php echo Text::_('COM_DATA_NCREPORT_ALL_LOT'); ?></option>
						<?php foreach ($this->lotOptions as $lotOption) : ?>
							<option value="<?php echo $this->escape($lotOption->value); ?>" <?php echo (string) $filters->lot === (string) $lotOption->value ? 'selected="selected"' : ''; ?>>
								<?php echo $this->escape($lotOption->text); ?>
							</option>
						<?php endforeach; ?>
					</select>
				</div>
			</div>
			<div class="selector col-md-3">
				<label for="filter_remark"><?php echo Text::_('COM_DATA_NCREPORT_REMARK_SELECTOR'); ?></label>
				<select name="filter_remark" id="filter_remark" class="form-select" onchange="this.form.submit();">
					<option value=""><?php echo Text::_('COM_DATA_NCREPORT_ALL_REMARKS'); ?></option>
					<?php foreach ($this->remarkOptions as $remarkKey => $remarkLabel) : ?>
						<option value="<?php echo $this->escape($remarkKey); ?>" <?php echo (string) $filters->remark === (string) $remarkKey ? 'selected="selected"' : ''; ?>>
							<?php echo $this->escape($remarkLabel); ?>
						</option>
					<?php endforeach; ?>
				</select>
				<div style="padding-top: 20px" ;>
					<label for="filter_operator"><?php echo Text::_('COM_DATA_NCREPORT_OPERATOR_SELECTOR'); ?></label>
					<select name="filter_operator" id="filter_operator" class="form-select js-choices" onchange="this.form.submit();">
						<option value=""><?php echo Text::_('COM_DATA_NCREPORT_ALL_OPERATORS'); ?></option>
						<?php foreach ($this->operatorOptions as $operatorOption) : ?>
							<option value="<?php echo $this->escape($operatorOption->key); ?>" <?php echo (string) $filters->operator === (string) $operatorOption->key ? 'selected="selected"' : ''; ?>>
								<?php echo $this->escape($operatorOption->value); ?>
							</option>
						<?php endforeach; ?>
					</select>
				</div>
			</div>
			<div class="selector col-md-3">
				<label for="filter_nc_category"><?php echo Text::_('COM_DATA_NCREPORT_NC_CATEGORY_SELECTOR'); ?></label>
				<select name="filter_nc_category" id="filter_nc_category" class="form-select" onchange="this.form.submit();">
					<option value=""><?php echo Text::_('COM_DATA_NCREPORT_ALL_NC_CATEGORIES'); ?></option>
					<?php foreach ($this->nccategoryOptions as $nccategoryOption) : ?>
						<option value="<?php echo $this->escape($nccategoryOption->value); ?>" <?php echo (string) $filters->nc_category === (string) $nccategoryOption->value ? 'selected="selected"' : ''; ?>>
							<?php echo $this->escape($nccategoryOption->text); ?>
						</option>
					<?php endforeach; ?>
				</select>
				<div style="padding-top: 20px" ;>
					<label for="filter_nc_type"><?php echo Text::_('COM_DATA_NCREPORT_NC_TYPE_SELECTOR'); ?></label>
					<select name="filter_nc_type" id="filter_nc_type" class="form-select js-choices" onchange="this.form.submit();">
						<option value=""><?php echo Text::_('COM_DATA_NCREPORT_ALL_NC_TYPES'); ?></option>
						<?php foreach ($this->nctypeOptions as $nctypeOption) : ?>
							<option value="<?php echo $this->escape($nctypeOption->value); ?>" <?php echo (string) $filters->nc_type === (string) $nctypeOption->value ? 'selected="selected"' : ''; ?>>
								<?php echo $this->escape($nctypeOption->text); ?>
							</option>
						<?php endforeach; ?>
					</select>
				</div>
			</div>
		</div>

		<div class="row mb-3">
			<div class="col-md-12 text-end">
				<button type="button" id="btn-clear-filters" class="btn btn-link btn-sm text-muted">
					<span class="icon-undo" aria-hidden="true"></span>
					<?php echo Text::_('COM_DATA_NCREPORT_CLEAR_FILTERS'); ?>
				</button>
			</div>
		</div>
	</div>

	<div class="filter-toggle-row">
		<div class="filter-toggle-title text-muted">
			<span id="filter-toggle-text">Less Filters</span>
		</div>

		<button type="button"
			id="btn-toggle-filters"
			class="filter-toggle-btn"
			aria-expanded="true"
			aria-controls="dashboard-filters">
			<span id="filter-toggle-icon" class="icon-chevron-up" aria-hidden="true"></span>
		</button>
	</div>

	<!-- Monthly Summary Card -->
	<div class="row mb-3">
		<div class="summary-cards col-md-12 d-flex flex-wrap gap-3">
			<div class="card text-center flex-fill border-start border-4 border-secondary">
				<div class="card-body">
					<div class="text-muted small"><?php echo Text::_('COM_DATA_NCREPORT_TOTAL_SORT'); ?></div>
					<div class="fs-4"><?php echo number_format($summary->total_sort); ?></div>
				</div>
			</div>
			<div class="card text-center flex-fill border-start border-4 border-secondary">
				<div class="card-body">
					<div class="text-muted small"><?php echo Text::_('COM_DATA_NCREPORT_TOTAL_ACCEPTED'); ?></div>
					<div class="fs-4"><?php echo number_format($summary->total_accepted); ?></div>
				</div>
			</div>
			<div class="card text-center flex-fill border-start border-4 border-danger">
				<div class="card-body">
					<div class="text-muted small"><?php echo Text::_('COM_DATA_NCREPORT_TOTAL_NC'); ?></div>
					<div class="fs-4"><?php echo number_format($summary->total_nc); ?></div>
				</div>
			</div>
			<div class="card text-center flex-fill border-start border-4 border-danger">
				<div class="card-body">
					<div class="text-muted small"><?php echo Text::_('COM_DATA_NCREPORT_TOTAL_NC_PCT'); ?></div>
					<div class="fs-4 <?php echo $ncPctClass($summary->total_nc_pct); ?>"><?php echo number_format($summary->total_nc_pct, 2); ?>%</div>
				</div>
			</div>
			<div class="card text-center flex-fill border-start border-4 border-success">
				<div class="card-body">
					<div class="text-muted small"><?php echo Text::_('COM_DATA_NCREPORT_YIELD_PCT'); ?></div>
					<div class="fs-4"><?php echo number_format($summary->yield_pct, 2); ?>%</div>
				</div>
			</div>
		</div>
	</div>

	<!-- Table -->
	<?php if (empty($pivot->rows)) : ?>
		<div class="alert alert-info">
			<?php echo Text::_('COM_DATA_NCREPORT_EMPTY'); ?>
		</div>
	<?php else : ?>
		<div class="table-responsive">
			<table class="table table-bordered" id="ncReportMonthlyList">
				<thead>
					<tr class="title">
						<th rowspan="2" class="align-middle"><?php echo Text::_('Category'); ?></th>
						<th rowspan="2" class="align-middle"><?php echo Text::_('COM_DATA_FORM_LBL_ENTRY_NC_TYPE'); ?></th>
						<th rowspan="2" class="align-middle text-center">
							<?php echo Text::_('COM_DATA_NCREPORT_TOTAL_NC'); ?>
						</th>
						<th rowspan="2" class="align-middle text-center"
							data-bs-toggle="tooltip" title="<?php echo $this->escape(Text::_('COM_DATA_NCREPORTMONTHLY_COLUMN_NC_PCT_HINT')); ?>">
							<?php echo Text::_('COM_DATA_NCREPORTMONTHLY_MONTH_PCT'); ?>
						</th>
						<?php foreach ($pivot->weeks as $weekCol) : ?>
							<?php
							$weekLinkUrl = 'index.php?option=com_data&view=ncreport&filter_year=' . (int) $weekCol->year . '&filter_week=' . (int) $weekCol->week;

							if ($filters->model !== '') {
								$weekLinkUrl .= '&filter_model=' . urlencode($filters->model);
							}

							if ($filters->vendor !== '') {
								$weekLinkUrl .= '&filter_vendor=' . urlencode($filters->vendor);
							}
							?>
							<th colspan="2" class="text-center">
								<a href="<?php echo Route::_($weekLinkUrl); ?>" class="text-decoration-none">
									<?php echo $this->escape($weekCol->label); ?>
								</a>
							</th>
						<?php endforeach; ?>
					</tr>
					<tr class="title">
						<?php foreach ($pivot->weeks as $weekCol) : ?>
							<th class="text-center"><?php echo Text::_('COM_DATA_NCREPORT_QTY'); ?></th>
							<th class="text-center">%</th>
						<?php endforeach; ?>
					</tr>
				</thead>
				<tbody>
					<?php
					$prevCategory = null;
					$colorIndex   = -1;
					$palette      = array('nc-cat-bg-0', 'nc-cat-bg-1', 'nc-cat-bg-2', 'nc-cat-bg-3', 'nc-cat-bg-4', 'nc-cat-bg-5', 'nc-cat-bg-6', 'nc-cat-bg-7');
					?>
					<?php foreach ($pivot->rows as $row) : ?>
						<?php
						if ($row->nc_category !== $prevCategory) {
							$colorIndex++;
							$prevCategory = $row->nc_category;
						}

						$rowClass = $palette[$colorIndex % count($palette)];
						?>
						<tr class="<?php echo $rowClass; ?>">
							<td><?php echo $this->escape($row->nc_category); ?></td>
							<td>
								<a href="#" class="nc-drilldown-link<?php echo $row->has_images ? ' has-images' : ''; ?>"
									data-category-id="<?php echo $this->escape($row->nc_category_id); ?>"
									data-type-id="<?php echo $this->escape($row->nc_type_id); ?>"
									data-category-label="<?php echo $this->escape($row->nc_category); ?>"
									data-type-label="<?php echo $this->escape($row->nc_type); ?>">
									<?php echo $this->escape($row->nc_type); ?>
								</a>
							</td>
							<td class="text-center"><?php echo (int) $row->month_qty; ?></td>
							<td class="text-center <?php echo $ncPctClass($row->month_pct); ?>"><?php echo number_format($row->month_pct, 2); ?>%</td>
							<?php foreach ($pivot->weeks as $weekCol) : ?>
								<?php $wk = $weekCol->key;
								$weekQty = (int) $row->by_week[$wk];
								$weekPct = $row->by_week_pct[$wk];
								?>
								<td class="text-center<?php echo $weekQty === 0 ? ' value-zero' : ''; ?>"><?php echo $weekQty; ?></td>
								<td class="text-center <?php echo ($weekPct === 0.0 && $weekQty === 0 ? ' value-zero' : '') . $ncPctClass($weekPct); ?>"><?php echo number_format($weekPct, 2); ?>%</td>
							<?php endforeach; ?>
						</tr>
					<?php endforeach; ?>
				</tbody>
				<tfoot>
					<tr class="overall-data">
						<th colspan="2" data-bs-toggle="tooltip" title="<?php echo $this->escape(Text::_('COM_DATA_NCREPORTMONTHLY_ROW_MONTH_SORT_HINT')); ?>">
							<?php echo Text::_('COM_DATA_NCREPORT_TOTAL_SORT'); ?>
						</th>
						<th colspan="2" class="text-center"><?php echo (int) $pivot->month_total_sort; ?></th>
						<?php foreach ($pivot->weeks as $weekCol) : ?>
							<?php $weekSortTotal = $pivot->week_sort_totals[$weekCol->key] ?? 0; ?>
							<th colspan="2" class="text-center"><?php echo (int) $weekSortTotal; ?></th>
						<?php endforeach; ?>
					</tr>

					<tr class="overall-data">
						<th colspan="2" data-bs-toggle="tooltip" title="<?php echo $this->escape(Text::_('COM_DATA_NCREPORTMONTHLY_ROW_TOTAL_NC_HINT')); ?>">
							<?php echo Text::_('COM_DATA_NCREPORT_TOTAL_NC'); ?>
						</th>
						<th colspan="2" class="text-center"><?php echo (int) $pivot->month_total_nc; ?></th>
						<?php foreach ($pivot->weeks as $weekCol) : ?>
							<?php $weekTotal = $pivot->week_totals[$weekCol->key] ?? 0; ?>
							<th colspan="2" class="text-center"><?php echo (int) $weekTotal; ?></th>
						<?php endforeach; ?>
					</tr>

					<tr class="overall-data">
						<th colspan="2" data-bs-toggle="tooltip" title="<?php echo $this->escape(Text::_('COM_DATA_NCREPORTMONTHLY_ROW_TOTAL_ACCEPTED_HINT')); ?>">
							<?php echo Text::_('COM_DATA_NCREPORT_TOTAL_ACCEPTED'); ?>
						</th>
						<?php
						$SortTotal = $pivot->month_total_sort ?? 0;
						$NcTotal   = $pivot->month_total_nc ?? 0;
						$AccTotal  = $SortTotal > 0 ? $SortTotal - $NcTotal : 0;
						?>
						<th colspan="2" class="text-center"><?php echo (int) $AccTotal; ?></th>
						<?php foreach ($pivot->weeks as $weekCol) : ?>
							<?php
							$weekSortTotal = $pivot->week_sort_totals[$weekCol->key] ?? 0;
							$weekTotal     = $pivot->week_totals[$weekCol->key] ?? 0;
							$weekAcc       = $weekSortTotal > 0 ? $weekSortTotal - $weekTotal : 0.0;
							?>
							<th colspan="2" class="text-center"><?php echo (int) $weekAcc; ?></th>
						<?php endforeach; ?>
					</tr>

					<tr class="overall-data">
						<th colspan="2" data-bs-toggle="tooltip" title="<?php echo $this->escape(Text::_('COM_DATA_NCREPORTMONTHLY_ROW_NC_PCT_HINT')); ?>">
							<?php echo Text::_('Overall NC Percentage'); ?>
						</th>
						<th colspan="2" class="text-center <?php echo $ncPctClass($pivot->month_total_nc_pct); ?>"><?php echo number_format($pivot->month_total_nc_pct, 2); ?>%</th>
						<?php foreach ($pivot->weeks as $weekCol) : ?>
							<?php
							$weekSortTotal = $pivot->week_sort_totals[$weekCol->key] ?? 0;
							$weekTotal     = $pivot->week_totals[$weekCol->key] ?? 0;
							$weekPct       = $weekSortTotal > 0 ? ($weekTotal / $weekSortTotal) * 100 : 0.0;
							?>
							<th colspan="2" class="text-center <?php echo $ncPctClass($weekPct); ?>"><?php echo number_format($weekPct, 2); ?>%</th>
						<?php endforeach; ?>
					</tr>
				</tfoot>
			</table>
		</div>
	<?php endif; ?>

	<div class="modal fade" id="ncDrilldownModal" tabindex="-1" aria-hidden="true">
		<div class="modal-dialog modal-dialog-centered modal-xl">
			<div class="modal-content">
				<div class="modal-header">
					<h5 class="modal-title" id="ncDrilldownTitle"></h5>
					<button type="button" class="btn-close" data-bs-dismiss="modal"></button>
				</div>
				<div class="modal-body">
					<div id="ncDrilldownLoading" class="text-muted small mb-2 d-none"><?php echo Text::_('JGLOBAL_LOADING'); ?>&hellip;</div>
					<div class="table-responsive">
						<table class="table table-sm table-bordered">
							<thead>
								<tr>
									<th><?php echo Text::_('COM_DATA_ENTRIES_REFERENCE_NO'); ?></th>
									<th><?php echo Text::_('COM_DATA_NCIMAGE_TITLE'); ?></th>
								</tr>
							</thead>
							<tbody id="ncDrilldownBody"></tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
	</div>

	<input type="hidden" name="clearfilters" id="clearfilters" value="0" />
	<input type="hidden" name="task" value="" />
	<?php echo HTMLHelper::_('form.token'); ?>
</form>

<script>
	document.addEventListener('DOMContentLoaded', function() {
		document.querySelectorAll('.js-choices').forEach(function(el) {
			new Choices(el, {
				searchEnabled: true,
				itemSelectText: '',
				shouldSort: false,
				allowHTML: false,
			});
		});

		var clearBtn = document.getElementById('btn-clear-filters');
		if (!clearBtn) {
			return;
		}

		clearBtn.addEventListener('click', function() {
			var form = document.getElementById('adminForm');
			var flag = document.getElementById('clearfilters');
			if (flag) {
				flag.value = '1';
			}
			form.submit();
		});

		document.querySelectorAll('.nc-drilldown-link').forEach(function(link) {
			link.addEventListener('click', function(e) {
				e.preventDefault();

				var categoryId = link.dataset.categoryId;
				var typeId = link.dataset.typeId;
				var body = document.getElementById('ncDrilldownBody');
				var loading = document.getElementById('ncDrilldownLoading');

				document.getElementById('ncDrilldownTitle').textContent =
					link.dataset.categoryLabel + ' \u2014 ' + link.dataset.typeLabel;

				body.innerHTML = '';
				loading.classList.remove('d-none');

				var modalEl = document.getElementById('ncDrilldownModal');
				bootstrap.Modal.getOrCreateInstance(modalEl).show();
				<?php
				$drilldownQuery = http_build_query(array_filter(array(
					'filter_year'     => (int) $filters->year,
					'filter_month'    => $filters->month ?? '',
					'filter_week'     => $filters->week ?? '',
					'filter_part'     => $filters->part,
					'filter_model'    => $filters->model,
					'filter_vendor'   => $filters->vendor,
					'filter_lot'      => $filters->lot,
					'filter_remark'   => $filters->remark,
					'filter_operator' => $filters->operator,
				), function ($v) {
					return $v !== '' && $v !== null;
				}));
				?>
				var drilldownQuery = <?php echo json_encode($drilldownQuery); ?>;

				fetch('index.php?option=com_data&task=ncentry.drilldown&' + drilldownQuery +
						'&category_id=' + encodeURIComponent(categoryId) +
						'&type_id=' + encodeURIComponent(typeId))
					.then(function(r) {
						return r.json();
					})
					.then(function(data) {
						loading.classList.add('d-none');

						if (!data.rows || !data.rows.length) {
							body.innerHTML = '<tr><td colspan="8" class="text-center text-muted">' +
								'<?php echo Text::_('JGLOBAL_NO_IMAGE_UPLOADED'); ?></td></tr>';
							return;
						}

						data.rows.forEach(function(row) {
							var tr = document.createElement('tr');

							var imagesHtml = row.images.length ?
								row.images.map(function(url) {
									return '<a href="' + url + '" target="_blank"><img src="' + url + '" style="width:160px;height:160px;object-fit:cover;border-radius:4px;margin:2px;"></a>';
								}).join('') :
								'<span class="text-muted small"><?php echo Text::_('COM_DATA_NCIMAGE_NONE_YET'); ?></span>';

							tr.innerHTML =
								'<td><strong>' + (row.reference_no || '') +
								'</strong><br><br><strong><?php echo Text::_('COM_DATA_ENTRIES_COMPONENT'); ?>: </strong>' + (row.component || '') +
								'<br><strong><?php echo Text::_('COM_DATA_ENTRIES_MODEL'); ?>: </strong>' + (row.model || '') +
								'<br><strong><?php echo Text::_('COM_DATA_ENTRIES_VENDOR'); ?>: </strong>' + (row.vendor || '') + ' (' + (row.lot || '') + ')' +
								'<br><br><strong><?php echo Text::_('COM_DATA_FORM_LBL_ENTRY_LOT'); ?>: </strong>' + (row.remark || '') + '</td>' +
								'<td style="display: flex;  flex-wrap: wrap; justify-content: flex-start; gap:10px;">' + imagesHtml + '</td>';

							body.appendChild(tr);
						});
					})
					.catch(function(err) {
						loading.classList.add('d-none');
						body.innerHTML = '<tr><td colspan="8" class="text-danger text-center">Failed to load.</td></tr>';
						console.error(err);
					});
			});
		});
	});
</script>