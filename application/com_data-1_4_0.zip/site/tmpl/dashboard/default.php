<?php

/**
 * @version    CVS: 1.3.0
 * @package    Com_Data
 * @author     Mei Chun <qc.yolotech@gmail.com>
 * @copyright  2026 YOLO
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

// No direct access
defined('_JEXEC') or die;

use \Joomla\CMS\HTML\HTMLHelper;
use \Joomla\CMS\Router\Route;
use \Joomla\CMS\Language\Text;
use \Joomla\CMS\Factory;
use Joomla\CMS\Component\ComponentHelper;
use Joomla\CMS\Helper\ModuleHelper;

HTMLHelper::_('bootstrap.tooltip');

$wa = $this->document->getWebAssetManager();
$wa->useStyle('com_data.list')
	->useStyle('com_data.dashboard');
$wa->useStyle('com_data.ncreport');
$wa->useStyle('choicesjs');
$wa->useScript('choicesjs');
$wa->useScript('com_data.ncreport');

$user       = Factory::getApplication()->getIdentity();
$filters = $this->activeFilters;
$summary = $this->summary;
$trend   = $this->trend;
$categoryTrend = $this->categoryTrend;

/**
 * This is an aggregate overview, not a row-per-record CRUD list - drill
 * into Data Entries or the NC reports to change the underlying data.
 */

/**
 * Render a compact SVG combo chart: bars for Total Sort, a line for NC Qty,
 * scaled to two independent axes so both stay readable together.
 *
 * @param   array    $points  Trend points: { label, sort, nc, nc_pct }.
 * @param   integer  $width   Chart width in px.
 * @param   integer  $height  Chart height in px.
 *
 * @return  string  Raw SVG markup.
 */
if (!function_exists('comDataSiteRenderTrendChart')) {
	function comDataSiteRenderTrendChart($points, $width = 900, $height = 260)
	{
		$count = count($points);

		if ($count === 0) {
			return '';
		}

		$maxSort = max(1, max(array_column($points, 'sort')));
		$maxNc   = max(1, max(array_column($points, 'nc')));

		$maxLabelText = number_format($maxSort);
		$padLeft      = max(46, (strlen($maxLabelText) * 7) + 16);

		// $padLeft   = 70;
		$padRight  = 16;
		$padTop    = 16;
		$padBottom = 34;
		$plotW     = $width - $padLeft - $padRight;
		$plotH     = $height - $padTop - $padBottom;

		$slot     = $plotW / $count;
		$barWidth = min(28, $slot * 0.5);

		$bars    = '';
		$linePts = array();
		$labels  = '';
		$labelStep = (int) ceil($count / 12);

		foreach ($points as $i => $p) {
			$cx = $padLeft + ($slot * $i) + ($slot / 2);

			$barH = $maxSort > 0 ? ($p->sort / $maxSort) * $plotH : 0;
			$barX = $cx - ($barWidth / 2);
			$barY = $padTop + $plotH - $barH;

			$bars .= sprintf(
				'<rect x="%.1f" y="%.1f" width="%.1f" height="%.1f" rx="2" fill="var(--com-data-bar)"><title>%s — Sort: %s</title></rect>',
				$barX,
				$barY,
				$barWidth,
				$barH,
				htmlspecialchars($p->label, ENT_QUOTES),
				number_format($p->sort)
			);

			$ncY = $padTop + $plotH - ($maxNc > 0 ? ($p->nc / $maxNc) * $plotH : 0);
			$linePts[] = array('x' => $cx, 'y' => $ncY, 'p' => $p);

			if ($i % $labelStep === 0 || $i === $count - 1) {
				$labelLines = preg_split('/\s+(?=\()/', $p->label, 2);

				$labels .= sprintf(
					'<text x="%.1f" y="%d" class="com-data-axis-label" text-anchor="middle">',
					$cx,
					$height - 16
				);

				foreach ($labelLines as $li => $line) {
					$labels .= sprintf(
						'<tspan x="%.1f" dy="%s">%s</tspan>',
						$cx,
						$li === 0 ? '0' : '12',
						htmlspecialchars($line, ENT_QUOTES)
					);
				}

				$labels .= '</text>';
			}
		}

		$linePath = '';

		foreach ($linePts as $i => $pt) {
			$linePath .= ($i === 0 ? 'M' : 'L') . sprintf('%.1f,%.1f ', $pt['x'], $pt['y']);
		}

		$dots = '';

		foreach ($linePts as $pt) {
			$dots .= sprintf(
				'<circle cx="%.1f" cy="%.1f" r="3.5" fill="var(--com-data-line)"><title>%s — NC: %s (%.1f%%)</title></circle>',
				$pt['x'],
				$pt['y'],
				htmlspecialchars($pt['p']->label, ENT_QUOTES),
				number_format($pt['p']->nc),
				$pt['p']->nc_pct
			);
		}

		$grid = '';

		foreach (array(0, 0.5, 1) as $frac) {
			$y = $padTop + $plotH - ($plotH * $frac);
			$grid .= sprintf(
				'<line x1="%d" y1="%.1f" x2="%d" y2="%.1f" class="com-data-gridline" />',
				$padLeft,
				$y,
				$width - $padRight,
				$y
			);
			$grid .= sprintf(
				'<text x="%d" y="%.1f" class="com-data-axis-label" text-anchor="end">%s</text>',
				$padLeft - 6,
				$y + 4,
				number_format($maxSort * $frac)
			);
		}


		return sprintf(
			'<svg viewBox="0 0 %d %d" width="%d" height="%d" class="com-data-chart" role="img" aria-label="Total Sort and NC trend">%s%s<path d="%s" fill="none" stroke="var(--com-data-line)" stroke-width="2" />%s%s</svg>',
			$width,
			$height,
			$width,
			$height,
			$grid,
			$bars,
			trim($linePath),
			$dots,
			$labels
		);
	}
}

if (!function_exists('comDataSiteRenderCategoryTrendChart')) {
	function comDataSiteRenderCategoryTrendChart($buckets, $categories, $width = 900, $height = 300, $axisTitleText = 'Total NC (Count)')
	{
		$count = count($buckets);

		if ($count === 0) {
			return '';
		}

		$palette = array('#0C447C', '#ef8460', '#7fab5b', '#d76e91', '#b37ec3', '#5F5E5A');

		// $padLeft   = 46;
		$padRight  = 16;
		$padTop    = 16;
		$padBottom = 34;
		// $plotW     = $width - $padLeft - $padRight;
		$plotH     = $height - $padTop - $padBottom;

		$totals = array();

		foreach ($buckets as $b) {
			$totals[] = $b->total_nc;
		}

		$maxVal = max(1, max($totals));

		foreach ($categories as $cat) {
			foreach ($cat->values as $v) {
				$maxVal = max($maxVal, $v->qty);
			}
		}

		$maxLabelText = number_format($maxVal);
		$padLeft      = max(60, (strlen($maxLabelText) * 7) + 16);
		$plotW        = $width - $padLeft - $padRight;

		$slot     = $plotW / $count;
		$barWidth = min(28, $slot * 0.5);

		$bars      = '';
		$labels    = '';
		$labelStep = (int) ceil($count / 12);

		foreach ($buckets as $i => $b) {
			$cx   = $padLeft + ($slot * $i) + ($slot / 2);
			$barH = $maxVal > 0 ? ($b->total_nc / $maxVal) * $plotH : 0;
			$barX = $cx - ($barWidth / 2);
			$barY = $padTop + $plotH - $barH;

			$bars .= sprintf(
				'<rect
					x="%.1f"
					y="%.1f"
					width="%.1f"
					height="%.1f"
					rx="2"
					fill="var(--com-data-bar)"
					class="com-data-cat-bar"
					data-label="%s"
					data-sort="%s"
					data-nc="%s"
					data-rate="%.2f">
				</rect>',
				$barX,
				$barY,
				$barWidth,
				$barH,
				htmlspecialchars($b->label, ENT_QUOTES),
				number_format($b->sort),
				number_format($b->total_nc),
				$b->nc_rate
			);

			if ($i % $labelStep === 0 || $i === $count - 1) {
				$labelLines = preg_split('/\s+(?=\()/', $b->label, 2);


				$labels .= sprintf(
					'<text x="%.1f" y="%d" class="com-data-axis-label" text-anchor="middle">',
					$cx,
					$height - 16
				);

				foreach ($labelLines as $li => $line) {
					$labels .= sprintf(
						'<tspan x="%.1f" dy="%s">%s</tspan>',
						$cx,
						$li === 0 ? '0' : '12',
						htmlspecialchars($line, ENT_QUOTES)
					);
				}

				$labels .= '</text>';
			}
		}

		$lines = '';

		foreach ($categories as $ci => $cat) {
			$color = $palette[$ci % count($palette)];
			$path  = '';
			$dots  = '';

			foreach ($cat->values as $i => $v) {
				$cx = $padLeft + ($slot * $i) + ($slot / 2);
				$cy = $padTop + $plotH - ($maxVal > 0 ? ($v->qty / $maxVal) * $plotH : 0);

				$path .= ($i === 0 ? 'M' : 'L') . sprintf('%.1f,%.1f ', $cx, $cy);
				$dots .= sprintf(
					'<circle
						cx="%.1f"
						cy="%.1f"
						r="4"
						fill="%s"
						class="com-data-cat-dot"
						data-label="%s"
						data-category="%s"
						data-nc="%s"
						data-rate="%.2f">
					</circle>
					<circle
						cx="%.1f"
						cy="%.1f"
						r="14"
						fill="transparent"
						class="com-data-cat-hit"
						data-label="%s"
						data-category="%s"
						data-nc="%s"
						data-rate="%.2f">
					</circle>',
					$cx,
					$cy,
					$color,
					htmlspecialchars($buckets[$i]->label, ENT_QUOTES),
					htmlspecialchars($cat->label, ENT_QUOTES),
					number_format($v->qty),
					$v->rate,
					$cx,
					$cy,
					htmlspecialchars($buckets[$i]->label, ENT_QUOTES),
					htmlspecialchars($cat->label, ENT_QUOTES),
					number_format($v->qty),
					$v->rate
				);
			}

			$lines .= sprintf(
				'<g class="com-data-cat-group" data-cat-index="%d"><path d="%s" fill="none" stroke="%s" stroke-width="2" />%s</g>',
				$ci,
				trim($path),
				$color,
				$dots
			);
		}

		$grid = '';

		foreach (array(0, 0.5, 1) as $frac) {
			$y = $padTop + $plotH - ($plotH * $frac);
			$grid .= sprintf('<line x1="%d" y1="%.1f" x2="%d" y2="%.1f" class="com-data-gridline" />', $padLeft, $y, $width - $padRight, $y);
			$grid .= sprintf('<text x="%d" y="%.1f" class="com-data-axis-label" text-anchor="end">%s</text>', $padLeft - 6, $y + 4, number_format($maxVal * $frac));
		}

		$axisTitle = sprintf(
			'<text x="16" y="%d" class="com-data-axis-title" text-anchor="middle" transform="rotate(-90, 16, %d)">%s</text>',
			$padTop + ($plotH / 2),
			$padTop + ($plotH / 2),
			htmlspecialchars($axisTitleText, ENT_QUOTES)
		);

		return sprintf(
			'<svg viewBox="0 0 %d %d" width="%d" height="%d" class="com-data-chart" role="img" aria-label="Total NC and category trend">%s%s%s%s%s</svg>',
			$width,
			$height,
			$width,
			$height,
			$grid,
			$axisTitle,
			$bars,
			$lines,
			$labels
		);
	}
}

/**
 * Render a compact horizontal bar chart for the NC category breakdown.
 *
 * @param   array  $rows  { nc_category, qty, pct_of_nc }
 *
 * @return  string  Raw SVG/HTML markup.
 */
if (!function_exists('comDataSiteRenderCategoryBars')) {
	function comDataSiteRenderCategoryBars($rows)
	{
		if (empty($rows)) {
			return '';
		}

		$max  = max(array_column($rows, 'qty'));
		$html = '<div class="com-data-hbars">';

		foreach ($rows as $row) {
			$pct = $max > 0 ? ($row->qty / $max) * 100 : 0;
			$html .= sprintf(
				'<div class="com-data-hbar-row">
				<div class="com-data-hbar-label" title="%1$s">%1$s</div>
				<div class="com-data-hbar-track"><div class="com-data-hbar-fill" style="width:%2$.1f%%"></div></div>
				<div class="com-data-hbar-value">%3$s</div>
				<div class="com-data-hbar-value">%4$.2f%%</div>
			</div>',
				htmlspecialchars($row->nc_category, ENT_QUOTES),
				$pct,
				number_format($row->qty),
				$row->pct_of_nc
				// $row->pct_of_impact
			);
		}

		$html .= '</div>';

		return $html;
	}
}

/**
 * Render a compact horizontal bar chart for the NC type breakdown.
 *
 * @param   array  $rows  { nc_type, qty, pct_of_nc }
 *
 * @return  string  Raw SVG/HTML markup.
 */
if (!function_exists('comDataSiteRenderNcTypeBars')) {
	function comDataSiteRenderNcTypeBars($rows)
	{
		if (empty($rows)) {
			return '';
		}

		$max  = max(array_column($rows, 'qty'));
		$html = '<div class="com-data-hbars">';

		foreach ($rows as $row) {
			$pct = $max > 0 ? ($row->qty / $max) * 100 : 0;
			$html .= sprintf(
				'<div class="com-data-hbar-type-row">
				<div class="com-data-hbar-label" title="%1$s">%1$s</div>
				<div class="com-data-hbar-track"><div class="com-data-hbar-type-fill" style="width:%2$.1f%%"></div></div>
				<div class="com-data-hbar-value">%3$s</div>
				<div class="com-data-hbar-value">%4$.2f%%</div>
			</div>',
				htmlspecialchars($row->nc_type, ENT_QUOTES),
				$pct,
				number_format($row->qty),
				$row->pct_of_nc
				// $row->pct_of_impact
			);
		}

		$html .= '</div>';

		return $html;
	}
}


/**
 * Status class for an NC% value.
 *
 * @param   float  $pct  The NC percentage.
 *
 * @return  string
 */
if (!function_exists('comDataSiteNcStatusClass')) {
	function comDataSiteNcStatusClass($pct)
	{
		$params = ComponentHelper::getParams('com_data');

		$dangerThreshold = (float) $params->get('danger_ncpct_threshold');
		$warningThreshold = (float) $params->get('warning_ncpct_threshold');

		if ($pct > $dangerThreshold) {
			return 'is-danger';
		}

		if ($pct > $warningThreshold) {
			return 'is-warning';
		}

		return 'is-good';
	}
}

?>

<div class="com-data-dashboard">

	<?php if ($this->params->get('show_page_heading')) : ?>
		<div class="page-header">
			<h1><?php echo $this->escape($this->params->get('page_heading')); ?></h1>
		</div>
	<?php endif; ?>

	<?php
	$userFullname  = $user->get('name');
	?>
	<div class="welcome-banner">
		<i class="fas fa-user-circle welcome-icon"></i>
		<span class="welcome-text">Welcome, <strong><?php echo $userFullname; ?></strong>!</span>
	</div>

	<form action="<?php echo Route::_('index.php?option=com_data&view=dashboard'); ?>" method="post" name="adminForm" id="adminForm">

		<div class="ncreport-header mb-4">
			<h1 class="ncreport-header__title"><?php echo Text::_('COM_DATA_TITLE_DASHBOARD'); ?></h1>
			<p class="ncreport-header__subtitle"><?php echo Text::_('COM_DATA_DASHBOARD_SUBTITLE'); ?></p>
			<p class="text-muted">
				<?php echo Text::sprintf('COM_DATA_DASHBOARD_RANGE_SUBTITLE', $this->escape($filters->date_from), $this->escape($filters->date_to), (int) $filters->day_span); ?>
			</p>
		</div>

		<div class="selectors row">
			<div class="selector col-md-4">
				<label><?php echo Text::_('COM_DATA_MODELSUMMARY_PERIOD_TYPE'); ?></label>
				<div class="btn-group d-block" role="group">
					<input type="radio" class="btn-check" name="filter_period_type" id="period_month" value="month"
						<?php echo $filters->period_type === 'month' ? 'checked' : ''; ?> onchange="this.form.submit();">
					<label class="btn btn-period" for="period_month"><?php echo Text::_('COM_DATA_MODELSUMMARY_MONTH'); ?></label>

					<input type="radio" class="btn-check" name="filter_period_type" id="period_week" value="week"
						<?php echo $filters->period_type === 'week' ? 'checked' : ''; ?> onchange="this.form.submit();">
					<label class="btn btn-period" for="period_week"><?php echo Text::_('COM_DATA_MODELSUMMARY_WEEK'); ?></label>

					<input type="radio" class="btn-check" name="filter_period_type" id="period_date" value="custom"
						<?php echo $filters->period_type === 'custom' ? 'checked' : ''; ?> onchange="this.form.submit();">
					<label class="btn btn-period" for="period_date"><?php echo Text::_('COM_DATA_MODELSUMMARY_DATE'); ?></label>
				</div>
			</div>

			<div class="selector col-md-4">
				<?php if ($filters->period_type === 'week') : ?>
					<label for="filter_year"><?php echo Text::_('COM_DATA_MODELSUMMARY_YEAR_SELECTOR'); ?></label>
					<select name="filter_year" id="filter_year" class="form-select" onchange="this.form.submit();">
						<?php foreach ($this->yearOptions as $yearOption) : ?>
							<option value="<?php echo (int) $yearOption; ?>" <?php echo (int) $filters->year === (int) $yearOption ? 'selected="selected"' : ''; ?>>
								<?php echo (int) $yearOption; ?>
							</option>
						<?php endforeach; ?>
					</select>

					<div style="padding-top:10px;">
						<label for="filter_week">
							<?php echo Text::_('COM_DATA_NCREPORT_WEEK_SELECTOR'); ?>
						</label>

						<select name="filter_week" id="filter_week" class="form-select" onchange="this.form.submit();">
							<?php foreach ($this->weekOptions as $weekOption) : ?>
								<option value="<?php echo (string) $weekOption->value; ?>"
									<?php echo (string) $filters->week === (string) $weekOption->value ? 'selected="selected"' : ''; ?>>
									<?php echo $weekOption->value === 'all'
										? $this->escape($weekOption->label)
										: Text::sprintf('COM_DATA_NCREPORT_WEEK_N', $weekOption->value, $weekOption->label); ?>
								</option>
							<?php endforeach; ?>
						</select>
					</div>

				<?php elseif ($filters->period_type === 'month') : ?>
					<label for="filter_year"><?php echo Text::_('COM_DATA_MODELSUMMARY_YEAR_SELECTOR'); ?></label>
					<select name="filter_year" id="filter_year" class="form-select" onchange="this.form.submit();">
						<?php foreach ($this->yearOptions as $yearOption) : ?>
							<option value="<?php echo (int) $yearOption; ?>" <?php echo (int) $filters->year === (int) $yearOption ? 'selected="selected"' : ''; ?>>
								<?php echo (int) $yearOption; ?>
							</option>
						<?php endforeach; ?>
					</select>

					<div style="padding-top:10px;">
						<label for="filter_month">
							<?php echo Text::_('COM_DATA_MODELSUMMARY_MONTH_SELECTOR'); ?>
						</label>

						<select name="filter_month" id="filter_month" class="form-select" onchange="this.form.submit();">
							<?php foreach ($this->monthOptions as $monthOption) : ?>
								<option value="<?php echo $this->escape((string) $monthOption->value); ?>"
									<?php echo (string) $filters->month === (string) $monthOption->value ? 'selected="selected"' : ''; ?>>
									<?php echo $this->escape($monthOption->label); ?>
								</option>
							<?php endforeach; ?>
						</select>
					</div>

				<?php elseif ($filters->period_type === 'custom') : ?>
					<div style="padding-top:10px;">
						<label for="filter_date_from">
							<?php echo Text::_('COM_DATA_DASHBOARD_DATE_FROM'); ?>
						</label>
						<input type="date" name="filter_date_from" id="filter_date_from" class="form-control"
							value="<?php echo $this->escape($filters->date_from); ?>" onchange="this.form.submit();" />
					</div>

					<div style="padding-top:10px;">
						<label for="filter_date_to">
							<?php echo Text::_('COM_DATA_DASHBOARD_DATE_TO'); ?>
						</label>
						<input type="date" name="filter_date_to" id="filter_date_to" class="form-control"
							value="<?php echo $this->escape($filters->date_to); ?>" onchange="this.form.submit();" />
					</div>
				<?php endif; ?>
			</div>
		</div>

		<!-- All Dashboard Filters -->
		<div id="dashboard-filters">
			<div class="selectors row">
				<div class="selector col-md-3">
					<label for="filter_part"><?php echo Text::_('COM_DATA_MODELSUMMARY_PART_SELECTOR'); ?></label>
					<select name="filter_part" id="filter_part" class="form-select js-choices" onchange="this.form.submit();">
						<option value=""><?php echo Text::_('COM_DATA_MODELSUMMARY_ALL_PARTS'); ?></option>
						<?php foreach ($this->partOptions as $partOption) : ?>
							<option value="<?php echo $this->escape($partOption->value); ?>" <?php echo (string) $filters->part === (string) $partOption->value ? 'selected="selected"' : ''; ?>>
								<?php echo $this->escape($partOption->text); ?>
							</option>
						<?php endforeach; ?>
					</select>
					<div style="padding-top: 20px" ;>
						<label for="filter_model"><?php echo Text::_('COM_DATA_DASHBOARD_MODEL_SELECTOR'); ?></label>
						<select name="filter_model" id="filter_model" class="form-select js-choices" onchange="this.form.submit();">
							<option value=""><?php echo Text::_('COM_DATA_DASHBOARD_ALL_MODELS'); ?></option>
							<?php foreach ($this->modelOptions as $modelOption) : ?>
								<option value="<?php echo $this->escape($modelOption->value); ?>" <?php echo (string) $filters->model === (string) $modelOption->value ? 'selected="selected"' : ''; ?>>
									<?php echo $this->escape($modelOption->text); ?>
								</option>
							<?php endforeach; ?>
						</select>
					</div>
				</div>

				<div class="selector col-md-3">
					<label for="filter_vendor"><?php echo Text::_('COM_DATA_DASHBOARD_VENDOR_SELECTOR'); ?></label>
					<select name="filter_vendor" id="filter_vendor" class="form-select" onchange="this.form.submit();">
						<option value=""><?php echo Text::_('COM_DATA_DASHBOARD_ALL_VENDORS'); ?></option>
						<?php foreach ($this->vendorOptions as $vendorOption) : ?>
							<option value="<?php echo $this->escape($vendorOption->key); ?>" <?php echo (string) $filters->vendor === (string) $vendorOption->key ? 'selected="selected"' : ''; ?>>
								<?php echo $this->escape($vendorOption->value); ?>
							</option>
						<?php endforeach; ?>
					</select>
					<div style="padding-top: 20px" ;>
						<label for="filter_lot"><?php echo Text::_('COM_DATA_NCREPORT_LOT_SELECTOR'); ?></label>
						<select name="filter_lot" id="filter_lot" class="form-select" onchange="this.form.submit();">
							<option value=""><?php echo Text::_('COM_DATA_NCREPORT_ALL_LOT'); ?></option>
							<?php foreach ($this->lotOptions as $lotOption) : ?>
								<option value="<?php echo $this->escape($lotOption->value); ?>" <?php echo (string) $filters->lot === (string) $lotOption->value ? 'selected="selected"' : ''; ?>>
									<?php echo $this->escape($lotOption->text); ?>
								</option>
							<?php endforeach; ?>
						</select>
					</div>
				</div>
				<div class="selector col-md-3">
					<label for="filter_remark"><?php echo Text::_('COM_DATA_NCREPORT_REMARK_SELECTOR'); ?></label>
					<select name="filter_remark" id="filter_remark" class="form-select" onchange="this.form.submit();">
						<option value=""><?php echo Text::_('COM_DATA_NCREPORT_ALL_REMARKS'); ?></option>
						<?php foreach ($this->remarkOptions as $remarkKey => $remarkLabel) : ?>
							<option value="<?php echo $this->escape($remarkKey); ?>" <?php echo (string) $filters->remark === (string) $remarkKey ? 'selected="selected"' : ''; ?>>
								<?php echo $this->escape($remarkLabel); ?>
							</option>
						<?php endforeach; ?>
					</select>
					<div style="padding-top: 20px" ;>
						<label for="filter_operator"><?php echo Text::_('COM_DATA_NCREPORT_OPERATOR_SELECTOR'); ?></label>
						<select name="filter_operator" id="filter_operator" class="form-select js-choices" onchange="this.form.submit();">
							<option value=""><?php echo Text::_('COM_DATA_NCREPORT_ALL_OPERATORS'); ?></option>
							<?php foreach ($this->operatorOptions as $operatorOption) : ?>
								<option value="<?php echo $this->escape($operatorOption->key); ?>" <?php echo (string) $filters->operator === (string) $operatorOption->key ? 'selected="selected"' : ''; ?>>
									<?php echo $this->escape($operatorOption->value); ?>
								</option>
							<?php endforeach; ?>
						</select>
					</div>
				</div>
				<div class="selector col-md-3">
					<label for="filter_nc_category"><?php echo Text::_('COM_DATA_NCREPORT_NC_CATEGORY_SELECTOR'); ?></label>
					<select name="filter_nc_category" id="filter_nc_category" class="form-select" onchange="this.form.submit();">
						<option value=""><?php echo Text::_('COM_DATA_NCREPORT_ALL_NC_CATEGORIES'); ?></option>
						<?php foreach ($this->nccategoryOptions as $nccategoryOption) : ?>
							<option value="<?php echo $this->escape($nccategoryOption->value); ?>" <?php echo (string) $filters->nc_category === (string) $nccategoryOption->value ? 'selected="selected"' : ''; ?>>
								<?php echo $this->escape($nccategoryOption->text); ?>
							</option>
						<?php endforeach; ?>
					</select>
					<div style="padding-top: 20px" ;>
						<label for="filter_nc_type"><?php echo Text::_('COM_DATA_NCREPORT_NC_TYPE_SELECTOR'); ?></label>
						<select name="filter_nc_type" id="filter_nc_type" class="form-select js-choices" onchange="this.form.submit();">
							<option value=""><?php echo Text::_('COM_DATA_NCREPORT_ALL_NC_TYPES'); ?></option>
							<?php foreach ($this->nctypeOptions as $nctypeOption) : ?>
								<option value="<?php echo $this->escape($nctypeOption->value); ?>" <?php echo (string) $filters->nc_type === (string) $nctypeOption->value ? 'selected="selected"' : ''; ?>>
									<?php echo $this->escape($nctypeOption->text); ?>
								</option>
							<?php endforeach; ?>
						</select>
					</div>
				</div>
			</div>

			<div class="row mb-4">
				<div class="col-md-12 text-end">
					<button type="button" id="btn-clear-filters" class="btn btn-link btn-sm text-muted">
						<span class="icon-undo" aria-hidden="true"></span>
						<?php echo Text::_('COM_DATA_NCREPORT_CLEAR_FILTERS'); ?>
					</button>
				</div>
			</div>
		</div>

		<div class="filter-toggle-row">
			<div class="filter-toggle-title text-muted">
				<span id="filter-toggle-text">Less Filters</span>
			</div>

			<button type="button"
				id="btn-toggle-filters"
				class="filter-toggle-btn"
				aria-expanded="true"
				aria-controls="dashboard-filters">
				<span id="filter-toggle-icon" class="icon-chevron-up" aria-hidden="true"></span>
			</button>
		</div>


		<!-- Summary cards -->
		<div class="row mb-3">
			<!-- <p class="text-muted">
				<?php echo Text::sprintf('COM_DATA_DASHBOARD_RANGE_SUBTITLE', $this->escape($filters->date_from), $this->escape($filters->date_to), (int) $filters->day_span); ?>
			</p> -->
			<div class="summary-cards col-md-12 d-flex flex-wrap gap-3">
				<div class="col">
					<div class="com-data-card">
						<div class="com-data-card-label"><?php echo Text::_('COM_DATA_DASHBOARD_TOTAL_SORT'); ?></div>
						<div class="com-data-card-value"><?php echo number_format($summary->total_sort); ?></div>
					</div>
				</div>
				<div class="col">
					<div class="com-data-card">
						<div class="com-data-card-label"><?php echo Text::_('COM_DATA_DASHBOARD_TOTAL_ACCEPTED'); ?></div>
						<div class="com-data-card-value"><?php echo number_format($summary->total_accepted); ?></div>
					</div>
				</div>
				<div class="col">
					<div class="com-data-card">
						<div class="com-data-card-label"><?php echo Text::_('COM_DATA_DASHBOARD_TOTAL_NC'); ?></div>
						<div class="com-data-card-value"><?php echo number_format($summary->total_nc); ?></div>
					</div>
				</div>
				<div class="col">
					<div class="com-data-card <?php echo comDataSiteNcStatusClass($summary->total_nc_pct); ?>">
						<div class="com-data-card-label"><?php echo Text::_('COM_DATA_DASHBOARD_NC_PCT'); ?></div>
						<div class="com-data-card-value"><?php echo number_format($summary->total_nc_pct, 2); ?>%</div>
					</div>
				</div>
				<div class="col">
					<div class="com-data-card">
						<div class="com-data-card-label"><?php echo Text::_('COM_DATA_DASHBOARD_YIELD_PCT'); ?></div>
						<div class="com-data-card-value"><?php echo number_format($summary->yield_pct, 2); ?>%</div>
					</div>
				</div>
				<div class="col">
					<div class="com-data-card com-data-card-muted">
						<div class="com-data-card-label"><?php echo Text::_('COM_DATA_DASHBOARD_ENTRIES'); ?></div>
						<div class="com-data-card-value"><?php echo number_format($summary->entry_count); ?></div>
						<div class="com-data-card-sub">
							<?php echo Text::sprintf('COM_DATA_DASHBOARD_ENTRIES_SUB', (int) $summary->vendor_count, (int) $summary->model_count); ?>
						</div>
					</div>
				</div>
			</div>
		</div>

		<!-- Trend chart -->
		<div class="com-data-panel mb-4">
			<div class="com-data-panel-header">
				<h3><?php echo Text::_('COM_DATA_DASHBOARD_TREND_TITLE'); ?></h3>
			</div>

			<div class="com-data-legend" id="ncCategoryLegend">
				<span class="com-data-legend-item"><span class="com-data-swatch com-data-swatch-bar"></span> <?php echo Text::_('COM_DATA_DASHBOARD_TOTAL_NC'); ?></span>
				<?php foreach ($categoryTrend->categories as $ci => $cat) : ?>
					<?php $color = array('#0C447C', '#ef8460', '#7fab5b', '#d76e91', '#b37ec3', '#5F5E5A')[$ci % 6]; ?>
					<span class="com-data-legend-item com-data-legend-item--clickable" data-cat-index="<?php echo (int) $ci; ?>">
						<span class="com-data-swatch" style="background:<?php echo $color; ?>"></span>
						<?php echo $this->escape($cat->label); ?>
					</span>
				<?php endforeach; ?>
				<button type="button" class="com-data-legend-reset d-none" id="ncCategoryLegendReset"><?php echo Text::_('COM_DATA_DASHBOARD_SHOW_ALL'); ?></button>
			</div>

			<?php
			$mobileBucketWidth = 55; // px reserved per bucket — tune to taste
			$mobileMinWidth     = 420;
			$mobileChartWidth   = max($mobileMinWidth, count($categoryTrend->buckets) * $mobileBucketWidth);
			?>

			<?php if (empty($categoryTrend->buckets)) : ?>
				<p class="text-muted mb-0"><?php echo Text::_('COM_DATA_DASHBOARD_EMPTY'); ?></p>
			<?php else : ?>
				<div class="com-data-chart-wrap com-data-chart-wrap--desktop">
					<?php echo comDataSiteRenderCategoryTrendChart($categoryTrend->buckets, $categoryTrend->categories, 900, 300, Text::_('COM_DATA_DASHBOARD_NC_COUNT_AXIS')); ?>
					<div id="com-data-chart-tooltip" class="com-data-chart-tooltip"></div>
				</div>
				<div class="com-data-chart-wrap com-data-chart-wrap--mobile">
					<?php echo comDataSiteRenderCategoryTrendChart($categoryTrend->buckets, $categoryTrend->categories, $mobileChartWidth, 380, Text::_('COM_DATA_DASHBOARD_NC_COUNT_AXIS')); ?>
					<div id="com-data-chart-tooltip-mobile" class="com-data-chart-tooltip"></div>
				</div>
			<?php endif; ?>
		</div>
		<?php
		// --- Map the dashboard period -> a (year, month) the monthly report understands ---
		$refDate = new DateTime($filters->date_from);

		if ($filters->period_type === 'week' && $filters->week !== 'all') {
			// A week can straddle two months; use its Thursday (the ISO rule) to pick one.
			$refDate->modify('+3 days');
		}

		$wholeYear = ($filters->period_type === 'week'  && $filters->week === 'all')
			|| ($filters->period_type === 'month' && $filters->month === 'all');

		if ($wholeYear) {
			// Monthly report can't show a full year: fall back to the current month
			// (if it's the current year) or December.
			$nowKl   = Factory::getDate('now', 'Asia/Kuala_Lumpur');
			$reportYear  = (int) $filters->year;
			$reportMonth = ((int) $nowKl->format('Y') === $reportYear) ? (int) $nowKl->format('n') : 12;
		} else {
			$reportYear  = (int) $refDate->format('Y');
			$reportMonth = (int) $refDate->format('n');
		}

		$buildMonthlyReportUrl = function ($row) use ($filters, $reportYear, $reportMonth) {
			$params = array(
				'filter_part'        => $row->part_id,
				'filter_model'       => $row->entity_id,
				'filter_year'        => $reportYear,
				'filter_month'       => $reportMonth,
				// carry the other dashboard filters so the numbers match
				'filter_vendor'      => $filters->vendor,
				'filter_operator'    => $filters->operator,
				'filter_lot'         => $filters->lot,
				'filter_remark'      => $filters->remark,
				'filter_nc_category' => $filters->nc_category,
				'filter_nc_type'     => $filters->nc_type,
				'filter_search'      => '',   // reset any stale search stored in the report's session
			);

			return Route::_('index.php?option=com_data&view=ncreportmonthly&' . http_build_query($params));
		};
		?>
		<div class="row">
			<!-- Models -->
			<div class="col-lg-7 mb-4">
				<div class="com-data-panel h-100">
					<div class="com-data-panel-header">
						<h3><?php echo Text::_('COM_DATA_DASHBOARD_MODEL_TITLE'); ?></h3>
					</div>
					<?php if (empty($this->modelBreakdown->rows)) : ?>
						<p class="text-muted mb-0"><?php echo Text::_('COM_DATA_DASHBOARD_EMPTY'); ?></p>
					<?php else : ?>
						<table class="table table-sm com-data-mini-table">
							<thead>
								<tr>
									<th><?php echo Text::_('COM_DATA_ENTRIES_COMPONENT'); ?></th>
									<th><?php echo Text::_('COM_DATA_ENTRIES_MODEL'); ?></th>
									<th class="text-end"><?php echo Text::_('COM_DATA_DASHBOARD_TOTAL_SORT'); ?></th>
									<th class="text-end"><?php echo Text::_('COM_DATA_DASHBOARD_TOTAL_NC'); ?></th>
									<th class="text-end"><?php echo Text::_('COM_DATA_DASHBOARD_NC_PCT'); ?></th>
								</tr>
							</thead>
							<tbody>
								<?php foreach ($this->modelBreakdown->rows as $row) : ?>
									<?php $reportUrl = $buildMonthlyReportUrl($row); ?>
									<tr class="com-data-clickable-row" data-href="<?php echo $this->escape($reportUrl); ?>">
										<td><?php echo $this->escape($row->part_label ?? ''); ?></td>
										<td>
											<a href="<?php echo $this->escape($reportUrl); ?>" class="text-reset text-decoration-none">
												<?php echo $this->escape($row->label); ?>
											</a>
										</td>
										<td class="text-end"><?php echo number_format($row->total_sort); ?></td>
										<td class="text-end"><?php echo number_format($row->total_nc); ?></td>
										<td class="text-end">
											<span class="com-data-pill <?php echo comDataSiteNcStatusClass($row->nc_pct); ?>"><?php echo number_format($row->nc_pct, 2); ?>%</span>
										</td>
									</tr>
								<?php endforeach; ?>
							</tbody>
						</table>
					<?php endif; ?>
				</div>
			</div>

			<!-- Vendors -->
			<div class="col-lg-5 mb-4">
				<div class="com-data-panel h-100">

					<div class="com-data-panel-header">
						<h3><?php echo Text::_('COM_DATA_DASHBOARD_VENDOR_TITLE'); ?></h3>
					</div>
					<?php if (empty($this->vendorBreakdown->rows)) : ?>
						<p class="text-muted mb-0"><?php echo Text::_('COM_DATA_DASHBOARD_EMPTY'); ?></p>
					<?php else : ?>
						<table class="table table-sm com-data-mini-table">
							<thead>
								<tr>
									<th><?php echo Text::_('COM_DATA_ENTRIES_VENDOR'); ?></th>
									<th class="text-end"><?php echo Text::_('COM_DATA_DASHBOARD_TOTAL_SORT'); ?></th>
									<th class="text-end"><?php echo Text::_('COM_DATA_DASHBOARD_TOTAL_NC'); ?></th>
									<th class="text-end"><?php echo Text::_('COM_DATA_DASHBOARD_NC_PCT'); ?></th>
								</tr>
							</thead>
							<tbody>
								<?php foreach ($this->vendorBreakdown->rows as $row) : ?>
									<tr>
										<td><?php echo $this->escape($row->label); ?></td>
										<td class="text-end"><?php echo number_format($row->total_sort); ?></td>
										<td class="text-end"><?php echo number_format($row->total_nc); ?></td>
										<td class="text-end">
											<span class="com-data-pill <?php echo comDataSiteNcStatusClass($row->nc_pct); ?>"><?php echo number_format($row->nc_pct, 2); ?>%</span>
										</td>
									</tr>
								<?php endforeach; ?>
							</tbody>
						</table>
					<?php endif; ?>
				</div>
			</div>
		</div>

		<div class="row">

			<!-- NC by category -->
			<div class="col-lg-6 mb-4">
				<div class="com-data-panel h-100">
					<div class="com-data-panel-header">
						<h3><?php echo Text::_('COM_DATA_DASHBOARD_CATEGORY_TITLE'); ?></h3>
					</div>
					<?php if (empty($this->categoryBreakdown)) : ?>
						<p class="text-muted mb-0"><?php echo Text::_('COM_DATA_DASHBOARD_EMPTY'); ?></p>
					<?php else : ?>
						<div class="com-data-hbar-row-title">
							<div class="com-data-panel-category"></div>
							<div class="com-data-panel-category"><?php echo Text::_('COM_DATA_DASHBOARD_TOTAL_NC'); ?></div>
							<div class="com-data-panel-category"><?php echo Text::_('COM_DATA_DASHBOARD_NC_PCT'); ?></div>
						</div>
						<?php echo comDataSiteRenderCategoryBars($this->categoryBreakdown); ?>
					<?php endif; ?>
				</div>
			</div>

			<!-- NC by nc type -->
			<div class="col-lg-6 mb-4">
				<div class="com-data-panel h-100">
					<div class="com-data-panel-header">
						<h3><?php echo Text::_('COM_DATA_DASHBOARD_TYPE_TITLE'); ?></h3>
					</div>
					<?php if (empty($this->ncTypeBreakdown)) : ?>
						<p class="text-muted mb-0"><?php echo Text::_('COM_DATA_DASHBOARD_EMPTY'); ?></p>
					<?php else : ?>
						<div class="com-data-hbar-row-title">
							<div class="com-data-panel-category"></div>
							<div class="com-data-panel-category"><?php echo Text::_('COM_DATA_DASHBOARD_TOTAL_NC'); ?></div>
							<div class="com-data-panel-category"><?php echo Text::_('COM_DATA_DASHBOARD_NC_PCT'); ?></div>
						</div>
						<?php echo comDataSiteRenderNcTypeBars($this->ncTypeBreakdown); ?>
					<?php endif; ?>
				</div>
			</div>
		</div>

		<!-- Kokeshi -->
		<div class="com-data-panel mb-4">
			<div class="com-data-panel-header d-flex justify-content-between align-items-center">
				<h3><?php echo Text::_('COM_DATA_DASHBOARD_KOKESHI_TITLE'); ?></h3>
				<!-- <a href="<?php echo Route::_('index.php?option=com_data&view=ncentries'); ?>" class="com-data-view-more">
					<?php echo Text::_('COM_DATA_DASHBOARD_VIEW_MORE'); ?> &rarr;
				</a> -->
			</div>
			<?php if (empty($this->kokeshiEntries)) : ?>
				<p class="text-muted mb-0"><?php echo Text::_('COM_DATA_DASHBOARD_EMPTY'); ?></p>
			<?php else : ?>
				<div class="com-data-kokeshi-scroll">
					<table class="table table-sm com-data-mini-table mb-0">
						<thead>
							<tr>
								<th><?php echo Text::_('COM_DATA_ENTRIES_REFERENCE_NO'); ?></th>
								<th><?php echo Text::_('COM_DATA_ENTRIES_COMPONENT'); ?></th>
								<th><?php echo Text::_('COM_DATA_ENTRIES_MODEL'); ?></th>
								<th><?php echo Text::_('COM_DATA_ENTRIES_NC_TYPE'); ?></th>
								<th class="text-end"><?php echo Text::_('COM_DATA_DASHBOARD_TOTAL_SORT'); ?></th>
								<th class="text-end"><?php echo Text::_('COM_DATA_DASHBOARD_TOTAL_NC'); ?></th>
								<th class="text-end"><?php echo Text::_('COM_DATA_DASHBOARD_NC_PCT'); ?></th>
							</tr>
						</thead>
						<tbody>
							<?php foreach ($this->kokeshiEntries as $row) : ?>
								<tr>
									<td><?php echo $this->escape($row->reference_no); ?></td>
									<td><?php echo $this->escape($row->component); ?></td>
									<td><?php echo $this->escape($row->model); ?></td>
									<td><?php echo $this->escape($row->nc_type); ?></td>
									<td class="text-end"><?php echo number_format($row->total_sort); ?></td>
									<td class="text-end"><?php echo number_format($row->nc_quantity); ?></td>
									<td class="text-end">
										<span class="com-data-pill <?php echo comDataSiteNcStatusClass($row->nc_rate); ?>"><?php echo number_format($row->nc_rate, 2); ?>%</span>
									</td>
								</tr>
							<?php endforeach; ?>
						</tbody>
					</table>
				</div>
			<?php endif; ?>
			<div class="com-data-panel-footer">
				<p class="text-muted mb-0"><?php echo COUNT($this->kokeshiEntries) . " records"; ?></p>
			</div>
		</div>

		<input type="hidden" name="clearfilters" id="clearfilters" value="0" />
		<input type="hidden" name="option" value="com_data" />
		<input type="hidden" name="view" value="dashboard" />
	</form>
</div>

<script>
	document.addEventListener('DOMContentLoaded', function() {

		// =====================================================
		// SHOW / HIDE DASHBOARD FILTERS in script: com_data.ncreport
		// =====================================================

		// =====================================================
		// NC TREND DOT TOOLTIP
		// =====================================================

		var chartElements = document.querySelectorAll(
			'.com-data-cat-hit, .com-data-cat-bar'
		);

		chartElements.forEach(function(element) {

			element.addEventListener('click', function(e) {

				e.stopPropagation();

				document.querySelectorAll('.com-data-cat-dot').forEach(function(dot) {
					dot.classList.remove('is-selected');
					dot.setAttribute('r', '4');
				});

				var visualDot = element.classList.contains('com-data-cat-hit') ?
					element.previousElementSibling :
					null;

				if (visualDot) {
					visualDot.classList.add('is-selected');
					visualDot.setAttribute('r', '7');
				}

				var chartWrap = element.closest('.com-data-chart-wrap');
				if (!chartWrap) return;

				var tooltip = chartWrap.querySelector('.com-data-chart-tooltip');
				if (!tooltip) return;

				var label = element.getAttribute('data-label');
				var nc = element.getAttribute('data-nc');
				var rate = element.getAttribute('data-rate');
				var category = element.getAttribute('data-category');
				var sort = element.getAttribute('data-sort');

				if (element.classList.contains('com-data-cat-bar')) {
					tooltip.innerHTML =
						'<div class="tooltip-label">' + label + '</div>' +
						'<div>Total Sort: <strong>' + sort + '</strong></div>' +
						'<div>Total NC: <strong>' + nc + '</strong></div>' +
						'<div>NC Rate: <strong>' + rate + '%</strong></div>';
				} else {
					tooltip.innerHTML =
						'<div class="tooltip-category">' + category + '</div>' +
						'<div class="tooltip-label">' + label + '</div>' +
						'<div>Total NC: <strong>' + nc + '</strong></div>' +
						'<div>NC Rate: <strong>' + rate + '%</strong></div>';
				}

				// Position tooltip
				var elementRect = element.getBoundingClientRect();
				var wrapRect = chartWrap.getBoundingClientRect();

				tooltip.style.visibility = 'hidden';
				tooltip.classList.add('is-visible');

				var tooltipWidth = tooltip.offsetWidth;
				var tooltipHeight = tooltip.offsetHeight;

				var left = elementRect.left - wrapRect.left;
				var top = elementRect.top - wrapRect.top;

				var wrapWidth = chartWrap.clientWidth;
				var wrapHeight = chartWrap.clientHeight;

				// Default: show tooltip to the right
				var tooltipLeft = left + 10;

				// If too far right, show on left
				if (tooltipLeft + tooltipWidth > wrapWidth) {
					tooltipLeft = left - tooltipWidth - 10;
				}

				// Prevent going outside left
				if (tooltipLeft < 5) {
					tooltipLeft = 5;
				}

				// Show above
				var tooltipTop = top - tooltipHeight - 10;

				// If not enough space above, show below
				if (tooltipTop < 5) {
					tooltipTop = top + 10;
				}

				// Prevent going below chart
				if (tooltipTop + tooltipHeight > wrapHeight - 5) {
					tooltipTop = wrapHeight - tooltipHeight - 5;
				}

				// Convert viewport-relative coords back into the wrap's own scrollable
				// coordinate space - since the tooltip is position:absolute inside an
				// overflow-x:auto container, style.left/top are relative to the
				// UNSCROLLED content origin, not the visible viewport. Without adding
				// the current scroll offset back in, the tooltip renders shifted left
				// by exactly however far the chart has been scrolled.
				tooltip.style.left = (tooltipLeft + chartWrap.scrollLeft) + 'px';
				tooltip.style.top = (tooltipTop + chartWrap.scrollTop) + 'px';

				tooltip.style.visibility = 'visible';
			});

		});


		// Click outside the chart to close tooltip
		document.addEventListener('click', function(e) {

			if (!e.target.closest('.com-data-cat-dot, .com-data-cat-bar')) {

				document.querySelectorAll('.com-data-chart-tooltip').forEach(function(tooltip) {
					tooltip.classList.remove('is-visible');
				});

				// Remove selected dot
				document.querySelectorAll('.com-data-cat-dot').forEach(function(dot) {
					dot.classList.remove('is-selected');
					dot.setAttribute('r', '4');
				});
			}

		});

		var legend = document.getElementById('ncCategoryLegend');
		if (!legend) return;

		var resetBtn = document.getElementById('ncCategoryLegendReset');
		var items = legend.querySelectorAll('.com-data-legend-item--clickable');
		var activeIndex = null;

		function applyState() {
			var groups = document.querySelectorAll('.com-data-cat-group');

			groups.forEach(function(g) {
				var idx = g.getAttribute('data-cat-index');
				var shouldHide = activeIndex !== null && idx !== String(activeIndex);
				g.classList.toggle('is-hidden', shouldHide);
			});

			items.forEach(function(item) {
				var idx = item.getAttribute('data-cat-index');
				item.classList.toggle('is-dimmed', activeIndex !== null && idx !== String(activeIndex));
			});

			resetBtn.classList.toggle('d-none', activeIndex === null);
		}

		items.forEach(function(item) {
			item.addEventListener('click', function() {
				var idx = item.getAttribute('data-cat-index');
				activeIndex = (activeIndex === idx) ? null : idx;
				applyState();
			});
		});

		resetBtn.addEventListener('click', function() {
			activeIndex = null;
			applyState();
		});

		document.querySelectorAll('.com-data-clickable-row').forEach(function(tr) {
			tr.addEventListener('click', function(e) {
				if (e.target.closest('a')) return; // let the real link handle itself
				window.location.href = tr.dataset.href;
			});
		});
	});
</script>