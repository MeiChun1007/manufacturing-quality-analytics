<?php

/**
 * @version    CVS: 1.0.0
 * @package    Com_Data
 * @author     Mei Chun <qc.yolotech@gmail.com>
 * @copyright  2026 YOLO
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */
// No direct access
defined('_JEXEC') or die;

use \Joomla\CMS\HTML\HTMLHelper;
use \Joomla\CMS\Factory;
use \Joomla\CMS\Uri\Uri;
use \Joomla\CMS\Router\Route;
use \Joomla\CMS\Language\Text;
use \Data\Component\Data\Site\Helper\DataHelper;

$wa = $this->document->getWebAssetManager();
$wa->useScript('keepalive')
	->useScript('form.validate');
HTMLHelper::_('bootstrap.tooltip');
$wa->useScript('jquery');

// Load admin language file
$lang = Factory::getLanguage();
$lang->load('com_data', JPATH_SITE);

$user    = Factory::getApplication()->getIdentity();
$canEdit = DataHelper::canUserEdit($this->item, $user);

// Resolve the existing (single) selected IDs for the cascading fields, so we can
// re-populate & re-select the correct dependent options on page load (edit mode).
// component/model/vendor/remark may be stored as arrays (multi-value support),
// so just take the first value for the purpose of driving the cascade.
$existingComponentId = '';
if (isset($this->item->component)) {
	$componentVal = $this->item->component;
	$existingComponentId = is_array($componentVal) ? (reset($componentVal) ?: '') : $componentVal;
}

$existingModelId = '';
if (isset($this->item->model)) {
	$modelVal = $this->item->model;
	$existingModelId = is_array($modelVal) ? (reset($modelVal) ?: '') : $modelVal;
}

$existingVendorId = '';
if (isset($this->item->vendor)) {
	$vendorVal = $this->item->vendor;
	$existingVendorId = is_array($vendorVal) ? (reset($vendorVal) ?: '') : $vendorVal;
}

$existingRemarkId = '';
if (isset($this->item->remark)) {
	$remarkVal = $this->item->remark;
	$existingRemarkId = is_array($remarkVal) ? (reset($remarkVal) ?: '') : $remarkVal;
}

// Adjust columns horizontally and force Choices.js dropdown container to expand
$this->document->addStyleDeclaration('
    /* 1. Allocate widths to the layout columns (Headers & Cells) */
    .options-form table th:nth-child(1),
    .options-form table td:nth-child(1) {
        width: 65% !important;
    }
    .options-form table th:nth-child(2),
    .options-form table td:nth-child(2) {
        width: 15% !important;
    }
    .options-form table th:nth-child(3),
    .options-form table td:nth-child(3) {
        width: 20% !important;
        text-align: center;
    }

    /* 2. FORCE Joomla wrappers and Choices.js to stretch to the 55% cell width */
    .options-form table td joomla-field-fancy-select,
    .options-form table td .choices,
    .options-form table td .choices__inner,
    .options-form table td select,
    .options-form table td input {
        width: 100% !important;
        max-width: 100% !important;
        min-width: 100% !important;
        display: block !important;
        box-sizing: border-box !important;
    }

	.subform-repeatable .table-responsive {
    overflow-x: unset;
	}

	.subform-repeatable .choices__list--dropdown {
	max-height:unset;
	}
');

?>

<div class="entry-edit front-end-edit">

	<?php if ($this->params->get('show_page_heading')) : ?>
		<div class="page-header">
			<h1> <?php echo $this->escape($this->params->get('page_heading')); ?> </h1>
		</div>
	<?php endif; ?>
	<?php if (!$canEdit) : ?>
		<h3>
			<?php throw new \Exception(Text::_('COM_DATA_ERROR_MESSAGE_NOT_AUTHORISED'), 403); ?>
		</h3>
	<?php else : ?>
		<?php if (!empty($this->item->id)): ?>
			<h1><?php echo Text::sprintf('COM_DATA_EDIT_ITEM_TITLE', $this->item->id); ?></h1>
		<?php else: ?>
			<h1><?php echo Text::_('COM_DATA_ADD_ITEM_TITLE'); ?></h1>
		<?php endif; ?>

		<form id="form-entry"
			action="<?php echo Route::_('index.php?option=com_data&task=entryform.save'); ?>"
			method="post" class="form-validate form-horizontal" enctype="multipart/form-data">

			<input type="hidden" name="jform[id]" value="<?php echo isset($this->item->id) ? $this->item->id : ''; ?>" />
			<input type="hidden" name="jform[state]" value="<?php echo isset($this->item->state) ? $this->item->state : ''; ?>" />
			<input type="hidden" name="submit_token" value="<?php echo $this->escape($this->submitToken); ?>">

			<!-- <?php echo $this->form->getInput('created_by'); ?> -->
			<?php echo $this->form->getInput('modified_by'); ?>

			<!-- Fieldset 1: Main Data Entry Details -->
			<fieldset class="options-form mb-4">
				<legend class="border-bottom pb-2 mb-3"><?php echo Text::_('COM_DATA_TAB_ENTRY'); ?></legend>
				<strong><?php echo $this->form->renderField('reference_no'); ?></strong>
				<?php echo $this->form->renderField('created_by'); ?>
				<?php echo $this->form->renderField('date'); ?>
				<?php echo $this->form->renderField('week'); ?>
				<?php echo $this->form->renderField('operator'); ?>
				<?php echo $this->form->renderField('component'); ?>
				<?php echo $this->form->renderField('model'); ?>
				<?php echo $this->form->renderField('vendor'); ?>
				<?php echo $this->form->renderField('remark'); ?>
				<?php echo $this->form->renderField('total'); ?>
				<?php echo $this->form->renderField('lot'); ?>
				<?php echo $this->form->renderField('resort_nc'); ?>
				<?php echo $this->form->renderField('work_order_no'); ?>
			</fieldset>

			<!-- Fieldset 2: Non-Conformance (NC) Entries -->
			<fieldset class="options-form mb-4">
				<legend class="border-bottom pb-2 mb-3"><?php echo Text::_('COM_DATA_TAB_NC_ENTRIES'); ?></legend>

				<?php echo $this->form->renderField('nc_entries'); ?>
			</fieldset>

			<div class="control-group">

				<div class="controls d-flex justify-content-end" style="gap: 3px;">
					<a class="btn btn-danger"
						href="<?php echo Route::_('index.php?option=com_data&task=entryform.cancel'); ?>"
						title="<?php echo Text::_('JCANCEL'); ?>">
						<span class="fas fa-times" aria-hidden="true"></span>
						<?php echo Text::_('JCANCEL'); ?>
					</a>
					<?php if ($this->canSave): ?>
						<button type="submit" class="validate btn btn-primary">
							<span class="fas fa-check" aria-hidden="true"></span>
							<?php echo Text::_('JSUBMIT'); ?>
						</button>
					<?php endif; ?>
				</div>
			</div>

			<input type="hidden" name="option" value="com_data" />
			<input type="hidden" name="task"
				value="entryform.save" />
			<?php echo HTMLHelper::_('form.token'); ?>
		</form>
	<?php endif; ?>
</div>

<script>
	document.addEventListener('DOMContentLoaded', function() {

		// Existing saved IDs (edit mode) — empty strings on the Add form
		const existingComponentId = <?php echo json_encode((string) $existingComponentId); ?>;
		const existingModelId = <?php echo json_encode((string) $existingModelId); ?>;
		const existingVendorId = <?php echo json_encode((string) $existingVendorId); ?>;
		const existingRemarkId = <?php echo json_encode((string) $existingRemarkId); ?>;

		// Debug: confirm the PHP-resolved values are reaching the client correctly
		console.log('existingComponentId:', existingComponentId);
		console.log('existingModelId:', existingModelId);
		console.log('existingVendorId:', existingVendorId);
		console.log('existingRemarkId:', existingRemarkId);

		/**
		 * Fetch and populate the Model dropdown for a given Component.
		 * If selectedModelId is provided, that option is pre-selected
		 * (used on page load to restore the saved value).
		 */
		function populateModelField(componentId, selectedModelId) {
			selectedModelId = selectedModelId || '';

			const modelField = document.querySelector('select[name="jform[model]"]');
			if (!modelField) {
				console.error("Could not find the model select element by name attribute.");
				return;
			}

			const modelWrapper = modelField.closest('joomla-field-fancy-select');

			modelField.innerHTML = '<option value="">Select Model</option>';

			if (modelWrapper && modelWrapper.choicesInstance) {
				modelWrapper.choicesInstance.clearChoices();
				modelWrapper.choicesInstance.setChoices([{
					value: '',
					label: 'Select Model',
					selected: true
				}], 'value', 'label', true);
			}

			if (!componentId) return;

			fetch(`index.php?option=com_data&task=entry.getModelsByComponent&component_id=${componentId}&format=json`)
				.then(response => response.json())
				.then(data => {
					if (data && data.success && data.data) {

						data.data.forEach(model => {
							const option = new Option(model.value, model.key);
							if (String(model.key) === String(selectedModelId)) {
								option.selected = true;
							}
							modelField.add(option);
						});

						if (modelWrapper && modelWrapper.choicesInstance) {
							const newChoices = data.data.map(m => ({
								value: String(m.key),
								label: String(m.value),
								selected: String(m.key) === String(selectedModelId)
							}));

							modelWrapper.choicesInstance.setChoices(newChoices, 'value', 'label', true);
						}
					}
				})
				.catch(error => console.error('Error Syncing JSON payload:', error));
		}

		/**
		 * Fetch and populate the Remark dropdown for a given Vendor.
		 * If selectedRemarkId is provided, that option is pre-selected
		 * (used on page load to restore the saved value).
		 */
		function populateRemarkField(vendorId, selectedRemarkId) {
			selectedRemarkId = selectedRemarkId || '';

			const remarkField = document.querySelector('select[name="jform[remark]"]');
			if (!remarkField) {
				console.error("Could not find the remark select element by name attribute.");
				return;
			}

			const remarkWrapper = remarkField.closest('joomla-field-fancy-select');

			remarkField.innerHTML = '<option value="">Select Remark</option>';

			if (remarkWrapper && remarkWrapper.choicesInstance) {
				remarkWrapper.choicesInstance.clearChoices();
				remarkWrapper.choicesInstance.setChoices([{
					value: '',
					label: '',
					selected: true
				}], 'value', 'label', true);
			}

			if (!vendorId) return;

			fetch(`index.php?option=com_data&task=entry.getRemarksByVendor&vendor_id=${vendorId}&format=json`)
				.then(response => response.json())
				.then(data => {
					if (data && data.success && data.data) {

						data.data.forEach(remark => {
							const option = new Option(remark.value, remark.key);
							if (String(remark.key) === String(selectedRemarkId)) {
								option.selected = true;
							}
							remarkField.add(option);
						});

						if (remarkWrapper && remarkWrapper.choicesInstance) {
							const newChoices = data.data.map(m => ({
								value: String(m.key),
								label: String(m.value),
								selected: String(m.key) === String(selectedRemarkId)
							}));

							remarkWrapper.choicesInstance.setChoices(newChoices, 'value', 'label', true);
						}
					}
				})
				.catch(error => console.error('Error Syncing JSON payload:', error));
		}

		// --- Component -> Model cascade ---
		const componentField = document.querySelector('select[name="jform[component]"]');

		// --- Vendor -> Remark cascade ---
		const vendorField = document.querySelector('select[name="jform[vendor]"]');

		document.addEventListener('change', function(event) {
			if (componentField && event.target === componentField) {
				populateModelField(componentField.value);
			}

			if (vendorField && event.target === vendorField) {
				populateRemarkField(vendorField.value);
			}
		});

		// --- Initialize on page load (edit mode): restore dependent dropdowns
		// to match the already-saved Component/Vendor selections ---
		if (existingComponentId) {
			populateModelField(existingComponentId, existingModelId);
		}

		if (existingVendorId) {
			populateRemarkField(existingVendorId, existingRemarkId);
		}

		// --- Sum of NC quantities must not exceed (or reach) the entry total ---
		const totalField = document.querySelector('input[name="jform[total]"], select[name="jform[total]"]');
		const submitBtn = document.querySelector('#form-entry button[type="submit"]');

		function sumNcQuantities() {
			let sum = 0;
			document.querySelectorAll('input[name*="[nc_quantity]"]').forEach(function(input) {
				sum += parseInt(input.value, 10) || 0;
			});
			return sum;
		}

		function validateNcTotal() {
			if (!totalField) return true;

			const total = parseInt(totalField.value, 10) || 0;
			const ncSum = sumNcQuantities();
			const valid = total === 0 || ncSum < total;

			let warning = document.getElementById('nc-total-warning');
			if (!valid) {
				if (!warning) {
					warning = document.createElement('div');
					warning.id = 'nc-total-warning';
					warning.className = 'alert alert-danger mt-2';
					document.querySelector('fieldset.options-form:nth-of-type(2)').appendChild(warning);
				}
				warning.textContent = `Total NC quantity (${ncSum}) must be less than the entry Total (${total}).`;
			} else if (warning) {
				warning.remove();
			}

			if (submitBtn) submitBtn.disabled = !valid;

			return valid;
		}

		document.addEventListener('input', function(e) {
			if (e.target === totalField || e.target.name?.includes('[nc_quantity]')) {
				validateNcTotal();
			}
		});

		document.getElementById('form-entry').addEventListener('submit', function(e) {
			if (!validateNcTotal()) {
				e.preventDefault();
			}
		});

		// --- NC Type/Category must not repeat within the same entry ---

		function checkDuplicateNcTypes() {
			const typeSelects = Array.from(document.querySelectorAll('select[name*="[nc_type]"]'));
			const seen = {};
			let hasDuplicate = false;

			// reset all rows first
			typeSelects.forEach(function(sel) {
				sel.classList.remove('is-invalid');
			});

			typeSelects.forEach(function(sel) {
				const val = sel.value;
				if (!val) return;

				if (seen[val]) {
					hasDuplicate = true;
					sel.classList.add('is-invalid');
					seen[val].classList.add('is-invalid');
				} else {
					seen[val] = sel;
				}
			});

			let warning = document.getElementById('nc-duplicate-warning');
			if (hasDuplicate) {
				if (!warning) {
					warning = document.createElement('div');
					warning.id = 'nc-duplicate-warning';
					warning.className = 'alert alert-danger mt-2';
					document.querySelector('fieldset.options-form:nth-of-type(2)').appendChild(warning);
				}
				warning.textContent = 'Each NC Category can only be used once per entry. Please remove the duplicate row.';
			} else if (warning) {
				warning.remove();
			}

			if (submitBtn) submitBtn.disabled = hasDuplicate || (totalField && !validateNcTotal());

			return !hasDuplicate;
		}

		document.addEventListener('change', function(e) {
			if (e.target.name && e.target.name.includes('[nc_type]')) {
				checkDuplicateNcTypes();
			}
		});

		document.getElementById('form-entry').addEventListener('submit', function(e) {
			if (!checkDuplicateNcTypes()) {
				e.preventDefault();
			}
		});
	});

	document.getElementById('adminForm').addEventListener('submit', function(e) {
		var btn = this.querySelector('button[type="submit"], input[type="submit"]');

		if (btn) {
			if (btn.dataset.submitted === '1') {
				e.preventDefault(); // extra guard if the event somehow fires twice
				return;
			}

			btn.dataset.submitted = '1';
			btn.disabled = true;
			btn.innerHTML = '<?php echo Text::_('COM_DATA_SUBMITTING'); ?>...';
		}
	});
</script>