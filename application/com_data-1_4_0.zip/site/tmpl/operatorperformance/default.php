<?php

/**
 * @version    CVS: 1.6.0
 * @package    Com_Data
 * @author     Mei Chun <qc.yolotech@gmail.com>
 * @copyright  2026 YOLO
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

use \Joomla\CMS\HTML\HTMLHelper;
use \Joomla\CMS\Router\Route;
use \Joomla\CMS\Language\Text;

$wa = $this->document->getWebAssetManager();
$wa->useStyle('com_data.list')
	->useStyle('com_data.dashboard')
	->useStyle('com_data.ncreport')
	->useStyle('choicesjs');
$wa->useScript('com_data.ncreport')
	->useScript('choicesjs');

$filters = $this->activeFilters;

if (!function_exists('comDataRenderTrendArrow')) {
	function comDataRenderTrendArrow($trend)
	{
		if ($trend === null) {
			return '<span class="text-muted small">&mdash;</span>';
		}

		if ($trend === 'up') {
			return '<span class="text-success" title="' . htmlspecialchars(Text::_('COM_DATA_OPERATORPERFORMANCE_TREND_UP'), ENT_QUOTES) . '">&uarr;</span>';
		}

		if ($trend === 'down') {
			return '<span class="text-danger" title="' . htmlspecialchars(Text::_('COM_DATA_OPERATORPERFORMANCE_TREND_DOWN'), ENT_QUOTES) . '">&darr;</span>';
		}

		return '<span class="text-muted" title="' . htmlspecialchars(Text::_('COM_DATA_OPERATORPERFORMANCE_TREND_FLAT'), ENT_QUOTES) . '">&rarr;</span>';
	}
}

if (!function_exists('comDataSiteRenderOperatorScatter')) {
	function comDataSiteRenderOperatorScatter($points, $width = 900, $height = 340)
	{
		if (empty($points)) {
			return '';
		}

		$padLeft   = 60;
		$padRight  = 20;
		$padTop    = 16;
		$padBottom = 40;
		$plotW     = $width - $padLeft - $padRight;
		$plotH     = $height - $padTop - $padBottom;

		$maxSort = max(1, max(array_column($points, 'total_sort')));
		$maxPct  = max(1, max(array_column($points, 'nc_pct')));
		$maxNc   = max(1, max(array_column($points, 'total_nc')));

		$dots = '';

		foreach ($points as $p) {
			$cx = $padLeft + ($p->total_sort / $maxSort) * $plotW;
			$cy = $padTop + $plotH - (($p->nc_pct / $maxPct) * $plotH);
			$r  = 4 + (($p->total_nc / $maxNc) * 14); // radius 4-18px, scaled by raw NC count

			$dots .= sprintf(
				'<circle
					cx="%.1f"
					cy="%.1f"
					r="%.1f"
					fill="var(--com-data-bar)"
					fill-opacity="0.65"
					stroke="var(--com-data-line)"
					stroke-width="1"
					class="com-data-scatter-dot">
				</circle>
				<circle
					cx="%.1f"
					cy="%.1f"
					r="%.1f"
					fill="transparent"
					class="com-data-scatter-hit"
					data-label="%s"
					data-sort="%s"
					data-nc="%s"
					data-rate="%.2f">
				</circle>',
				$cx,
				$cy,
				$r,
				$cx,
				$cy,
				max($r, 14), // hit target never smaller than 14px, even for tiny bubbles
				htmlspecialchars($p->label, ENT_QUOTES),
				number_format($p->total_sort),
				number_format($p->total_nc),
				$p->nc_pct
			);
		}

		$grid = sprintf(
			'<line x1="%d" y1="%d" x2="%d" y2="%d" class="com-data-gridline" /><line x1="%d" y1="%d" x2="%d" y2="%d" class="com-data-gridline" />',
			$padLeft,
			$padTop,
			$padLeft,
			$padTop + $plotH,
			$padLeft,
			$padTop + $plotH,
			$padLeft + $plotW,
			$padTop + $plotH
		);

		$axisLabels = sprintf(
			'<text x="%d" y="%d" class="com-data-axis-label" text-anchor="middle">%s</text>' .
				'<text x="%d" y="%d" class="com-data-axis-label" text-anchor="middle" transform="rotate(-90 %d %d)">%s</text>',
			$padLeft + ($plotW / 2),
			$height - 8,
			'Total Sort (Production) →',
			14,
			$padTop + ($plotH / 2),
			14,
			$padTop + ($plotH / 2),
			'NC Rate % →'
		);

		return sprintf(
			'<svg viewBox="0 0 %d %d" width="%d" height="%d" class="com-data-chart" role="img" aria-label="Operator production vs NC rate scatter">%s%s%s</svg>',
			$width,
			$height,
			$width,
			$height + 10,
			$grid,
			$dots,
			$axisLabels
		);
	}
}
if (!function_exists('comDataRenderRankingTable')) {
	function comDataRenderRankingTable($ranking)
	{
		if (empty($ranking->rows)) {
			echo '<p class="text-muted mb-0">' . Text::_('COM_DATA_DASHBOARD_EMPTY') . '</p>';
			return;
		}
?>
		<div class="com-data-ranking-scroll">
			<table class="table table-sm com-data-mini-table mb-2">
				<thead>
					<tr>
						<th>#</th>
						<th><?php echo Text::_('COM_DATA_ENTRIES_OPERATOR'); ?></th>
						<th class="text-end"><?php echo Text::_('COM_DATA_DASHBOARD_TOTAL_SORT'); ?></th>
						<th class="text-end"><?php echo Text::_('COM_DATA_DASHBOARD_TOTAL_NC'); ?></th>
						<th class="text-end"><?php echo Text::_('COM_DATA_DASHBOARD_NC_PCT'); ?></th>
						<th class="text-center"><?php echo Text::_('COM_DATA_OPERATORPERFORMANCE_TREND_COL'); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ($ranking->rows as $i => $row) : ?>
						<tr>
							<td><?php echo $i + 1; ?></td>
							<td>
								<a href="<?php echo Route::_('index.php?option=com_data&view=dashboard&filter_operator=' . (int) $row->entity_id); ?>">
									<?php echo htmlspecialchars($row->label, ENT_QUOTES); ?>
								</a>
							</td>
							<td class="text-end"><?php echo number_format($row->total_sort); ?></td>
							<td class="text-end"><?php echo number_format($row->total_nc); ?></td>
							<td class="text-end"><?php echo number_format($row->nc_pct, 2); ?>%</td>
							<td class="text-center"><?php echo comDataRenderTrendArrow($row->trend); ?></td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		</div>

		<?php if ($ranking->excluded > 0) : ?>
			<p class="text-muted small mb-0">
				<?php echo sprintf(Text::_('COM_DATA_OPERATORPERFORMANCE_EXCLUDED'), $ranking->excluded); ?>
			</p>
		<?php endif; ?>
<?php
	}
}

?>

<div class="com-data-dashboard">

	<?php if ($this->params->get('show_page_heading')) : ?>
		<div class="page-header">
			<h1><?php echo $this->escape($this->params->get('page_heading')); ?></h1>
		</div>
	<?php endif; ?>

	<form action="<?php echo Route::_('index.php?option=com_data&view=operatorperformance'); ?>" method="post" name="adminForm" id="adminForm">

		<div class="ncreport-header mb-4">
			<h1 class="ncreport-header__title"><?php echo Text::_('COM_DATA_TITLE_OPERATORPERFORMANCE'); ?></h1>
			<p class="ncreport-header__subtitle"><?php echo Text::_('COM_DATA_OPERATORPERFORMANCE_SUBTITLE'); ?></p>
			<p class="ncreport-header__subtitle">
				<?php echo Text::sprintf('COM_DATA_DASHBOARD_RANGE_SUBTITLE', $this->escape($filters->date_from), $this->escape($filters->date_to), (int) $filters->day_span); ?>
			</p>
			<?php if (!empty($this->previousPeriod)) : ?>
				<p class="text-muted">
					<?php echo Text::sprintf(
						'COM_DATA_COMPARED_TO_PERIOD',
						HTMLHelper::_('date', $this->previousPeriod->from, 'Y-m-d'),
						HTMLHelper::_('date', $this->previousPeriod->to, 'Y-m-d')
					); ?>
				</p>
			<?php endif; ?>
		</div>

		<div class="selectors row">
			<div class="selector col-md-4">
				<label><?php echo Text::_('COM_DATA_MODELSUMMARY_PERIOD_TYPE'); ?></label>
				<div class="btn-group d-block" role="group">
					<input type="radio" class="btn-check" name="filter_period_type" id="period_month" value="month"
						<?php echo $filters->period_type === 'month' ? 'checked' : ''; ?> onchange="this.form.submit();">
					<label class="btn btn-period" for="period_month"><?php echo Text::_('COM_DATA_MODELSUMMARY_MONTH'); ?></label>

					<input type="radio" class="btn-check" name="filter_period_type" id="period_week" value="week"
						<?php echo $filters->period_type === 'week' ? 'checked' : ''; ?> onchange="this.form.submit();">
					<label class="btn btn-period" for="period_week"><?php echo Text::_('COM_DATA_MODELSUMMARY_WEEK'); ?></label>

					<input type="radio" class="btn-check" name="filter_period_type" id="period_date" value="custom"
						<?php echo $filters->period_type === 'custom' ? 'checked' : ''; ?> onchange="this.form.submit();">
					<label class="btn btn-period" for="period_date"><?php echo Text::_('COM_DATA_MODELSUMMARY_DATE'); ?></label>
				</div>
			</div>

			<div class="selector col-md-4">
				<?php if ($filters->period_type === 'week') : ?>
					<label for="filter_year"><?php echo Text::_('COM_DATA_MODELSUMMARY_YEAR_SELECTOR'); ?></label>
					<select name="filter_year" id="filter_year" class="form-select" onchange="this.form.submit();">
						<?php foreach ($this->yearOptions as $yearOption) : ?>
							<option value="<?php echo (int) $yearOption; ?>" <?php echo (int) $filters->year === (int) $yearOption ? 'selected="selected"' : ''; ?>>
								<?php echo (int) $yearOption; ?>
							</option>
						<?php endforeach; ?>
					</select>

					<div style="padding-top:10px;">
						<label for="filter_week">
							<?php echo Text::_('COM_DATA_NCREPORT_WEEK_SELECTOR'); ?>
						</label>

						<select name="filter_week" id="filter_week" class="form-select" onchange="this.form.submit();">
							<?php foreach ($this->weekOptions as $weekOption) : ?>
								<option value="<?php echo (string) $weekOption->value; ?>"
									<?php echo (string) $filters->week === (string) $weekOption->value ? 'selected="selected"' : ''; ?>>
									<?php echo $weekOption->value === 'all'
										? $this->escape($weekOption->label)
										: Text::sprintf('COM_DATA_NCREPORT_WEEK_N', $weekOption->value, $weekOption->label); ?>
								</option>
							<?php endforeach; ?>
						</select>
					</div>

				<?php elseif ($filters->period_type === 'month') : ?>
					<label for="filter_year"><?php echo Text::_('COM_DATA_MODELSUMMARY_YEAR_SELECTOR'); ?></label>
					<select name="filter_year" id="filter_year" class="form-select" onchange="this.form.submit();">
						<?php foreach ($this->yearOptions as $yearOption) : ?>
							<option value="<?php echo (int) $yearOption; ?>" <?php echo (int) $filters->year === (int) $yearOption ? 'selected="selected"' : ''; ?>>
								<?php echo (int) $yearOption; ?>
							</option>
						<?php endforeach; ?>
					</select>

					<div style="padding-top:10px;">
						<label for="filter_month">
							<?php echo Text::_('COM_DATA_MODELSUMMARY_MONTH_SELECTOR'); ?>
						</label>

						<select name="filter_month" id="filter_month" class="form-select" onchange="this.form.submit();">
							<?php foreach ($this->monthOptions as $monthOption) : ?>
								<option value="<?php echo $this->escape((string) $monthOption->value); ?>"
									<?php echo (string) $filters->month === (string) $monthOption->value ? 'selected="selected"' : ''; ?>>
									<?php echo $this->escape($monthOption->label); ?>
								</option>
							<?php endforeach; ?>
						</select>
					</div>

				<?php elseif ($filters->period_type === 'custom') : ?>
					<div style="padding-top:10px;">
						<label for="filter_date_from">
							<?php echo Text::_('COM_DATA_DASHBOARD_DATE_FROM'); ?>
						</label>
						<input type="date" name="filter_date_from" id="filter_date_from" class="form-control"
							value="<?php echo $this->escape($filters->date_from); ?>" onchange="this.form.submit();" />
					</div>

					<div style="padding-top:10px;">
						<label for="filter_date_to">
							<?php echo Text::_('COM_DATA_DASHBOARD_DATE_TO'); ?>
						</label>
						<input type="date" name="filter_date_to" id="filter_date_to" class="form-control"
							value="<?php echo $this->escape($filters->date_to); ?>" onchange="this.form.submit();" />
					</div>
				<?php endif; ?>
			</div>
		</div>

		<!-- All Dashboard Filters -->
		<div id="dashboard-filters">
			<div class="selectors row">
				<div class="selector col-md-3">
					<label for="filter_part"><?php echo Text::_('COM_DATA_MODELSUMMARY_PART_SELECTOR'); ?></label>
					<select name="filter_part" id="filter_part" class="form-select js-choices" onchange="this.form.submit();">
						<option value=""><?php echo Text::_('COM_DATA_MODELSUMMARY_ALL_PARTS'); ?></option>
						<?php foreach ($this->partOptions as $partOption) : ?>
							<option value="<?php echo $this->escape($partOption->value); ?>" <?php echo (string) $filters->part === (string) $partOption->value ? 'selected="selected"' : ''; ?>>
								<?php echo $this->escape($partOption->text); ?>
							</option>
						<?php endforeach; ?>
					</select>
					<div style="padding-top: 20px" ;>
						<label for="filter_model"><?php echo Text::_('COM_DATA_DASHBOARD_MODEL_SELECTOR'); ?></label>
						<select name="filter_model" id="filter_model" class="form-select js-choices" onchange="this.form.submit();">
							<option value=""><?php echo Text::_('COM_DATA_DASHBOARD_ALL_MODELS'); ?></option>
							<?php foreach ($this->modelOptions as $modelOption) : ?>
								<option value="<?php echo $this->escape($modelOption->value); ?>" <?php echo (string) $filters->model === (string) $modelOption->value ? 'selected="selected"' : ''; ?>>
									<?php echo $this->escape($modelOption->text); ?>
								</option>
							<?php endforeach; ?>
						</select>
					</div>
				</div>
				<div class="selector col-md-3">
					<label for="filter_vendor"><?php echo Text::_('COM_DATA_DASHBOARD_VENDOR_SELECTOR'); ?></label>
					<select name="filter_vendor" id="filter_vendor" class="form-select" onchange="this.form.submit();">
						<option value=""><?php echo Text::_('COM_DATA_DASHBOARD_ALL_VENDORS'); ?></option>
						<?php foreach ($this->vendorOptions as $vendorOption) : ?>
							<option value="<?php echo $this->escape($vendorOption->key); ?>" <?php echo (string) $filters->vendor === (string) $vendorOption->key ? 'selected="selected"' : ''; ?>>
								<?php echo $this->escape($vendorOption->value); ?>
							</option>
						<?php endforeach; ?>
					</select>
					<div style="padding-top: 20px" ;>
						<label for="filter_lot"><?php echo Text::_('COM_DATA_NCREPORT_LOT_SELECTOR'); ?></label>
						<select name="filter_lot" id="filter_lot" class="form-select" onchange="this.form.submit();">
							<option value=""><?php echo Text::_('COM_DATA_NCREPORT_ALL_LOT'); ?></option>
							<?php foreach ($this->lotOptions as $lotOption) : ?>
								<option value="<?php echo $this->escape($lotOption->value); ?>" <?php echo (string) $filters->lot === (string) $lotOption->value ? 'selected="selected"' : ''; ?>>
									<?php echo $this->escape($lotOption->text); ?>
								</option>
							<?php endforeach; ?>
						</select>
					</div>
				</div>
				<div class="selector col-md-3">
					<label for="filter_remark"><?php echo Text::_('COM_DATA_NCREPORT_REMARK_SELECTOR'); ?></label>
					<select name="filter_remark" id="filter_remark" class="form-select" onchange="this.form.submit();">
						<option value=""><?php echo Text::_('COM_DATA_NCREPORT_ALL_REMARKS'); ?></option>
						<?php foreach ($this->remarkOptions as $remarkKey => $remarkLabel) : ?>
							<option value="<?php echo $this->escape($remarkKey); ?>" <?php echo (string) $filters->remark === (string) $remarkKey ? 'selected="selected"' : ''; ?>>
								<?php echo $this->escape($remarkLabel); ?>
							</option>
						<?php endforeach; ?>
					</select>
					<div style="padding-top: 20px" ;>
						<label for="filter_operator"><?php echo Text::_('COM_DATA_NCREPORT_OPERATOR_SELECTOR'); ?></label>
						<select name="filter_operator" id="filter_operator" class="form-select js-choices" onchange="this.form.submit();">
							<option value=""><?php echo Text::_('COM_DATA_NCREPORT_ALL_OPERATORS'); ?></option>
							<?php foreach ($this->operatorOptions as $operatorOption) : ?>
								<option value="<?php echo $this->escape($operatorOption->key); ?>" <?php echo (string) $filters->operator === (string) $operatorOption->key ? 'selected="selected"' : ''; ?>>
									<?php echo $this->escape($operatorOption->value); ?>
								</option>
							<?php endforeach; ?>
						</select>
					</div>
				</div>
				<div class="selector col-md-3">
					<label for="filter_nc_category"><?php echo Text::_('COM_DATA_NCREPORT_NC_CATEGORY_SELECTOR'); ?></label>
					<select name="filter_nc_category" id="filter_nc_category" class="form-select" onchange="this.form.submit();">
						<option value=""><?php echo Text::_('COM_DATA_NCREPORT_ALL_NC_CATEGORIES'); ?></option>
						<?php foreach ($this->nccategoryOptions as $nccategoryOption) : ?>
							<option value="<?php echo $this->escape($nccategoryOption->value); ?>" <?php echo (string) $filters->nc_category === (string) $nccategoryOption->value ? 'selected="selected"' : ''; ?>>
								<?php echo $this->escape($nccategoryOption->text); ?>
							</option>
						<?php endforeach; ?>
					</select>
					<div style="padding-top: 20px" ;>
						<label for="filter_nc_type"><?php echo Text::_('COM_DATA_NCREPORT_NC_TYPE_SELECTOR'); ?></label>
						<select name="filter_nc_type" id="filter_nc_type" class="form-select js-choices" onchange="this.form.submit();">
							<option value=""><?php echo Text::_('COM_DATA_NCREPORT_ALL_NC_TYPES'); ?></option>
							<?php foreach ($this->nctypeOptions as $nctypeOption) : ?>
								<option value="<?php echo $this->escape($nctypeOption->value); ?>" <?php echo (string) $filters->nc_type === (string) $nctypeOption->value ? 'selected="selected"' : ''; ?>>
									<?php echo $this->escape($nctypeOption->text); ?>
								</option>
							<?php endforeach; ?>
						</select>
					</div>
				</div>
			</div>

			<div class="row mb-4">
				<div class="col-md-12 text-end">
					<button type="button" id="btn-clear-filters" class="btn btn-link btn-sm text-muted">
						<span class="icon-undo" aria-hidden="true"></span>
						<?php echo Text::_('COM_DATA_NCREPORT_CLEAR_FILTERS'); ?>
					</button>
				</div>
			</div>
		</div>

		<div class="filter-toggle-row">
			<div class="filter-toggle-title text-muted">
				<span id="filter-toggle-text">Less Filters</span>
			</div>

			<button type="button"
				id="btn-toggle-filters"
				class="filter-toggle-btn"
				aria-expanded="true"
				aria-controls="dashboard-filters">
				<span id="filter-toggle-icon" class="icon-chevron-up" aria-hidden="true"></span>
			</button>
		</div>

		<?php
		$mobileMinWidth     = 420;
		?>

		<!-- Scatter panel -->
		<div class="com-data-panel mb-4" style="margin-top: 40px;">
			<div class="com-data-panel-header">
				<h3><?php echo Text::_('COM_DATA_OPPERF_SCATTER_TITLE'); ?></h3>
			</div>
			<div class="com-data-legend">
				<span class="com-data-legend-item"><?php echo Text::_('COM_DATA_OPPERF_SCATTER_X_HINT'); ?></span>
				<span class="com-data-legend-item"><?php echo Text::_('COM_DATA_OPPERF_SCATTER_Y_HINT'); ?></span>
				<span class="com-data-legend-item"><?php echo Text::_('COM_DATA_OPPERF_SCATTER_BUBBLE_HINT'); ?></span>
			</div>

			<div class="com-data-chart-wrap com-data-chart-wrap--desktop">
				<?php echo comDataSiteRenderOperatorScatter($this->scatterData, 900, 350); ?>
				<div id="com-data-chart-tooltip" class="com-data-chart-tooltip"></div>
			</div>
			<div class="com-data-chart-wrap com-data-chart-wrap--mobile">
				<?php echo comDataSiteRenderOperatorScatter($this->scatterData, $mobileMinWidth, 350); ?>
				<div id="com-data-chart-tooltip-mobile" class="com-data-chart-tooltip"></div>
			</div>
		</div>

		<div class="row">
			<div class="col-lg-6 mb-4">
				<div class="com-data-panel h-100">
					<div class="com-data-panel-header">
						<h3><?php echo Text::_('COM_DATA_OPERATORPERFORMANCE_QUALITY_TITLE'); ?></h3>
					</div>
					<?php comDataRenderRankingTable($this->qualityRanking); ?>
				</div>
			</div>

			<div class="col-lg-6 mb-4">
				<div class="com-data-panel h-100">
					<div class="com-data-panel-header">
						<h3><?php echo Text::_('COM_DATA_OPERATORPERFORMANCE_PRODUCTION_TITLE'); ?></h3>
					</div>
					<?php comDataRenderRankingTable($this->productionRanking); ?>
				</div>
			</div>
		</div>

		<!-- Biggest Movers -->
		<!-- <div class="row mb-4">
			<div class="col-md-6">
				<div class="com-data-panel h-100 is-good">
					<h4><?php echo Text::_('COM_DATA_OPPERF_MOST_IMPROVED'); ?></h4>
					<?php foreach ($this->biggestMovers->improved as $m) : ?>
						<div class="com-data-mover-row">
							<span><?php echo $this->escape($m->label); ?></span>
							<span class="com-data-pill is-good"><?php echo number_format($m->delta, 2); ?>%</span>
						</div>
					<?php endforeach; ?>
				</div>
			</div>
			<div class="col-md-6">
				<div class="com-data-panel h-100 is-danger">
					<h4><?php echo Text::_('COM_DATA_OPPERF_MOST_DECLINED'); ?></h4>
					<?php foreach ($this->biggestMovers->declined as $m) : ?>
						<div class="com-data-mover-row">
							<span><?php echo $this->escape($m->label); ?></span>
							<span class="com-data-pill is-danger">+<?php echo number_format($m->delta, 2); ?>%</span>
						</div>
					<?php endforeach; ?>
				</div>
			</div>
		</div> -->

		<input type="hidden" name="clearfilters" id="clearfilters" value="0" />
		<input type="hidden" name="option" value="com_data" />
		<input type="hidden" name="view" value="operatorperformance" />
	</form>

</div>

<script>
	document.addEventListener('DOMContentLoaded', function() {

		// =====================================================
		// SHOW / HIDE DASHBOARD FILTERS in script: com_data.ncreport
		// =====================================================

		var chartElements = document.querySelectorAll(
			'.com-data-scatter-hit'
		);

		chartElements.forEach(function(element) {

			element.addEventListener('click', function(e) {

				e.stopPropagation();

				// Deselect any highlighted scatter dot
				document.querySelectorAll('.com-data-scatter-dot').forEach(function(dot) {
					dot.classList.remove('is-selected');
				});

				var visualDot = null;

				if (element.classList.contains('com-data-scatter-hit')) {
					visualDot = element.previousElementSibling;
				}

				if (visualDot) {
					visualDot.classList.add('is-selected');
				}

				var chartWrap = element.closest('.com-data-chart-wrap');
				if (!chartWrap) return;

				var tooltip = chartWrap.querySelector('.com-data-chart-tooltip');
				if (!tooltip) return;

				var label = element.getAttribute('data-label');
				var nc = element.getAttribute('data-nc');
				var rate = element.getAttribute('data-rate');
				var category = element.getAttribute('data-category');
				var sort = element.getAttribute('data-sort');

				if (element.classList.contains('com-data-scatter-hit')) {
					tooltip.innerHTML =
						'<div class="tooltip-label">' + label + '</div>' +
						'<div>Total Sort: <strong>' + sort + '</strong></div>' +
						'<div>Total NC: <strong>' + nc + '</strong></div>' +
						'<div>NC Rate: <strong>' + rate + '%</strong></div>';
				} else {
					tooltip.innerHTML =
						'<div class="tooltip-category">' + category + '</div>' +
						'<div class="tooltip-label">' + label + '</div>' +
						'<div>Total NC: <strong>' + nc + '</strong></div>' +
						'<div>NC Rate: <strong>' + rate + '%</strong></div>';
				}

				// Position tooltip
				var elementRect = element.getBoundingClientRect();
				var wrapRect = chartWrap.getBoundingClientRect();

				tooltip.style.visibility = 'hidden';
				tooltip.classList.add('is-visible');

				var tooltipWidth = tooltip.offsetWidth;
				var tooltipHeight = tooltip.offsetHeight;

				var left = elementRect.left - wrapRect.left;
				var top = elementRect.top - wrapRect.top;

				var wrapWidth = chartWrap.clientWidth;
				var wrapHeight = chartWrap.clientHeight;

				// Default: show tooltip to the right
				var tooltipLeft = left + 10;

				// If too far right, show on left
				if (tooltipLeft + tooltipWidth > wrapWidth) {
					tooltipLeft = left - tooltipWidth - 10;
				}

				// Prevent going outside left
				if (tooltipLeft < 5) {
					tooltipLeft = 5;
				}

				// Show above
				var tooltipTop = top - tooltipHeight - 10;

				// If not enough space above, show below
				if (tooltipTop < 5) {
					tooltipTop = top + 10;
				}

				// Prevent going below chart
				if (tooltipTop + tooltipHeight > wrapHeight - 5) {
					tooltipTop = wrapHeight - tooltipHeight - 5;
				}

				// Convert viewport-relative coords back into the wrap's own scrollable
				// coordinate space - since the tooltip is position:absolute inside an
				// overflow-x:auto container, style.left/top are relative to the
				// UNSCROLLED content origin, not the visible viewport. Without adding
				// the current scroll offset back in, the tooltip renders shifted left
				// by exactly however far the chart has been scrolled.
				tooltip.style.left = (tooltipLeft + chartWrap.scrollLeft) + 'px';
				tooltip.style.top = (tooltipTop + chartWrap.scrollTop) + 'px';

				tooltip.style.visibility = 'visible';
			});
		});

		document.addEventListener('click', function(e) {

			if (!e.target.closest('.com-data-scatter-dot')) {

				document.querySelectorAll('.com-data-chart-tooltip').forEach(function(tooltip) {
					tooltip.classList.remove('is-visible');
				});

				document.querySelectorAll('.com-data-scatter-dot').forEach(function(dot) {
					dot.classList.remove('is-selected');
				});
			}
		});

	});
</script>