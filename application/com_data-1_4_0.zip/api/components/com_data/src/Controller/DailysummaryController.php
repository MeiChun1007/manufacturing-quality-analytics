<?php

/**
 * @package    Com_Data
 * @copyright  2026 YOLO
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace Data\Component\Data\Api\Controller;

\defined('_JEXEC') or die;

use Joomla\CMS\MVC\Controller\BaseController;

/**
 * Read-only: GET /api/index.php/v1/data/daily-summary
 *
 * Optional: filter[date_from]=YYYY-MM-DD  filter[date_to]=YYYY-MM-DD
 * Returns one row per (day, model): total_sort and total_nc.
 */
class DailysummaryController extends BaseController
{
	public function displayList()
	{
		$user = $this->app->getIdentity();

		if (!$user || $user->guest || !$user->authorise('core.manage', 'com_data')) {
			$this->respond(['errors' => [['title' => 'Forbidden']]], 403);
		}

		$filter = (array) $this->input->get('filter', [], 'array');

		try {
			$model = $this->factory->createModel('Dailysummary', 'Api', ['ignore_request' => true]);
			$rows  = $model->summary($filter);
		} catch (\Throwable $e) {
			$this->respond(['errors' => [['title' => 'Summary failed', 'detail' => $e->getMessage()]]], 500);
		}

		$this->respond(['data' => $rows, 'meta' => ['count' => count($rows)]]);
	}

	protected function respond(array $payload, int $status = 200): void
	{
		$this->app->setHeader('status', (string) $status, true);
		$this->app->setHeader('Content-Type', 'application/json; charset=utf-8', true);
		$this->app->sendHeaders();

		echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

		$this->app->close();
	}
}
