<?php

/**
 * @package    Com_Data
 * @copyright  2026 YOLO
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace Data\Component\Data\Api\Model;

\defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\MVC\Model\BaseDatabaseModel;
use Joomla\Database\DatabaseInterface;

class DailysummaryModel extends BaseDatabaseModel
{
	/**
	 * One row per (day, model, part):
	 * [ { date, model_id, model, part_id, part, total_sort, total_nc }, ... ]
	 */
	public function summary(array $filter): array
	{
		$db = Factory::getContainer()->get(DatabaseInterface::class);

		$from = $this->validDate($filter['date_from'] ?? '');
		$to   = $this->validDate($filter['date_to'] ?? '');

		$day = 'DATE(' . $db->quoteName('a.date') . ')';

		// Total Sort: sum of the entry's own `total`.
		$sortQuery = $db->getQuery(true)
			->select(
				$day . ' AS d, ' .
					$db->quoteName('a.model', 'model_id') . ', ' .
					$db->quoteName('a.component', 'part_id') . ', ' .
					'SUM(' . $db->quoteName('a.total') . ') AS total_sort'
			)
			->from($db->quoteName('#__data_entry', 'a'))
			->where($db->quoteName('a.state') . ' = 1')
			->group('d, ' . $db->quoteName('a.model') . ', ' . $db->quoteName('a.component'));
		$this->applyRange($db, $sortQuery, $from, $to);
		$db->setQuery($sortQuery);
		$sortRows = $db->loadObjectList() ?: [];

		// Total NC: sum of every NC row's quantity (separate query so the
		// join can never multiply Total Sort).
		$ncQuery = $db->getQuery(true)
			->select(
				$day . ' AS d, ' .
					$db->quoteName('a.model', 'model_id') . ', ' .
					$db->quoteName('a.component', 'part_id') . ', ' .
					'SUM(' . $db->quoteName('nc.nc_quantity') . ') AS total_nc'
			)
			->from($db->quoteName('#__data_entry_nc', 'nc'))
			->join('INNER', $db->quoteName('#__data_entry', 'a') . ' ON ' . $db->quoteName('a.id') . ' = ' . $db->quoteName('nc.entry_id'))
			->where($db->quoteName('a.state') . ' = 1')
			->group('d, ' . $db->quoteName('a.model') . ', ' . $db->quoteName('a.component'));
		$this->applyRange($db, $ncQuery, $from, $to);
		$db->setQuery($ncQuery);
		$ncRows = $db->loadObjectList() ?: [];

		$ncByKey = [];

		foreach ($ncRows as $r) {
			$ncByKey[$r->d . '|' . $r->model_id . '|' . $r->part_id] = (int) $r->total_nc;
		}

		$modelNames = $this->nameMap($db, '#__product_catalogs', 'model_name', array_map(fn($r) => $r->model_id, $sortRows));
		$partNames  = $this->nameMap($db, '#__product_components', 'component_name', array_map(fn($r) => $r->part_id, $sortRows));

		$out = [];

		foreach ($sortRows as $r) {
			$out[] = [
				'date'       => $r->d,
				'model_id'   => (int) $r->model_id,
				'model'      => $modelNames[$r->model_id] ?? (string) $r->model_id,
				'part_id'    => (int) $r->part_id,
				'part'       => $partNames[$r->part_id] ?? (string) $r->part_id,
				'total_sort' => (int) $r->total_sort,
				'total_nc'   => $ncByKey[$r->d . '|' . $r->model_id . '|' . $r->part_id] ?? 0,
			];
		}

		usort($out, fn($x, $y) => [$x['date'], $x['model'], $x['part']] <=> [$y['date'], $y['model'], $y['part']]);

		return $out;
	}

	private function nameMap(DatabaseInterface $db, string $table, string $labelCol, array $ids): array
	{
		$ids = array_values(array_unique(array_filter(array_map('intval', $ids))));

		if (!$ids) {
			return [];
		}

		$db->setQuery(
			$db->getQuery(true)
				->select($db->quoteName(['id', $labelCol]))
				->from($db->quoteName($table))
				->where($db->quoteName('id') . ' IN (' . implode(',', $ids) . ')')
		);

		$map = [];

		foreach ($db->loadAssocList() ?: [] as $row) {
			$map[$row['id']] = $row[$labelCol];
		}

		return $map;
	}

	private function applyRange(DatabaseInterface $db, $query, string $from, string $to): void
	{
		if ($from !== '') {
			$query->where($db->quoteName('a.date') . ' >= ' . $db->quote($from . ' 00:00:00'));
		}

		if ($to !== '') {
			$query->where($db->quoteName('a.date') . ' <= ' . $db->quote($to . ' 23:59:59'));
		}
	}

	private function validDate(string $value): string
	{
		return preg_match('/^\d{4}-\d{2}-\d{2}$/', $value) ? $value : '';
	}
}
