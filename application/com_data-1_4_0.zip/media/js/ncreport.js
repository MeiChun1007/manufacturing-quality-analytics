document.addEventListener('DOMContentLoaded', function() {
    document.querySelectorAll('.js-choices').forEach(function(el) {
        new Choices(el, {
            searchEnabled: true,
            itemSelectText: '',
            shouldSort: false,
            allowHTML: false,
        });
    });

    var clearBtn = document.getElementById('btn-clear-filters');
    if (!clearBtn) {
        return;
    }

    clearBtn.addEventListener('click', function() {
        var form = document.getElementById('adminForm');
        var flag = document.getElementById('clearfilters');
        if (flag) {
            flag.value = '1';
        }
        form.submit();
    });

// =====================================================
// SHOW / HIDE DASHBOARD FILTERS
// =====================================================

    var filterToggle = document.getElementById('btn-toggle-filters');
    var filterPanel = document.getElementById('dashboard-filters');
    var filterToggleIcon = document.getElementById('filter-toggle-icon');
    var filterToggleText = document.getElementById('filter-toggle-text');

    if (filterToggle && filterPanel && filterToggleIcon && filterToggleText) {

        function updateFilterState(isHidden) {

            filterPanel.classList.toggle('is-hidden', isHidden);

            if (isHidden) {

                filterToggleIcon.classList.remove('icon-chevron-up');
                filterToggleIcon.classList.add('icon-chevron-down');

                filterToggleText.textContent = 'More Filters';

                filterToggle.setAttribute('aria-expanded', 'false');

            } else {

                filterToggleIcon.classList.remove('icon-chevron-down');
                filterToggleIcon.classList.add('icon-chevron-up');

                filterToggleText.textContent = 'Less Filters';

                filterToggle.setAttribute('aria-expanded', 'true');
            }
        }

        // Initial state
        if (window.innerWidth < 768) {
            // Mobile → hidden
            updateFilterState(true);
        } else {
            // Desktop → shown
            updateFilterState(false);
        }

        // Toggle button
        filterToggle.addEventListener('click', function() {

            var isHidden = filterPanel.classList.contains('is-hidden');

            updateFilterState(!isHidden);

        });
    }
});