<?php

namespace Data\Plugin\WebServices\Data\Extension;

\defined('_JEXEC') or die;

use Joomla\CMS\Plugin\CMSPlugin;
use Joomla\CMS\Router\ApiRouter;
use Joomla\Event\SubscriberInterface;
use Joomla\Router\Route;

final class Data extends CMSPlugin implements SubscriberInterface
{
	public static function getSubscribedEvents(): array
	{
		return ['onBeforeApiRoute' => 'onBeforeApiRoute'];
	}

	/**
	 * @param   mixed  $event  BeforeApiRouteEvent on 4.2+/5.x, or the router itself on older 4.x.
	 */
	public function onBeforeApiRoute($event): void
	{
		$router = $this->resolveRouter($event);

		if ($router === null) {
			return; // Leave the rest of the API untouched; our route will simply 404.
		}

		$router->addRoutes([
			new Route(['GET'], 'v1/data/daily-summary', 'dailysummary.displayList', [], ['component' => 'com_data']),
		]);
	}

	/**
	 * Find the API router wherever this Joomla version puts it.
	 */
	private function resolveRouter($event)
	{
		$candidates = [$event];

		if (is_object($event)) {
			try {
				if (method_exists($event, 'getRouter')) {
					$candidates[] = $event->getRouter();
				}

				if (method_exists($event, 'getArgument')) {
					foreach (['router', 'subject', 0] as $key) {
						$candidates[] = $event->getArgument($key);
					}
				}

				if (method_exists($event, 'getArguments')) {
					foreach ((array) $event->getArguments() as $value) {
						$candidates[] = $value;
					}
				}
			} catch (\Throwable $e) {
				// fall through to the application lookup below
			}
		}

		try {
			$app = method_exists($this, 'getApplication') ? $this->getApplication() : null;

			if ($app && method_exists($app, 'getApiRouter')) {
				$candidates[] = $app->getApiRouter();
			}
		} catch (\Throwable $e) {
			// ignore
		}

		foreach ($candidates as $candidate) {
			if ($candidate instanceof ApiRouter) {
				return $candidate;
			}
		}

		foreach ($candidates as $candidate) {
			if (is_object($candidate) && method_exists($candidate, 'addRoutes')) {
				return $candidate;
			}
		}

		return null;
	}
}
