<?php

namespace Data\Plugin\Task\DataSync\Extension;

\defined('_JEXEC') or die;

use Joomla\CMS\Plugin\CMSPlugin;
use Joomla\Component\Scheduler\Administrator\Event\ExecuteTaskEvent;
use Joomla\Component\Scheduler\Administrator\Task\Status;
use Joomla\Component\Scheduler\Administrator\Traits\TaskPluginTrait;
use Joomla\Event\SubscriberInterface;
use Product\Component\Product\Administrator\Helper\SyncHelper as ProductSyncHelper;
use Production\Component\Production\Administrator\Helper\SyncHelper;

/**
 * Two scheduled tasks, each with its own schedule:
 *  - datasync.products : product master data (com_product Options > Data Sync)
 *  - datasync.pull     : daily summary, auto mode (com_production Options > Data Sync)
 */
final class DataSync extends CMSPlugin implements SubscriberInterface
{
	use TaskPluginTrait;

	protected const TASKS_MAP = [
		'datasync.products' => [
			'langConstPrefix' => 'PLG_TASK_DATASYNC_PRODUCTS',
			'method'          => 'syncProducts',
		],
		'datasync.pull' => [
			'langConstPrefix' => 'PLG_TASK_DATASYNC_PULL',
			'method'          => 'pullSummary',
		],
	];

	protected $autoloadLanguage = true;

	public static function getSubscribedEvents(): array
	{
		return [
			'onTaskOptionsList'    => 'advertiseRoutines',
			'onExecuteTask'        => 'standardRoutineHandler',
			'onContentPrepareForm' => 'enhanceTaskItemForm',
		];
	}

	private function syncProducts(ExecuteTaskEvent $event): int
	{
		if (!class_exists(ProductSyncHelper::class)) {
			$this->logTask('Data Sync (products): com_product is not installed (SyncHelper not found).', 'error');

			return Status::KNOCKOUT;
		}

		if (!ProductSyncHelper::isConfigured()) {
			$this->logTask('Data Sync (products): fill in Components > Product > Options > Data Sync first.', 'error');

			return Status::KNOCKOUT;
		}

		try {
			$p = ProductSyncHelper::run();
		} catch (\Throwable $e) {
			$this->logTask('Data Sync (products): ' . $e->getMessage(), 'error');

			return Status::KNOCKOUT;
		}

		$this->logTask(sprintf(
			'Data Sync (products): parts %d inserted / %d updated; models %d inserted / %d updated.',
			$p['components']['inserted'],
			$p['components']['updated'],
			$p['catalogs']['inserted'],
			$p['catalogs']['updated']
		));

		return Status::OK;
	}

	private function pullSummary(ExecuteTaskEvent $event): int
	{
		if (!class_exists(SyncHelper::class)) {
			$this->logTask('Data Sync (summary): com_production is not installed (SyncHelper not found).', 'error');

			return Status::KNOCKOUT;
		}

		try {
			$r = SyncHelper::run(SyncHelper::MODE_AUTO);
		} catch (\Throwable $e) {
			$this->logTask('Data Sync (summary): ' . $e->getMessage(), 'error');

			return Status::KNOCKOUT;
		}

		$this->logTask(sprintf(
			'Data Sync (summary, %s): %d inserted, %d updated.',
			$r['from'] === null ? 'all data' : 'from ' . $r['from'],
			$r['inserted'],
			$r['updated']
		));

		return Status::OK;
	}
}
