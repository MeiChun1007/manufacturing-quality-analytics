<?php

/**
 * @version    CVS: 1.2.0
 * @package    Com_Data
 * @author     Mei Chun <qc.yolotech@gmail.com>
 * @copyright  2026 YOLO
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

// No direct access
defined('_JEXEC') or die;

use \Joomla\CMS\HTML\HTMLHelper;
use \Joomla\CMS\Router\Route;
use \Joomla\CMS\Language\Text;

HTMLHelper::_('bootstrap.tooltip');

$filters = $this->activeFilters;
$pivot   = $this->pivot;
$summary = $this->summary;

/**
 * This is a pivot/aggregate report, not a row-per-record CRUD list, so it has
 * no add/edit/delete actions here - drill into an individual "Total Data
 * Entry" record from the Entries list to change the underlying data.
 */
?>

<form action="<?php echo Route::_('index.php?option=com_data&view=ncreport'); ?>" method="post" name="adminForm" id="adminForm">

	<div class="row mb-3">
		<div class="col-md-3">
			<label for="filter_model"><?php echo Text::_('COM_DATA_NCREPORT_MODEL_SELECTOR'); ?></label>
			<select name="filter_model" id="filter_model" class="form-select" onchange="this.form.submit();">
				<option value=""><?php echo Text::_('COM_DATA_NCREPORT_ALL_MODELS'); ?></option>
				<?php foreach ($this->modelOptions as $modelOption) : ?>
					<option value="<?php echo $this->escape($modelOption->value); ?>" <?php echo (string) $filters->model === (string) $modelOption->value ? 'selected="selected"' : ''; ?>>
						<?php echo $this->escape($modelOption->text); ?>
					</option>
				<?php endforeach; ?>
			</select>
		</div>
		<div class="col-md-3">
			<label for="filter_vendor"><?php echo Text::_('COM_DATA_NCREPORT_VENDOR_SELECTOR'); ?></label>
			<select name="filter_vendor" id="filter_vendor" class="form-select" onchange="this.form.submit();">
				<option value=""><?php echo Text::_('COM_DATA_NCREPORT_ALL_VENDORS'); ?></option>
				<?php foreach ($this->vendorOptions as $vendorOption) : ?>
					<option value="<?php echo $this->escape($vendorOption->key); ?>" <?php echo (string) $filters->vendor === (string) $vendorOption->key ? 'selected="selected"' : ''; ?>>
						<?php echo $this->escape($vendorOption->value); ?>
					</option>
				<?php endforeach; ?>
			</select>
		</div>
		<div class="col-md-3">
			<label for="filter_week"><?php echo Text::_('COM_DATA_NCREPORT_WEEK_SELECTOR'); ?></label>
			<select name="filter_week" id="filter_week" class="form-select" onchange="this.form.submit();">
				<?php foreach ($this->weekOptions as $weekOption) : ?>
					<option value="<?php echo $this->escape($weekOption->value); ?>" <?php echo $filters->week === $weekOption->value ? 'selected="selected"' : ''; ?>>
						<?php echo Text::sprintf('COM_DATA_NCREPORT_WEEK_N', $weekOption->week, $weekOption->label); ?>
					</option>
				<?php endforeach; ?>
			</select>
		</div>
		<div class="selector col-md-3">
			<label for="filter_remark"><?php echo Text::_('COM_DATA_NCREPORT_REMARK_SELECTOR'); ?></label>
			<select name="filter_remark" id="filter_remark" class="form-select" onchange="this.form.submit();">
				<option value=""><?php echo Text::_('COM_DATA_NCREPORT_ALL_REMARKS'); ?></option>
				<?php foreach ($this->remarkOptions as $remarkKey => $remarkLabel) : ?>
					<option value="<?php echo $this->escape($remarkKey); ?>" <?php echo (string) $filters->remark === (string) $remarkKey ? 'selected="selected"' : ''; ?>>
						<?php echo $this->escape($remarkLabel); ?>
					</option>
				<?php endforeach; ?>
			</select>
		</div>
	</div>

	<p class="text-muted">
		<?php echo HTMLHelper::_('date', $filters->week_start, Text::_('DATE_FORMAT_LC4')); ?>
		&ndash;
		<?php echo HTMLHelper::_('date', $filters->week_end, Text::_('DATE_FORMAT_LC4')); ?>
	</p>

	<div class="row mb-3">
		<div class="col-md-12 d-flex flex-wrap gap-3">
			<div class="card text-center flex-fill">
				<div class="card-body">
					<div class="text-muted small"><?php echo Text::_('COM_DATA_NCREPORT_TOTAL_SORT'); ?></div>
					<div class="fs-4"><?php echo (int) $summary->total_sort; ?></div>
				</div>
			</div>
			<div class="card text-center flex-fill">
				<div class="card-body">
					<div class="text-muted small"><?php echo Text::_('COM_DATA_NCREPORT_TOTAL_NC'); ?></div>
					<div class="fs-4"><?php echo (int) $summary->total_nc; ?></div>
				</div>
			</div>
			<div class="card text-center flex-fill">
				<div class="card-body">
					<div class="text-muted small"><?php echo Text::_('COM_DATA_NCREPORT_TOTAL_ACCEPTED'); ?></div>
					<div class="fs-4"><?php echo (int) $summary->total_accepted; ?></div>
				</div>
			</div>
			<div class="card text-center flex-fill">
				<div class="card-body">
					<div class="text-muted small"><?php echo Text::_('COM_DATA_NCREPORT_YIELD_PCT'); ?></div>
					<div class="fs-4"><?php echo number_format($summary->yield_pct, 2); ?>%</div>
				</div>
			</div>
			<div class="card text-center flex-fill">
				<div class="card-body">
					<div class="text-muted small"><?php echo Text::_('COM_DATA_NCREPORT_TOTAL_NC_PCT'); ?></div>
					<div class="fs-4"><?php echo number_format($summary->total_nc_pct, 2); ?>%</div>
				</div>
			</div>
		</div>
	</div>

	<?php if (empty($pivot->rows)) : ?>
		<div class="alert alert-info">
			<?php echo Text::_('COM_DATA_NCREPORT_EMPTY'); ?>
		</div>
	<?php else : ?>
		<div class="table-responsive">
			<table class="table table-bordered table-striped" id="ncReportList">
				<thead>
					<tr class="title">
						<th rowspan="2" class="align-middle"><?php echo Text::_('Category'); ?></th>
						<th rowspan="2" class="align-middle"><?php echo Text::_('COM_DATA_FORM_LBL_ENTRY_NC_TYPE'); ?></th>
						<th rowspan="2" class="align-middle text-center"
							data-bs-toggle="tooltip" title="<?php echo $this->escape(Text::_('COM_DATA_NCREPORT_COLUMN_SORT_HINT')); ?>">
							<?php echo Text::_('COM_DATA_NCREPORT_TOTAL_SORT'); ?>
						</th>
						<th rowspan="2" class="align-middle text-center">
							<?php echo Text::_('COM_DATA_NCREPORT_TOTAL_NC'); ?>
						</th>
						<th rowspan="2" class="align-middle text-center"
							data-bs-toggle="tooltip" title="<?php echo $this->escape(Text::_('COM_DATA_NCREPORT_COLUMN_NC_PCT_HINT')); ?>">
							<?php echo Text::_('COM_DATA_NCREPORT_WEEK_PCT'); ?>
						</th>
						<?php foreach ($pivot->dates as $date) : ?>
							<th colspan="2" class="text-center">
								<?php echo strtoupper(HTMLHelper::_('date', $date, 'd M')); ?>
							</th>
						<?php endforeach; ?>

					</tr>
					<tr class="title">
						<?php foreach ($pivot->dates as $date) : ?>
							<th class="text-center"><?php echo Text::_('COM_DATA_NCREPORT_QTY'); ?></th>
							<th class="text-center">%</th>
						<?php endforeach; ?>
					</tr>
				</thead>
				<tbody>
					<?php foreach ($pivot->rows as $row) : ?>
						<tr>
							<td><?php echo $this->escape($row->nc_category); ?></td>
							<td><?php echo $this->escape($row->nc_type); ?></td>
							<td class="text-center"><?php echo (int) $row->week_sort; ?></td>
							<td class="text-center"><?php echo (int) $row->week_qty; ?></td>
							<td class="text-center"><?php echo number_format($row->week_pct, 1); ?>%</td>
							<?php foreach ($pivot->dates as $date) : ?>
								<td class="text-center"><?php echo (int) $row->by_date[$date]; ?></td>
								<td class="text-center<?php echo $row->by_date_pct[$date] >= 5.0 ? ' text-danger fw-bold' : ''; ?>"><?php echo number_format($row->by_date_pct[$date], 1); ?>%</td>
							<?php endforeach; ?>
						</tr>
					<?php endforeach; ?>
				</tbody>
				<tfoot>
					<tr class="overall-data">
						<th colspan="2" data-bs-toggle="tooltip" title="<?php echo $this->escape(Text::_('COM_DATA_NCREPORT_ROW_WEEK_SORT_HINT')); ?>">
							<?php echo Text::_('COM_DATA_NCREPORT_TOTAL_SORT'); ?>
						</th>
						<th colspan="3" class="text-center"><?php echo (int) $pivot->week_total_sort; ?></th>
						<?php foreach ($pivot->dates as $date) : ?>
							<?php
							$daySortTotal = $pivot->day_sort_totals[$date] ?? 0;
							?>
							<th colspan="2" class="text-center"><?php echo (int) $daySortTotal; ?></th>
						<?php endforeach; ?>

					</tr>

					<tr class="overall-data">
						<th colspan="2" data-bs-toggle="tooltip" title="<?php echo $this->escape(Text::_('COM_DATA_NCREPORT_ROW_TOTAL_NC_HINT')); ?>">
							<?php echo Text::_('COM_DATA_NCREPORT_TOTAL_NC'); ?>
						</th>
						<th colspan="3" class="text-center"><?php echo (int) $pivot->week_total_nc; ?></th>
						<?php foreach ($pivot->dates as $date) : ?>
							<?php
							$dayTotal = $pivot->day_totals[$date] ?? 0;
							?>
							<th colspan="2" class="text-center"><?php echo (int) $dayTotal; ?></th>
						<?php endforeach; ?>

					</tr>

					<tr class="overall-data">
						<th colspan="2" data-bs-toggle="tooltip" title="<?php echo $this->escape(Text::_('COM_DATA_NCREPORT_ROW_NC_PCT_HINT')); ?>">
							<?php echo Text::_('Overall NC Percentage'); ?>
						</th>
						<th colspan="3" class="text-center"><?php echo number_format($pivot->week_total_nc_pct, 2); ?>%</th>
						<?php foreach ($pivot->dates as $date) : ?>
							<?php
							$daySortTotal = $pivot->day_sort_totals[$date] ?? 0;
							$dayTotal = $pivot->day_totals[$date] ?? 0;
							$dayPct   = $daySortTotal > 0 ? ($dayTotal / $daySortTotal) * 100 : 0.0;
							?>
							<th colspan="2" class="text-center"><?php echo number_format($dayPct, 2); ?>%</th>
						<?php endforeach; ?>

					</tr>
				</tfoot>
			</table>
		</div>
	<?php endif; ?>

	<input type="hidden" name="task" value="" />
	<?php echo HTMLHelper::_('form.token'); ?>
</form>