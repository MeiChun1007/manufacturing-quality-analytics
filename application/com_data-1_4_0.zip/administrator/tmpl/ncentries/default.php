<?php

/**
 * @version    CVS: 1.2.0
 * @package    Com_Data
 * @author     Mei Chun <qc.yolotech@gmail.com>
 * @copyright  2026 YOLO
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

// No direct access
defined('_JEXEC') or die;

use \Joomla\CMS\HTML\HTMLHelper;
use \Joomla\CMS\Factory;
use \Joomla\CMS\Router\Route;
use \Joomla\CMS\Layout\LayoutHelper;
use \Joomla\CMS\Language\Text;

HTMLHelper::_('bootstrap.tooltip');

$wa = $this->document->getWebAssetManager();
$wa->useStyle('com_data.admin')
	->useScript('com_data.admin');

$listOrder = $this->state->get('list.ordering');
$listDirn  = $this->state->get('list.direction');

?>

<form action="<?php echo Route::_('index.php?option=com_data&view=ncentries'); ?>" method="post"
	name="adminForm" id="adminForm">
	<div class="row">
		<div class="col-md-12">
			<div id="j-main-container" class="j-main-container">
				<?php echo LayoutHelper::render('joomla.searchtools.default', array('view' => $this)); ?>

				<div class="clearfix"></div>
				<table class="table table-striped" id="ncentryList">
					<thead>
						<tr>
							<th class='left'>
								<?php echo HTMLHelper::_('searchtools.sort', 'COM_DATA_ENTRIES_REFERENCE_NO', 'a.reference_no', $listDirn, $listOrder); ?>
							</th>
							<th class='left'>
								<?php echo HTMLHelper::_('searchtools.sort', 'COM_DATA_ENTRIES_DATE', 'a.date', $listDirn, $listOrder); ?>
							</th>
							<th class='left'>
								<?php echo HTMLHelper::_('searchtools.sort', 'COM_DATA_ENTRIES_WORK_ORDER_NO', 'a.work_order_no', $listDirn, $listOrder); ?>
							</th>
							<th class='left'>
								<?php echo Text::_('COM_DATA_ENTRIES_OPERATOR'); ?>
							</th>
							<th class='left'>
								<?php echo Text::_('COM_DATA_ENTRIES_COMPONENT'); ?>
							</th>
							<th class='left'>
								<?php echo Text::_('COM_DATA_ENTRIES_MODEL') . '-' . Text::_('COM_DATA_ENTRIES_VENDOR'); ?>
							</th>
							<th class=''>
								<?php echo HTMLHelper::_('grid.sort',  'COM_DATA_FORM_LBL_ENTRY_LOT', 'a.lot', $listDirn, $listOrder); ?>
							</th>
							<th class='left'>
								<?php echo HTMLHelper::_('searchtools.sort', 'COM_DATA_ENTRIES_NC_CATEGORY', 'nc.nc_category', $listDirn, $listOrder); ?>
							</th>
							<th class='left'>
								<?php echo HTMLHelper::_('searchtools.sort', 'COM_DATA_ENTRIES_NC_TYPE', 'nc.nc_type', $listDirn, $listOrder); ?>
							</th>
							<th class='left'>
								<?php echo HTMLHelper::_('searchtools.sort', 'COM_DATA_ENTRIES_NC_QUANTITY', 'nc.nc_quantity', $listDirn, $listOrder); ?>
							</th>
							<th class='left'>
								<?php echo HTMLHelper::_('searchtools.sort', 'COM_DATA_ENTRIES_NC_PERCENTAGE', 'nc.nc_percentage', $listDirn, $listOrder); ?>
							</th>
							<th scope="col" class="w-3 d-none d-lg-table-cell">
								<?php echo HTMLHelper::_('searchtools.sort', 'JGRID_HEADING_ID', 'nc.id', $listDirn, $listOrder); ?>
							</th>
						</tr>
					</thead>
					<tfoot>
						<tr>
							<td colspan="12">
								<?php echo $this->pagination->getListFooter(); ?>
							</td>
						</tr>
					</tfoot>
					<tbody>
						<?php if (empty($this->items)) : ?>
							<tr>
								<td colspan="10" class="text-center">
									<?php echo Text::_('JGLOBAL_NO_MATCHING_RESULTS'); ?>
								</td>
							</tr>
						<?php endif; ?>
						<?php foreach ($this->items as $i => $item) : ?>
							<tr class="row<?php echo $i % 2; ?>">
								<td>
									<?php echo $this->escape($item->entry_reference_no); ?>
								</td>
								<td>
									<?php echo $this->escape($item->entry_date); ?>
								</td>
								<td>
									<?php echo $this->escape($item->entry_work_order_no); ?>
								</td>
								<td>
									<?php echo $this->escape($item->operator_name); ?>
								</td>
								<td>
									<?php echo $this->escape($item->entry_component); ?>
								</td>
								<td>
									<?php echo $this->escape($item->entry_model);
									if (!empty($item->entry_vendor)) {
										echo "-" . $this->escape($item->entry_vendor);
										if ($item->entry_remark) {
											echo "(" . $this->escape($item->entry_remark) . ")";
										}
									};
									?>
								</td>
								<td>
									<?php echo $item->entry_lot; ?><br>
									<?php if (isset($item->entry_lot_raw) && $item->entry_lot_raw === '1') : ?>
										<?php if (!empty($item->entry_resort_nc)) : ?>
											<small class="text-muted"><?php echo $this->escape($item->entry_resort_nc); ?></small>
										<?php endif; ?>
									<?php endif; ?>
								</td>
								<td>
									<?php echo $this->escape($item->nc_category_name); ?>
								</td>
								<td>
									<?php echo $this->escape($item->nc_code); ?>
								</td>
								<td>
									<?php echo $this->escape($item->nc_quantity); ?>
								</td>
								<td>
									<?php echo $this->escape($item->nc_percentage); ?>%
								</td>
								<td class="d-none d-lg-table-cell">
									<?php echo (int) $item->id; ?>
								</td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
			</div>
		</div>
	</div>

	<input type="hidden" name="task" value="" />
	<input type="hidden" name="boxchecked" value="0" />
	<?php echo HTMLHelper::_('form.token'); ?>
</form>