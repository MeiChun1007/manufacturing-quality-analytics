<?php

/**
 * @version    CVS: 1.0.0
 * @package    Com_Data
 * @author     Mei Chun <qc.yolotech@gmail.com>
 * @copyright  2026 YOLO
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

// No direct access
defined('_JEXEC') or die;


use \Joomla\CMS\HTML\HTMLHelper;
use \Joomla\CMS\Factory;
use \Joomla\CMS\Uri\Uri;
use \Joomla\CMS\Router\Route;
use \Joomla\CMS\Layout\LayoutHelper;
use \Joomla\CMS\Language\Text;
use Joomla\CMS\Session\Session;

HTMLHelper::_('bootstrap.tooltip');
HTMLHelper::_('behavior.multiselect');

// Import CSS
$wa =  $this->document->getWebAssetManager();
$wa->useStyle('com_data.admin')
	->useScript('com_data.admin');

$user      = Factory::getApplication()->getIdentity();
$userId    = $user->get('id');
$listOrder = $this->state->get('list.ordering');
$listDirn  = $this->state->get('list.direction');
$canOrder  = $user->authorise('core.edit.state', 'com_data');

$saveOrder = $listOrder == 'a.ordering';

if (!empty($saveOrder)) {
	$saveOrderingUrl = 'index.php?option=com_data&task=entries.saveOrderAjax&tmpl=component&' . Session::getFormToken() . '=1';
	HTMLHelper::_('draggablelist.draggable');
}

?>

<form action="<?php echo Route::_('index.php?option=com_data&view=entries'); ?>" method="post"
	name="adminForm" id="adminForm">
	<div class="row">
		<div class="col-md-12">
			<div id="j-main-container" class="j-main-container">
				<?php echo LayoutHelper::render('joomla.searchtools.default', array('view' => $this)); ?>

				<div class="clearfix"></div>
				<table class="table table-striped" id="entryList">
					<thead>
						<tr>
							<th class="w-1 text-center">
								<input type="checkbox" autocomplete="off" class="form-check-input" name="checkall-toggle" value=""
									title="<?php echo Text::_('JGLOBAL_CHECK_ALL'); ?>" onclick="Joomla.checkAll(this)" />
							</th>

							<?php if (isset($this->items[0]->ordering)): ?>
								<th scope="col" class="w-1 text-center d-none d-md-table-cell">

									<?php echo HTMLHelper::_('searchtools.sort', '', 'a.ordering', $listDirn, $listOrder, null, 'asc', 'JGRID_HEADING_ORDERING', 'icon-menu-2'); ?>

								</th>
							<?php endif; ?>


							<th scope="col" class="w-1 text-center">
								<?php echo HTMLHelper::_('searchtools.sort', 'JSTATUS', 'a.state', $listDirn, $listOrder); ?>
							</th>
							<th class='left'>
								<?php echo HTMLHelper::_('searchtools.sort',  'COM_DATA_ENTRIES_REFERENCE_NO', 'a.reference_no', $listDirn, $listOrder); ?>
							</th>
							<th class='left'>
								<?php echo HTMLHelper::_('searchtools.sort',  'COM_DATA_ENTRIES_DATE', 'a.date', $listDirn, $listOrder); ?>
							</th>
							<th class='left'>
								<?php echo HTMLHelper::_('searchtools.sort',  'COM_DATA_ENTRIES_WEEK', 'a.week', $listDirn, $listOrder); ?>
							</th>
							<th class='left'>
								<?php echo HTMLHelper::_('searchtools.sort',  'COM_DATA_ENTRIES_COMPONENT', 'a.component', $listDirn, $listOrder); ?>
							</th>
							<th class='left'>
								<?php echo HTMLHelper::_('searchtools.sort',  'COM_DATA_ENTRIES_MODEL', 'a.model', $listDirn, $listOrder); ?>
							</th>
							<th class='left'>
								<?php echo HTMLHelper::_('searchtools.sort',  'COM_DATA_ENTRIES_VENDOR', 'a.vendor', $listDirn, $listOrder); ?>
							</th>
							<th class='left'>
								<?php echo HTMLHelper::_('searchtools.sort',  'COM_DATA_ENTRIES_OPERATOR', 'a.operator', $listDirn, $listOrder); ?>
							</th>
							<th class='left'>
								<?php echo HTMLHelper::_('searchtools.sort',  'COM_DATA_ENTRIES_WORK_ORDER_NO', 'a.work_order_no', $listDirn, $listOrder); ?>
							</th>
							<th class=''>
								<?php echo HTMLHelper::_('grid.sort',  'COM_DATA_FORM_LBL_ENTRY_LOT', 'a.lot', $listDirn, $listOrder); ?>
							</th>
							<th class=''>
								<?php echo HTMLHelper::_('grid.sort',  'COM_DATA_FORM_LBL_ENTRY_RESORT_NC', 'a.lot', $listDirn, $listOrder); ?>
							</th>
							<th class='left'>
								<?php echo HTMLHelper::_('searchtools.sort',  'COM_DATA_ENTRIES_TOTAL', 'a.total', $listDirn, $listOrder); ?>
							</th>
							<th class='left'>
								<?php echo HTMLHelper::_('searchtools.sort',  'COM_DATA_ENTRIES_NC_ENTRY_COUNT', 'nc_entry_count', $listDirn, $listOrder); ?>
							</th>
							<th class='left'>
								<?php echo HTMLHelper::_('searchtools.sort',  'COM_DATA_ENTRIES_NC_QUANTITY_TOTAL', 'nc_quantity_total', $listDirn, $listOrder); ?>
							</th>

							<th scope="col" class="w-3 d-none d-lg-table-cell">

								<?php echo HTMLHelper::_('searchtools.sort',  'JGRID_HEADING_ID', 'a.id', $listDirn, $listOrder); ?> </th>
						</tr>
					</thead>
					<tfoot>
						<tr>
							<td colspan="<?php echo isset($this->items[0]) ? count(get_object_vars($this->items[0])) : 10; ?>">
								<?php echo $this->pagination->getListFooter(); ?>
							</td>
						</tr>
					</tfoot>
					<tbody <?php if (!empty($saveOrder)) : ?> class="js-draggable" data-url="<?php echo $saveOrderingUrl; ?>" data-direction="<?php echo strtolower($listDirn); ?>" <?php endif; ?>>
						<?php foreach ($this->items as $i => $item) :
							$ordering   = ($listOrder == 'a.ordering');
							$canCreate  = $user->authorise('core.create', 'com_data');
							$canEdit    = $user->authorise('core.edit', 'com_data');
							$canCheckin = $user->authorise('core.manage', 'com_data');
							$canChange  = $user->authorise('core.edit.state', 'com_data');
						?>
							<tr class="row<?php echo $i % 2; ?>" data-draggable-group='1' data-transition>
								<td class="text-center">
									<?php echo HTMLHelper::_('grid.id', $i, $item->id); ?>
								</td>

								<?php if (isset($this->items[0]->ordering)) : ?>

									<td class="text-center d-none d-md-table-cell">

										<?php

										$iconClass = '';

										if (!$canChange) {
											$iconClass = ' inactive';
										} elseif (!$saveOrder) {
											$iconClass = ' inactive" title="' . Text::_('JORDERINGDISABLED');
										}							?> <span class="sortable-handler<?php echo $iconClass ?>">
											<span class="icon-ellipsis-v" aria-hidden="true"></span>
										</span>
										<?php if ($canChange && $saveOrder) : ?>
											<input type="text" name="order[]" size="5" value="<?php echo $item->ordering; ?>" class="width-20 text-area-order hidden">
										<?php endif; ?>
									</td>
								<?php endif; ?>


								<td class="text-center">
									<?php echo HTMLHelper::_('jgrid.published', $item->state, $i, 'entries.', $canChange, 'cb'); ?>
								</td>
								<td>
									<?php echo $item->reference_no; ?>
								</td>
								<td>
									<?php echo $item->date; ?>
								</td>
								<td>
									<?php echo $item->week; ?>
								</td>
								<td>
									<?php echo $item->component; ?>
								</td>
								<td>
									<?php echo $item->model; ?>
								</td>
								<td>
									<?php echo $item->vendor; ?>
									<?php if (!empty($item->remark)) {
										echo "(" . $item->remark . ")";
									}; ?>
								</td>
								<td>
									<?php echo $item->operator; ?>
								</td>
								<td>
									<?php echo $item->work_order_no; ?>
								</td>
								<td>
									<?php echo $item->lot; ?>
								</td>
								<td>
									<?php echo $item->resort_nc; ?>
								</td>
								<td>
									<?php echo $item->total; ?>
								</td>
								<td>
									<?php echo (int) $item->nc_entry_count; ?>
								</td>
								<td>
									<?php echo $item->nc_quantity_total !== null ? $item->nc_quantity_total : 0; ?>
								</td>

								<td class="d-none d-lg-table-cell">
									<?php echo $item->id; ?>

								</td>


							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>

				<input type="hidden" name="task" value="" />
				<input type="hidden" name="boxchecked" value="0" />
				<input type="hidden" name="list[fullorder]" value="<?php echo $listOrder; ?> <?php echo $listDirn; ?>" />
				<?php echo HTMLHelper::_('form.token'); ?>
			</div>
		</div>
	</div>
</form>