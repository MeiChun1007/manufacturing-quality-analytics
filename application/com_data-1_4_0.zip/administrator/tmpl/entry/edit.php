<?php

/**
 * @version    CVS: 1.0.0
 * @package    Com_Data
 * @author     Mei Chun <qc.yolotech@gmail.com>
 * @copyright  2026 YOLO
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

// No direct access
defined('_JEXEC') or die;

use \Joomla\CMS\HTML\HTMLHelper;
use \Joomla\CMS\Factory;
use \Joomla\CMS\Uri\Uri;
use \Joomla\CMS\Router\Route;
use \Joomla\CMS\Language\Text;

$wa = $this->document->getWebAssetManager();
$wa->useScript('keepalive')
	->useScript('form.validate')
	->useStyle('com_data.admin');
HTMLHelper::_('bootstrap.tooltip');
?>

<form
	action="<?php echo Route::_('index.php?option=com_data&layout=edit&id=' . (int) $this->item->id); ?>"
	method="post" enctype="multipart/form-data" name="adminForm" id="entry-form" class="form-validate form-horizontal">


	<?php echo HTMLHelper::_('uitab.startTabSet', 'myTab', array('active' => 'entry')); ?>
	<?php echo HTMLHelper::_('uitab.addTab', 'myTab', 'entry', Text::_('COM_DATA_TAB_ENTRY', true)); ?>
	<div class="row-fluid">
		<div class="col-md-12 form-horizontal">
			<fieldset class="adminform">
				<legend><?php echo Text::_('COM_DATA_FIELDSET_ENTRY'); ?></legend>
				<?php echo $this->form->renderField('reference_no'); ?>
				<?php echo $this->form->renderField('created_by'); ?>
				<?php echo $this->form->renderField('date'); ?>
				<?php echo $this->form->renderField('week'); ?>
				<?php echo $this->form->renderField('operator'); ?>
				<?php echo $this->form->renderField('component'); ?>
				<?php echo $this->form->renderField('model'); ?>
				<?php echo $this->form->renderField('vendor'); ?>
				<?php echo $this->form->renderField('remark'); ?>
				<?php echo $this->form->renderField('total'); ?>
				<?php echo $this->form->renderField('lot'); ?>
				<?php echo $this->form->renderField('resort_nc'); ?>
				<?php echo $this->form->renderField('work_order_no'); ?>
			</fieldset>
		</div>
	</div>
	<?php echo HTMLHelper::_('uitab.endTab'); ?>
	<?php echo HTMLHelper::_('uitab.addTab', 'myTab', 'nc_entries', Text::_('COM_DATA_TAB_NC_ENTRIES', true)); ?>
	<div class="row-fluid">
		<div class="col-md-12 form-horizontal">
			<fieldset class="adminform">
				<legend><?php echo Text::_('COM_DATA_FIELDSET_NC_ENTRIES'); ?></legend>
				<?php echo $this->form->renderField('nc_entries'); ?>
			</fieldset>
		</div>
	</div>
	<div id="ncImagePanel" class="nc-image-panel d-none">
		<div class="nc-image-panel__header">
			<h5 class="nc-image-panel__title"><?php echo Text::_('COM_DATA_NCIMAGE_MODAL_TITLE'); ?></h5>
			<button type="button" class="nc-image-panel__close" id="ncImagePanelClose" aria-label="<?php echo Text::_('JCLOSE'); ?>">&times;</button>
		</div>

		<div class="nc-image-panel__body">
			<div id="ncImageGrid" class="d-flex flex-wrap gap-2 mb-3"></div>

			<label class="form-label"><?php echo Text::_('COM_DATA_NCIMAGE_SELECT_FILES'); ?></label>
			<input type="file" id="ncImageFileInput" class="form-control"
				accept="image/jpeg,image/png,image/webp,image/heic,image/heif,image/gif,image/bmp" multiple>
			<button type="button" id="ncImageUploadBtn" class="btn btn-primary mt-2">
				<?php echo Text::_('COM_DATA_NCIMAGE_UPLOAD_BTN'); ?>
			</button>
			<div id="ncImageErrors" class="text-danger small mt-2"></div>
		</div>
	</div>
	<?php echo HTMLHelper::_('uitab.endTab'); ?>


	<input type="hidden" name="jform[id]" value="<?php echo isset($this->item->id) ? $this->item->id : ''; ?>" />

	<input type="hidden" name="jform[state]" value="<?php echo isset($this->item->state) ? $this->item->state : ''; ?>" />

	<?php echo $this->form->renderField('modified_by'); ?>


	<?php echo HTMLHelper::_('uitab.endTabSet'); ?>

	<input type="hidden" name="task" value="" />
	<?php echo HTMLHelper::_('form.token'); ?>

</form>



<script>
	var ncAjaxBase = <?php echo json_encode(rtrim(\Joomla\CMS\Uri\Uri::root(true), '/') . '/index.php'); ?>;

	document.addEventListener('DOMContentLoaded', function() {
		// --- Component -> Model cascade ---
		const componentField = document.querySelector('select[name="jform[component]"]');

		document.addEventListener('change', function(event) {
			if (!componentField || event.target !== componentField) return;

			const componentId = event.target.value;
			const modelField = document.querySelector('select[name="jform[model]"]');
			if (!modelField) {
				console.error("Could not find the model select element by name attribute.");
				return;
			}

			const modelWrapper = modelField.closest('joomla-field-fancy-select');

			modelField.innerHTML = '<option value="">Select Model</option>';

			if (modelWrapper && modelWrapper.choicesInstance) {
				modelWrapper.choicesInstance.clearChoices();
				modelWrapper.choicesInstance.setChoices([{
					value: '',
					label: 'Select Model',
					selected: true
				}], 'value', 'label', true);
			}

			if (!componentId) return;

			fetch(`index.php?option=com_data&task=entries.getModelsByComponent&component_id=${componentId}&format=json`)
				.then(response => response.json())
				.then(data => {
					if (data && data.success && data.data) {
						data.data.forEach(model => {
							const option = new Option(model.value, model.key);
							modelField.add(option);
						});

						if (modelWrapper && modelWrapper.choicesInstance) {
							const newChoices = data.data.map(m => ({
								value: String(m.key),
								label: String(m.value)
							}));
							modelWrapper.choicesInstance.setChoices(newChoices, 'value', 'label', true);
						}
					}
				})
				.catch(error => console.error('Error Syncing JSON payload:', error));
		});

		// --- Vendor -> Remark cascade ---
		const vendorField = document.querySelector('select[name="jform[vendor]"]');

		document.addEventListener('change', function(event) {
			if (!vendorField || event.target !== vendorField) return;

			const vendorId = event.target.value;
			const remarkField = document.querySelector('select[name="jform[remark]"]');
			if (!remarkField) {
				console.error("Could not find the remark select element by name attribute.");
				return;
			}

			const remarkWrapper = remarkField.closest('joomla-field-fancy-select');

			remarkField.innerHTML = '<option value="">Select Remark</option>';

			if (remarkWrapper && remarkWrapper.choicesInstance) {
				remarkWrapper.choicesInstance.clearChoices();
				remarkWrapper.choicesInstance.setChoices([{
					value: '',
					label: '',
					selected: true
				}], 'value', 'label', true);
			}

			if (!vendorId) return;

			fetch(`index.php?option=com_data&task=entries.getRemarksByVendor&vendor_id=${vendorId}&format=json`)
				.then(response => response.json())
				.then(data => {
					if (data && data.success && data.data) {
						data.data.forEach(remark => {
							const option = new Option(remark.value, remark.key);
							remarkField.add(option);
						});

						if (remarkWrapper && remarkWrapper.choicesInstance) {
							const newChoices = data.data.map(r => ({
								value: String(r.key),
								label: String(r.value)
							}));
							remarkWrapper.choicesInstance.setChoices(newChoices, 'value', 'label', true);
						}
					}
				})
				.catch(error => console.error('Error Syncing JSON payload:', error));
		});

		var allowDelete = true; // admin: any backend user can delete, per earlier decision
		var csrfToken = '<?php echo \Joomla\CMS\Session\Session::getFormToken(); ?>';
		var currentEntryId = null;

		function ajaxUrl(task) {
			return 'index.php?option=com_data&task=entries.' + task;
		}

		function renderImages(images) {
			var grid = document.getElementById('ncImageGrid');
			grid.innerHTML = '';

			if (!images.length) {
				grid.innerHTML = '<p class="text-muted"><?php echo Text::_('COM_DATA_NCIMAGE_EMPTY'); ?></p>';
				return;
			}

			images.forEach(function(img) {
				var wrap = document.createElement('div');
				wrap.className = 'position-relative';
				wrap.innerHTML = '<a href="' + img.url + '" target="_blank">' +
					'<img src="' + img.url + '" style="width:90px;height:90px;object-fit:cover;border-radius:4px;">' +
					'</a>';

				if (allowDelete) {
					var delBtn = document.createElement('button');
					delBtn.type = 'button';
					delBtn.className = 'btn btn-sm btn-danger position-absolute top-0 end-0';
					delBtn.innerHTML = '&times;';
					delBtn.addEventListener('click', function() {
						if (!confirm('<?php echo Text::_('COM_DATA_NCIMAGE_DELETE_CONFIRM'); ?>')) return;

						var fd = new FormData();
						fd.append('image_id', img.id);
						fd.append(csrfToken, '1');

						fetch(ajaxUrl('delete'), {
								method: 'POST',
								body: fd,
								credentials: 'same-origin'
							})
							.then(function(r) {
								return r.json();
							})
							.then(function() {
								loadImages(currentEntryId);
								refreshCount(currentEntryId);
							});
					});
					wrap.appendChild(delBtn);
				}

				grid.appendChild(wrap);
			});
		}

		function loadImages(ncId) {
			fetch(ajaxUrl('list') + '&nc_id=' + ncId, {
					credentials: 'same-origin'
				})
				.then(function(r) {
					return r.json();
				})
				.then(function(data) {
					if (data.success === false) {
						document.getElementById('ncImageGrid').innerHTML =
							'<p class="text-danger">' + (data.message || 'Failed to load images.') + '</p>';
						return;
					}

					renderImages(data.images || []);
				})
				.catch(function(err) {
					console.error('Load images failed:', err);
				});
		}

		function refreshCount(ncId) {
			fetch(ajaxUrl('list') + '&nc_id=' + ncId, {
					credentials: 'same-origin'
				})
				.then(function(r) {
					return r.json();
				})
				.then(function(data) {
					var span = document.querySelector('.nc-image-count[data-nc-id="' + ncId + '"]');
					if (span) {
						span.textContent = (data.images || []).length;
					}
				})
				.catch(function() {});
		}

		var panel = document.getElementById('ncImagePanel');
		var panelClose = document.getElementById('ncImagePanelClose');

		document.querySelectorAll('.nc-image-btn').forEach(function(btn) {
			btn.addEventListener('click', function() {
				if (!btn.dataset.ncId) return;

				currentEntryId = btn.dataset.ncId;
				loadImages(currentEntryId);

				panel.classList.remove('d-none');
				panel.scrollIntoView({
					behavior: 'smooth',
					block: 'nearest'
				});
			});
		});

		if (panelClose) {
			panelClose.addEventListener('click', function() {
				panel.classList.add('d-none');
			});
		}
		var uploadBtn = document.getElementById('ncImageUploadBtn');

		if (uploadBtn) {
			uploadBtn.addEventListener('click', function() {
				var input = document.getElementById('ncImageFileInput');
				var errBox = document.getElementById('ncImageErrors');
				errBox.innerHTML = '';

				if (!input.files.length) {
					errBox.innerHTML = '<?php echo Text::_('COM_DATA_NCIMAGE_ERROR_NO_FILE'); ?>';
					return;
				}

				var fd = new FormData();

				for (var i = 0; i < input.files.length; i++) {
					fd.append('images[]', input.files[i]);
				}

				fd.append('nc_id', currentEntryId);
				fd.append(csrfToken, '1');

				fetch(ajaxUrl('upload'), {
						method: 'POST',
						body: fd,
						credentials: 'same-origin'
					})
					.then(function(r) {
						return r.json().then(function(data) {
							return {
								ok: r.ok,
								data: data
							};
						});
					})
					.then(function(resp) {
						var data = resp.data;

						if (data.success === false && data.message) {
							errBox.innerHTML = data.message;
							return;
						}

						if (data.errors && data.errors.length) {
							errBox.innerHTML = data.errors.join('<br>');
						}

						input.value = '';
						loadImages(currentEntryId);
						refreshCount(currentEntryId);
					})
					.catch(function(err) {
						console.error('Upload request failed:', err);
						errBox.innerHTML = 'Upload failed - check the browser console for details.';
					});
			});
		}


	});
</script>