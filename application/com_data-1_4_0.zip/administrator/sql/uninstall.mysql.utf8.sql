DROP TABLE IF EXISTS `#__data_entry_nc_images`;
DROP TABLE IF EXISTS `#__data_entry_nc`;
DROP TABLE IF EXISTS `#__data_entry`;
