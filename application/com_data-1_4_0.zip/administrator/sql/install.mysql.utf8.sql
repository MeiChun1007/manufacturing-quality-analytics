CREATE TABLE IF NOT EXISTS `#__data_entry` (
`id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
`state` TINYINT(1)  NULL  DEFAULT 1,
`ordering` INT(11)  NULL  DEFAULT 0,
`checked_out` INT(11)  UNSIGNED,
`checked_out_time` DATETIME NULL  DEFAULT NULL ,
`created_by` INT(11)  NULL  DEFAULT 0,
`modified_by` INT(11)  NULL  DEFAULT 0,
`custom_field_1` VARCHAR(255)  NULL  DEFAULT "",
`custom_field_2` VARCHAR(255)  NULL  DEFAULT "",
`custom_field_3` VARCHAR(255)  NULL  DEFAULT "",
`custom_field_4` VARCHAR(255)  NULL  DEFAULT "",
`custom_field_5` VARCHAR(255)  NULL  DEFAULT "",
`date` DATETIME NULL  DEFAULT NULL ,
`week` VARCHAR(255) NULL  DEFAULT "",
`component` TEXT NULL ,
`model` TEXT NULL ,
`vendor` TEXT NULL ,
`operator` INT(11)  NULL  DEFAULT 0,
`total` INT NULL  DEFAULT 0,
`work_order_no` VARCHAR(255)  NULL  DEFAULT "",
`remark` VARCHAR(255)  NULL  DEFAULT "",
`lot` VARCHAR(255)  NULL  DEFAULT "",
`resort_nc` VARCHAR(255)  NULL  DEFAULT "",
`reference_no` VARCHAR(255)  NULL  DEFAULT "",
PRIMARY KEY (`id`)
,KEY `idx_state` (`state`)
,KEY `idx_checked_out` (`checked_out`)
,KEY `idx_created_by` (`created_by`)
,KEY `idx_modified_by` (`modified_by`)
) DEFAULT COLLATE=utf8mb4_unicode_ci;

CREATE INDEX `#__data_entry_date` ON `#__data_entry`(`date`);

CREATE INDEX `#__data_entry_week` ON `#__data_entry`(`week`);

CREATE INDEX `#__data_entry_total` ON `#__data_entry`(`total`);


-- One "Total Data Entry" record (#__data_entry) can now have MANY
-- "NC Data Entry" rows (category / quantity / percentage).
CREATE TABLE IF NOT EXISTS `#__data_entry_nc` (
`id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
`entry_id` int(11) UNSIGNED NOT NULL,
`nc_category` TEXT NULL,
`nc_type` TEXT NULL,
`nc_quantity` INT(11) NULL DEFAULT 0,
`nc_percentage` DECIMAL(15,2) NULL DEFAULT 0,
`ordering` INT(11) NULL DEFAULT 0,
PRIMARY KEY (`id`),
KEY `idx_entry_id` (`entry_id`)
) DEFAULT COLLATE=utf8mb4_unicode_ci;


-- Images attached to an "NC Data Entry" row (#__data_entry_nc).
-- One NC row can have MANY images.
CREATE TABLE IF NOT EXISTS `#__data_entry_nc_images` (
`id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
`nc_id` int(11) UNSIGNED NOT NULL,
`filename` VARCHAR(255) NOT NULL,
`filepath` VARCHAR(512) NOT NULL,
`uploaded_by` int(11) UNSIGNED NOT NULL,
`created` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
`ordering` INT(11) NULL DEFAULT 0,
PRIMARY KEY (`id`),
KEY `idx_nc_id` (`nc_id`)
) DEFAULT COLLATE=utf8mb4_unicode_ci;