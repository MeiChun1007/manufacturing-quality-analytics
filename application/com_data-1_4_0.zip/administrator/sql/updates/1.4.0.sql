-- Images attached to an "NC Data Entry" row (#__data_entry_nc).
-- One NC row can have MANY images.
CREATE TABLE IF NOT EXISTS `#__data_entry_nc_images` (
`id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
`nc_id` int(11) UNSIGNED NOT NULL,
`filename` VARCHAR(255) NOT NULL,
`filepath` VARCHAR(512) NOT NULL,
`uploaded_by` int(11) UNSIGNED NOT NULL,
`created` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
`ordering` INT(11) NULL DEFAULT 0,
PRIMARY KEY (`id`),
KEY `idx_nc_id` (`nc_id`)
) DEFAULT COLLATE=utf8mb4_unicode_ci;
