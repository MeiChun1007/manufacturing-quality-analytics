-- Introduces repeatable "NC Data Entry" rows (category / quantity / percentage)
-- linked to a single "Total Data Entry" record.

CREATE TABLE IF NOT EXISTS `#__data_entry_nc` (
`id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
`entry_id` int(11) UNSIGNED NOT NULL,
`nc_category` TEXT NULL,
`nc_quantity` DECIMAL(15,2) NULL DEFAULT 0,
`nc_percentage` DECIMAL(15,2) NULL DEFAULT 0,
`ordering` INT(11) NULL DEFAULT 0,
PRIMARY KEY (`id`),
KEY `idx_entry_id` (`entry_id`)
) DEFAULT COLLATE=utf8mb4_unicode_ci;

-- Migrate any existing single NC value per entry into the new child table,
-- then drop the old columns from the parent table.
INSERT INTO `#__data_entry_nc` (`entry_id`, `nc_category`, `nc_quantity`, `nc_percentage`, `ordering`)
SELECT `id`, `nc_category`, `nc_quantity`, `nc_percentage`, 0
FROM `#__data_entry`
WHERE (`nc_category` IS NOT NULL AND `nc_category` <> '')
   OR (`nc_quantity` IS NOT NULL AND `nc_quantity` <> 0)
   OR (`nc_percentage` IS NOT NULL AND `nc_percentage` <> 0);

ALTER TABLE `#__data_entry` DROP COLUMN `nc_category`;
ALTER TABLE `#__data_entry` DROP COLUMN `nc_quantity`;
ALTER TABLE `#__data_entry` DROP COLUMN `nc_percentage`;
