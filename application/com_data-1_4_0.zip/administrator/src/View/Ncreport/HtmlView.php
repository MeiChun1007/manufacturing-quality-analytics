<?php

/**
 * @version    CVS: 1.2.0
 * @package    Com_Data
 * @author     Mei Chun <qc.yolotech@gmail.com>
 * @copyright  2026 YOLO
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace Data\Component\Data\Administrator\View\Ncreport;
// No direct access
defined('_JEXEC') or die;

use \Joomla\CMS\MVC\View\HtmlView as BaseHtmlView;
use \Joomla\CMS\Toolbar\Toolbar;
use \Joomla\CMS\Toolbar\ToolbarHelper;
use \Joomla\CMS\Language\Text;
use \Data\Component\Data\Administrator\Helper\DataHelper;

/**
 * View class for the weekly NC Report pivot.
 *
 * @since  1.2.0
 */
class HtmlView extends BaseHtmlView
{
	/**
	 * @var  object  { total_sort, total_nc, total_accepted, yield_pct, total_nc_pct }
	 */
	protected $summary;

	/**
	 * @var  object  { dates, rows, day_totals, week_total_nc }
	 */
	protected $pivot;

	/**
	 * @var  array  Distinct models for the Model Selector.
	 */
	protected $modelOptions;

	/**
	 * @var  array  Distinct models for the Model Selector.
	 */
	protected $vendorOptions;

	/**
	 * @var  array  Distinct weeks for the Week Selector.
	 */
	protected $weekOptions;

	/**
	 * @var  array  Distinct remarks for the Remark Selector.
	 */
	protected $remarkOptions;

	/**
	 * @var  object  { model, week, search }
	 */
	protected $activeFilters;

	/**
	 * Display the view
	 *
	 * @param   string  $tpl  Template name
	 *
	 * @return void
	 *
	 * @throws Exception
	 */
	public function display($tpl = null)
	{
		$this->summary       = $this->get('Summary');
		$this->pivot          = $this->get('Pivot');
		$this->modelOptions   = $this->get('ModelOptions');
		$this->vendorOptions  = $this->get('VendorOptions');
		$this->remarkOptions  = $this->get('RemarkOptions');
		$this->weekOptions    = $this->get('WeekOptions');
		$this->activeFilters  = $this->get('ActiveFilters');

		$this->addToolbar();

		parent::display($tpl);
	}

	/**
	 * Add the page title and toolbar.
	 *
	 * @return  void
	 *
	 * @since   1.2.0
	 */
	protected function addToolbar()
	{
		$canDo = DataHelper::getActions();

		ToolbarHelper::title(Text::_('COM_DATA_TITLE_NCREPORT'), 'list');

		$toolbar = Toolbar::getInstance('toolbar');

		if ($canDo->get('core.admin')) {
			$toolbar->preferences('com_data');
		}
	}
}
