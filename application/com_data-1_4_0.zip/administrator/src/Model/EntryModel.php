<?php

/**
 * @version    CVS: 1.0.0
 * @package    Com_Data
 * @author     Mei Chun <qc.yolotech@gmail.com>
 * @copyright  2026 YOLO
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace Data\Component\Data\Administrator\Model;
// No direct access.
defined('_JEXEC') or die;

use \Joomla\CMS\Table\Table;
use \Joomla\CMS\Factory;
use \Joomla\CMS\Language\Text;
use \Joomla\CMS\Plugin\PluginHelper;
use \Joomla\CMS\MVC\Model\AdminModel;
use \Joomla\CMS\Helper\TagsHelper;
use Joomla\CMS\Versioning\VersionableModelTrait;
use \Joomla\CMS\Filter\OutputFilter;
use \Joomla\CMS\Event\Model;
use Joomla\CMS\Event\AbstractEvent;
use \Joomla\Database\DatabaseInterface;

/**
 * Entry model.
 *
 * @since  1.0.0
 */
class EntryModel extends AdminModel
{
	use VersionableModelTrait;

	/**
	 * @var    string  The prefix to use with controller messages.
	 *
	 * @since  1.0.0
	 */
	protected $text_prefix = 'COM_DATA';

	/**
	 * @var    string  Alias to manage history control
	 *
	 * @since  1.0.0
	 */
	public $typeAlias = 'com_data.entry';

	/**
	 * @var    null  Item data
	 *
	 * @since  1.0.0
	 */
	protected $item = null;




	/**
	 * Returns a reference to the a Table object, always creating it.
	 *
	 * @param   string  $type    The table type to instantiate
	 * @param   string  $prefix  A prefix for the table class name. Optional.
	 * @param   array   $config  Configuration array for model. Optional.
	 *
	 * @return  Table    A database object
	 *
	 * @since   1.0.0
	 */
	public function getTable($type = 'Entry', $prefix = 'Administrator', $config = array())
	{
		return parent::getTable($type, $prefix, $config);
	}

	/**
	 * Method to get the record form.
	 *
	 * @param   array    $data      An optional array of data for the form to interogate.
	 * @param   boolean  $loadData  True if the form is to load its own data (default case), false if not.
	 *
	 * @return  \JForm|boolean  A \JForm object on success, false on failure
	 *
	 * @since   1.0.0
	 */
	public function getForm($data = array(), $loadData = true)
	{
		// Initialise variables.
		$app = Factory::getApplication();

		// Get the form.
		$form = $this->loadForm(
			'com_data.entry',
			'entry',
			array(
				'control' => 'jform',
				'load_data' => $loadData
			)
		);



		if (empty($form)) {
			return false;
		}

		return $form;
	}



	/**
	 * Method to get the data that should be injected in the form.
	 *
	 * @return  mixed  The data for the form.
	 *
	 * @since   1.0.0
	 */
	protected function loadFormData()
	{
		// Check the session for previously entered form data.
		$data = Factory::getApplication()->getUserState('com_data.edit.entry.data', array());

		if (empty($data)) {
			if ($this->item === null) {
				$this->item = $this->getItem();
			}

			$data = $this->item;

			// Default the operator to the current logged-in user on new entries only
			if (empty($data->id)) {
				$data->operator = Factory::getApplication()->getIdentity()->id;
			}

			// Support for multiple or not foreign key field: component
			$array = array();

			foreach ((array) $data->component as $value) {
				if (!is_array($value)) {
					$array[] = $value;
				}
			}
			if (!empty($array)) {

				$data->component = $array;
			}

			// Support for multiple or not foreign key field: model
			$array = array();

			foreach ((array) $data->model as $value) {
				if (!is_array($value)) {
					$array[] = $value;
				}
			}
			if (!empty($array)) {

				$data->model = $array;
			}

			// Support for multiple or not foreign key field: vendor
			$array = array();

			foreach ((array) $data->vendor as $value) {
				if (!is_array($value)) {
					$array[] = $value;
				}
			}
			if (!empty($array)) {

				$data->vendor = $array;
			}

			// Support for multiple foreign key field: resort_nc
			$array = array();
			$resortNcData = isset($data->resort_nc) ? (array) $data->resort_nc : array();

			foreach ($resortNcData as $value) {
				if (!is_array($value)) {
					$array[] = $value;
				}
			}
			if (!empty($array)) {
				$data->resort_nc = $array;
			}

			// Load the repeatable NC Data Entry rows (category/quantity/percentage)
			// that belong to this entry, so the subform is pre-filled on edit.
			if (!empty($data->id)) {
				$data->nc_entries = $this->loadNcEntries((int) $data->id);
			}
		}

		return $data;
	}

	/**
	 * Load the repeatable "NC Data Entry" rows for an entry.
	 *
	 * @param   int  $entryId  The parent entry id.
	 *
	 * @return  array  List of associative arrays: nc_category, nc_quantity, nc_percentage.
	 *
	 * @since   1.1.0
	 */
	protected function loadNcEntries($entryId)
	{
		$db = Factory::getContainer()->get(DatabaseInterface::class);

		$query = $db->getQuery(true)
			->select($db->quoteName(['id', 'nc_category', 'nc_type', 'nc_quantity', 'nc_percentage']))
			->from($db->quoteName('#__data_entry_nc'))
			->where($db->quoteName('entry_id') . ' = ' . (int) $entryId)
			->order($db->quoteName('ordering') . ' ASC, ' . $db->quoteName('id') . ' ASC');

		$db->setQuery($query);

		return $db->loadAssocList() ?: array();
	}

	/**
	 * Replace all "NC Data Entry" rows belonging to an entry with the posted set.
	 *
	 * @param   int    $entryId  The parent entry id.
	 * @param   array  $rows     Rows posted from the nc_entries subform field.
	 *
	 * @return  void
	 *
	 * @since   1.1.0
	 */
	protected function saveNcEntries($entryId, $rows, $total)
	{
		$parentTotal = isset($total) ? (float) $total : 0;

		$db = Factory::getContainer()->get(DatabaseInterface::class);

		if (empty($rows) || !is_array($rows)) {
			return;
		}
		$keptIds  = array();
		$ordering = 0;

		foreach ($rows as $row) {
			$rowId = isset($row['id']) ? (int) $row['id'] : 0;
			$type   = isset($row['nc_type']) ? trim((string) $row['nc_type']) : '';

			if (!empty($type)) {
				$db = Factory::getDbo();
				$query = $db->getQuery(true);
				$query
					->select($db->quoteName('category'))
					->from($db->quoteName('#__nc_types'))
					->where($db->quoteName('id') . '=' . $db->quote($type))
					->where($db->quoteName('state') . '=' . $db->quote(1));
				$db->setQuery($query);
				$category = $db->loadResult();
			}

			$quantity   = isset($row['nc_quantity']) ? (float) $row['nc_quantity'] : 0;

			// ====================================================================
			// AUTOGENERATE PERCENTAGE: Calculate based on parent total
			// ====================================================================
			$percentage = 0.00;
			if ($parentTotal > 0 && $quantity > 0) {
				$percentage = round(($quantity / $parentTotal) * 100, 2);
			}
			// ====================================================================

			// Skip rows the operator left completely empty.
			if ($type === '' && $quantity == 0 && $percentage == 0) {
				continue;
			}

			if ($rowId > 0) {
				// Confirm this id actually belongs to this entry before touching it.
				$check = $db->getQuery(true)
					->select('id')
					->from($db->quoteName('#__data_entry_nc'))
					->where($db->quoteName('id') . ' = ' . $rowId)
					->where($db->quoteName('entry_id') . ' = ' . (int) $entryId);
				$db->setQuery($check);

				if ((int) $db->loadResult() === $rowId) {
					$update = $db->getQuery(true)
						->update($db->quoteName('#__data_entry_nc'))
						->set($db->quoteName('nc_category') . ' = ' . $db->quote($category))
						->set($db->quoteName('nc_type') . ' = ' . $db->quote($type))
						->set($db->quoteName('nc_quantity') . ' = ' . (float) $quantity)
						->set($db->quoteName('nc_percentage') . ' = ' . (float) $percentage)
						->set($db->quoteName('ordering') . ' = ' . (int) $ordering)
						->where($db->quoteName('id') . ' = ' . $rowId);
					$db->setQuery($update)->execute();

					$keptIds[] = $rowId;
					$ordering++;
					continue;
				}

				// id was posted but doesn't belong to this entry — treat as new.
				$rowId = 0;
			}

			// New row — insert and remember the id it was assigned.
			$query = $db->getQuery(true)
				->insert($db->quoteName('#__data_entry_nc'))
				->columns($db->quoteName(['entry_id', 'nc_category', 'nc_type', 'nc_quantity', 'nc_percentage', 'ordering']))
				->values(
					implode(
						',',
						array(
							(int) $entryId,
							$db->quote($category),
							$db->quote($type),
							(float) $quantity,
							(float) $percentage,
							(int) $ordering++,
						)
					)
				);

			$db->setQuery($query)->execute();
			$keptIds[] = (int) $db->insertid();
		}

		// Anything that used to belong to this entry but wasn't resubmitted was
		// removed in the subform — delete it, and take its photos with it.
		$existing = $db->getQuery(true)
			->select('id')
			->from($db->quoteName('#__data_entry_nc'))
			->where($db->quoteName('entry_id') . ' = ' . (int) $entryId);
		$db->setQuery($existing);
		$existingIds = array_map('intval', (array) $db->loadColumn());

		foreach (array_diff($existingIds, $keptIds) as $removedId) {
			$this->deleteNcRowImages($removedId);

			$delete = $db->getQuery(true)
				->delete($db->quoteName('#__data_entry_nc'))
				->where($db->quoteName('id') . ' = ' . $removedId);
			$db->setQuery($delete)->execute();
		}
	}

	/**
	 * Delete every uploaded image (files + rows) belonging to one NC entry row.
	 *
	 * @param   int  $ncId  The #__data_entry_nc row id.
	 *
	 * @return  void
	 *
	 * @since   1.4.0
	 */
	protected function deleteNcRowImages($ncId)
	{
		$db = Factory::getContainer()->get(DatabaseInterface::class);

		$query = $db->getQuery(true)
			->select($db->quoteName('image_path'))
			->from($db->quoteName('#__data_entry_nc_images'))
			->where($db->quoteName('nc_id') . ' = ' . (int) $ncId);
		$db->setQuery($query);

		foreach ((array) $db->loadColumn() as $path) {
			$fullPath = JPATH_ROOT . '/' . ltrim($path, '/');

			if (is_file($fullPath)) {
				@unlink($fullPath);
			}
		}

		$delete = $db->getQuery(true)
			->delete($db->quoteName('#__data_entry_nc_images'))
			->where($db->quoteName('nc_id') . ' = ' . (int) $ncId);
		$db->setQuery($delete)->execute();
	}

	/**
	 * Method to save the form data.
	 *
	 * @param   array  $data  The form data.
	 *
	 * @return  boolean  True on success.
	 *
	 * @since   1.1.0
	 */
	public function save($data)
	{
		$ncEntries = $data['nc_entries'] ?? array();
		$total = isset($data['total']) ? (int) $data['total'] : 0;

		unset($data['nc_entries']);

		// resort_nc is a multiple="true" field — Joomla submits it as an array
		// (e.g. ['3','7']), but the DB column is a plain VARCHAR, so it must be
		// flattened to a comma-separated string before the Table tries to save it.
		if (isset($data['resort_nc']) && is_array($data['resort_nc'])) {
			$data['resort_nc'] = implode(',', array_filter($data['resort_nc']));
		}

		// Capture the id of the record that gets saved via the core save event,
		// so we know which entry the NC rows below belong to (works for both
		// new records and edits, without guessing the internal model/state key).
		$context  = $this->option . '.' . $this->name;
		$savedId  = null;
		$listener = function ($event) use (&$savedId, $context) {
			if ($event->getArgument('context') === $context) {
				$table   = $event->getArgument('subject');
				$savedId = $table->id;
			}
		};

		$dispatcher = $this->getDispatcher();
		$dispatcher->addListener($this->event_after_save, $listener);

		$result = parent::save($data);

		$dispatcher->removeListener($this->event_after_save, $listener);

		if ($result && !empty($savedId)) {
			$this->saveNcEntries((int) $savedId, $ncEntries, $total);

			// Generate the reference number once, only if this record doesn't have one yet
			// (so editing an existing entry never overwrites its original reference).
			$db    = Factory::getDbo();
			$query = $db->getQuery(true)
				->select($db->quoteName(['reference_no', 'date']))
				->from($db->quoteName('#__data_entry'))
				->where($db->quoteName('id') . ' = ' . (int) $savedId);
			$db->setQuery($query);
			$row = $db->loadObject();

			if ($row && empty($row->reference_no)) {
				$entryDate    = !empty($row->date) ? $row->date : Factory::getDate('now')->toSql();
				$referenceNo  = 'IR' . Factory::getDate($entryDate)->format('ymd') . '-' . str_pad($savedId, 4, '0', STR_PAD_LEFT);

				$updateQuery = $db->getQuery(true)
					->update($db->quoteName('#__data_entry'))
					->set($db->quoteName('reference_no') . ' = ' . $db->quote($referenceNo))
					->where($db->quoteName('id') . ' = ' . (int) $savedId);
				$db->setQuery($updateQuery);
				$db->execute();
			}
		}

		return $result;
	}

	/**
	 * Method to get a single record.
	 *
	 * @param   integer  $pk  The id of the primary key.
	 *
	 * @return  mixed    Object on success, false on failure.
	 *
	 * @since   1.0.0
	 */
	public function getItem($pk = null)
	{

		if ($item = parent::getItem($pk)) {
			if (isset($item->params)) {
				$item->params = json_encode($item->params);
			}

			// Do any procesing on fields here if needed
		}

		return $item;
	}

	/**
	 * Method to duplicate an Entry
	 *
	 * @param   array  &$pks  An array of primary key IDs.
	 *
	 * @return  boolean  True if successful.
	 *
	 * @throws  Exception
	 */
	public function duplicate(&$pks)
	{
		$app = Factory::getApplication();
		$user = $app->getIdentity();
		$dispatcher = $this->getDispatcher();

		// Access checks.
		if (!$user->authorise('core.create', 'com_data')) {
			throw new \Exception(Text::_('JERROR_CORE_CREATE_NOT_PERMITTED'));
		}

		$context    = $this->option . '.' . $this->name;

		// Include the plugins for the save events.
		PluginHelper::importPlugin($this->events_map['save']);

		$table = $this->getTable();

		foreach ($pks as $pk) {

			if ($table->load($pk, true)) {
				// Reset the id to create a new record.
				$table->id = 0;

				if (!$table->check()) {
					throw new \Exception($table->getError());
				}


				// Create the before save event.
				$beforeSaveEvent = AbstractEvent::create(
					$this->event_before_save,
					[
						'context' => $context,
						'subject' => $table,
						'isNew'   => true,
						'data'    => $table,
					]
				);

				// Trigger the before save event.
				$dispatchResult = Factory::getApplication()->getDispatcher()->dispatch($this->event_before_save, $beforeSaveEvent);

				// Check if dispatch result is an array and handle accordingly
				$result = isset($dispatchResult['result']) ? $dispatchResult['result'] : [];

				// Proceed with your logic
				if (in_array(false, $result, true) || !$table->store()) {
					throw new \Exception($table->getError());
				}

				// Trigger the after save event.
				Factory::getApplication()->getDispatcher()->dispatch(
					$this->event_after_save,
					AbstractEvent::create(
						$this->event_after_save,
						[
							'context'    => $context,
							'subject'    => $table,
							'isNew'      => true,
							'data'       => $table,
						]
					)
				);
			} else {
				throw new \Exception($table->getError());
			}
		}

		// Clean cache
		$this->cleanCache();

		return true;
	}

	/**
	 * Prepare and sanitise the table prior to saving.
	 *
	 * @param   Table  $table  Table Object
	 *
	 * @return  void
	 *
	 * @since   1.0.0
	 */
	// protected function prepareTable($table)
	// {
	// 	jimport('joomla.filter.output');

	// 	if (empty($table->id))
	// 	{
	// 		// Set ordering to the last item if not set
	// 		if (@$table->ordering === '')
	// 		{
	// 			$db = Factory::getContainer()->get(DatabaseInterface::class);
	// 			$db->setQuery('SELECT MAX(ordering) FROM #__data_entry');
	// 			$max             = $db->loadResult();
	// 			$table->ordering = $max + 1;
	// 		}
	// 	}
	// }

	protected function prepareTable($table)
	{
		jimport('joomla.filter.output');

		if (empty($table->id)) {
			// Set ordering to the last item if not set
			if (@$table->ordering === '') {
				$db = Factory::getContainer()->get(DatabaseInterface::class);
				$db->setQuery('SELECT MAX(ordering) FROM #__data_entry');
				$max             = $db->loadResult();
				$table->ordering = $max + 1;
			}

			// Force created date to current Kuala Lumpur local time on new records
			$table->date = Factory::getDate('now', 'Asia/Kuala_Lumpur')->format('Y-m-d H:i:s', true);
		}
	}
}
