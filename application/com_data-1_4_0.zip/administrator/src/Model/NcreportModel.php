<?php

/**
 * @version    CVS: 1.2.0
 * @package    Com_Data
 * @author     Mei Chun <qc.yolotech@gmail.com>
 * @copyright  2026 YOLO
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace Data\Component\Data\Administrator\Model;
// No direct access.
defined('_JEXEC') or die;

use \Joomla\CMS\Factory;
use \Joomla\CMS\MVC\Model\BaseDatabaseModel;
use \Joomla\Database\DatabaseInterface;
use \Joomla\CMS\Language\Text;


/**
 * Model for the weekly NC Report pivot: rows are (NC Category, NC Type)
 * combinations, columns are always the 7 calendar days (Monday-Sunday) of
 * one selected ISO week - built from #__data_entry_nc joined to its parent
 * #__data_entry record.
 *
 * @since  1.2.0
 */
class NcreportModel extends BaseDatabaseModel
{
	/**
	 * @var  string
	 * @since  1.2.0
	 */
	protected $filterModel = '';

	/**
	 * @var  string
	 * @since  1.2.0
	 */
	protected $filterVendor = '';

	/**
	 * @var  string  ISO year-week key, e.g. "2026-W29".
	 * @since  1.2.0
	 */
	protected $filterWeek = '';

	/**
	 * @var  string  Remark: Normal/Resort
	 * @since  1.2.0
	 */
	protected $filterRemark = '';

	/**
	 * @var  string
	 * @since  1.2.0
	 */
	protected $filterSearch = '';

	/**
	 * @var  \DateTime  Monday 00:00:00 of the selected/default ISO week.
	 * @since  1.2.0
	 */
	protected $weekStart;

	/**
	 * @var  \DateTime  Sunday 23:59:59 of the selected/default ISO week.
	 * @since  1.2.0
	 */
	protected $weekEnd;

	/**
	 * Constructor.
	 *
	 * @param   array  $config  An optional associative array of configuration settings.
	 *
	 * @since   1.2.0
	 */
	public function __construct($config = array())
	{
		parent::__construct($config);

		$this->populateState();
	}

	/**
	 * Read the Model/Week/Search filters from the request, persist them in the
	 * user state, and resolve the selected (or default = current) ISO week
	 * into a concrete Monday-Sunday date range.
	 *
	 * @return  void
	 *
	 * @since   1.2.0
	 */
	protected function populateState()
	{
		$app     = Factory::getApplication();
		$context = 'com_data.ncreport.';

		$this->filterModel  = (string) $app->getUserStateFromRequest($context . 'filter.model', 'filter_model', '', 'string');
		$this->filterVendor  = (string) $app->getUserStateFromRequest($context . 'filter.vendor', 'filter_vendor', '', 'string');
		$this->filterWeek   = (string) $app->getUserStateFromRequest($context . 'filter.week', 'filter_week', '', 'string');
		$this->filterRemark   = (string) $app->getUserStateFromRequest($context . 'filter.remark', 'filter_remark', '0', 'string');
		$this->filterSearch = (string) $app->getUserStateFromRequest($context . 'filter.search', 'filter_search', '', 'string');

		list($year, $week) = $this->parseIsoWeekKey($this->filterWeek);

		if ($year === null) {
			// Default to the current ISO week when nothing is selected yet.
			$now  = new \DateTime('now', Factory::getApplication()->get('offset') ? new \DateTimeZone(Factory::getApplication()->get('offset')) : null);
			$year = (int) $now->format('o');
			$week = (int) $now->format('W');
		}

		$this->weekStart = new \DateTime();
		$this->weekStart->setISODate($year, $week, 1)->setTime(0, 0, 0);

		$this->weekEnd = clone $this->weekStart;
		$this->weekEnd->modify('+6 days')->setTime(23, 59, 59);

		// Normalise filterWeek to the key we actually resolved, so the view can re-select it.
		$this->filterWeek = sprintf('%04d-W%02d', $year, $week);
	}

	/**
	 * Split an ISO year-week key ("2026-W29") into [year, week], or [null, null] if empty/invalid.
	 *
	 * @param   string  $key  The ISO year-week key.
	 *
	 * @return  array
	 *
	 * @since   1.2.0
	 */
	protected function parseIsoWeekKey($key)
	{
		if ($key !== '' && preg_match('/^(\d{4})-W(\d{1,2})$/', $key, $m)) {
			return array((int) $m[1], (int) $m[2]);
		}

		return array(null, null);
	}

	/**
	 * The currently active filters, so the view can re-select them in the dropdowns.
	 *
	 * @return  object
	 *
	 * @since   1.2.0
	 */
	public function getActiveFilters()
	{
		return (object) array(
			'model'      => $this->filterModel,
			'vendor'      => $this->filterVendor,
			'week'       => $this->filterWeek,
			'remark'       => $this->filterRemark,
			'search'     => $this->filterSearch,
			'week_start' => $this->weekStart->format('Y-m-d'),
			'week_end'   => $this->weekEnd->format('Y-m-d'),
		);
	}

	/**
	 * Distinct list of models available for the Model Selector.
	 *
	 * @return  array
	 *
	 * @since   1.2.0
	 */
	public function getModelOptions()
	{
		$db = Factory::getContainer()->get(DatabaseInterface::class);

		$query = $db->getQuery(true)
			->select(
				'DISTINCT ' . $db->quoteName('pm.id', 'value') . ', ' .
					$db->quoteName('pm.model_name', 'text')
			)
			->from($db->quoteName('#__data_entry', 'a'))
			->join('INNER', $db->quoteName('#__product_catalogs', 'pm') . ' ON ' . $db->quoteName('pm.id') . ' = ' . $db->quoteName('a.model'))
			->where($db->quoteName('a.model') . ' IS NOT NULL')
			->where($db->quoteName('a.state') . ' = 1')
			->order($db->quoteName('pm.model_name') . ' ASC');

		$db->setQuery($query);

		return $db->loadObjectList() ?: array();
	}

	/**
	 * Distinct list of models available for the Vendor Selector.
	 *
	 * @return  array
	 *
	 * @since   1.2.0
	 */
	public function getVendorOptions()
	{
		$db = Factory::getContainer()->get(DatabaseInterface::class);

		$query = $db->getQuery(true)
			->select(
				'DISTINCT ' . $db->quoteName('a.vendor', 'key') . ', ' .
					$db->quoteName('uv.name', 'value')
			)
			->from($db->quoteName('#__data_entry', 'a'))
			->join('INNER', $db->quoteName('#__users', 'uv') . ' ON ' . $db->quoteName('uv.id') . ' = ' . $db->quoteName('a.vendor'))
			->where($db->quoteName('a.state') . ' = 1')
			->order($db->quoteName('uv.name') . ' ASC');

		$db->setQuery($query);

		return $db->loadObjectList() ?: array();
	}


	/**
	 * Distinct ISO weeks (Monday-Sunday, derived from the `date` field - not
	 * the free-text `week` field) available for the Week Selector, newest first.
	 * Always includes the current week even if it has no entries yet.
	 *
	 * @return  array  List of objects: { value: "2026-W29", label: "Week 29, 2026 (13 Jul - 19 Jul)" }
	 *
	 * @since   1.2.0
	 */
	public function getWeekOptions()
	{
		$db = Factory::getContainer()->get(DatabaseInterface::class);

		// ISO year-week, MySQL mode 3 = ISO 8601 (Monday first day, week 1 has the year's first Thursday).
		$query = $db->getQuery(true)
			->select('DISTINCT YEARWEEK(' . $db->quoteName('date') . ', 3) AS iso_yw')
			->from($db->quoteName('#__data_entry'))
			->where($db->quoteName('date') . ' IS NOT NULL')
			->order('iso_yw DESC');

		$db->setQuery($query);
		$rawWeeks = $db->loadColumn() ?: array();

		$keys = array();

		foreach ($rawWeeks as $yw) {
			$yw   = (string) $yw;
			$year = (int) substr($yw, 0, 4);
			$week = (int) substr($yw, 4);

			if ($year > 0 && $week > 0) {
				$keys[sprintf('%04d-W%02d', $year, $week)] = true;
			}
		}

		// Make sure "this week" is always selectable, even with no data yet.
		$keys[$this->filterWeek === '' ? $this->defaultWeekKey() : $this->filterWeek] = true;

		$options = array();

		foreach (array_keys($keys) as $key) {
			list($year, $week) = $this->parseIsoWeekKey($key);

			if ($year === null) {
				continue;
			}

			$start = new \DateTime();
			$start->setISODate($year, $week, 1);
			$end = (clone $start)->modify('+6 days');

			$options[$key] = (object) array(
				'value' => $key,
				'week'  => $week,
				'year'  => $year,
				'label' => sprintf('%s - %s', $start->format('d M'), $end->format('d M Y')),
			);
		}

		krsort($options);

		return array_values($options);
	}

	public function getRemarkOptions()
	{
		$remarkOptions = array(
			'0' => Text::_('COM_DATA_LOT_NORMAL'),
			'1' => Text::_('COM_DATA_LOT_RESORT'),
		);

		return $remarkOptions;
	}

	/**
	 * The current default week key (this ISO week), used before any filter is applied.
	 *
	 * @return  string
	 *
	 * @since   1.2.0
	 */
	protected function defaultWeekKey()
	{
		$now = new \DateTime();

		return sprintf('%04d-W%02d', (int) $now->format('o'), (int) $now->format('W'));
	}

	/**
	 * The top summary cards: Total Sort, Total NC, Total Accepted, Yield%, Total NC%.
	 * Always scoped to the selected Monday-Sunday week (and Model, if chosen).
	 *
	 * @return  object
	 *
	 * @since   1.2.0
	 */
	public function getSummary()
	{
		$db = Factory::getContainer()->get(DatabaseInterface::class);

		// Total Sort: sum of the parent entry's `total` field within the current scope.
		$sortQuery = $db->getQuery(true)
			->select('SUM(' . $db->quoteName('a.total') . ') AS total_sort')
			->from($db->quoteName('#__data_entry', 'a'))
			->where($db->quoteName('a.state') . ' = 1');
		$this->applyEntryFilters($db, $sortQuery);

		$db->setQuery($sortQuery);
		$totalSort = (float) $db->loadResult();

		// Total NC: sum of every NC row's quantity within the current scope.
		$ncQuery = $db->getQuery(true)
			->select('SUM(' . $db->quoteName('nc.nc_quantity') . ') AS total_nc')
			->from($db->quoteName('#__data_entry_nc', 'nc'))
			->join('INNER', $db->quoteName('#__data_entry', 'a') . ' ON ' . $db->quoteName('a.id') . ' = ' . $db->quoteName('nc.entry_id'))
			->where($db->quoteName('a.state') . ' = 1');
		$this->applyEntryFilters($db, $ncQuery);
		$this->applyNcSearch($db, $ncQuery);

		$db->setQuery($ncQuery);
		$totalNc = (float) $db->loadResult();

		$totalAccepted = $totalSort - $totalNc;
		$yieldPct      = $totalSort > 0 ? ($totalAccepted / $totalSort) * 100 : 0.0;
		$totalNcPct    = $totalSort > 0 ? ($totalNc / $totalSort) * 100 : 0.0;

		return (object) array(
			'total_sort'     => $totalSort,
			'total_nc'       => $totalNc,
			'total_accepted' => $totalAccepted,
			'yield_pct'      => $yieldPct,
			'total_nc_pct'   => $totalNcPct,
		);
	}

	/**
	 * Build the pivot: rows are (Category, Type), columns are always the 7
	 * calendar days (Monday-Sunday) of the selected week - present or not.
	 *
	 * Per-day/per-week percentages are the ACTUAL stored `nc_percentage`
	 * values from #__data_entry_nc, summed - not a recomputed share of that
	 * day's/week's total defect quantity. Total Sort is also broken out per
	 * day and for the week, computed from a de-duplicated subquery so an
	 * entry with multiple NC rows doesn't have its `total` counted more than once.
	 *
	 * @return  object  { dates, rows, day_totals, day_totals_pct, day_sort_totals,
	 *                    week_total_nc, week_total_nc_pct, week_total_sort }
	 *
	 * @since   1.2.0
	 */
	public function getPivot()
	{
		$db = Factory::getContainer()->get(DatabaseInterface::class);

		// Always show all 7 days of the selected week, in order, whether or not they have data.
		$dates = array();
		$cursor = clone $this->weekStart;

		for ($i = 0; $i < 7; $i++) {
			$dates[] = $cursor->format('Y-m-d');
			$cursor->modify('+1 day');
		}

		// --- Main pivot data: qty + the actual stored nc_percentage, per (category, type, date) ---
		$query = $db->getQuery(true)
			->select(
				$db->quoteName('nc.nc_category', 'nc_category') . ', ' .
					$db->quoteName('nc.nc_type', 'nc_type') . ', ' .
					'DATE(' . $db->quoteName('a.date') . ') AS entry_date, ' .
					'SUM(' . $db->quoteName('nc.nc_quantity') . ') AS qty, ' .
					'SUM(' . $db->quoteName('nc.nc_percentage') . ') AS pct'
			)
			->from($db->quoteName('#__data_entry_nc', 'nc'))
			->join('INNER', $db->quoteName('#__data_entry', 'a') . ' ON ' . $db->quoteName('a.id') . ' = ' . $db->quoteName('nc.entry_id'))
			->where($db->quoteName('a.state') . ' = 1')
			->group($db->quoteName('nc.nc_category') . ', ' . $db->quoteName('nc.nc_type') . ', DATE(' . $db->quoteName('a.date') . ')');
		$this->applyEntryFilters($db, $query);
		$this->applyNcSearch($db, $query);

		$db->setQuery($query);
		$raw = $db->loadObjectList() ?: array();

		// --- Total Sort per day: de-duplicated first (one row per entry), THEN summed,
		// so an entry with several NC rows doesn't inflate the day's sort total. ---
		$sortSubQuery = $db->getQuery(true)
			->select(
				'DISTINCT ' . $db->quoteName('a.id') . ', ' .
					$db->quoteName('a.total') . ', ' .
					'DATE(' . $db->quoteName('a.date') . ') AS entry_date'
			)
			->from($db->quoteName('#__data_entry', 'a'))
			->where($db->quoteName('a.state') . ' = 1');
		$this->applyEntryFilters($db, $sortSubQuery);

		$sortQuery = $db->getQuery(true)
			->select('entry_date, SUM(total) AS day_sort')
			->from('(' . (string) $sortSubQuery . ') AS dedup')
			->group('entry_date');

		$db->setQuery($sortQuery);
		$sortRows = $db->loadObjectList() ?: array();

		$daySortTotals = array_fill_keys($dates, 0.0);

		foreach ($sortRows as $sr) {
			if (isset($daySortTotals[$sr->entry_date])) {
				$daySortTotals[$sr->entry_date] = (float) $sr->day_sort;
			}
		}

		$weekTotalSort = array_sum($daySortTotals);

		// --- Total Sort per (category, type), for the whole week: the sum
		// of #__data_entry.total for every entry that had this specific NC
		// during the week - deduped by entry id, so an entry with more than
		// one row under the same category+type doesn't have its total
		// counted twice. ---
		$rowSortSubQuery = $db->getQuery(true)
			->select(
				'DISTINCT ' .
					$db->quoteName('nc.nc_category') . ', ' .
					$db->quoteName('nc.nc_type') . ', ' .
					$db->quoteName('a.id', 'entry_id') . ', ' .
					$db->quoteName('a.total')
			)
			->from($db->quoteName('#__data_entry_nc', 'nc'))
			->join('INNER', $db->quoteName('#__data_entry', 'a') . ' ON ' . $db->quoteName('a.id') . ' = ' . $db->quoteName('nc.entry_id'))
			->where($db->quoteName('a.state') . ' = 1');
		$this->applyEntryFilters($db, $rowSortSubQuery);

		$rowSortQuery = $db->getQuery(true)
			->select('nc_category, nc_type, SUM(total) AS week_sort')
			->from('(' . (string) $rowSortSubQuery . ') AS dedup')
			->group('nc_category, nc_type');

		$db->setQuery($rowSortQuery);
		$rowSortRows = $db->loadObjectList() ?: array();

		$weekSortByKey = array();

		foreach ($rowSortRows as $rs) {
			$weekSortByKey[$rs->nc_category . '|' . $rs->nc_type] = (float) $rs->week_sort;
		}

		// --- Assemble the (category, type) rows ---
		$rows          = array();
		$dayTotals     = array_fill_keys($dates, 0.0);
		$dayTotalsPct  = array_fill_keys($dates, 0.0);
		$weekTotalNc   = 0.0;
		$weekTotalNcPct = 0.0;

		foreach ($raw as $r) {
			$date = $r->entry_date;
			$qty  = (float) $r->qty;
			$pct  = (float) $r->pct;
			$key  = $r->nc_category . '|' . $r->nc_type;

			if (!isset($rows[$key])) {
				$catQuery = $db->getQuery(true)
					->select($db->quoteName('category'))
					->from($db->quoteName('#__nc_category'))
					->where($db->quoteName('id') . ' = ' . $db->quote($r->nc_category))
					->where($db->quoteName('state') . ' = ' . $db->quote(1));
				$db->setQuery($catQuery);
				$ncCat = $db->loadResult();

				$typeQuery = $db->getQuery(true)
					->select($db->quoteName('nc'))
					->from($db->quoteName('#__nc_types'))
					->where($db->quoteName('id') . ' = ' . $db->quote($r->nc_type))
					->where($db->quoteName('state') . ' = ' . $db->quote(1));
				$db->setQuery($typeQuery);
				$ncType = $db->loadResult();

				$rows[$key] = (object) array(
					'nc_category'  => $ncCat,
					'nc_type'      => $ncType,
					'by_date'      => array_fill_keys($dates, 0.0),
					'by_date_pct'  => array_fill_keys($dates, 0.0),
					'week_qty'     => 0.0,
					'week_sort'    => $weekSortByKey[$key] ?? 0.0,
					'week_pct'     => 0.0,
				);
			}

			// Ignore stray rows outside the 7 selected days (shouldn't normally happen,
			// since applyEntryFilters() already constrains a.date to this range).
			if (!isset($rows[$key]->by_date[$date])) {
				continue;
			}

			$rows[$key]->by_date[$date]     += $qty;
			$rows[$key]->by_date_pct[$date] += $pct;
			$rows[$key]->week_qty           += $qty;
			// $rows[$key]->week_pct           += $pct;

			$dayTotals[$date]     += $qty;
			// $dayTotalsPct[$date]  += $pct;
			$weekTotalNc          += $qty;
			// $weekTotalNcPct       += $pct;
		}

		$weekTotalNcPct = $weekTotalSort > 0 ? (float)($weekTotalNc / $weekTotalSort) * 100 : 0.0;

		foreach ($rows as $key => $row) {
			$row->week_pct = $row->week_sort > 0 ? ($row->week_qty / $row->week_sort) * 100 : 0.0;
			$rows[$key]    = $row;
		}

		uasort(
			$rows,
			function ($a, $b) {
				return strcmp($a->nc_category . $a->nc_type, $b->nc_category . $b->nc_type);
			}
		);

		return (object) array(
			'dates'             => $dates,
			'rows'              => array_values($rows),
			'day_totals'        => $dayTotals,
			'day_totals_pct'    => $dayTotalsPct,
			'day_sort_totals'   => $daySortTotals,
			'week_total_nc'     => $weekTotalNc,
			'week_total_sort'   => $weekTotalSort,
			'week_total_nc_pct' => $weekTotalNcPct,
		);
	}

	/**
	 * Apply the Model filter and the resolved Monday-Sunday week range,
	 * shared by every query in this model.
	 *
	 * @param   DatabaseInterface              $db     The database driver.
	 * @param   \Joomla\Database\DatabaseQuery  $query  The query to constrain.
	 *
	 * @return  void
	 *
	 * @since   1.2.0
	 */
	protected function applyEntryFilters(DatabaseInterface $db, $query)
	{
		if ($this->filterModel !== '') {
			$query->where($db->quoteName('a.model') . ' = ' . $db->quote($this->filterModel));
		}

		if ($this->filterVendor !== '') {
			$query->where($db->quoteName('a.vendor') . ' = ' . $db->quote($this->filterVendor));
		}

		if ($this->filterRemark !== '') {
			$query->where($db->quoteName('a.lot') . ' = ' . $db->quote($this->filterRemark));
		}

		$query->where($db->quoteName('a.date') . ' BETWEEN ' . $db->quote($this->weekStart->format('Y-m-d H:i:s')) . ' AND ' . $db->quote($this->weekEnd->format('Y-m-d H:i:s')));
	}

	/**
	 * Apply the category/type search filter (only relevant to NC-row queries).
	 *
	 * @param   DatabaseInterface              $db     The database driver.
	 * @param   \Joomla\Database\DatabaseQuery  $query  The query to constrain.
	 *
	 * @return  void
	 *
	 * @since   1.2.0
	 */
	protected function applyNcSearch(DatabaseInterface $db, $query)
	{
		if ($this->filterSearch === '') {
			return;
		}

		$search = $db->quote('%' . $db->escape($this->filterSearch, true) . '%');
		$query->where(
			'(' . $db->quoteName('nc.nc_category') . ' LIKE ' . $search .
				' OR ' . $db->quoteName('nc.nc_type') . ' LIKE ' . $search . ')'
		);
	}
}
