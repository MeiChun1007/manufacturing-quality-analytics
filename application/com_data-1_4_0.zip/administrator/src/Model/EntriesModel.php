<?php

/**
 * @version    CVS: 1.0.0
 * @package    Com_Data
 * @author     Mei Chun <qc.yolotech@gmail.com>
 * @copyright  2026 YOLO
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace Data\Component\Data\Administrator\Model;
// No direct access.
defined('_JEXEC') or die;

use \Joomla\CMS\MVC\Model\ListModel;
use \Joomla\Component\Fields\Administrator\Helper\FieldsHelper;
use \Joomla\CMS\Factory;
use \Joomla\CMS\Language\Text;
use \Joomla\CMS\Helper\TagsHelper;
use \Joomla\Database\ParameterType;
use \Joomla\Utilities\ArrayHelper;
use Data\Component\Data\Administrator\Helper\DataHelper;
use \Joomla\Database\DatabaseInterface;

/**
 * Methods supporting a list of Entries records.
 *
 * @since  1.0.0
 */
class EntriesModel extends ListModel
{
	/**
	 * Constructor.
	 *
	 * @param   array  $config  An optional associative array of configuration settings.
	 *
	 * @see        JController
	 * @since      1.6
	 */
	public function __construct($config = array())
	{
		if (empty($config['filter_fields'])) {
			$config['filter_fields'] = array(
				'id',
				'a.id',
				'state',
				'a.state',
				'ordering',
				'a.ordering',
				'created_by',
				'a.created_by',
				'modified_by',
				'a.modified_by',
				'custom_field_1',
				'a.custom_field_1',
				'custom_field_2',
				'a.custom_field_2',
				'custom_field_3',
				'a.custom_field_3',
				'custom_field_4',
				'a.custom_field_4',
				'custom_field_5',
				'a.custom_field_5',
				'date',
				'a.date',
				'week',
				'a.week',
				'component',
				'a.component',
				'model',
				'a.model',
				'vendor',
				'a.vendor',
				'operator',
				'a.operator',
				'total',
				'a.total',
				'work_order_no',
				'a.work_order_no',
				'nc_entry_count',
				'nc_entry_count',
				'nc_quantity_total',
				'nc_quantity_total',
			);
		}

		parent::__construct($config);
	}








	/**
	 * Method to auto-populate the model state.
	 *
	 * Note. Calling getState in this method will result in recursion.
	 *
	 * @param   string  $ordering   Elements order
	 * @param   string  $direction  Order direction
	 *
	 * @return void
	 *
	 * @throws Exception
	 */
	protected function populateState($ordering = null, $direction = null)
	{
		// List state information.
		parent::populateState("a.id", "DESC");

		$context = $this->getUserStateFromRequest($this->context . '.filter.search', 'filter_search');
		$this->setState('filter.search', $context);

		// Split context into component and optional section
		if (!empty($context)) {
			$parts = FieldsHelper::extract($context);

			if ($parts) {
				$this->setState('filter.component', $parts[0]);
				$this->setState('filter.section', $parts[1]);
			}
		}
	}

	/**
	 * Method to get a store id based on model configuration state.
	 *
	 * This is necessary because the model is used by the component and
	 * different modules that might need different sets of data or different
	 * ordering requirements.
	 *
	 * @param   string  $id  A prefix for the store id.
	 *
	 * @return  string A store id.
	 *
	 * @since   1.0.0
	 */
	protected function getStoreId($id = '')
	{
		// Compile the store id.
		$id .= ':' . $this->getState('filter.search');
		$id .= ':' . $this->getState('filter.state');


		return parent::getStoreId($id);
	}

	/**
	 * Build an SQL query to load the list data.
	 *
	 * @return  DatabaseQuery
	 *
	 * @since   1.0.0
	 */
	protected function getListQuery()
	{
		// Create a new query object.
		$db    = Factory::getContainer()->get(DatabaseInterface::class);
		$query = $db->getQuery(true);

		// Select the required fields from the table.
		$query->select(
			$this->getState(
				'list.select',
				'DISTINCT a.*'
			)
		);
		$query->from('`#__data_entry` AS a');

		// Join over the users for the checked out user
		$query->select("uc.name AS uEditor");
		$query->join("LEFT", "#__users AS uc ON uc.id=a.checked_out");

		// Join over the user field 'operator'
		$query->select('`operator`.name AS `operator`');
		$query->join('LEFT', '#__users AS `operator` ON `operator`.id = a.`operator`');

		// Summarise the repeatable "NC Data Entry" rows for this entry
		$query->select('(SELECT COUNT(*) FROM #__data_entry_nc AS nc WHERE nc.entry_id = a.id) AS nc_entry_count');
		$query->select('(SELECT SUM(nc.nc_quantity) FROM #__data_entry_nc AS nc WHERE nc.entry_id = a.id) AS nc_quantity_total');


		// Filter by published state
		$published = $this->getState('filter.state');

		if (is_numeric($published)) {
			$query->where('a.state = ' . (int) $published);
		} elseif (empty($published)) {
			$query->where('(a.state IN (0, 1))');
		}

		// Filter by search in title
		$search = $this->getState('filter.search');

		if (!empty($search)) {
			if (stripos($search, 'id:') === 0) {
				$query->where('a.id = ' . (int) substr($search, 3));
			} else {
				$escaped = $db->Quote('%' . $db->escape($search, true) . '%');
				$query->where(
					'(' . $db->quoteName('a.work_order_no') . ' LIKE ' . $escaped .
						' OR ' . $db->quoteName('a.reference_no') . ' LIKE ' . $escaped .
						' OR EXISTS (SELECT 1 FROM ' . $db->quoteName('#__vendor_details', 'vd') .
						' INNER JOIN ' . $db->quoteName('#__vendor_remarks', 'vr') . ' ON ' . $db->quoteName('vr.id') . ' = ' . $db->quoteName('vd.remark') .
						' WHERE FIND_IN_SET(' . $db->quoteName('vd.id') . ', ' . $db->quoteName('a.remark') . ')' .
						' AND ' . $db->quoteName('vr.remark') . ' LIKE ' . $escaped . ')' .
						' OR EXISTS (SELECT 1 FROM ' . $db->quoteName('#__product_components', 'pc_s') .
						' WHERE FIND_IN_SET(' . $db->quoteName('pc_s.id') . ', ' . $db->quoteName('a.component') . ')' .
						' AND ' . $db->quoteName('pc_s.component_name') . ' LIKE ' . $escaped . ')' .
						' OR EXISTS (SELECT 1 FROM ' . $db->quoteName('#__product_catalogs', 'pcat_s') .
						' WHERE FIND_IN_SET(' . $db->quoteName('pcat_s.id') . ', ' . $db->quoteName('a.model') . ')' .
						' AND ' . $db->quoteName('pcat_s.model_name') . ' LIKE ' . $escaped . ')' .
						' OR EXISTS (SELECT 1 FROM ' . $db->quoteName('#__users', 'ven_s') .
						' WHERE FIND_IN_SET(' . $db->quoteName('ven_s.id') . ', ' . $db->quoteName('a.vendor') . ')' .
						' AND ' . $db->quoteName('ven_s.name') . ' LIKE ' . $escaped . ')' .
						' OR EXISTS (SELECT 1 FROM ' . $db->quoteName('#__users', 'op_s') .
						' WHERE FIND_IN_SET(' . $db->quoteName('op_s.id') . ', ' . $db->quoteName('a.operator') . ')' .
						' AND ' . $db->quoteName('op_s.name') . ' LIKE ' . $escaped . ')' .
						')'
				);
			}
		}


		// Filtering component
		$filter_component = $this->state->get("filter.component");
		if (is_array($filter_component) && count($filter_component) === 1) {
			$filter_component = reset($filter_component);
		}

		if ((is_array($filter_component) && count(array_filter($filter_component, function ($v) {
			return $v !== "" && $v !== null;
		})) > 0) || (!is_array($filter_component) && $filter_component !== "" && $filter_component !== null)) {
			if (!is_array($filter_component)) {
				$query->where($db->quoteName("a.component") . " = " . $db->quote($filter_component));
			}
		}

		// Filtering model
		$filter_model = $this->state->get("filter.model");
		if (is_array($filter_model) && count($filter_model) === 1) {
			$filter_model = reset($filter_model);
		}

		if ((is_array($filter_model) && count(array_filter($filter_model, function ($v) {
			return $v !== "" && $v !== null;
		})) > 0) || (!is_array($filter_model) && $filter_model !== "" && $filter_model !== null)) {
			if (!is_array($filter_model)) {
				$query->where($db->quoteName("a.model") . " = " . $db->quote($filter_model));
			}
		}

		// Filtering vendor
		$filter_vendor = $this->state->get("filter.vendor");
		if (is_array($filter_vendor) && count($filter_vendor) === 1) {
			$filter_vendor = reset($filter_vendor);
		}

		if ((is_array($filter_vendor) && count(array_filter($filter_vendor, function ($v) {
			return $v !== "" && $v !== null;
		})) > 0) || (!is_array($filter_vendor) && $filter_vendor !== "" && $filter_vendor !== null)) {
			if (!is_array($filter_vendor)) {
				$query->where($db->quoteName("a.vendor") . " = " . $db->quote($filter_vendor));
			}
		}

		// Filtering lot
		$filter_lot = $this->state->get('filter.lot');
		if ($filter_lot !== null && $filter_lot !== '') {
			$query->where($db->quoteName('a.lot') . ' = ' . (int) $filter_lot);
		}

		// Add the list ordering clause.
		$orderCol  = $this->state->get('list.ordering', "a.id");
		$orderDirn = $this->state->get('list.direction', "DESC");

		if ($orderCol && $orderDirn) {
			$query->order($db->escape($orderCol . ' ' . $orderDirn));
		}

		return $query;
	}

	/**
	 * Get an array of data items
	 *
	 * @return mixed Array of data items on success, false on failure.
	 */
	public function getItems()
	{
		$items = parent::getItems();

		foreach ($items as $item) {
			if (isset($item->component)) {
				$values    = explode(',', $item->component);
				$textValue = array();

				foreach ($values as $value) {
					if (!empty($value)) {
						$db    = Factory::getContainer()->get(DatabaseInterface::class);
						$query = $db->getQuery(true)
							->select($db->quoteName('component_name'))
							->from($db->quoteName('#__product_components'))
							->where($db->quoteName('id') . ' = ' . $db->quote((int) $value));

						$db->setQuery($query);

						// FIX: loadResult() returns the text string directly instead of an object
						$componentName = $db->loadResult();

						if ($componentName) {
							$textValue[] = $componentName;
						}
					}
				}

				$item->component = !empty($textValue) ? implode(', ', $textValue) : $item->component;
			}

			if (!empty($item->model)) {
				// Split out commas if multiple IDs are saved (e.g., "1,2") and clean up integers
				$modelIds = array_filter(array_map('intval', explode(',', $item->model)));

				if (!empty($modelIds)) {
					$db = Factory::getContainer()->get(\Joomla\Database\DatabaseInterface::class);

					// Build a clean query to translate model IDs into human-readable model names
					$query = $db->getQuery(true)
						->select($db->quoteName('model_name'))         // Fetches the text value column
						->from($db->quoteName('#__product_catalogs'))     // Targets your models table
						->where($db->quoteName('id') . ' IN (' . implode(',', $modelIds) . ')');

					$db->setQuery($query);

					// Fetches all matching model names in one single trip to the database
					$modelNames = $db->loadColumn();

					if (!empty($modelNames)) {
						// Replaces the numeric ID with the readable string (e.g., "BLMT501L, BLMT501R")
						$item->model = implode(', ', $modelNames);
					}
				}
			}
			if (!empty($item->vendor)) {
				// Split out commas if multiple IDs are saved (e.g., "1,2") and sanitize
				$vendorIds = array_filter(array_map('intval', explode(',', $item->vendor)));

				if (!empty($vendorIds)) {
					$db = Factory::getContainer()->get(\Joomla\Database\DatabaseInterface::class);

					// Build a query to translate vendor IDs into human-readable vendor names
					$query = $db->getQuery(true)
						->select($db->quoteName('name'))         // Replace 'vendor_name' with your actual column name
						->from($db->quoteName('#__users'))     // Replace with your actual vendors table name
						->where($db->quoteName('id') . ' IN (' . implode(',', $vendorIds) . ')');

					$db->setQuery($query);

					// Fetches matching vendor names in a single query
					$vendorNames = $db->loadColumn();

					if (!empty($vendorNames)) {
						// Replaces "1, 2" with "Vendor A, Vendor B"
						$item->vendor = implode(', ', $vendorNames);
					}
				}
			}

			if (isset($item->lot) && $item->lot !== '') {
				$lotOptions = array(
					'0' => Text::_('COM_DATA_LOT_NORMAL'),
					'1' => Text::_('COM_DATA_LOT_RESORT'),
				);

				$item->lot_raw = $item->lot;
				$item->lot     = $lotOptions[$item->lot] ?? $item->lot;
			}

			if (!empty($item->remark)) {
				$remarkIds = array_filter(array_map('intval', explode(',', $item->remark)));

				if (!empty($remarkIds)) {
					$db = Factory::getContainer()->get(\Joomla\Database\DatabaseInterface::class);

					$query = $db->getQuery(true)
						->select($db->quoteName('vr.remark'))
						->from($db->quoteName('#__vendor_details', 'vd'))
						->join('INNER', $db->quoteName('#__vendor_remarks', 'vr') . ' ON ' . $db->quoteName('vr.id') . ' = ' . $db->quoteName('vd.remark'))
						->where($db->quoteName('vd.id') . ' IN (' . implode(',', $remarkIds) . ')');

					$db->setQuery($query);

					$remarkNames = $db->loadColumn();

					if (!empty($remarkNames)) {
						$item->remark = implode(', ', $remarkNames);
					}
				}
			}

			if (!empty($item->resort_nc)) {
				$resortNcIds = array_filter(array_map('intval', explode(',', $item->resort_nc)));

				if (!empty($resortNcIds)) {
					$db = Factory::getContainer()->get(\Joomla\Database\DatabaseInterface::class);

					$query = $db->getQuery(true)
						->select($db->quoteName('nc'))
						->from($db->quoteName('#__nc_types'))
						->where($db->quoteName('id') . ' IN (' . implode(',', $resortNcIds) . ')');

					$db->setQuery($query);

					$resortNcNames = $db->loadColumn();

					if (!empty($resortNcNames)) {
						$item->resort_nc = implode(', ', $resortNcNames);
					}
				}
			}
		}

		return $items;
	}
}
