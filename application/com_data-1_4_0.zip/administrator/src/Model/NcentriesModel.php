<?php

/**
 * @version    CVS: 1.1.0
 * @package    Com_Data
 * @author     Mei Chun <qc.yolotech@gmail.com>
 * @copyright  2026 YOLO
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace Data\Component\Data\Administrator\Model;
// No direct access.
defined('_JEXEC') or die;

use \Joomla\CMS\Factory;
use \Joomla\CMS\MVC\Model\ListModel;
use \Joomla\Database\DatabaseInterface;
use \Joomla\CMS\Language\Text;


/**
 * Methods supporting a flat list of "NC Data Entry" rows (#__data_entry_nc),
 * across every "Total Data Entry" record, for a standalone read-only screen.
 *
 * @since  1.2.0
 */
class NcentriesModel extends ListModel
{
	/**
	 * Constructor.
	 *
	 * @param   array  $config  An optional associative array of configuration settings.
	 *
	 * @since  1.2.0
	 */
	public function __construct($config = array())
	{
		if (empty($config['filter_fields'])) {
			$config['filter_fields'] = array(
				'id',
				'nc.id',
				'entry_id',
				'nc.entry_id',
				'nc_category',
				'nc.nc_category',
				'nc_type',
				'nc.nc_type',
				'nc_quantity',
				'nc.nc_quantity',
				'nc_percentage',
				'nc.nc_percentage',
				'entry_date',
				'a.date',
				'entry_week',
				'a.week',
				'entry_work_order_no',
				'a.work_order_no',
				'entry_component',
				'a.component',
				'entry_model',
				'a.model',
				'entry_vendor',
				'a.vendor',
				'entry_reference_no',
				'a.reference_no',
				'entry_remark',
				'a.remark',
				'entry_lot',
				'a.lot',
				'entry_resort_nc',
				'a.resort_nc',
			);
		}

		parent::__construct($config);
	}

	/**
	 * Method to auto-populate the model state.
	 *
	 * @param   string  $ordering   Elements order
	 * @param   string  $direction  Order direction
	 *
	 * @return  void
	 *
	 * @since   1.2.0
	 */
	protected function populateState($ordering = null, $direction = null)
	{
		parent::populateState('nc.id', 'DESC');

		$context = $this->getUserStateFromRequest($this->context . '.filter.search', 'filter_search');
		$this->setState('filter.search', $context);
	}

	/**
	 * Method to get a store id based on model configuration state.
	 *
	 * @param   string  $id  A prefix for the store id.
	 *
	 * @return  string  A store id.
	 *
	 * @since   1.2.0
	 */
	protected function getStoreId($id = '')
	{
		$id .= ':' . $this->getState('filter.search');

		return parent::getStoreId($id);
	}

	/**
	 * Build an SQL query to load the list data.
	 *
	 * @return  \Joomla\Database\DatabaseQuery
	 *
	 * @since   1.2.0
	 */
	protected function getListQuery()
	{
		$db    = Factory::getContainer()->get(DatabaseInterface::class);
		$query = $db->getQuery(true);

		$query->select(
			$this->getState(
				'list.select',
				'DISTINCT nc.id AS id, nc.entry_id AS entry_id, nc.nc_category AS nc_category, ' .
					'nc.nc_quantity AS nc_quantity, nc.nc_percentage AS nc_percentage, nc.ordering AS ordering'
			)
		);
		$query->from($db->quoteName('#__data_entry_nc', 'nc'));

		// Bring in the parent "Total Data Entry" context for each row.
		$query->select(
			'a.date AS entry_date, a.week AS entry_week, a.work_order_no AS entry_work_order_no, ' .
				'a.component AS entry_component, a.model AS entry_model, a.vendor AS entry_vendor, ' .
				'a.operator AS entry_operator, a.total AS entry_total, a.reference_no AS entry_reference_no, ' .
				'a.lot AS entry_lot, a.remark AS entry_remark, a.resort_nc AS entry_resort_nc'
		);
		$query->join('INNER', $db->quoteName('#__data_entry', 'a') . ' ON ' . $db->quoteName('a.id') . ' = ' . $db->quoteName('nc.entry_id'));

		// --- NEW CODE ADDED HERE ---
		// Only fetch records where the parent entry's state is active/published (state = 1)
		$query->where($db->quoteName('a.state') . ' = 1');
		// ---------------------------

		// Resolve the operator's display name.
		$query->select($db->quoteName('op.name', 'operator_name'));
		$query->join('LEFT', $db->quoteName('#__users', 'op') . ' ON ' . $db->quoteName('op.id') . ' = ' . $db->quoteName('a.operator'));

		// Resolve the human readable NC category, if the reference table exists on this site.
		$query->select($db->quoteName('nctype.nc', 'nc_code'));
		$query->select($db->quoteName('cat.category', 'nc_category_name'));
		$query->join('LEFT', $db->quoteName('#__nc_types', 'nctype') . ' ON ' . $db->quoteName('nctype.id') . ' = ' . $db->quoteName('nc.nc_type'));
		$query->join('LEFT', $db->quoteName('#__nc_category', 'cat') . ' ON ' . $db->quoteName('cat.id') . ' = ' . $db->quoteName('nctype.category'));

		// Filter by search (matches the parent WO number or the NC category text).
		$search = $this->getState('filter.search');

		if (!empty($search)) {
			if (stripos($search, 'id:') === 0) {
				$query->where('a.id = ' . (int) substr($search, 3));
			} else {
				$escaped = $db->Quote('%' . $db->escape($search, true) . '%');
				$query->where(
					'(' . $db->quoteName('a.work_order_no') . ' LIKE ' . $escaped .
						' OR ' . $db->quoteName('a.reference_no') . ' LIKE ' . $escaped .
						' OR EXISTS (SELECT 1 FROM ' . $db->quoteName('#__product_components', 'pc_s') .
						' WHERE FIND_IN_SET(' . $db->quoteName('pc_s.id') . ', ' . $db->quoteName('a.component') . ')' .
						' AND ' . $db->quoteName('pc_s.component_name') . ' LIKE ' . $escaped . ')' .
						' OR EXISTS (SELECT 1 FROM ' . $db->quoteName('#__product_catalogs', 'pcat_s') .
						' WHERE FIND_IN_SET(' . $db->quoteName('pcat_s.id') . ', ' . $db->quoteName('a.model') . ')' .
						' AND ' . $db->quoteName('pcat_s.model_name') . ' LIKE ' . $escaped . ')' .
						' OR EXISTS (SELECT 1 FROM ' . $db->quoteName('#__users', 'ven_s') .
						' WHERE FIND_IN_SET(' . $db->quoteName('ven_s.id') . ', ' . $db->quoteName('a.vendor') . ')' .
						' AND ' . $db->quoteName('ven_s.name') . ' LIKE ' . $escaped . ')' .
						' OR EXISTS (SELECT 1 FROM ' . $db->quoteName('#__users', 'op_s') .
						' WHERE FIND_IN_SET(' . $db->quoteName('op_s.id') . ', ' . $db->quoteName('a.operator') . ')' .
						' AND ' . $db->quoteName('op_s.name') . ' LIKE ' . $escaped . ')' .
						' OR EXISTS (SELECT 1 FROM ' . $db->quoteName('#__nc_types', 'nctype') .
						' WHERE FIND_IN_SET(' . $db->quoteName('nctype.id') . ', ' . $db->quoteName('nc.nc_type') . ')' .
						' AND ' . $db->quoteName('nctype.nc') . ' LIKE ' . $escaped . ')' .
						')'
				);
			}
		}

		// Filtering component / model / vendor (reuses the same filters as the Entries screen).
		$filterComponent = $this->getState('filter.component');
		if (!empty($filterComponent)) {
			$query->where($db->quoteName('a.component') . ' = ' . $db->quote($filterComponent));
		}

		$filterModel = $this->getState('filter.model');
		if (!empty($filterModel)) {
			$query->where($db->quoteName('a.model') . ' = ' . $db->quote($filterModel));
		}

		$filterVendor = $this->getState('filter.vendor');
		if (!empty($filterVendor)) {
			$query->where($db->quoteName('a.vendor') . ' = ' . $db->quote($filterVendor));
		}

		// Add the list ordering clause.
		$orderCol  = $this->state->get('list.ordering', 'nc.id');
		$orderDirn = $this->state->get('list.direction', 'DESC');

		if ($orderCol && $orderDirn) {
			$query->order($db->escape($orderCol . ' ' . $orderDirn));
		}

		return $query;
	}

	/**
	 * Get an array of data items, resolving component/model/vendor ids into readable labels.
	 *
	 * @return  mixed  Array of data items on success, false on failure.
	 *
	 * @since   1.2.0
	 */
	public function getItems()
	{
		$items = parent::getItems();

		$db = Factory::getContainer()->get(DatabaseInterface::class);

		foreach ($items as $item) {
			// Human readable NC category label (falls back to the raw stored value).
			if (!empty($item->nc_code) || !empty($item->nc_category_name)) {
				$item->nc_category_label = trim(($item->nc_code ?? '') . ' - ' . ($item->nc_category_name ?? ''), ' -');
			} else {
				$item->nc_category_label = $item->nc_category;
			}

			// Resolve component label(s).
			if (!empty($item->entry_component)) {
				$componentIds = array_filter(array_map('intval', explode(',', $item->entry_component)));

				if (!empty($componentIds)) {
					$query = $db->getQuery(true)
						->select($db->quoteName('component_name'))
						->from($db->quoteName('#__product_components'))
						->where($db->quoteName('id') . ' IN (' . implode(',', $componentIds) . ')');
					$db->setQuery($query);
					$names = $db->loadColumn();

					if (!empty($names)) {
						$item->entry_component = implode(', ', $names);
					}
				}
			}

			// Resolve model label(s).
			if (!empty($item->entry_model)) {
				$modelIds = array_filter(array_map('intval', explode(',', $item->entry_model)));

				if (!empty($modelIds)) {
					$query = $db->getQuery(true)
						->select($db->quoteName('model_name'))
						->from($db->quoteName('#__product_catalogs'))
						->where($db->quoteName('id') . ' IN (' . implode(',', $modelIds) . ')');
					$db->setQuery($query);
					$names = $db->loadColumn();

					if (!empty($names)) {
						$item->entry_model = implode(', ', $names);
					}
				}
			}

			// Resolve vendor label(s).
			if (!empty($item->entry_vendor)) {
				$vendorIds = array_filter(array_map('intval', explode(',', $item->entry_vendor)));

				if (!empty($vendorIds)) {
					$query = $db->getQuery(true)
						->select($db->quoteName('name'))
						->from($db->quoteName('#__users'))
						->where($db->quoteName('id') . ' IN (' . implode(',', $vendorIds) . ')');
					$db->setQuery($query);
					$names = $db->loadColumn();

					if (!empty($names)) {
						$item->entry_vendor = implode(', ', $names);
					}
				}
			}

			if (!empty($item->entry_remark)) {
				$remarkIds = array_filter(array_map('intval', explode(',', $item->entry_remark)));

				if (!empty($remarkIds)) {
					$query = $db->getQuery(true)
						->select($db->quoteName('vr.remark'))
						->from($db->quoteName('#__vendor_details', 'vd'))
						->join('INNER', $db->quoteName('#__vendor_remarks', 'vr') . ' ON ' . $db->quoteName('vr.id') . ' = ' . $db->quoteName('vd.remark'))
						->where($db->quoteName('vd.id') . ' IN (' . implode(',', $remarkIds) . ')');

					$db->setQuery($query);

					$remarkNames = $db->loadColumn();

					if (!empty($remarkNames)) {
						$item->entry_remark = implode(', ', $remarkNames);
					}
				}
			}

			if (isset($item->entry_lot) && $item->entry_lot !== '') {
				$lotOptions = array(
					'0' => Text::_('COM_DATA_LOT_NORMAL'),
					'1' => Text::_('COM_DATA_LOT_RESORT'),
				);

				// Keep the raw value for reliable comparisons elsewhere (e.g. in templates),
				// since entry_lot below gets overwritten with the translated label for display.
				$item->entry_lot_raw = $item->entry_lot;
				$item->entry_lot     = $lotOptions[$item->entry_lot] ?? $item->entry_lot;
			}

			if (!empty($item->entry_resort_nc)) {
				$resortNcIds = array_filter(array_map('intval', explode(',', $item->entry_resort_nc)));

				if (!empty($resortNcIds)) {
					$query = $db->getQuery(true)
						->select($db->quoteName('nc'))
						->from($db->quoteName('#__nc_types'))
						->where($db->quoteName('id') . ' IN (' . implode(',', $resortNcIds) . ')');

					$db->setQuery($query);

					$resortNcNames = $db->loadColumn();

					if (!empty($resortNcNames)) {
						$item->entry_resort_nc = implode(', ', $resortNcNames);
					}
				}
			}
		}


		return $items;
	}
}
