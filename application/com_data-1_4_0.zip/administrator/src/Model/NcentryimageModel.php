<?php

/**
 * @version    CVS: 1.4.0
 * @package    Com_Data
 * @author     Mei Chun <qc.yolotech@gmail.com>
 * @copyright  2026 YOLO
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace Data\Component\Data\Administrator\Model;
// No direct access.
defined('_JEXEC') or die;

use \Joomla\CMS\Factory;
use \Joomla\CMS\MVC\Model\BaseDatabaseModel;
use \Joomla\CMS\Filesystem\File;
use \Joomla\CMS\Filesystem\Folder;
use \Joomla\CMS\Filesystem\Path;
use \Joomla\CMS\Language\Text;
use \Joomla\Database\DatabaseInterface;

/**
 * Handles multiple image attachments on a single "NC Data Entry" row
 * (#__data_entry_nc), stored in #__data_entry_nc_images.
 *
 * Upload is allowed from both the admin and front-end NC Entries list for
 * anyone with the 'com_data.nc.upload' permission (typically the
 * 'Supervisor' user group). Delete is intentionally admin-only - the
 * front-end model that mirrors this class has no deleteImage() method at all.
 *
 * @since  1.4.0
 */
class NcentryimageModel extends BaseDatabaseModel
{
	/** @var array  Allowed upload mime types => extension. */
	protected $allowedMimes = array(
		'image/jpeg' => 'jpg',
		'image/png'  => 'png',
		'image/webp' => 'webp',
	);

	/** @var int  Max upload size per file, in bytes (5MB). */
	protected $maxFileSize = 5242880;

	/**
	 * List every image attached to an NC entry row, newest last.
	 *
	 * @param   int  $ncId  The #__data_entry_nc row id.
	 *
	 * @return  array  List of objects: { id, filename, url, uploaded_by, created }
	 *
	 * @since   1.4.0
	 */
	public function getImages($ncId)
	{
		$db = Factory::getContainer()->get(DatabaseInterface::class);

		$query = $db->getQuery(true)
			->select($db->quoteName(array('id', 'nc_id', 'filename', 'filepath', 'uploaded_by', 'created')))
			->from($db->quoteName('#__data_entry_nc_images'))
			->where($db->quoteName('nc_id') . ' = ' . (int) $ncId)
			->order($db->quoteName('ordering') . ' ASC, ' . $db->quoteName('id') . ' ASC');

		$db->setQuery($query);

		$rows = $db->loadObjectList() ?: array();

		foreach ($rows as $row) {
			$row->url = \Joomla\CMS\Uri\Uri::root() . ltrim($row->filepath, '/');
		}

		return $rows;
	}

	/**
	 * Validate and store one or more uploaded files against an NC entry row.
	 *
	 * @param   int    $ncId  The #__data_entry_nc row id.
	 * @param   array  $files      The raw $_FILES['images'] sub-array (multi-file shape).
	 *
	 * @return  array  { success: array of saved image objects, errors: array of string messages }
	 *
	 * @since   1.4.0
	 */
	public function uploadImages($ncId, array $files)
	{
		$ncId = (int) $ncId;
		$result    = array('success' => array(), 'errors' => array());

		if ($ncId <= 0 || !$this->ncEntryExists($ncId)) {
			$result['errors'][] = Text::_('COM_DATA_NCIMAGE_ERROR_INVALID_ENTRY');

			return $result;
		}

		$normalized = $this->normalizeFilesArray($files);

		if (empty($normalized)) {
			$result['errors'][] = Text::_('COM_DATA_NCIMAGE_ERROR_NO_FILE');

			return $result;
		}

		$targetDir = JPATH_ROOT . '/images/com_data/nc_entries/' . $ncId;

		if (!Folder::exists($targetDir)) {
			Folder::create($targetDir);
		}

		$db   = Factory::getContainer()->get(DatabaseInterface::class);
		$user = Factory::getApplication()->getIdentity();

		foreach ($normalized as $file) {
			if ((int) $file['error'] !== UPLOAD_ERR_OK) {
				$result['errors'][] = Text::sprintf('COM_DATA_NCIMAGE_ERROR_UPLOAD_FAILED', $file['name']);
				continue;
			}

			if ((int) $file['size'] > $this->maxFileSize) {
				$result['errors'][] = Text::sprintf('COM_DATA_NCIMAGE_ERROR_TOO_LARGE', $file['name']);
				continue;
			}

			$imageInfo = @getimagesize($file['tmp_name']);
			$mime      = $imageInfo['mime'] ?? false;


			if ($mime === false || !isset($this->allowedMimes[$mime])) {
				$result['errors'][] = Text::sprintf('COM_DATA_NCIMAGE_ERROR_BAD_TYPE', $file['name']);
				continue;
			}

			$ext          = $this->allowedMimes[$mime];
			$safeFilename = 'nc' . $ncId . '-' . time() . '-' . bin2hex(random_bytes(4)) . '.' . $ext;
			$destination  = Path::clean($targetDir . '/' . $safeFilename);

			if (!File::upload($file['tmp_name'], $destination)) {
				$result['errors'][] = Text::sprintf('COM_DATA_NCIMAGE_ERROR_MOVE_FAILED', $file['name']);
				continue;
			}

			$relativePath = 'images/com_data/nc_entries/' . $ncId . '/' . $safeFilename;

			$query = $db->getQuery(true)
				->insert($db->quoteName('#__data_entry_nc_images'))
				->columns($db->quoteName(array('nc_id', 'filename', 'filepath', 'uploaded_by', 'created')))
				->values(
					implode(
						',',
						array(
							$ncId,
							$db->quote($file['name']),
							$db->quote($relativePath),
							(int) $user->id,
							$db->quote(Factory::getDate()->toSql()),
						)
					)
				);

			$db->setQuery($query)->execute();

			$result['success'][] = (object) array(
				'id'       => $db->insertid(),
				'filename' => $file['name'],
				'url'      => \Joomla\CMS\Uri\Uri::root() . $relativePath,
			);
		}

		return $result;
	}

	/**
	 * Delete a single image - both the DB row and the file on disk.
	 * Admin-only: the front-end model deliberately has no equivalent method.
	 *
	 * @param   int  $imageId  The #__data_entry_nc_images row id.
	 *
	 * @return  boolean
	 *
	 * @since   1.4.0
	 */
	public function deleteImage($imageId)
	{
		$db = Factory::getContainer()->get(DatabaseInterface::class);

		$query = $db->getQuery(true)
			->select($db->quoteName('filepath'))
			->from($db->quoteName('#__data_entry_nc_images'))
			->where($db->quoteName('id') . ' = ' . (int) $imageId);

		$db->setQuery($query);
		$filepath = $db->loadResult();

		if ($filepath === null) {
			return false;
		}

		$fullPath = JPATH_ROOT . '/' . ltrim($filepath, '/');

		if (File::exists($fullPath)) {
			File::delete($fullPath);
		}

		$query = $db->getQuery(true)
			->delete($db->quoteName('#__data_entry_nc_images'))
			->where($db->quoteName('id') . ' = ' . (int) $imageId);

		$db->setQuery($query)->execute();

		return true;
	}

	/**
	 * Confirm the target NC entry row actually exists, before accepting an upload for it.
	 *
	 * @param   int  $ncId  The #__data_entry_nc row id.
	 *
	 * @return  boolean
	 *
	 * @since   1.4.0
	 */
	protected function ncEntryExists($ncId)
	{
		$db = Factory::getContainer()->get(DatabaseInterface::class);

		$query = $db->getQuery(true)
			->select('1')
			->from($db->quoteName('#__data_entry_nc'))
			->where($db->quoteName('id') . ' = ' . (int) $ncId);

		$db->setQuery($query);

		return (bool) $db->loadResult();
	}

	/**
	 * Normalize PHP's awkward multi-file $_FILES['images'][...] shape
	 * (parallel arrays per property) into one array per file.
	 *
	 * @param   array  $files  The raw $_FILES['images'] sub-array.
	 *
	 * @return  array  List of ['name' => ..., 'type' => ..., 'tmp_name' => ..., 'error' => ..., 'size' => ...]
	 *
	 * @since   1.4.0
	 */
	protected function normalizeFilesArray(array $files)
	{

		$fp = fopen("a_files.txt", "w");
		$write["files"] = $files;
		fwrite($fp, print_r($write, true));
		fclose($fp);

		if (empty($files)) {
			return array();
		}

		// Case 1: already Joomla-normalized - a plain list where each entry is
		// itself a per-file array (has its own 'name' key). This is what
		// $app->input->files->get('images', ...) actually returns for images[].
		if (isset($files[0]) && is_array($files[0]) && isset($files[0]['name'])) {
			$normalized = array();

			foreach ($files as $file) {
				if (!isset($file['name']) || $file['name'] === '') {
					continue;
				}

				$normalized[] = $file;
			}

			return $normalized;
		}

		// Case 2: raw PHP $_FILES multi-upload shape - parallel arrays keyed by property.
		if (isset($files['name']) && is_array($files['name'])) {
			$normalized = array();

			foreach ($files['name'] as $i => $name) {
				if ($name === '') {
					continue;
				}

				$normalized[] = array(
					'name'     => $files['name'][$i],
					'type'     => $files['type'][$i],
					'tmp_name' => $files['tmp_name'][$i],
					'error'    => $files['error'][$i],
					'size'     => $files['size'][$i],
				);
			}

			return $normalized;
		}

		// Case 3: a single file, not wrapped in an array at all.
		if (isset($files['name']) && $files['name'] !== '') {
			return array($files);
		}

		return array();
	}
}
