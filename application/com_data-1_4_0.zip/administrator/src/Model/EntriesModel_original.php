<?php
/**
 * @version    CVS: 1.0.0
 * @package    Com_Data
 * @author     Mei Chun <qc.yolotech@gmail.com>
 * @copyright  2026 YOLO
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace Data\Component\Data\Administrator\Model;
// No direct access.
defined('_JEXEC') or die;

use \Joomla\CMS\MVC\Model\ListModel;
use \Joomla\Component\Fields\Administrator\Helper\FieldsHelper;
use \Joomla\CMS\Factory;
use \Joomla\CMS\Language\Text;
use \Joomla\CMS\Helper\TagsHelper;
use \Joomla\Database\ParameterType;
use \Joomla\Utilities\ArrayHelper;
use Data\Component\Data\Administrator\Helper\DataHelper;
use \Joomla\Database\DatabaseInterface;

/**
 * Methods supporting a list of Entries records.
 *
 * @since  1.0.0
 */
class EntriesModel extends ListModel
{
	/**
	* Constructor.
	*
	* @param   array  $config  An optional associative array of configuration settings.
	*
	* @see        JController
	* @since      1.6
	*/
	public function __construct($config = array())
	{
		if (empty($config['filter_fields']))
		{
			$config['filter_fields'] = array(
				'id', 'a.id',
				'state', 'a.state',
				'ordering', 'a.ordering',
				'created_by', 'a.created_by',
				'modified_by', 'a.modified_by',
				'custom_field_1', 'a.custom_field_1',
				'custom_field_2', 'a.custom_field_2',
				'custom_field_3', 'a.custom_field_3',
				'custom_field_4', 'a.custom_field_4',
				'custom_field_5', 'a.custom_field_5',
				'date', 'a.date',
				'week', 'a.week',
				'component', 'a.component',
				'model', 'a.model',
				'vendor', 'a.vendor',
				'operator', 'a.operator',
				'total', 'a.total',
				'work_order_no', 'a.work_order_no',
				'nc_entry_count', 'nc_entry_count',
				'nc_quantity_total', 'nc_quantity_total',
			);
		}

		parent::__construct($config);
	}


	

	

	

	/**
	 * Method to auto-populate the model state.
	 *
	 * Note. Calling getState in this method will result in recursion.
	 *
	 * @param   string  $ordering   Elements order
	 * @param   string  $direction  Order direction
	 *
	 * @return void
	 *
	 * @throws Exception
	 */
	protected function populateState($ordering = null, $direction = null)
	{
		// List state information.
		parent::populateState("a.id", "ASC");

		$context = $this->getUserStateFromRequest($this->context.'.filter.search', 'filter_search');
		$this->setState('filter.search', $context);

		// Split context into component and optional section
		if (!empty($context))
		{
			$parts = FieldsHelper::extract($context);

			if ($parts)
			{
				$this->setState('filter.component', $parts[0]);
				$this->setState('filter.section', $parts[1]);
			}
		}
	}

	/**
	 * Method to get a store id based on model configuration state.
	 *
	 * This is necessary because the model is used by the component and
	 * different modules that might need different sets of data or different
	 * ordering requirements.
	 *
	 * @param   string  $id  A prefix for the store id.
	 *
	 * @return  string A store id.
	 *
	 * @since   1.0.0
	 */
	protected function getStoreId($id = '')
	{
		// Compile the store id.
		$id .= ':' . $this->getState('filter.search');
		$id .= ':' . $this->getState('filter.state');

		
		return parent::getStoreId($id);
		
	}

	/**
	 * Build an SQL query to load the list data.
	 *
	 * @return  DatabaseQuery
	 *
	 * @since   1.0.0
	 */
	protected function getListQuery()
	{
		// Create a new query object.
		$db    = Factory::getContainer()->get(DatabaseInterface::class);
		$query = $db->getQuery(true);

		// Select the required fields from the table.
		$query->select(
			$this->getState(
				'list.select', 'DISTINCT a.*'
			)
		);
		$query->from('`#__data_entry` AS a');
		
		// Join over the users for the checked out user
		$query->select("uc.name AS uEditor");
		$query->join("LEFT", "#__users AS uc ON uc.id=a.checked_out");

		// Join over the user field 'operator'
		$query->select('`operator`.name AS `operator`');
		$query->join('LEFT', '#__users AS `operator` ON `operator`.id = a.`operator`');

		// Summarise the repeatable "NC Data Entry" rows for this entry
		$query->select('(SELECT COUNT(*) FROM #__data_entry_nc AS nc WHERE nc.entry_id = a.id) AS nc_entry_count');
		$query->select('(SELECT SUM(nc.nc_quantity) FROM #__data_entry_nc AS nc WHERE nc.entry_id = a.id) AS nc_quantity_total');
		

		// Filter by published state
		$published = $this->getState('filter.state');

		if (is_numeric($published))
		{
			$query->where('a.state = ' . (int) $published);
		}
		elseif (empty($published))
		{
			$query->where('(a.state IN (0, 1))');
		}

		// Filter by search in title
		$search = $this->getState('filter.search');

		if (!empty($search))
		{
			if (stripos($search, 'id:') === 0)
			{
				$query->where('a.id = ' . (int) substr($search, 3));
			}
			else
			{
				$search = $db->Quote('%' . $db->escape($search, true) . '%');
				$query->where('( a.custom_field_1 LIKE ' . $search . '  OR  a.custom_field_2 LIKE ' . $search . '  OR  a.custom_field_3 LIKE ' . $search . '  OR  a.custom_field_4 LIKE ' . $search . '  OR  a.custom_field_5 LIKE ' . $search . '  OR  a.date LIKE ' . $search . '  OR  a.component LIKE ' . $search . '  OR  a.model LIKE ' . $search . '  OR  a.vendor LIKE ' . $search . '  OR operator.name LIKE ' . $search . '  OR  a.work_order_no LIKE ' . $search . ' )');
			}
		}
		

		// Filtering component
		$filter_component = $this->state->get("filter.component");
		if (is_array($filter_component) && count($filter_component) === 1) {
			$filter_component = reset($filter_component);
		}

		if ((is_array($filter_component) && count(array_filter($filter_component, function($v){return $v !== "" && $v !== null;})) > 0) || (!is_array($filter_component) && $filter_component !== "" && $filter_component !== null))
		{
			if (!is_array($filter_component)) {
				$query->where($db->quoteName("a.component") . " = " . $db->quote($filter_component));
			}
		}

		// Filtering model
		$filter_model = $this->state->get("filter.model");
		if (is_array($filter_model) && count($filter_model) === 1) {
			$filter_model = reset($filter_model);
		}

		if ((is_array($filter_model) && count(array_filter($filter_model, function($v){return $v !== "" && $v !== null;})) > 0) || (!is_array($filter_model) && $filter_model !== "" && $filter_model !== null))
		{
			if (!is_array($filter_model)) {
				$query->where($db->quoteName("a.model") . " = " . $db->quote($filter_model));
			}
		}

		// Filtering vendor
		$filter_vendor = $this->state->get("filter.vendor");
		if (is_array($filter_vendor) && count($filter_vendor) === 1) {
			$filter_vendor = reset($filter_vendor);
		}

		if ((is_array($filter_vendor) && count(array_filter($filter_vendor, function($v){return $v !== "" && $v !== null;})) > 0) || (!is_array($filter_vendor) && $filter_vendor !== "" && $filter_vendor !== null))
		{
			if (!is_array($filter_vendor)) {
				$query->where($db->quoteName("a.vendor") . " = " . $db->quote($filter_vendor));
			}
		}

		// Add the list ordering clause.
		$orderCol  = $this->state->get('list.ordering', "a.id");
		$orderDirn = $this->state->get('list.direction', "ASC");

		if ($orderCol && $orderDirn)
		{
			$query->order($db->escape($orderCol . ' ' . $orderDirn));
		}

		return $query;
	}

	/**
	 * Get an array of data items
	 *
	 * @return mixed Array of data items on success, false on failure.
	 */
	public function getItems()
	{
		$items = parent::getItems();
		
		foreach ($items as $oneItem)
		{

			if (isset($oneItem->component))
			{
				$values    = explode(',', $oneItem->component);
				$textValue = array();

				foreach ($values as $value)
				{
					if (!empty($value))
					{
						$db = Factory::getContainer()->get(DatabaseInterface::class);
						$query = "SELECT  FROM  WHERE .component LIKE '" . $value . "'";
						$db->setQuery($query);
						$results = $db->loadObject();

						if ($results)
						{
							$textValue[] = $results->value;
						}
					}
				}

				$oneItem->component = !empty($textValue) ? implode(', ', $textValue) : $oneItem->component;
			}

			if (isset($oneItem->model))
			{
				$values    = explode(',', $oneItem->model);
				$textValue = array();

				foreach ($values as $value)
				{
					if (!empty($value))
					{
						$db = Factory::getContainer()->get(DatabaseInterface::class);
						$query = "SELECT  FROM  WHERE .model LIKE '" . $value . "'";
						$db->setQuery($query);
						$results = $db->loadObject();

						if ($results)
						{
							$textValue[] = $results->value;
						}
					}
				}

				$oneItem->model = !empty($textValue) ? implode(', ', $textValue) : $oneItem->model;
			}

			if (isset($oneItem->vendor))
			{
				$values    = explode(',', $oneItem->vendor);
				$textValue = array();

				foreach ($values as $value)
				{
					if (!empty($value))
					{
						$db = Factory::getContainer()->get(DatabaseInterface::class);
						$query = "SELECT  FROM  WHERE .vendor LIKE '" . $value . "'";
						$db->setQuery($query);
						$results = $db->loadObject();

						if ($results)
						{
							$textValue[] = $results->value;
						}
					}
				}

				$oneItem->vendor = !empty($textValue) ? implode(', ', $textValue) : $oneItem->vendor;
			}
		}

		return $items;
	}
}
