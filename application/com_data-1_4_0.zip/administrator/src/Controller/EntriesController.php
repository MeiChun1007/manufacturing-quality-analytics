<?php

/**
 * @version    CVS: 1.0.0
 * @package    Com_Data
 * @author     Mei Chun <qc.yolotech@gmail.com>
 * @copyright  2026 YOLO
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace Data\Component\Data\Administrator\Controller;

\defined('_JEXEC') or die;

use Joomla\CMS\Application\SiteApplication;
use Joomla\CMS\Factory;
use Joomla\CMS\Language\Multilanguage;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\Controller\AdminController;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Uri\Uri;
use Joomla\Utilities\ArrayHelper;
use \Joomla\CMS\Session\Session;


/**
 * Entries list controller class.
 *
 * @since  1.0.0
 */
class EntriesController extends AdminController
{
	/**
	 * Method to clone existing Entries
	 *
	 * @return  void
	 *
	 * @throws  Exception
	 */
	public function duplicate()
	{
		// Check for request forgeries
		$this->checkToken();

		// Get id(s)
		$pks = $this->input->post->get('cid', array(), 'array');

		try {
			if (empty($pks)) {
				throw new \Exception(Text::_('COM_DATA_NO_ELEMENT_SELECTED'));
			}

			ArrayHelper::toInteger($pks);
			$model = $this->getModel();
			$model->duplicate($pks);
			$this->setMessage(Text::_('COM_DATA_ITEMS_SUCCESS_DUPLICATED'));
		} catch (\Exception $e) {
			Factory::getApplication()->enqueueMessage($e->getMessage(), 'warning');
		}

		$this->setRedirect('index.php?option=com_data&view=entries');
	}

	/**
	 * Proxy for getModel.
	 *
	 * @param   string  $name    Optional. Model name
	 * @param   string  $prefix  Optional. Class prefix
	 * @param   array   $config  Optional. Configuration array for model
	 *
	 * @return  object	The Model
	 *
	 * @since   1.0.0
	 */
	public function getModel($name = 'Entry', $prefix = 'Administrator', $config = array())
	{
		return parent::getModel($name, $prefix, array('ignore_request' => true));
	}



	/**
	 * Method to save the submitted ordering values for records via AJAX.
	 *
	 * @return  void
	 *
	 * @since   1.0.0
	 *
	 * @throws  Exception
	 */
	public function saveOrderAjax()
	{
		// Get the input
		$pks   = $this->input->post->get('cid', array(), 'array');
		$order = $this->input->post->get('order', array(), 'array');

		// Sanitize the input
		ArrayHelper::toInteger($pks);
		ArrayHelper::toInteger($order);

		// Get the model
		$model = $this->getModel();

		// Save the ordering
		$return = $model->saveorder($pks, $order);

		if ($return) {
			echo "1";
		}

		// Close the application
		Factory::getApplication()->close();
	}

	public function getModelsByComponent()
	{
		// Safety check to ensure it's a JSON call
		$this->input->set('format', 'json');

		$componentId = $this->input->getInt('component_id', 0);
		$db = Factory::getDbo();

		$query = $db->getQuery(true)
			->select($db->quoteName('id', 'key'))
			->select($db->quoteName('model_name', 'value')) // Change to your actual column name
			->from($db->quoteName('#__product_catalogs'))     // Change to your actual table name
			->where($db->quoteName('component') . ' = ' . (int) $componentId)
			->where($db->quoteName('state') . ' = 1')
			->order($db->quoteName('model_name') . ' ASC');

		$db->setQuery($query);
		$results = $db->loadObjectList();

		// Output clean JSON back to JavaScript
		echo json_encode([
			'success' => true,
			'data'    => $results
		]);

		Factory::getApplication()->close();
	}

	public function getRemarksByVendor()
	{
		$app = Factory::getApplication();
		$input = $app->getInput();
		$vendorId = $input->getInt('vendor_id', 0);

		$db = Factory::getDbo();
		$query = $db->getQuery(true)
			->select(
				$db->quoteName('vd.id', 'key') . ', ' .
					'CASE WHEN ' . $db->quoteName('vr.note') . ' IS NULL OR ' . $db->quoteName('vr.note') . ' = ' . $db->quote('') .
					' THEN ' . $db->quoteName('vr.remark') .
					' ELSE CONCAT(' . $db->quoteName('vr.remark') . ', ' . $db->quote(' (') . ', ' . $db->quoteName('vr.note') . ', ' . $db->quote(')') . ')' .
					' END AS ' . $db->quoteName('value')
			)
			->from($db->quoteName('#__vendor_details', 'vd'))
			->join('INNER', $db->quoteName('#__vendor_remarks', 'vr') . ' ON ' . $db->quoteName('vr.id') . ' = ' . $db->quoteName('vd.remark'))
			->where($db->quoteName('vd.vendor') . ' = ' . $db->quote($vendorId))
			->where($db->quoteName('vd.state') . ' = ' . $db->quote(1));


		$db->setQuery($query);
		$remarks = $db->loadObjectList();

		$app->setHeader('Content-Type', 'application/json');
		echo json_encode(['success' => true, 'data' => $remarks]);
		$app->close();
	}

	/**
	 * List the images attached to an NC entry row.
	 *
	 * @return  void
	 *
	 * @since   1.4.0
	 */
	public function list()
	{
		$app = Factory::getApplication();

		$ncId = $app->input->getInt('nc_id', 0);

		/** @var \Data\Component\Data\Administrator\Model\NcentryimageModel $model */
		$model  = $this->getModel('Ncentryimage', 'Administrator');
		$images = $model->getImages($ncId);

		$this->sendJson(true, array('images' => $images));
	}

	/**
	 * Upload one or more images against an NC entry row.
	 *
	 * @return  void
	 *
	 * @since   1.4.0
	 */
	public function upload()
	{
		$app = Factory::getApplication();

		$ncId = $app->input->getInt('nc_id', 0);
		$files     = $app->input->files->get('images', array(), 'raw');

		/** @var \Data\Component\Data\Administrator\Model\NcentryimageModel $model */
		$model  = $this->getModel('Ncentryimage', 'Administrator');
		$result = $model->uploadImages($ncId, $files);

		$this->sendJson(empty($result['errors']), $result);
	}


	/**
	 * Delete a single image. Admin-only task - there is no front-end
	 * equivalent controller task for this.
	 *
	 * @return  void
	 *
	 * @since   1.4.0
	 */
	/**
	 * Delete a single image. Any backend user who can reach this admin view
	 * can delete - simply reaching this controller already requires a valid
	 * backend login, so no additional ACL gate is applied here.
	 *
	 * @return  void
	 *
	 * @since   1.4.0
	 */
	public function delete()
	{
		$app = Factory::getApplication();

		if (!Session::checkToken('post')) {
			$this->sendJson(false, array(), Text::_('JINVALID_TOKEN'), 403);

			return;
		}

		$imageId = $app->input->getInt('image_id', 0);

		/** @var \Data\Component\Data\Administrator\Model\NcentryimageModel $model */
		$model   = $this->getModel('Ncentryimage', 'Administrator');
		$deleted = $model->deleteImage($imageId);

		$this->sendJson($deleted, array(), $deleted ? '' : Text::_('COM_DATA_NCIMAGE_ERROR_DELETE_FAILED'));
	}

	/**
	 * Send a JSON response and close the request - this controller never renders HTML.
	 *
	 * @param   boolean  $success     Whether the operation succeeded.
	 * @param   array    $data        Payload to merge into the response.
	 * @param   string   $message     Optional error/status message.
	 * @param   integer  $httpStatus  HTTP status code to send.
	 *
	 * @return  void
	 *
	 * @since   1.4.0
	 */
	protected function sendJson($success, array $data = array(), $message = '', $httpStatus = 200)
	{
		$app = Factory::getApplication();

		if ($httpStatus !== 200) {
			http_response_code($httpStatus);
		}

		$app->setHeader('Content-Type', 'application/json; charset=utf-8', true);
		$app->sendHeaders();

		echo json_encode(
			array_merge(
				array('success' => (bool) $success, 'message' => $message),
				$data
			)
		);

		$app->close();
	}
}
