<?php

/**
 * @version    CVS: 1.4.0
 * @package    Com_Data
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace Data\Component\Data\Administrator\Field;

defined('_JEXEC') or die;

use Joomla\CMS\Form\FormField;
use Joomla\CMS\Language\Text;

/**
 * Renders a "Manage Photos" button for one NC subform row, reading that
 * row's own [id] field to know which #__data_entry_nc record to attach
 * uploads to. Rows that haven't been saved yet (id = 0) render disabled.
 *
 * @since  1.4.0
 */
class NcimagesField extends FormField
{
	protected $type = 'ncimages';

	protected function getInput()
	{
		// $this->form here is the per-row Form instance the subform field
		// builds for each repeated row, so 'id' resolves to this row's own id.
		$ncId = (int) $this->form->getValue('id');

		if ($ncId > 0) {
			return '<button type="button" class="btn btn-sm btn-outline-secondary nc-image-btn"'
				. ' data-nc-id="' . $ncId . '">'
				. '<i class="fas fa-camera"></i> '
				. '<span class="nc-image-count" data-nc-id="' . $ncId . '">&hellip;</span>'
				. '</button>';
		}

		return '<button type="button" class="btn btn-sm btn-outline-secondary nc-image-btn" disabled'
			. ' title="' . htmlspecialchars(Text::_('COM_DATA_NCIMAGE_SAVE_FIRST'), ENT_QUOTES) . '">'
			. '<i class="fas fa-camera"></i> <span class="nc-image-count">&ndash;</span>'
			. '</button>';
	}
}
