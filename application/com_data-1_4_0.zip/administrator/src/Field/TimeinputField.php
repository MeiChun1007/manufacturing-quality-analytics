<?php
/**
 * @version    CVS: 1.0.0
 * @package    Com_Data
 * @author     Mei Chun <qc.yolotech@gmail.com>
 * @copyright  2026 YOLO
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace Data\Component\Data\Administrator\Field;

defined('JPATH_BASE') or die;

use \Joomla\CMS\Factory;
use \Joomla\CMS\Language\Text;
use \Joomla\CMS\Form\FormField;
use \Joomla\CMS\Date\Date;
use Joomla\CMS\HTML\HTMLHelper;

/**
 * Editable date/time field that defaults to the current local time when
 * left blank - used to be a read-only "time created" stamp, now the user
 * can override it, but an empty value still falls back to "now" (handled
 * both here for display, and in the Model's save() as a safety net for
 * whatever actually gets submitted).
 *
 * @since  1.0.0
 */
class TimeinputField extends FormField
{
	/**
	 * The form field type.
	 *
	 * @var    string
	 * @since  1.0.0
	 */
	protected $type = 'timeinput';

	/**
	 * Method to get the field input markup.
	 *
	 * @return  string    The field input markup.
	 *
	 * @since   1.0.0
	 */
	protected function getInput()
	{
		$timeInput = $this->value;

		// If there's no value yet (new record) or it's invalid, default the
		// DISPLAYED value to the current local time - the user can still
		// change it from here before saving.
		if (empty($timeInput) || $timeInput === '0000-00-00 00:00:00' || !strtotime($timeInput)) {
			$now         = Factory::getDate('now', 'Asia/Kuala_Lumpur');
			$timeInput = $now->format('Y-m-d H:i:s', true);
		}

		// Render Joomla's standard calendar+time picker widget, matching the
		// look of every other date field in this component (type="calendar").
		return HTMLHelper::_(
			'calendar',
			$timeInput,
			$this->name,
			$this->id,
			'%Y-%m-%d %H:%M:%S',
			array(
				'showTime' => true,
				'class'    => 'inputbox',
			)
		);
	}
}