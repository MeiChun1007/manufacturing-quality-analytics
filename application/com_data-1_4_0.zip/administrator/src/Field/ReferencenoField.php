<?php
/**
 * @version    CVS: 1.0.0
 * @package    Com_Data
 * @author     Mei Chun <qc.yolotech@gmail.com>
 * @copyright  2026 YOLO
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace Data\Component\Data\Administrator\Field;

defined('JPATH_BASE') or die;

use \Joomla\CMS\Form\FormField;

/**
 * Read-only display field for the auto-generated Reference No.
 * Renders as plain text, matching CreatedbyField's style (no input box).
 *
 * @since  1.0.0
 */
class ReferencenoField extends FormField
{
	/**
	 * The form field type.
	 *
	 * @var    string
	 * @since  1.0.0
	 */
	protected $type = 'referenceno';

	/**
	 * Method to get the field input markup.
	 *
	 * @return  string    The field input markup.
	 *
	 * @since   1.0.0
	 */
	protected function getInput()
	{
		// Initialize variables.
		$html = array();

		$refNo = $this->value;

		// Preserve the value in the posted form data, same as CreatedbyField does for user_id.
		$html[] = '<input type="hidden" name="' . $this->name . '" value="' . htmlspecialchars((string) $refNo, ENT_QUOTES, 'UTF-8') . '" />';

		if (!$this->hidden)
		{
			$html[] = "<div>" . ($refNo !== '' && $refNo !== null ? htmlspecialchars((string) $refNo, ENT_QUOTES, 'UTF-8') : '&#8212;') . "</div>";
		}

		return implode($html);
	}
}