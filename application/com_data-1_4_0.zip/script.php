<?php
/**
 * @package    Com_Data
 * @copyright  2026 YOLO
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

\defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Installer\Installer;
use Joomla\Database\DatabaseInterface;

/**
 * Installs the plugins bundled inside the com_data package:
 *
 *  - plg_webservices_data : GET /api/index.php/v1/data/daily-summary (Data site API)
 *  - plg_task_datasync    : scheduled syncs for com_product / com_production (SOT site)
 *
 * Plugins are installed in postflight, enabled the first time they are installed,
 * and removed again when the component is uninstalled.
 */
class com_dataInstallerScript
{
	/** @var array  [group, element, folder inside the package's plugins/ directory] */
	private const PLUGINS = [
		['webservices', 'data', 'webservices_data'],
		['task', 'datasync', 'task_datasync'],
	];

	public function preflight($type, $parent)
	{
		return true;
	}

	public function install($parent)
	{
		return true;
	}

	public function update($parent)
	{
		return true;
	}

	public function postflight($type, $parent)
	{
		if (!\in_array($type, ['install', 'update', 'discover_install'], true)) {
			return true;
		}

		$app    = Factory::getApplication();
		$source = $parent->getParent()->getPath('source');

		foreach (self::PLUGINS as [$group, $element, $folder]) {
			$path = $source . '/plugins/' . $folder;

			if (!is_dir($path)) {
				$app->enqueueMessage('com_data: bundled plugin folder not found: plugins/' . $folder, 'warning');

				continue;
			}

			$existed   = $this->getPluginId($group, $element) !== 0;
			$installer = new Installer();

			if (method_exists($installer, 'setDatabase')) {
				$installer->setDatabase(Factory::getContainer()->get(DatabaseInterface::class));
			}

			if (!$installer->install($path)) {
				$app->enqueueMessage('com_data: could not install plugin ' . $group . '/' . $element . '.', 'error');

				continue;
			}

			// Switch a plugin on only the first time it is installed, so a later
			// component update never re-enables something that was turned off on purpose.
			if (!$existed && $this->shouldEnable($group, $element)) {
				$this->enablePlugin($group, $element);
			}
		}

		return true;
	}

	public function uninstall($parent)
	{
		foreach (self::PLUGINS as [$group, $element]) {
			$id = $this->getPluginId($group, $element);

			if ($id) {
				$installer = new Installer();

				if (method_exists($installer, 'setDatabase')) {
					$installer->setDatabase(Factory::getContainer()->get(DatabaseInterface::class));
				}

				$installer->uninstall('plugin', $id);
			}
		}

		return true;
	}

	/**
	 * The sync task plugin only makes sense where com_product / com_production exist (SOT site),
	 * so it is left disabled on the Data site. The web services plugin is always enabled.
	 */
	private function shouldEnable(string $group, string $element): bool
	{
		if ($group !== 'task') {
			return true;
		}

		return $this->componentExists('com_production') || $this->componentExists('com_product');
	}

	private function componentExists(string $name): bool
	{
		$db    = Factory::getContainer()->get(DatabaseInterface::class);
		$query = $db->getQuery(true)
			->select($db->quoteName('extension_id'))
			->from($db->quoteName('#__extensions'))
			->where($db->quoteName('type') . ' = ' . $db->quote('component'))
			->where($db->quoteName('element') . ' = :name')
			->bind(':name', $name);

		return (int) $db->setQuery($query)->loadResult() > 0;
	}

	private function getPluginId(string $group, string $element): int
	{
		$db    = Factory::getContainer()->get(DatabaseInterface::class);
		$query = $db->getQuery(true)
			->select($db->quoteName('extension_id'))
			->from($db->quoteName('#__extensions'))
			->where($db->quoteName('type') . ' = ' . $db->quote('plugin'))
			->where($db->quoteName('folder') . ' = :folder')
			->where($db->quoteName('element') . ' = :element')
			->bind(':folder', $group)
			->bind(':element', $element);

		return (int) $db->setQuery($query)->loadResult();
	}

	private function enablePlugin(string $group, string $element): void
	{
		$db      = Factory::getContainer()->get(DatabaseInterface::class);
		$enabled = 1;
		$query   = $db->getQuery(true)
			->update($db->quoteName('#__extensions'))
			->set($db->quoteName('enabled') . ' = :enabled')
			->where($db->quoteName('type') . ' = ' . $db->quote('plugin'))
			->where($db->quoteName('folder') . ' = :folder')
			->where($db->quoteName('element') . ' = :element')
			->bind(':enabled', $enabled)
			->bind(':folder', $group)
			->bind(':element', $element);

		$db->setQuery($query)->execute();
	}
}
