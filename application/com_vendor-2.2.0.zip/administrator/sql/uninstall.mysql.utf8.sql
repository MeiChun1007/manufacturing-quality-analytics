DROP TABLE IF EXISTS `#__vendor_details`;
DROP TABLE IF EXISTS `#__vendor_remarks`;
DROP TABLE IF EXISTS `#__vendor_access`;
