<?php

/**
 * @version    CVS: 1.0.0
 * @package    Com_Vendor
 * @author     QA YOLO <qa.yolotech@gmail.com>
 * @copyright  2026 QA YOLO
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace Vendor\Component\Vendor\Administrator\Field;

defined('JPATH_BASE') or die;

use \Joomla\CMS\Factory;
use \Joomla\CMS\Component\ComponentHelper;
use \Joomla\CMS\Form\Field\ListField;

/**
 * Lists Joomla users belonging to the user group(s) configured in the
 * "viewOwnVendor" setting of com_data. Used for both the "Main Vendor"
 * (single select) and "Vendors" (multiple select) fields.
 *
 * If no groups are configured, the field renders with no options.
 *
 * @since  1.0.0
 */
#[\AllowDynamicProperties]
class VendorusersField extends ListField
{
	/**
	 * The form field type.
	 *
	 * @var    string
	 * @since  1.0.0
	 */
	protected $type = 'vendorusers';

	protected $layout = 'joomla.form.field.list-fancy-select';

	/**
	 * Method to get the field input markup.
	 *
	 * @return  string  The field input markup.
	 *
	 * @since   1.0.0
	 */
	protected function getInput()
	{
		$data = $this->getLayoutData();

		if (!\is_array($this->value) && !empty($this->value))
		{
			// String in format 2,5,4
			if (\is_string($this->value))
			{
				$this->value = explode(',', $this->value);
			}

			// Integer is given
			if (\is_int($this->value))
			{
				$this->value = array($this->value);
			}

			$data['value'] = $this->value;
		}

		$data['options'] = $this->getOptions();

		return $this->getRenderer($this->layout)->render($data);
	}

	/**
	 * Method to get the field options: users belonging to the group(s)
	 * configured in com_data's "viewOwnVendor" parameter.
	 *
	 * @return  array  The field option objects.
	 *
	 * @since   1.0.0
	 */
	protected function getOptions()
	{
		$options = array();

		$params = ComponentHelper::getParams('com_data');
		$viewOwnVendorGroups = array_map('intval', (array) $params->get('viewOwnVendor', []));
		$viewAllVendorGroups = array_map('intval', (array) $params->get('viewAllVendor', []));

		// Vendor managers (viewAllVendor) are eligible alongside regular
		// vendor users (viewOwnVendor).
		$vendorGroups = array_values(array_unique(array_merge($viewOwnVendorGroups, $viewAllVendorGroups)));

		// No groups configured yet - render an empty list until it's set up.
		if (empty($vendorGroups))
		{
			return array_merge(parent::getOptions(), $options);
		}

		$db = Factory::getContainer()->get('DatabaseDriver');
		$query = $db->getQuery(true);

		$query->select(
				array(
					'DISTINCT ' . $db->quoteName('u.id'),
					$db->quoteName('u.name'),
				)
			)
			->from($db->quoteName('#__users', 'u'))
			->join(
				'INNER',
				$db->quoteName('#__user_usergroup_map', 'm') . ' ON ' . $db->quoteName('m.user_id') . ' = ' . $db->quoteName('u.id')
			)
			->whereIn($db->quoteName('m.group_id'), $vendorGroups)
			->order($db->quoteName('u.name') . ' ASC');

		try
		{
			$db->setQuery($query);
			$results = $db->loadObjectList();
		}
		catch (\Exception $e)
		{
			Factory::getApplication()->enqueueMessage($e->getMessage(), 'error');
			$results = array();
		}

		if (!empty($results))
		{
			foreach ($results as $item)
			{
				$options[] = (object) array(
					'value' => $item->id,
					'text'  => $item->name,
				);
			}
		}

		// Merge any additional options in the XML definition.
		$options = array_merge(parent::getOptions(), $options);

		return $options;
	}
}