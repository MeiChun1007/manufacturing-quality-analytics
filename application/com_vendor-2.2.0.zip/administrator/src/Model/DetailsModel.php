<?php
/**
 * @version    CVS: 1.0.0
 * @package    Com_Vendor
 * @author     QA YOLO <qa.yolotech@gmail.com>
 * @copyright  2026 QA YOLO
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace Vendor\Component\Vendor\Administrator\Model;
// No direct access.
defined('_JEXEC') or die;

use \Joomla\CMS\MVC\Model\ListModel;
use \Joomla\Component\Fields\Administrator\Helper\FieldsHelper;
use \Joomla\CMS\Factory;
use \Joomla\CMS\Language\Text;
use \Joomla\CMS\Helper\TagsHelper;
use \Joomla\Database\ParameterType;
use \Joomla\Utilities\ArrayHelper;
use Vendor\Component\Vendor\Administrator\Helper\VendorHelper;
use \Joomla\Database\DatabaseInterface;

/**
 * Methods supporting a list of Details records.
 *
 * @since  1.0.0
 */
class DetailsModel extends ListModel
{
	/**
	* Constructor.
	*
	* @param   array  $config  An optional associative array of configuration settings.
	*
	* @see        JController
	* @since      1.6
	*/
	public function __construct($config = array())
	{
		if (empty($config['filter_fields']))
		{
			$config['filter_fields'] = array(
				'id', 'a.id',
				'state', 'a.state',
				'ordering', 'a.ordering',
				'created_by', 'a.created_by',
				'modified_by', 'a.modified_by',
				'custom_field_1', 'a.custom_field_1',
				'custom_field_2', 'a.custom_field_2',
				'custom_field_3', 'a.custom_field_3',
				'custom_field_4', 'a.custom_field_4',
				'custom_field_5', 'a.custom_field_5',
				'remark', 'a.remark',
				'vendor', 'a.vendor',
			);
		}

		parent::__construct($config);
	}


	

	

	

	/**
	 * Method to auto-populate the model state.
	 *
	 * Note. Calling getState in this method will result in recursion.
	 *
	 * @param   string  $ordering   Elements order
	 * @param   string  $direction  Order direction
	 *
	 * @return void
	 *
	 * @throws Exception
	 */
	protected function populateState($ordering = null, $direction = null)
	{
		// List state information.
		parent::populateState('id', 'DESC');

		$context = $this->getUserStateFromRequest($this->context.'.filter.search', 'filter_search');
		$this->setState('filter.search', $context);

		// Split context into component and optional section
		if (!empty($context))
		{
			$parts = FieldsHelper::extract($context);

			if ($parts)
			{
				$this->setState('filter.component', $parts[0]);
				$this->setState('filter.section', $parts[1]);
			}
		}
	}

	/**
	 * Method to get a store id based on model configuration state.
	 *
	 * This is necessary because the model is used by the component and
	 * different modules that might need different sets of data or different
	 * ordering requirements.
	 *
	 * @param   string  $id  A prefix for the store id.
	 *
	 * @return  string A store id.
	 *
	 * @since   1.0.0
	 */
	protected function getStoreId($id = '')
	{
		// Compile the store id.
		$id .= ':' . $this->getState('filter.search');
		$id .= ':' . $this->getState('filter.state');

		
		return parent::getStoreId($id);
		
	}

	/**
	 * Build an SQL query to load the list data.
	 *
	 * @return  DatabaseQuery
	 *
	 * @since   1.0.0
	 */
	protected function getListQuery()
	{
		// Create a new query object.
		$db    = Factory::getContainer()->get(DatabaseInterface::class);
		$query = $db->getQuery(true);

		// Select the required fields from the table.
		$query->select(
			$this->getState(
				'list.select', 'DISTINCT a.*'
			)
		);
		$query->from('`#__vendor_details` AS a');
		
		// Join over the users for the checked out user
		$query->select("uc.name AS uEditor");
		$query->join("LEFT", "#__users AS uc ON uc.id=a.checked_out");
		

		// Filter by published state
		$published = $this->getState('filter.state');

		if (is_numeric($published))
		{
			$query->where('a.state = ' . (int) $published);
		}
		elseif (empty($published))
		{
			$query->where('(a.state IN (0, 1))');
		}

		// Filter by search in title
		$search = $this->getState('filter.search');

		if (!empty($search))
		{
			if (stripos($search, 'id:') === 0)
			{
				$query->where('a.id = ' . (int) substr($search, 3));
			}
			else
			{
				$search = $db->Quote('%' . $db->escape($search, true) . '%');
				$query->where('( a.remark LIKE ' . $search . '  OR  a.vendor LIKE ' . $search . ' )');
			}
		}
		
		// Add the list ordering clause.
		$orderCol  = $this->state->get('list.ordering', 'id');
		$orderDirn = $this->state->get('list.direction', 'DESC');

		if ($orderCol && $orderDirn)
		{
			$query->order($db->escape($orderCol . ' ' . $orderDirn));
		}

		return $query;
	}

	/**
	 * Get an array of data items
	 *
	 * @return mixed Array of data items on success, false on failure.
	 */
	public function getItems()
	{
		$items = parent::getItems();
		
		foreach ($items as $item) {
			
			if (!empty($item->remark)) {
				// Split out commas if multiple IDs are saved (e.g., "1,2") and clean up integers
				$remarkIds = array_filter(array_map('intval', explode(',', $item->remark)));

				if (!empty($remarkIds)) {
					$db = Factory::getContainer()->get(\Joomla\Database\DatabaseInterface::class);

					// Build a clean query to translate model IDs into human-readable model names
					$query = $db->getQuery(true)
						->select($db->quoteName('remark'))         // Fetches the text value column
						->from($db->quoteName('#__vendor_remarks'))     // Targets your models table
						->where($db->quoteName('id') . ' IN (' . implode(',', $remarkIds) . ')');

					$db->setQuery($query);

					// Fetches all matching model names in one single trip to the database
					$remarkNames = $db->loadColumn();

					if (!empty($remarkNames)) {
						// Replaces the numeric ID with the readable string (e.g., "BLMT501L, BLMT501R")
						$item->remark = implode(', ', $remarkNames);
					}
				}
			}
			if (!empty($item->vendor)) {
				// Split out commas if multiple IDs are saved (e.g., "1,2") and sanitize
				$vendorIds = array_filter(array_map('intval', explode(',', $item->vendor)));

				if (!empty($vendorIds)) {
					$db = Factory::getContainer()->get(\Joomla\Database\DatabaseInterface::class);

					// Build a query to translate vendor IDs into human-readable vendor names
					$query = $db->getQuery(true)
						->select($db->quoteName('name'))         // Replace 'vendor_name' with your actual column name
						->from($db->quoteName('#__users'))     // Replace with your actual vendors table name
						->where($db->quoteName('id') . ' IN (' . implode(',', $vendorIds) . ')');

					$db->setQuery($query);

					// Fetches matching vendor names in a single query
					$vendorNames = $db->loadColumn();

					if (!empty($vendorNames)) {
						// Replaces "1, 2" with "Vendor A, Vendor B"
						$item->vendor = implode(', ', $vendorNames);
					}
				}
			}
		}

		return $items;
	}
}
