<?php
/**
 * @version    CVS: 1.0.0
 * @package    Com_Vendor
 * @author     QA YOLO <qa.yolotech@gmail.com>
 * @copyright  2026 QA YOLO
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace Vendor\Component\Vendor\Administrator\Model;
// No direct access.
defined('_JEXEC') or die;

use \Joomla\CMS\MVC\Model\ListModel;
use \Joomla\Component\Fields\Administrator\Helper\FieldsHelper;
use \Joomla\CMS\Factory;
use \Joomla\CMS\Language\Text;
use \Joomla\CMS\Helper\TagsHelper;
use \Joomla\Database\ParameterType;
use \Joomla\Utilities\ArrayHelper;
use Vendor\Component\Vendor\Administrator\Helper\VendorHelper;
use \Joomla\Database\DatabaseInterface;

/**
 * Methods supporting a list of Access records.
 *
 * @since  1.0.0
 */
class AccessesModel extends ListModel
{
	/**
	* Constructor.
	*
	* @param   array  $config  An optional associative array of configuration settings.
	*
	* @see        JController
	* @since      1.6
	*/
	public function __construct($config = array())
	{
		if (empty($config['filter_fields']))
		{
			$config['filter_fields'] = array(
				'id', 'a.id',
				'state', 'a.state',
				'ordering', 'a.ordering',
				'created_by', 'a.created_by',
				'modified_by', 'a.modified_by',
				'main_vendor', 'a.main_vendor',
				'vendors', 'a.vendors',
			);
		}

		parent::__construct($config);
	}

	/**
	 * Method to auto-populate the model state.
	 *
	 * Note. Calling getState in this method will result in recursion.
	 *
	 * @param   string  $ordering   Elements order
	 * @param   string  $direction  Order direction
	 *
	 * @return void
	 *
	 * @throws Exception
	 */
	protected function populateState($ordering = null, $direction = null)
	{
		// List state information.
		parent::populateState('id', 'DESC');

		$context = $this->getUserStateFromRequest($this->context.'.filter.search', 'filter_search');
		$this->setState('filter.search', $context);

		// Split context into component and optional section
		if (!empty($context))
		{
			$parts = FieldsHelper::extract($context);

			if ($parts)
			{
				$this->setState('filter.component', $parts[0]);
				$this->setState('filter.section', $parts[1]);
			}
		}
	}

	/**
	 * Method to get a store id based on model configuration state.
	 *
	 * This is necessary because the model is used by the component and
	 * different modules that might need different sets of data or different
	 * ordering requirements.
	 *
	 * @param   string  $id  A prefix for the store id.
	 *
	 * @return  string A store id.
	 *
	 * @since   1.0.0
	 */
	protected function getStoreId($id = '')
	{
		// Compile the store id.
		$id .= ':' . $this->getState('filter.search');
		$id .= ':' . $this->getState('filter.state');

		
		return parent::getStoreId($id);
		
	}

	/**
	 * Build an SQL query to load the list data.
	 *
	 * @return  DatabaseQuery
	 *
	 * @since   1.0.0
	 */
	protected function getListQuery()
	{
		// Create a new query object.
		$db    = Factory::getContainer()->get(DatabaseInterface::class);
		$query = $db->getQuery(true);

		// Select the required fields from the table.
		$query->select(
			$this->getState(
				'list.select', 'DISTINCT a.*'
			)
		);
		$query->from('`#__vendor_access` AS a');
		
		// Join over the users for the checked out user
		$query->select("uc.name AS uEditor");
		$query->join("LEFT", "#__users AS uc ON uc.id=a.checked_out");

		// Join over the users table to resolve the Main Vendor's name
		$query->select($db->quoteName('mv.name', 'main_vendor_name'));
		$query->join('LEFT', $db->quoteName('#__users', 'mv') . ' ON ' . $db->quoteName('mv.id') . ' = ' . $db->quoteName('a.main_vendor'));

		// Filter by published state
		$published = $this->getState('filter.state');

		if (is_numeric($published))
		{
			$query->where('a.state = ' . (int) $published);
		}
		elseif (empty($published))
		{
			$query->where('(a.state IN (0, 1))');
		}

		// Filter by search
		$search = $this->getState('filter.search');

		if (!empty($search))
		{
			if (stripos($search, 'id:') === 0)
			{
				$query->where('a.id = ' . (int) substr($search, 3));
			}
			else
			{
				$search = $db->Quote('%' . $db->escape($search, true) . '%');
				$query->where('( mv.name LIKE ' . $search . ' )');
			}
		}
		
		// Add the list ordering clause.
		$orderCol  = $this->state->get('list.ordering', 'id');
		$orderDirn = $this->state->get('list.direction', 'DESC');

		if ($orderCol && $orderDirn)
		{
			if ($orderCol === 'main_vendor')
			{
				$query->order($db->escape('mv.name ' . $orderDirn));
			}
			else
			{
				$query->order($db->escape($orderCol . ' ' . $orderDirn));
			}
		}

		return $query;
	}

	/**
	 * Get an array of data items
	 *
	 * @return mixed Array of data items on success, false on failure.
	 */
	public function getItems()
	{
		$items = parent::getItems();

		if (empty($items))
		{
			return $items;
		}

		// Resolve the "vendors" CSV of user ids into display names in one query,
		// rather than one lookup per row.
		$allIds = array();

		foreach ($items as $item)
		{
			if (!empty($item->vendors))
			{
				foreach (explode(',', $item->vendors) as $id)
				{
					$id = (int) $id;

					if ($id > 0)
					{
						$allIds[$id] = $id;
					}
				}
			}
		}

		$namesById = array();

		if (!empty($allIds))
		{
			$db    = Factory::getContainer()->get(DatabaseInterface::class);
			$query = $db->getQuery(true)
				->select(array($db->quoteName('id'), $db->quoteName('name')))
				->from($db->quoteName('#__users'))
				->whereIn($db->quoteName('id'), array_values($allIds));

			$db->setQuery($query);

			foreach ($db->loadObjectList() as $row)
			{
				$namesById[(int) $row->id] = $row->name;
			}
		}

		foreach ($items as $item)
		{
			$names = array();

			if (!empty($item->vendors))
			{
				foreach (explode(',', $item->vendors) as $id)
				{
					$id = (int) $id;

					if ($id > 0 && isset($namesById[$id]))
					{
						$names[] = $namesById[$id];
					}
				}
			}

			$item->vendors_names = implode(', ', $names);
		}

		return $items;
	}
}
