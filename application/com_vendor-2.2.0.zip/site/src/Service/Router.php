<?php

/**
 * @version    CVS: 1.0.0
 * @package    Com_Vendor
 * @author     QA YOLO <qa.yolotech@gmail.com>
 * @copyright  2026 QA YOLO
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace Vendor\Component\Vendor\Site\Service;

// No direct access
defined('_JEXEC') or die;

use Joomla\CMS\Component\Router\RouterViewConfiguration;
use Joomla\CMS\Component\Router\RouterView;
use Joomla\CMS\Component\Router\Rules\StandardRules;
use Joomla\CMS\Component\Router\Rules\NomenuRules;
use Joomla\CMS\Component\Router\Rules\MenuRules;
use Joomla\CMS\Factory;
use Joomla\CMS\Categories\Categories;
use Joomla\CMS\Application\SiteApplication;
use Joomla\CMS\Categories\CategoryFactoryInterface;
use Joomla\CMS\Categories\CategoryInterface;
use Joomla\Database\DatabaseInterface;
use Joomla\CMS\Menu\AbstractMenu;
use Joomla\CMS\Component\ComponentHelper;

/**
 * Class VendorRouter
 *
 */
class Router extends RouterView
{
	private $noIDs;
	/**
	 * The category factory
	 *
	 * @var    CategoryFactoryInterface
	 *
	 * @since  1.0.0
	 */
	private $categoryFactory;

	/**
	 * The category cache
	 *
	 * @var    array
	 *
	 * @since  1.0.0
	 */
	private $categoryCache = [];

	public function __construct(SiteApplication $app, AbstractMenu $menu, CategoryFactoryInterface $categoryFactory, DatabaseInterface $db)
	{
		$params = ComponentHelper::getParams('com_vendor');
		$this->noIDs = (bool) $params->get('sef_ids');
		$this->categoryFactory = $categoryFactory;
		
		
			$details = new RouterViewConfiguration('details');
			$this->registerView($details);
			$ccDetail = new RouterViewConfiguration('detail');
			$ccDetail->setKey('id')->setParent($details);
			$this->registerView($ccDetail);
			$detailform = new RouterViewConfiguration('detailform');
			$detailform->setKey('id');
			$this->registerView($detailform);

			$remarks = new RouterViewConfiguration('remarks');
			$this->registerView($remarks);
			$ccRemark = new RouterViewConfiguration('remark');
			$ccRemark->setKey('id')->setParent($remarks);
			$this->registerView($ccRemark);
			$remarkform = new RouterViewConfiguration('remarkform');
			$remarkform->setKey('id');
			$this->registerView($remarkform);

		parent::__construct($app, $menu);

		$this->attachRule(new MenuRules($this));
		$this->attachRule(new StandardRules($this));
		$this->attachRule(new NomenuRules($this));
	}


	
		/**
		 * Method to get the segment(s) for an detail
		 *
		 * @param   string  $id     ID of the detail to retrieve the segments for
		 * @param   array   $query  The request that is built right now
		 *
		 * @return  array|string  The segments of this item
		 */
		public function getDetailSegment($id, $query)
		{
			return array((int) $id => $id);
		}
			/**
			 * Method to get the segment(s) for an detailform
			 *
			 * @param   string  $id     ID of the detailform to retrieve the segments for
			 * @param   array   $query  The request that is built right now
			 *
			 * @return  array|string  The segments of this item
			 */
			public function getDetailformSegment($id, $query)
			{
				return $this->getDetailSegment($id, $query);
			}

	
		/**
		 * Method to get the segment(s) for an remark
		 *
		 * @param   string  $id     ID of the remark to retrieve the segments for
		 * @param   array   $query  The request that is built right now
		 *
		 * @return  array|string  The segments of this item
		 */
		public function getRemarkSegment($id, $query)
		{
			return array((int) $id => $id);
		}
			/**
			 * Method to get the segment(s) for an remarkform
			 *
			 * @param   string  $id     ID of the remarkform to retrieve the segments for
			 * @param   array   $query  The request that is built right now
			 *
			 * @return  array|string  The segments of this item
			 */
			public function getRemarkformSegment($id, $query)
			{
				return $this->getRemarkSegment($id, $query);
			}

	
		/**
		 * Method to get the segment(s) for an detail
		 *
		 * @param   string  $segment  Segment of the detail to retrieve the ID for
		 * @param   array   $query    The request that is parsed right now
		 *
		 * @return  mixed   The id of this item or false
		 */
		public function getDetailId($segment, $query)
		{
			return (int) $segment;
		}
			/**
			 * Method to get the segment(s) for an detailform
			 *
			 * @param   string  $segment  Segment of the detailform to retrieve the ID for
			 * @param   array   $query    The request that is parsed right now
			 *
			 * @return  mixed   The id of this item or false
			 */
			public function getDetailformId($segment, $query)
			{
				return $this->getDetailId($segment, $query);
			}

	
		/**
		 * Method to get the segment(s) for an remark
		 *
		 * @param   string  $segment  Segment of the remark to retrieve the ID for
		 * @param   array   $query    The request that is parsed right now
		 *
		 * @return  mixed   The id of this item or false
		 */
		public function getRemarkId($segment, $query)
		{
			return (int) $segment;
		}
			/**
			 * Method to get the segment(s) for an remarkform
			 *
			 * @param   string  $segment  Segment of the remarkform to retrieve the ID for
			 * @param   array   $query    The request that is parsed right now
			 *
			 * @return  mixed   The id of this item or false
			 */
			public function getRemarkformId($segment, $query)
			{
				return $this->getRemarkId($segment, $query);
			}

	/**
	 * Method to get categories from cache
	 *
	 * @param   array  $options   The options for retrieving categories
	 *
	 * @return  CategoryInterface  The object containing categories
	 *
	 * @since   1.0.0
	 */
	private function getCategories(array $options = []): CategoryInterface
	{
		$key = serialize($options);

		if (!isset($this->categoryCache[$key]))
		{
			$this->categoryCache[$key] = $this->categoryFactory->createCategory($options);
		}

		return $this->categoryCache[$key];
	}
}
