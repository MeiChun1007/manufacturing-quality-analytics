<?php
/**
 * @version    CVS: 1.0.0
 * @package    Com_Vendor
 * @author     QA YOLO <qa.yolotech@gmail.com>
 * @copyright  2026 QA YOLO
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */
namespace Vendor\Component\Vendor\Api\Controller;

\defined('_JEXEC') or die;

use Joomla\CMS\MVC\Controller\ApiController;

/**
 * The XXX_UCFIRST_INTERNAL_NAME_FORCE_LIST_XXX controller
 *
 * @since  1.0.0
 */
class XXX_UCFIRST_INTERNAL_NAME_FORCE_LIST_XXXController extends ApiController 
{
	/**
	 * The content type of the item.
	 *
	 * @var    string
	 * @since  1.0.0
	 */
	protected $contentType = 'XXX_INTERNAL_NAME_FORCE_LIST_XXX';

	/**
	 * The default view for the display method.
	 *
	 * @var    string
	 * @since  1.0.0
	 */
	protected $default_view = 'XXX_INTERNAL_NAME_FORCE_LIST_XXX';
}