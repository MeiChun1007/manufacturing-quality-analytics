<?php

/**
 * @package    Com_Data
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Plugin\CMSPlugin;
use Joomla\CMS\Router\Route;

/**
 * Redirects a configurable user group straight to a configurable landing
 * view right after login. Both are set on this plugin's own Options tab
 * (System > Manage > Plugins > User - Com Data Redirect).
 *
 * @since  1.0.0
 */
class PlgUserComdataredirect extends CMSPlugin
{
	/**
	 * @param   array  $options  Login event options.
	 *
	 * @return  void
	 *
	 * @since   1.0.0
	 */
	public function onUserAfterLogin($options)
	{
		$app = Factory::getApplication();

		if (!$app->isClient('site')) {
			return;
		}

		$user = $app->getIdentity();

		if ($user->guest) {
			return;
		}

		$operatorGroupId = (int) $this->params->get('operator_group_id', 10);
		$landingView     = (string) $this->params->get('operator_landing_view', 'entries');

		if ($operatorGroupId <= 0 || $landingView === '') {
			return;
		}

		$userGroups = (array) $user->get('groups');

		if (in_array($operatorGroupId, $userGroups, true)) {
			$app->redirect(Route::_('index.php?option=com_data&view=' . $landingView, false));
		}
	}
}