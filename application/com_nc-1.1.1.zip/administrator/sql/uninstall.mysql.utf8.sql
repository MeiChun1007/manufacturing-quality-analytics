DROP TABLE IF EXISTS `#__nc_category`;
DROP TABLE IF EXISTS `#__nc_types`;
