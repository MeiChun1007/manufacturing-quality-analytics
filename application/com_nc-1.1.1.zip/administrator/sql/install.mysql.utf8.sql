CREATE TABLE IF NOT EXISTS `#__nc_category` (
`id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,

`state` TINYINT(1)  NULL  DEFAULT 1,
`ordering` INT(11)  NULL  DEFAULT 0,
`checked_out` INT(11)  UNSIGNED,
`checked_out_time` DATETIME NULL  DEFAULT NULL ,
`created_by` INT(11)  NULL  DEFAULT 0,
`modified_by` INT(11)  NULL  DEFAULT 0,
`custom_field_1` VARCHAR(255)  NULL  DEFAULT "",
`custom_field_2` VARCHAR(255)  NULL  DEFAULT "",
`custom_field_3` VARCHAR(255)  NULL  DEFAULT "",
`custom_field_4` VARCHAR(255)  NULL  DEFAULT "",
`custom_field_5` VARCHAR(255)  NULL  DEFAULT "",
`category` VARCHAR(255)  NULL  DEFAULT "",
PRIMARY KEY (`id`)
,KEY `idx_state` (`state`)
,KEY `idx_checked_out` (`checked_out`)
,KEY `idx_created_by` (`created_by`)
,KEY `idx_modified_by` (`modified_by`)
) DEFAULT COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `#__nc_types` (
`id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,

`state` TINYINT(1)  NULL  DEFAULT 1,
`ordering` INT(11)  NULL  DEFAULT 0,
`checked_out` INT(11)  UNSIGNED,
`checked_out_time` DATETIME NULL  DEFAULT NULL ,
`created_by` INT(11)  NULL  DEFAULT 0,
`modified_by` INT(11)  NULL  DEFAULT 0,
`custom_field_1` VARCHAR(255)  NULL  DEFAULT "",
`custom_field_2` VARCHAR(255)  NULL  DEFAULT "",
`custom_field_3` VARCHAR(255)  NULL  DEFAULT "",
`custom_field_4` VARCHAR(255)  NULL  DEFAULT "",
`custom_field_5` VARCHAR(255)  NULL  DEFAULT "",
`category` INT(11) UNSIGNED NULL DEFAULT 0,
`nc` VARCHAR(255)  NULL  DEFAULT "",
PRIMARY KEY (`id`)
,KEY `idx_state` (`state`)
,KEY `idx_checked_out` (`checked_out`)
,KEY `idx_created_by` (`created_by`)
,KEY `idx_modified_by` (`modified_by`)
,KEY `idx_category` (`category`)
) DEFAULT COLLATE=utf8mb4_unicode_ci;

